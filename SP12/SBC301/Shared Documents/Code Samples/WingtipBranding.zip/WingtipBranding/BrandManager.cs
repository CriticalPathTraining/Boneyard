﻿using System;
using Microsoft.SharePoint;

namespace WingtipBranding {
  public class BrandManager {

    public static string SiteCollectionUrl {
      get {
        // get server-relative url to site collection
        string CurrentSiteCollectionUrl
               = SPContext.Current.Site.ServerRelativeUrl;
        // append / at end if it's not already there
        if (!CurrentSiteCollectionUrl.EndsWith(@"/"))
          CurrentSiteCollectionUrl += @"/";
        return CurrentSiteCollectionUrl;
      }
    }

    public static string DefaultMasterPageUrl {
      get {
        return SiteCollectionUrl + "_catalogs/masterpage/default.master";
      }
    }

    public static string CustomMasterPageUrl {
      get {
        return SiteCollectionUrl + "_catalogs/masterpage/wingtipBranding.master";
      }
    }

    public static string CustomCssUrl {
      get {
        return "/_layouts/1033/STYLES/WingtipBranding/spstyles.css";
      }
    }

    public static string CustomSiteLogoUrl {
      get {
        return "/_layouts/images/WingtipBranding/SiteLogo.gif";
      }
    }

    public static void ConfigureMasterUrl(bool ApplyMasterUrl) {
      // determine MasterUrl property setting
      string MasterUrlPath = (ApplyMasterUrl ? CustomMasterPageUrl : DefaultMasterPageUrl);
      // update MasterUrl property for all sites
      foreach (SPWeb site in SPContext.Current.Site.AllWebs) {
        site.MasterUrl = MasterUrlPath;
        site.Update();
      }
    }

    public static void ConfigureCustomMasterUrl(bool ApplyCustomMasterUrl) {
      // determine MasterUrl property setting
      string CustomMasterUrlPath = (ApplyCustomMasterUrl ? CustomMasterPageUrl : DefaultMasterPageUrl);
      // update MasterUrl property for all sites
      foreach (SPWeb site in SPContext.Current.Site.AllWebs) {
        site.CustomMasterUrl = CustomMasterUrlPath;
        site.Update();
      }
    }

    public static void ConfigureAlternateCss(bool ApplyCustomCss) {
      // determine MasterUrl property setting
      string AlternateCssUrl = (ApplyCustomCss ? CustomCssUrl : string.Empty);
      // update AlternateCssUrl for all sites
      foreach (SPWeb site in SPContext.Current.Site.AllWebs) {
        site.AlternateCssUrl = AlternateCssUrl;
        // make sure no theme is enabled
        site.ApplyTheme(string.Empty);
        site.Update();
      }
    }

    public static void ConfigureSiteLogo(bool ApplySiteLogo) {
      // determine SiteLogoUrl property setting
      string SiteLogoUrl = (ApplySiteLogo ? CustomSiteLogoUrl : string.Empty);
      // update AlternateCssUrl for all sites
      foreach (SPWeb site in SPContext.Current.Site.AllWebs) {
        site.SiteLogoUrl = SiteLogoUrl;
        site.Update();
      }
    }

  }
}
