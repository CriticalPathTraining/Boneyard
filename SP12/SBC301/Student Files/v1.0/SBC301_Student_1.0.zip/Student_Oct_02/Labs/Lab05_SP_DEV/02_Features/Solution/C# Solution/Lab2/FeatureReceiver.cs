using System;
using Microsoft.SharePoint;

namespace Lab2
{
    public class FeatureReceiver : SPFeatureReceiver
    {
        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPWeb site = properties.Feature.Parent as SPWeb;
            // track original site Title using SPWeb property bag
            site.Properties["OriginalTitle"] = site.Title;
            site.Properties.Update();
            // update site title
            site.Title = "Hello World";
            site.Update();
        }

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            // reset site Title back to its original value
            SPWeb site = properties.Feature.Parent as SPWeb;
            site.Title = site.Properties["OriginalTitle"];
            site.Update();
        }
    }
}