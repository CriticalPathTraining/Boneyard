Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls

Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls

Public Class SiteInfo
    Inherits LayoutsPageBase

    ' add control fields to match controls tags on .aspx page
    Protected grdSiteProperties As SPGridView


    Protected Overrides Sub OnLoad(ByVal e As EventArgs)

        ' get current site and web
        Dim siteCollection As SPSite = Me.Site
        Dim site As SPWeb = Me.Web

        ' program against controls on .aspx page
        Dim binder As New PropertyCollectionBinder()

        ' remove the next line and begin your work here

        ' get site collection properties
        binder.AddProperty("Site Collection ID", siteCollection.ID.ToString().ToUpper())
        binder.AddProperty("Site Collection Url", siteCollection.Url)
        binder.AddProperty("Count of Sites", siteCollection.AllWebs.Count.ToString())
        binder.AddProperty("Site Collection Host Name", siteCollection.HostName)

        ' get site properties
        binder.AddProperty("Site ID", site.ID.ToString().ToUpper())
        binder.AddProperty("Site Title", site.Title)
        binder.AddProperty("Site Description", site.Description)
        binder.AddProperty("Site URL", site.Url)

        binder.AddProperty("Site Created", site.Created.ToString())
        binder.AddProperty("Current User Name", site.CurrentUser.Name)

        binder.AddProperty("Is Site Root Web?", site.IsRootWeb.ToString())
        binder.AddProperty("Site Locale", site.Locale.ToString())
        binder.AddProperty("Site Time zone", site.RegionalSettings.TimeZone.Description)

        binder.BindGrid(grdSiteProperties)
    End Sub 'OnLoad 
End Class 'SiteInfo

