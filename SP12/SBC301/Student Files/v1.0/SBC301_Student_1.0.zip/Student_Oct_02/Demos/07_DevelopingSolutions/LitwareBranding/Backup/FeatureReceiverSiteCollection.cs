using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Navigation;
using Microsoft.SharePoint.Administration;

namespace LitwareBranding {
  public class FeatureReceiverSiteCollection : SPFeatureReceiver {

    public void EnsureWebApplicationFeatureEnabled() {
      // make sure feature is activated that adds HttpHandler to web.config
      SPSecurity.RunWithElevatedPrivileges(delegate() {
        using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID)) {
          try {
            Guid FeatureId = new Guid("FF739C76-0B08-4bc2-A3A2-F61524B492D8");
            siteCollection.WebApplication.Features.Add(FeatureId);
          }
          catch { }
        }
      });
    }

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      EnsureWebApplicationFeatureEnabled();
      BrandManager.ConfigureMasterUrl(true);
      BrandManager.ConfigureCustomMasterUrl(true);
      BrandManager.ConfigureAlternateCss(true);
      BrandManager.ConfigureSiteLogo(true);
      BrandManager.ConfigureApplicationPageMaster(true);
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      BrandManager.ConfigureMasterUrl(false);
      BrandManager.ConfigureCustomMasterUrl(false);
      BrandManager.ConfigureAlternateCss(false);
      BrandManager.ConfigureSiteLogo(false);
      BrandManager.ConfigureApplicationPageMaster(false);
    }

    public override void FeatureInstalled(SPFeatureReceiverProperties properties) {
      /* no op */
    }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) {
      /* no op */
    }
  }
}
