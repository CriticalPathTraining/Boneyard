using System;
using System.Web;
using System.Web.UI;

using Microsoft.SharePoint;

namespace LitwareBranding {
  public class LitwareBrandingHttpModule : IHttpModule {

    public void Init(HttpApplication context) {
      context.PreRequestHandlerExecute
        += new EventHandler(context_PreRequestHandlerExecute);
    }

    void context_PreRequestHandlerExecute(object sender, EventArgs e) {
      Page page = HttpContext.Current.CurrentHandler as Page;
      if (page != null) {         
        // register handler for PreInit event
        page.PreInit += new EventHandler(page_PreInit);
      }
    }

    void page_PreInit(object sender, EventArgs e) {
      Page page = sender as Page;
      if ((page != null) &&
          (page.MasterPageFile != null) &&
          (page.Request.Url.AbsolutePath.Contains("_layouts")) &&
          (SPContext.Current != null)  ) {
        // inspect UseCustomApplicationPageMaster property
        SPWeb site = SPContext.Current.Site.RootWeb;
        string UseCustomApplicationPageMaster =
          site.Properties["UseCustomApplicationPageMaster"];
        if ((!string.IsNullOrEmpty(UseCustomApplicationPageMaster)) &&
           (UseCustomApplicationPageMaster.Equals("True"))) {
          // now replace application.master with customized version
          if (page.MasterPageFile.Contains("application.master")) {
            page.MasterPageFile = "/_layouts/LitwareBranding/application.master";
          }          
        }
      }
    }

    public void Dispose() { }
  }
}
