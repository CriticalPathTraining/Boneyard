using System;
using Microsoft.SharePoint;

namespace LitwareTypes {
  public class VendorListEventReceiver : SPListEventReceiver {


    public override void FieldAdding(SPListEventProperties properties) {
      properties.ErrorMessage = "You cannot change this list schema!";
      properties.Cancel = true;
    }



    public override void FieldUpdating(SPListEventProperties properties) {
      properties.ErrorMessage = "You cannot change this list schema!";
      properties.Cancel = true;
    } 

    public override void FieldDeleting(SPListEventProperties properties) {
      properties.ErrorMessage = "You cannot change this list schema!";
      properties.Cancel = true;
    }
  }
}
