﻿' Demo 2
Public Class Product
    Public ID As String
    Public Name As String
    Public Model As String
    Public UnitPrice As Double
    Public UnitsInStock As Double

    Public Sub New(ByVal productId As String, ByVal productName As String, _
                   ByVal productModel As String, ByVal price As Double, _
                   ByVal units As Double)
        ID = productId
        Name = productName
        Model = productModel
        UnitPrice = price
        UnitsInStock = units
    End Sub

    Public Overrides Function ToString() As String
        Return Name
    End Function

End Class
