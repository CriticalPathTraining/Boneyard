using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace DocumentManager {
  public class FeatureReceiver : SPFeatureReceiver {

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      SPWeb site = (SPWeb)properties.Feature.Parent;

      SPDocumentLibrary libProposals = (SPDocumentLibrary)site.Lists["Proposals"];
      string templateUrl = @"Proposals/Forms/ProposalTemplate.dotx";
      libProposals.DocumentTemplateUrl = templateUrl;
      libProposals.Update();

      SPDocumentLibrary libLeadsheets;
      libLeadsheets = (SPDocumentLibrary)site.Lists["Leadsheets"];
      libLeadsheets.DocumentTemplateUrl = @"Leadsheets/Forms/Leadsheet.xsn";
      libLeadsheets.EnableVersioning = true;
      libLeadsheets.EnableFolderCreation = false;
      libLeadsheets.ForceCheckout = true;
      libLeadsheets.Update();

      string asmName = "DocumentManager, Version=1.0.0.0, Culture=neutral, PublicKeyToken=52cb0cd67d773ef7";
      string className = "DocumentManager.ItemEventHandler";
      libLeadsheets.EventReceivers.Add(SPEventReceiverType.ItemAdded,
                                       asmName,
                                       className);

      // create new list for sales leads
      if (!ListExists(site, "Sales Leads")) {
        SPListTemplate template = site.ListTemplates["Custom List"];
        Guid listSalesLeadsID = site.Lists.Add("Sales Leads", "", template);
        SPList listSalesLeads = site.Lists[listSalesLeadsID];
        listSalesLeads.Fields["Title"].Title = "Lead Name";
        listSalesLeads.Fields["Title"].Update();

        listSalesLeads.Fields.Add("Phone", SPFieldType.Text, true);
        listSalesLeads.Fields.Add("Email", SPFieldType.Text, true);
        listSalesLeads.OnQuickLaunch = true;
        listSalesLeads.Update();

        SPView view = listSalesLeads.DefaultView;
        SPField fldPhone = listSalesLeads.Fields["Phone"];
        SPField fldEmail = listSalesLeads.Fields["Email"];
        view.ViewFields.Add(fldPhone);
        view.ViewFields.Add(fldEmail);
        view.Update();
      }

      // create new list for customer letter templates
      if (!ListExists(site, "Letter Templates")) {
        SPListTemplate template = site.ListTemplates["Custom List"];
        Guid listLetterTemplatesID = site.Lists.Add("Letter Templates", "", template);
        SPList listLetterTemplates = site.Lists[listLetterTemplatesID];

        listLetterTemplates.Fields.Add("Body", SPFieldType.Text, true);
        listLetterTemplates.OnQuickLaunch = false;
        listLetterTemplates.Update();

        SPListItem newLetterTemplate;

        newLetterTemplate = listLetterTemplates.Items.Add();
        newLetterTemplate["Title"] = "Initial Greeting";
        newLetterTemplate["Body"] = "Thanks for your recent interest in Litware products and services. We would like to know if we can answer any questions about how we can help your business grow. Please let us know if I can set up a time to call you and discuss what we can provide for you.";
        newLetterTemplate.Update();

        newLetterTemplate = listLetterTemplates.Items.Add();
        newLetterTemplate["Title"] = "Follow Up";
        newLetterTemplate["Body"] = "Thanks for your recent purchase. At Litware, our goal is 100% customer satisfaction. Please let us know how things are going. Within a few weeks, someone from our sales staff will follow up with you and make sure we are meeting all your needs.";
        newLetterTemplate.Update();

        newLetterTemplate = listLetterTemplates.Items.Add();
        newLetterTemplate["Title"] = "Overdue Payment";
        newLetterTemplate["Body"] = "It has come to our attention that you account is more than 90 days past due. Please remit payment as soon as possible or we will be forced to repossess all the Litware products we have sold you in the past. We take this matter very serious.";
        newLetterTemplate.Update();
      }

      SPDocumentLibrary libLetterTemplates = (SPDocumentLibrary)site.Lists["Customer Letters"];
      templateUrl = @"CustomerLetters/Forms/LetterTemplate.docx";
      libLetterTemplates.DocumentTemplateUrl = templateUrl;
      libLetterTemplates.Update();

    }

    private bool ListExists(SPWeb site, string ListName) {
      bool retval = false;
      foreach (SPList list in site.Lists) {
        if (list.Title.Equals(ListName)) {
          retval = true;
          break;
        }
      }
      return retval;
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) { }
    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
  }

}
