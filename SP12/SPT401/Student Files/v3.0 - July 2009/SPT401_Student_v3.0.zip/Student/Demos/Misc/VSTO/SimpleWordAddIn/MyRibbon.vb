﻿Imports Microsoft.Office.Tools.Ribbon
Imports System.Windows.Forms

Public Class MyRibbon

    Private Sub MyRibbon_Load(ByVal sender As System.Object, ByVal e As RibbonUIEventArgs) Handles MyBase.Load

    End Sub

    Private Sub MyToggleButton_Click(ByVal sender As System.Object, ByVal e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles MyToggleButton.Click
        If (MyToggleButton.Checked) Then
            MyToggleButton.Label = "Hide Products"
        Else
            MyToggleButton.Label = "Show Products"
        End If

        ' Demo 1: show message box instead of custom task pane
        'MessageBox.Show("this will show a custom task pane")

        ' Demo 2: interaction between button and custom task pane
        Globals.ThisAddIn.productsTaskPane.Visible = MyToggleButton.Checked
    End Sub

End Class
