
using System;
using System.Web.UI.WebControls.WebParts;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Navigation;

namespace Lab4 {
  public class FeatureReceiver : SPFeatureReceiver {

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {

      // get a hold off current site in context of feature activation
      SPWeb site = (SPWeb)properties.Feature.Parent;
      SPNavigationNodeCollection topNav = site.Navigation.TopNavigationBar;      
      
      // create dropdown menu for custom site pages
      SPNavigationNode DropDownMenu1 = 
                       new SPNavigationNode("Site Pages", "", false);
      topNav[0].Children.AddAsLast(DropDownMenu1);
      DropDownMenu1.Children.AddAsLast(
        new SPNavigationNode("Site Page 1", "SitePages/Page01.aspx"));

      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 2", "SitePages/Page02.aspx"));
      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 3", "SitePages/Page03.aspx"));
      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 4", "SitePages/Page04.aspx"));
      

  }


    public override void FeatureDeactivating(SPFeatureReceiverProperties properties)  {

      SPWeb site = (SPWeb)properties.Feature.Parent;
      // delete folder of site pages provisioned during activation
      SPFolder sitePagesFolder = site.GetFolder("SitePages");
      sitePagesFolder.Delete();

      SPNavigationNodeCollection topNav = site.Navigation.TopNavigationBar;

      for (int i = topNav[0].Children.Count - 1; i >= 0; i--) {
        if(topNav[0].Children[i].Title ==  "Site Pages") {
          // delete node
          topNav[0].Children[i].Delete();
        }
      }
    }

    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { /* no op */}
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { /* no op */}

  }
}
