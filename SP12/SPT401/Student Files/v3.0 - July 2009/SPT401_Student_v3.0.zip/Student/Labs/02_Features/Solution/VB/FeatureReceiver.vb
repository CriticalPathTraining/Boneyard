Imports System
Imports Microsoft.SharePoint

Public Class FeatureReceiver
    Inherits SPFeatureReceiver

    Public Overrides Sub FeatureActivated(ByVal properties As Microsoft.SharePoint.SPFeatureReceiverProperties)
        Dim site As SPWeb = properties.Feature.Parent
        ' track original site Title using SPWeb property bag
        site.Properties("OriginalTitle") = site.Title
        site.Properties.Update()
        ' update site title
        site.Title = "Hello World"
        site.Update()
    End Sub

    Public Overrides Sub FeatureDeactivating(ByVal properties As Microsoft.SharePoint.SPFeatureReceiverProperties)
        ' reset site Title back to its original value
        Dim site As SPWeb = properties.Feature.Parent
        site.Title = site.Properties("OriginalTitle")
        site.Update()
    End Sub

    Public Overrides Sub FeatureInstalled(ByVal properties As Microsoft.SharePoint.SPFeatureReceiverProperties)
    End Sub

    Public Overrides Sub FeatureUninstalling(ByVal properties As Microsoft.SharePoint.SPFeatureReceiverProperties)
    End Sub
End Class
