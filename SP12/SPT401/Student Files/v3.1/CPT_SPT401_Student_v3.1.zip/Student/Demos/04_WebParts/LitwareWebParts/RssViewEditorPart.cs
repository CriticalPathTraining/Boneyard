using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareWebParts {

  public class RssViewEditorPart : EditorPart {

    public RssViewEditorPart() {
      this.Title = "RSS View Custom Editor";
    }

    TextBox txtXmlUrl;
    RadioButtonList lstHeadlineMode;

    protected override void CreateChildControls() {
      Controls.Add(new LiteralControl("Feed Url:<br/>"));
      txtXmlUrl = new TextBox();
      txtXmlUrl.Width = new Unit("100%");
      txtXmlUrl.TextMode = TextBoxMode.MultiLine;
      txtXmlUrl.Rows = 3;
      // mark XmlUrl Textbox read-only in personalization mode
      if (WebPartManager.Personalization.Scope == PersonalizationScope.User)
        txtXmlUrl.Enabled = false;
      this.Controls.Add(txtXmlUrl);

      Controls.Add(new LiteralControl("Headline Model:<br/>"));
      lstHeadlineMode = new RadioButtonList();
      lstHeadlineMode.Items.Add(RenderMode.Full.ToString());
      lstHeadlineMode.Items.Add(RenderMode.Titles.ToString());
      this.Controls.Add(lstHeadlineMode);
    }


    public override void SyncChanges() {
      this.EnsureChildControls();
      RssViewWebPart targetPart = (RssViewWebPart)this.WebPartToEdit;
      string SelectedMode = targetPart.HeadlineMode.ToString();
      lstHeadlineMode.Items.FindByText(SelectedMode).Selected = true;
      txtXmlUrl.Text = targetPart.XmlUrl;
    }

    public override bool ApplyChanges() {
      this.EnsureChildControls();
      RssViewWebPart targetPart = (RssViewWebPart)this.WebPartToEdit;
      targetPart.XmlUrl = txtXmlUrl.Text;
      if (lstHeadlineMode.SelectedValue.Equals("Full"))
        targetPart.HeadlineMode = RenderMode.Full;
      else
        targetPart.HeadlineMode = RenderMode.Titles;
      return true;
    }
  }
}