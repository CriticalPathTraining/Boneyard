using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;

  namespace LitwareWebParts { 

    public class RssViewWebPart2 : WebPart {

      private string xmlUrl;
      [ Personalizable(PersonalizationScope.Shared),
        WebBrowsable(true),
        WebDisplayName("Feed Url"),
        WebDescription("Set your RSS feed's XML URL here!"),
        Category("Configuration")]
      public string XmlUrl {
        get { return xmlUrl; }
        set { xmlUrl = value; }
      }

      private RenderMode headlineMode = RenderMode.Full;
      [ Personalizable(PersonalizationScope.User),
        WebBrowsable(true),
        WebDisplayName("Headline Mode"),
        WebDescription("Do you want to only display headlines?"),
        Category("Configuration")]
      public RenderMode HeadlineMode {
        get { return headlineMode; }
        set { headlineMode = value; }
      }

      private Label lblDisplayUrl;
      private Label lblDisplayHeadlineMode;

      protected override void CreateChildControls() {
        // add label to display Feed ULR
        lblDisplayUrl = new Label();
        this.Controls.Add(lblDisplayUrl);
        // add line break
        Controls.Add(new LiteralControl("<br/>"));
        // add label to display Feed ULR
        lblDisplayHeadlineMode = new Label();
        this.Controls.Add(lblDisplayHeadlineMode);        
      }

      protected override void OnPreRender(System.EventArgs e) {
        lblDisplayUrl.Text = this.xmlUrl;
        lblDisplayHeadlineMode.Text = this.HeadlineMode.ToString();
      }
    
    }
  }
