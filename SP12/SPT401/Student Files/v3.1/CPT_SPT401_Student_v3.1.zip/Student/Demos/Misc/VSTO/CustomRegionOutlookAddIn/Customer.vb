﻿Public Class Customer
    Public ID As String
    Public Name As String
    Public Address As String
    Public Zip As String
    Public City As String
    Public Country As String

    Public Sub New(ByVal customerId As String, ByVal customerName As String, _
                   ByVal customerAddress As String, ByVal customerZip As String, _
                   ByVal customerCity As String, ByVal customerCountry As String)
        ID = customerId
        Name = customerName
        Address = customerAddress
        Zip = customerZip
        City = customerCity
        Country = customerCountry
    End Sub

    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class
