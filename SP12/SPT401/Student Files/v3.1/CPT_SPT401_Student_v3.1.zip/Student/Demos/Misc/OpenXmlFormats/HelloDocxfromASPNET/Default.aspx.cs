using System;
using System.IO;
using System.IO.Packaging;
using System.Xml;

partial class _Default : System.Web.UI.Page {

  protected void WriteContentToPackage(Package package ){
    // create main document part (document.xml) ...
    Uri uri = new Uri("/word/document.xml", UriKind.Relative);
    string partContentType;
    partContentType = "application/vnd.openxmlformats" +
                      "-officedocument.wordprocessingml.document.main+xml";
    PackagePart part = package.CreatePart(uri, partContentType);

    // get stream for document.xml
    StreamWriter streamPart;
    streamPart = new StreamWriter(part.GetStream(FileMode.Create,
                                                 FileAccess.Write));


    // define string variable for Open XML namespace for nsWP:
    string nsWP = "http://schemas.openxmlformats.org" +
                   "/wordprocessingml/2006/main";

    // create the start part, set up the nested structure ...
    XmlWriter writer = XmlWriter.Create(streamPart);
    writer.WriteStartDocument();
    writer.WriteStartElement("w", "document", nsWP);
    writer.WriteStartElement("body", nsWP);
    writer.WriteStartElement("p", nsWP);
    writer.WriteStartElement("r", nsWP);
    writer.WriteStartElement("t", nsWP);

    writer.WriteValue(txtBodyContent.Text);

    writer.WriteEndElement();
    writer.WriteEndElement();
    writer.WriteEndElement();
    writer.WriteEndElement();
    writer.WriteEndElement();
    writer.WriteEndDocument();

    writer.Close();


    streamPart.Close();
    package.Flush();

    // create the relationship part
    string relationshipType;
    relationshipType = "http://schemas.openxmlformats.org" +
                       "/officeDocument/2006/relationships/officeDocument";
    package.CreateRelationship(uri, TargetMode.Internal, relationshipType, "rId1");
    package.Flush();

  }


  protected void cmdGenerateDOCX_Click(object sender , EventArgs e) {
 // create in-memory stream as buffer
MemoryStream bufferStream = new MemoryStream();
// create new package in memory stream
Package package = Package.Open(bufferStream, 
                               FileMode.Create, 
                               FileAccess.ReadWrite);

// this calls same code shown in Hello World example
WriteContentToPackage(package);

// save/close package object leaving DOCX file in MemoryStream
package.Close();

Response.ClearHeaders();
Response.AddHeader("content-disposition", 
                   "attachment; filename=Hello.docx");

Response.ClearContent();
Response.ContentEncoding = System.Text.Encoding.UTF8;
Response.ContentType = "application/vnd.ms-word.document.12";
// write package to response stream
bufferStream.Position = 0;
BinaryWriter writer = new BinaryWriter(Response.OutputStream);
BinaryReader reader = new BinaryReader(bufferStream);
writer.Write(reader.ReadBytes((int)bufferStream.Length));
reader.Close();
writer.Close();
bufferStream.Close();

// flush and close the response object
Response.Flush();
Response.Close();

  }

}
