﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls.WebParts;
using System.ComponentModel;
using System.Web.UI;

namespace SilverlightWrapper
{
    public class SilverlightWrapperWebPart: System.Web.UI.WebControls.WebParts.WebPart
    {
        public SilverlightWrapperWebPart()
        {
        }

        private string source;
        private string initParams;
        private int width;
        private int height;

        [Personalizable(PersonalizationScope.Shared),
           WebBrowsable(true),
           WebDisplayName("Silverlight Source"),
           WebDescription("Relative path to the Silverlight application, f.e. /XAPS/SL.HelloWorld.xap:"),
           Category("Silverlight")]
        public string Source
        {
            get { return source; }
            set { source = value; }
        }

        [Personalizable(PersonalizationScope.Shared),
           WebBrowsable(true),
           WebDisplayName("Silverlight Parameters"),
           WebDescription("Silverlight initparams"),
           Category("Silverlight")]
        public string InitParams
        {
            get { return initParams; }
            set { initParams = value; }
        }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [WebDisplayName("Silverlight object Width")]
        [WebDescription("Width of the Silverlight object.")]
        [Category("Silverlight")]
        [DefaultValue(300)]
        public int SLWidth
        {
            get { return width; }
            set { width = value; }
        }

        [WebBrowsable(true)]
        [Personalizable(PersonalizationScope.Shared)]
        [WebDisplayName("Silverlight object Height")]
        [WebDescription("Height of the Silverligth object.")]
        [Category("Silverlight")]
        [DefaultValue(300)]
        public int SLHeight
        {
            get { return height; }
            set { height = value; }
        }

        protected override void CreateChildControls()
        {

            base.CreateChildControls();
        }


        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            ClientScriptManager cs = Page.ClientScript;// Include the required javascript file.
            if (!cs.IsClientScriptIncludeRegistered("sl_javascript"))
                cs.RegisterClientScriptInclude(this.GetType(), "sl_javascript", "/_LAYOUTS/Silverlight 3 Core/Silverlight.js");
        }

        public override void RenderControl(HtmlTextWriter writer)
        {
            base.RenderControl(writer);

            writer.WriteLine("<object id=\"SilverlightHost\"");
            writer.WriteLine(" width=\"" + width + "\"");
            writer.WriteLine(" height=\"" + height + "\"");
            writer.WriteLine(" data=\"data:application/x-silverlight-2,\"");
            writer.WriteLine(" type=\"application/x-silverlight-2\" >");
            writer.WriteLine(" <param name=\"source\" value=\"" + source + "\"/>");
            if (!string.IsNullOrEmpty(initParams))
            {
                writer.WriteLine(" <param name=\"initParams\" value=\"" + initParams + "\"/>");
            }
            writer.WriteLine(" <a href=\"http://go.microsoft.com/fwlink/?LinkID=149156\" ");
            writer.WriteLine(" style=\"text-decoration: none;\">");
            writer.WriteLine(" <img src=\"http://go.microsoft.com/fwlink/?LinkId=108181\" ");
            writer.WriteLine(" alt=\"Get Microsoft Silverlight\" ");
            writer.WriteLine(" style=\"border-style: none\"/>");
            writer.WriteLine(" </a>");
            writer.WriteLine("</object>");
        }
    }
}
