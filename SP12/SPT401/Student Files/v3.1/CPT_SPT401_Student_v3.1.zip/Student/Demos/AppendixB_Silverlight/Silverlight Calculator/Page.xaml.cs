﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Silverlight_Calculator
{
    public partial class Page : UserControl
    {
        bool signClicked = false;
        int total = 0;
        int previoustotal = 0;
        string sign = null;

        public Page()
        {
            InitializeComponent();
        }

        private void ButtonDigit_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                string caption = btn.Content as string;
                if (TotalTextBlock.Text == "0")
                    TotalTextBlock.Text = caption;
                else if (signClicked)
                    TotalTextBlock.Text = caption;
                else
                    TotalTextBlock.Text += caption;
            }
            signClicked = false;
        }

        private void ButtonSign_Click(object sender, RoutedEventArgs e)
        {
            signClicked = true;
            Button btn = sender as Button;
            if (btn != null)
            {
                int digit = 0;
                int.TryParse(TotalTextBlock.Text, out digit);
                string buttoncaption = btn.Content as string;
                if (sign == null)
                {
                    total = digit;
                }
                else
                {
                    switch (sign)
                    {
                        case "+":
                            total += digit;
                            break;
                        case "-":
                            total -= digit;
                            break;
                        case "*":
                            total *= digit;
                            break;
                        case "/":
                            total /= digit;
                            break;
                    }
                    TotalTextBlock.Text = total.ToString();
                }

                sign = buttoncaption;
                if (sign == "=")
                    total = 0;
            }
        }

        private void ButtonClear_Click(object sender, RoutedEventArgs e)
        {
            TotalTextBlock.Text = "0";
            total = 0;
            sign = null;
        }
    }
}
