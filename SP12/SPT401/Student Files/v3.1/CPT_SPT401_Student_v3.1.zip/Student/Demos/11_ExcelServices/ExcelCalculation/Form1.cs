using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ExcelCalculation.localhost;

namespace ExcelCalculation {
  public partial class Form1 : Form {
    public Form1() {
      InitializeComponent();
    }

    private void buttonCalculate_Click(object sender, EventArgs e) {
      //-- create instance of proxy and take care of authentication
      ExcelService ws = new ExcelService();
      ws.Credentials = System.Net.CredentialCache.DefaultCredentials;

      //-- open the Excel workbook
      Status[] status = null;
      string sessionID = null;
      sessionID = ws.OpenWorkbook(textBoxURL.Text, "en-US", "en-US", out status);

      //-- set the cell values
      status = ws.SetCellA1(sessionID, "Mortgage Calculator", "CustomerName", textBoxCustomerName.Text);
      status = ws.SetCellA1(sessionID, "Mortgage Calculator", "MortgageAmount", textBoxAmount.Text);
      status = ws.SetCellA1(sessionID, "Mortgage Calculator", "InterestRate", textBoxInterestRate.Text);
      status = ws.SetCellA1(sessionID, "Mortgage Calculator", "MortgageLength", textBoxLength.Text);

      //-- calculate the workbook and get result            
      status = ws.CalculateWorkbook(sessionID, CalculateType.Recalculate);
      object result = null;
      result = ws.GetCellA1(sessionID, "Mortgage Calculator", "Payment", true, out status);

      //-- display result and close workbook
      if (result != null)
        MessageBox.Show("You pay " + result.ToString());
      status = ws.CloseWorkbook(sessionID);

    }
  }
}