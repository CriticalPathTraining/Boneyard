using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;

namespace LitwareWorkflows {
  public class LitwareApprovalInitiationForm : LayoutsPageBase {


    // controls
    protected PeopleEditor pickerApprover;
    protected RadioButton radInternalApproval;
    protected RadioButton radExternalApproval;
    protected InputFormTextBox txtInstructions;


    // form-level variables
    protected SPList List;
    protected SPListItem ListItem;
    protected string ListItemName;
    protected string ListItemUrl;
    protected SPContentType CType;
    protected SPWorkflowAssociation WorkflowAssociation;
    protected SPWorkflowTemplate WorkflowTemplate;
    protected string WorkflowAssociationName;
    protected string AssociationData;
    protected string InitiationData;
    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected override void OnLoad(EventArgs e) {

      // Get Form Parameters
      string paramList = Request.Params["List"];
      string paramID = Request.Params["ID"];
      string paramCType = Request.Params["ctype"];
      string paramTemplateID = Request.Params["TemplateID"];

      List = Web.Lists[new Guid(paramList)];
      ListItem = List.GetItemById(Convert.ToInt32(paramID));

      Guid WorkflowAssociationID = new Guid(Request.Params["TemplateID"]);
      WorkflowAssociation = List.WorkflowAssociations[WorkflowAssociationID];
      if (WorkflowAssociation == null) { // its on a content type
        SPContentTypeId CTypeID = (SPContentTypeId)ListItem["ContentTypeId"];
        CType = List.ContentTypes[CTypeID];
        WorkflowAssociation = CType.WorkflowAssociations[WorkflowAssociationID];
      }

      // make sure we found the association
      if (WorkflowAssociation == null)
        throw new SPException("The requested workflow could not be found.");

      // get base template, workflow name, and form data
      WorkflowAssociationName = WorkflowAssociation.Name;
      AssociationData = (string)WorkflowAssociation.AssociationData;
      WorkflowTemplate = Web.WorkflowTemplates[WorkflowAssociation.BaseId];

      // set URL for workflow item
      if (ListItem.File == null)
        ListItemUrl = Web.Url + ListItem.ParentList.Forms[PAGETYPE.PAGE_DISPLAYFORM].ServerRelativeUrl + "?ID=" + ListItem.ID.ToString();
      else
        ListItemUrl = Web.Url + "/" + ListItem.File.Url;

      // set Item Name
      if (List.BaseType == SPBaseType.DocumentLibrary) {
        // if this is a doc lib, remove the extension of the file
        ListItemName = (string)ListItem["Name"];
        int i = ListItemName.LastIndexOf('.');
        if (i > 0)
          ListItemName = ListItemName.Substring(0, i);
      }
      else
        ListItemName = (string)ListItem["Title"];

      PageTitle = "Start New Workflow Instance";
      PageTitleInArea = "Start New Litware Approval Workflow Instance on " + ListItemName;
      PageDescription = "Click OK to start a new workflow instance from the Litware Approval workflow template on the item " +
                                ListItemName +
                                " using the workflow association named " +
                                WorkflowAssociationName;


    }

    protected void PopulateFormDataFromString(string AssociationData) {
      XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
      XmlTextReader reader = new XmlTextReader(new StringReader(AssociationData));
      LitwareApprovalWorkflowData FormData = (LitwareApprovalWorkflowData)serializer.Deserialize(reader);

      pickerApprover.CommaSeparatedAccounts = FormData.Approver;

      if (FormData.ApprovalScope.Equals("Internal")) {
        radInternalApproval.Checked = true;
      }
      else {
        radExternalApproval.Checked = true;
      }
      txtInstructions.Text = FormData.Instructions;
    }

    protected string SerializeFormDataToString() {

      LitwareApprovalWorkflowData FormData = new LitwareApprovalWorkflowData();

      PickerEntity ApproverEntity = (PickerEntity)pickerApprover.Entities[0];
      FormData.Approver = ApproverEntity.Key;

      if (radInternalApproval.Checked) {
        FormData.ApprovalScope = "Internal";
      }
      else {
        FormData.ApprovalScope = "External";
      }
      FormData.Instructions = txtInstructions.Text;
      FormData.Comments = "";

      using (MemoryStream stream = new MemoryStream()) {
        XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
        serializer.Serialize(stream, FormData);
        stream.Position = 0;
        byte[] bytes = new byte[stream.Length];
        stream.Read(bytes, 0, bytes.Length);
        return Encoding.UTF8.GetString(bytes);
      }
    }

    public void cmdCancel_OnClick(object sender, EventArgs e) {
      SPUtility.Redirect(List.DefaultViewUrl,
                         SPRedirectFlags.Default,
                         HttpContext.Current);
    }

    public void cmdSubmit_OnClick(object sender, EventArgs e) {

      try {
        InitiationData = SerializeFormDataToString();
        Web.Site.WorkflowManager.StartWorkflow(ListItem,
                                               WorkflowAssociation,
                                               InitiationData);
      }
      catch (Exception ex) {
        SPException spEx = ex as SPException;

        string errorString;

        if (spEx != null && spEx.ErrorCode == -2130575205 /* SPErrorCode.TP_E_WORKFLOW_ALREADY_RUNNING */)
          errorString = SPResource.GetString(Strings.WorkflowFailedAlreadyRunningMessage);
        else if (spEx != null && spEx.ErrorCode == -2130575339 /* SPErrorCode.TP_E_VERSIONCONFLICT */)
          errorString = SPResource.GetString(Strings.ListVersionMismatch);
        else if (spEx != null && spEx.ErrorCode == -2130575338 /* SPErrorCode.TP_E_LISTITEMDELETED */)
          errorString = spEx.Message;
        else
          errorString = SPResource.GetString(Strings.WorkflowFailedStartMessage);

        SPUtility.Redirect("Error.aspx",
                           SPRedirectFlags.RelativeToLayoutsPage,
                           HttpContext.Current,
                           "ErrorText=" + SPHttpUtility.UrlKeyValueEncode(errorString));
      }

      SPUtility.Redirect(List.DefaultViewUrl,
                        SPRedirectFlags.Default,
                        HttpContext.Current);
    }

    protected override void OnPreRender(EventArgs e) {
      PopulateFormDataFromString(WorkflowAssociation.AssociationData);
    }


  }
}
