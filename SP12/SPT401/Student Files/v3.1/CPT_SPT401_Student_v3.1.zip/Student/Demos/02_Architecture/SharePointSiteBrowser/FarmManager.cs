using System;
using System.Windows;
using System.Windows.Forms;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace SharePointSiteBrowser {

  enum NodeType {
    Farm,
    WebApplication,
    SiteCollection,
    Site
  }

  class NodeTypeImage {
    public const int Farm = 0;
    public const int WebApplication = 1;
    public const int SiteCollection = 2;
    public const int Site = 3;
  }

  struct NodeInfo {
    public NodeType Type;
    public Guid ID;
    public string URL;
    public NodeInfo(NodeType Type, Guid ID, string URL) {
      this.Type = Type;
      this.ID = ID;
      this.URL = URL;
    }
  }

  public class FarmManager {

    public static TreeNode LoadWebAppNodes() {

      SPFarm CurrentFarm = SPFarm.Local;
      
      TreeNode nodeFarm = new TreeNode("Local Farm (Config DB = " + CurrentFarm.DisplayName + " )", NodeTypeImage.Farm, NodeTypeImage.Farm);
      NodeInfo info = new NodeInfo(NodeType.Farm, Guid.Empty, "http://" + Environment.MachineName);
      nodeFarm.Tag = info;

      SPWebService CurrentWebService = CurrentFarm.Services.GetValue<SPWebService>();      
      SPWebApplicationCollection WebApps = CurrentWebService.WebApplications;

      foreach (SPWebApplication WebApp in WebApps) {

        TreeNode nodeWebApp = new TreeNode(WebApp.Name + " (" + WebApp.AlternateUrls[0].IncomingUrl + ")", NodeTypeImage.WebApplication, NodeTypeImage.WebApplication);
        NodeInfo infoWebApp = new NodeInfo(NodeType.WebApplication, WebApp.Id, WebApp.AlternateUrls[0].IncomingUrl);
        nodeWebApp.Tag = infoWebApp;
        LoadSiteCollectionNodes(WebApp, nodeWebApp);
        nodeFarm.Nodes.Add(nodeWebApp);
      }

      return nodeFarm;
    }

    protected static void LoadSiteCollectionNodes(SPWebApplication WebApp, TreeNode nodeWebApp) {

      foreach (SPSite SiteCollection in WebApp.Sites) {

        if (SiteCollection.RootWeb.DoesUserHavePermissions(SPBasePermissions.Open)) {

          TreeNode SiteCollectionNode = new TreeNode("Site Collection [" + SiteCollection.Url.ToString() + "]", NodeTypeImage.SiteCollection, NodeTypeImage.SiteCollection);
          NodeInfo SiteCollectionInfo = new NodeInfo(NodeType.SiteCollection, SiteCollection.ID, SiteCollection.Url);
          SiteCollectionNode.Tag = SiteCollectionInfo;

          SPWeb TopLevelSite = SiteCollection.RootWeb;
          TreeNode TopLevelSiteNode = new TreeNode(TopLevelSite.Title, NodeTypeImage.Site, NodeTypeImage.Site);
          NodeInfo SiteInfo = new NodeInfo(NodeType.Site, TopLevelSite.ID, TopLevelSite.Url);
          TopLevelSiteNode.Tag = SiteInfo;

          LoadChildSiteNodes(TopLevelSite, TopLevelSiteNode);
          SiteCollectionNode.Nodes.Add(TopLevelSiteNode);
          nodeWebApp.Nodes.Add(SiteCollectionNode);

        }
      }

    }

    protected static void LoadChildSiteNodes(SPWeb Site, TreeNode node) {
      try {
        foreach (SPWeb ChildSite in Site.Webs) {
          if (ChildSite.DoesUserHavePermissions(SPBasePermissions.FullMask)) {
            TreeNode ChildNode = new TreeNode(ChildSite.Title, NodeTypeImage.Site, NodeTypeImage.Site);
            NodeInfo SiteInfo = new NodeInfo(NodeType.Site, ChildSite.ID, ChildSite.Url);
            ChildNode.Tag = SiteInfo;
            LoadChildSiteNodes(ChildSite, ChildNode);
            node.Nodes.Add(ChildNode);
          }
        }
      }
      catch (Exception ex) {
        GlobalErrors.AppendError(ex, Site.Url);
      }
    }

  }
}
