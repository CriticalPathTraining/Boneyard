using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("SharePoint Site Browser")]
[assembly: AssemblyCompany("Ted Pattison Group, Inc.")]

[assembly: AssemblyVersion("1.0.1.0")]
