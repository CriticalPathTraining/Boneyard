using System;
using System.Collections.Generic;
using System.Text;

namespace SharePointSiteBrowser
{
    static class GlobalErrors
    {
        private static bool _ErrorsOccurred = false;
        private static StringBuilder _Errors = new StringBuilder();

        public static void Clear(){
            _ErrorsOccurred = false;
            _Errors = new StringBuilder();
        }

      public static void AppendError(Exception ex, string location)  {
        _Errors.AppendLine("--- " + ex.GetType().ToString() + "----------------");
        _Errors.AppendLine("Message: " + ex.Message);
        _Errors.AppendLine("Location: " + location);    
        _Errors.AppendLine("-------------------------------------------");
        _Errors.AppendLine("");
        _ErrorsOccurred = true;
        }

        public static bool ErrorsOccurred
        {
            get { return _ErrorsOccurred; }
        }

        public static string Errors
        {
            get { return _Errors.ToString(); }
        }


    }
}
