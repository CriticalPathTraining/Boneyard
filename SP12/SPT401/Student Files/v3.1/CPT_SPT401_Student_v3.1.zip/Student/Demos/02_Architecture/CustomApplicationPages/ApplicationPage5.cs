// demo using RunWithElevatedPrivileges

using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPages {

  public class ApplicationPage5 : LayoutsPageBase {

      protected Label lblSiteTile;
      protected Label lblSiteID;
      protected Label lblMasterPage;
      protected Label lblSiteUrl;
      protected Label lblSiteCollectionUrl;
      protected Label lblSiteCollectionID;
      protected Label lblCurrentUser;
      protected Label lblUserIsSiteAdmin;
      protected Label lblUserIsWebAdmin;
      protected Label lblUserCount;
      protected Label lblHostName;
      protected Label lblZone;
      protected Label lblSystemAccount;
      protected Label lblSiteCollectionOwner;
      protected Label lblVisits;
      protected Label lblRootAuditEntries;

    protected override void OnLoad(EventArgs e) {     
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      
      lblSiteTile.Text = site.Title;
      lblSiteID.Text = site.ID.ToString().ToUpper();
      lblMasterPage.Text = site.MasterUrl;
      lblSiteUrl.Text = site.Url.ToLower();

      lblSiteCollectionUrl.Text = siteCollection.Url.ToLower();
      lblSiteCollectionID.Text = siteCollection.ID.ToString().ToUpper();

      lblCurrentUser.Text = site.CurrentUser.Name;
      lblUserIsSiteAdmin.Text = site.UserIsSiteAdmin.ToString();
      lblUserIsWebAdmin.Text = site.UserIsWebAdmin.ToString();
      lblUserCount.Text = site.SiteUsers.Count.ToString();

      lblHostName.Text = siteCollection.HostName;
      lblZone.Text = siteCollection.Zone.ToString();
      lblSystemAccount.Text = siteCollection.SystemAccount.Name;

      SPSecurity.RunWithElevatedPrivileges(delegate() {

        using (SPSite ElevatedsiteCollection = new SPSite(siteCollection.ID)) {
          using (SPWeb ElevatedSite = ElevatedsiteCollection.OpenWeb(site.ID)) {
            lblSiteCollectionOwner.Text = ElevatedsiteCollection.Owner.Name;
            lblVisits.Text = ElevatedsiteCollection.Usage.Visits.ToString();
            lblRootAuditEntries.Text = ElevatedSite.RootFolder.Audit.GetEntries().Count.ToString();
          }
        }
      });
    }
  }
}
