using System;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

namespace LitwareUserControlWebParts {
  public class Hello4EditorUserControlBase : UserControl {

    protected RadioButtonList lstBackgroundColors;
    protected RadioButtonList lstFontColors;
    protected TextBox txtNumber1;
    protected TextBox txtNumber2;
    protected CheckBox chkPersistValues;

    #region "Initialize RadioList Controls"

    void InitializeRadioListControls() {
      // populate list with background colors
      lstBackgroundColors.Items.Clear();      
      foreach(string color in Enum.GetNames(typeof(Hello4.BackgroundColorEnum))) {
        ListItem item = new ListItem(color);
        item.Attributes["style"] = "width:100%;background-color:" + color;        
        lstBackgroundColors.Items.Add(item);
      }
      // populate list with font colors
      lstFontColors.Items.Clear();
      foreach (string color in Enum.GetNames(typeof(Hello4.FontColorEnum))) {
        ListItem item = new ListItem(color);
        item.Attributes["style"] = "color:" + color;
        lstFontColors.Items.Add(item);
      }     
    }

    #endregion

    protected override void CreateChildControls() {
      base.CreateChildControls();
      InitializeRadioListControls();
    }

    public void SetControlValues(Hashtable ControlValues) {
      EnsureChildControls();
      string BackgroundColor = ControlValues["BackgroundColor"].ToString();
      lstBackgroundColors.Items.FindByValue(BackgroundColor).Selected = true;
      string FontColor = ControlValues["FontColor"].ToString();
      lstFontColors.Items.FindByValue(FontColor).Selected = true;
      txtNumber1.Text = ControlValues["Number1Default"].ToString();
      txtNumber2.Text = ControlValues["Number2Default"].ToString();
      chkPersistValues.Checked = (bool)ControlValues["PersistUserEntries"];
    }

    public Hashtable GetControlValues() {
      EnsureChildControls();
      Hashtable ControlValues = new Hashtable();
      ControlValues["BackgroundColor"] = lstBackgroundColors.SelectedValue;
      ControlValues["FontColor"] = lstFontColors.SelectedValue;
      ControlValues["Number1Default"] = Convert.ToDouble(txtNumber1.Text);
      ControlValues["Number2Default"] = Convert.ToDouble(txtNumber2.Text);
      ControlValues["PersistUserEntries"] = chkPersistValues.Checked;
      return ControlValues;
    }

  }
}
