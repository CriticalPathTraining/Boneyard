using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts {
  public class Hello5Editor : EditorPart {

    protected Hello5EditorUserControlBase userControl;


    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      this.Controls.Clear();
      userControl = (Hello5EditorUserControlBase)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello5Editor.ascx");
      this.Controls.Add(userControl);
    }

    public override void SyncChanges() {
      EnsureChildControls();
      Hello5 webpart = (Hello5)this.WebPartToEdit;
      Hashtable ControlValues = new Hashtable();
      ControlValues["BackgroundColor"] = webpart.BackgroundColor.ToString();
      ControlValues["FontColor"] = webpart.FontColor.ToString();
      ControlValues["Number1Default"] = webpart.Number1Default;
      ControlValues["Number2Default"] = webpart.Number2Default;
      ControlValues["PersistUserEntries"] = webpart.PersistUserEntries;
      userControl.SetControlValues(ControlValues);
    }

    public override bool ApplyChanges() {
      EnsureChildControls();
      Hello5 webpart = (Hello5)this.WebPartToEdit;
      Hashtable ControlValues = userControl.GetControlValues();
      // convert string for BackgroundColor back to enumeration value
      webpart.BackgroundColor = (Hello5.BackgroundColorEnum)Enum.Parse(typeof(Hello5.BackgroundColorEnum), 
                                                                       ControlValues["BackgroundColor"].ToString());
      // convert string for FontColor back to enumeration value
      webpart.FontColor = (Hello5.FontColorEnum)Enum.Parse(typeof(Hello5.FontColorEnum), 
                                                           ControlValues["FontColor"].ToString());
      webpart.Number1Default = Convert.ToDouble(ControlValues["Number1Default"]);
      webpart.Number2Default = Convert.ToDouble(ControlValues["Number2Default"]);
      webpart.PersistUserEntries = Convert.ToBoolean(ControlValues["PersistUserEntries"]);
      return true;
    }


  }
}
