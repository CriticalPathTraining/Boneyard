using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts {
  public class Hello : WebPart {

    // field to hold onto UserControl instance
    protected UserControl userControl;
    
    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      try {
        this.Controls.Clear();
        userControl = (UserControl)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello.ascx");
        this.Controls.Add(userControl);
      }
      catch (Exception ex) {
        string errMessage = ex.GetType().ToString() + ": " + ex.Message;
        this.Controls.Add(new LiteralControl(errMessage));
      }
    }
 
  }
}
