﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


// LitwareTypes, Version=1.0.0.0, Culture=neutral, PublicKeyToken=74bad7277fe0d19e

[assembly: AssemblyVersion("1.0.0.0")]


