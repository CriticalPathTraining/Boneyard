

using System;
using Microsoft.Office.Excel.Server.Udf;

namespace MortgageCalculator {

  [UdfClass]
  public class Calculator {
  
    [UdfMethod]
    public double CalculateMortgage(int salesPrice, int mortgageLength, 
                                    double downPaymentPercentage, 
                                    double annualInterestPercentage) {
      // implementation
      double financed = (1 - downPaymentPercentage) * salesPrice;
      int nrOfMonths = mortgageLength * 12;
      double monthlyInterestRate = annualInterestPercentage / 12;
      return financed * 
             (monthlyInterestRate / 
             (1 - Math.Pow((1 + monthlyInterestRate), nrOfMonths * -1)));
    }
  }
}


