Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Microsoft.SharePoint
Public Class CustomControl1
    Inherits WebControl

    Protected Overrides Sub RenderContents(ByVal output As HtmlTextWriter)
        Dim site As SPWeb = SPContext.Current.Web
        output.Write(("Current Site: " + site.Title))
        output.Write("<br/>")
        output.Write(("Current Site ID: " + site.ID.ToString()))
    End Sub 'RenderContents

End Class 'CustomControl1

