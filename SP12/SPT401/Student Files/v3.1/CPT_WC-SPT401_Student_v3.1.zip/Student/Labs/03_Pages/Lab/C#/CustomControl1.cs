using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;

namespace Lab4 {
  public class CustomControl1 : WebControl  {
    protected override void RenderContents(HtmlTextWriter output)  {
      SPWeb site = SPContext.Current.Web;
      output.Write("Current Site: " + site.Title);
      output.Write("<br/>");
      output.Write("Current Site ID: " + site.ID.ToString());
    }
  }
}
