using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Navigation;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebPartPages;

namespace Lab4 {

  public class SitePageCreator : LayoutsPageBase {

    // add control fields to match controls tags on .aspx page
    protected TextBox txtPageName;
    protected TextBox txtPageTitle;
    protected TextBox txtPageContent;

    protected override void OnLoad(EventArgs e) {
      
      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
          
    }

    protected void btnCreateStandardPage_Click(object sender, EventArgs e) {

    }

    protected void btnCreateWebPartPage_Click(object sender, EventArgs e) {

    }

  }
}
