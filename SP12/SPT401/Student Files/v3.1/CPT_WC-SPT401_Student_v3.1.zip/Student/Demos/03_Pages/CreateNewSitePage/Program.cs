using System;
using System.IO;
using Microsoft.SharePoint;

namespace CreateNewSitePage {
  class Program {
    static void Main() {

      string sitePath = "http://litwareinc.com";
      SPSite siteCollection = new SPSite(sitePath);
      SPWeb site = siteCollection.RootWeb;

      // write out new page in memory stream
      MemoryStream stream = new MemoryStream();
      StreamWriter writer = new StreamWriter(stream);
      writer.WriteLine("<html><body><h1>");
      writer.WriteLine("Hello, World");
      writer.WriteLine("</h1></body></html>");
      writer.Flush();

      // add new page to site
      site.Files.Add("hello.htm", stream);

    }
  }
}
