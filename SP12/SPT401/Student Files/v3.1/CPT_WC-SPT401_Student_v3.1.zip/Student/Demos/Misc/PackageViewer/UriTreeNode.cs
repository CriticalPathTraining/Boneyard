using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace PackageViewer {
  class UriTreeNode : TreeNode {
    #region Private Fields
    public Uri m_partUri;
    #endregion

    #region Constructor
    protected UriTreeNode(Uri partUri) {
      m_partUri = partUri;
    }
    #endregion

    #region Public Properties
    public Uri PartUri {
      get { return m_partUri; }
    }
    #endregion
  }
}
