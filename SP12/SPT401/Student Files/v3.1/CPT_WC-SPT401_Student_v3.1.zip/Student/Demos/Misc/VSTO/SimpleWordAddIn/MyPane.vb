﻿Public Class MyPane
    'Demo 2
    Dim productList As List(Of Product)
    Dim selectedProduct As Product

    Private Sub ProductsPane_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        PopulateProducts()
        ProductComboBox.DataSource = productList
    End Sub

    Private Sub CustomerComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProductComboBox.SelectedIndexChanged
        selectedProduct = productList(ProductComboBox.SelectedIndex)
        NameTextBox.Text = selectedProduct.Name
        ModelTextBox.Text = selectedProduct.Model
        UnitPriceTextBox.Text = selectedProduct.UnitPrice
        StockTextBox.Text = selectedProduct.UnitsInStock
    End Sub

    Private Sub SelectButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectButton.Click
        Globals.ThisAddIn.Application.Selection.Range.Text = _
            String.Format("You ordered product {0} at a unit price of {1} ({2} items in stock). ", selectedProduct.Name, _
                          selectedProduct.UnitPrice.ToString(), selectedProduct.UnitsInStock)
    End Sub

    Private Sub PopulateProducts()
        productList = New List(Of Product)
        productList.Add(New Product("1", "Chai", "10 boxes x 20 bags", 18.0, 39))
        productList.Add(New Product("3", "Aniseed Syrup", "12 - 550 ml bottles", 10.0, 13))
        productList.Add(New Product("18", "Carnarvon Tigers", "16 kg pkg.", 62.0, 42))
        productList.Add(New Product("51", "Manjimup Dried Apples", "50 - 300 g pkgs.", 53.0, 20))
        productList.Add(New Product("67", "Laughing Lumberjack Lager", "24 - 12 oz bottles", 14.0, 52))
    End Sub



End Class
