Imports System.Data
Imports System.IO
Imports System.Text
Imports System.Xml
Imports System.Xml.Serialization

Partial Class GenerateXml
    Inherits System.Web.UI.Page


    Function GetLetterXml() As String

        '*** get user input data
        Dim CustomerID As String = cboCustomer.SelectedValue
        Dim LetterTypeTitle As String = cboLetterType.SelectedValue
        Dim EmployeeID As String = cboEmployee.SelectedValue

        '*** create customer letter object
        Dim letter As New LitwareLetter

        letter.Customer = New LitwareLetterCustomer
        For Each row As DataRowView In CustomerDataSource.Select(New DataSourceSelectArguments())
            If CustomerID = row("CustomerID") Then
                letter.Customer.Company = row("Company")
                letter.Customer.ContactFirstName = row("ContactFirstName")
                letter.Customer.ContactLastName = row("ContactLastName")
                letter.Customer.Address = row("Address")
                letter.Customer.City = row("City")
                letter.Customer.State = row("State")
                letter.Customer.Zip = row("Zipcode")
                Exit For
            End If
        Next

        letter.Date = DateTime.Today.ToString("MMMM d, yyyy")
        For Each row As DataRowView In LetterDataSource.Select(New DataSourceSelectArguments())
            If LetterTypeTitle = row("Title") Then
                letter.Body = row("Body")
                Exit For
            End If
        Next


        letter.Employee = New LitwareLetterEmployee
        For Each row As DataRowView In EmployeeDataSource.Select(New DataSourceSelectArguments())
            If EmployeeID = row("EmployeeID") Then
                letter.Employee.Name = row("Name")
                letter.Employee.Title = row("Title")
                Exit For
            End If
        Next



        Dim buffer As New MemoryStream
        Dim writer As New StreamWriter(buffer, Encoding.UTF8)
        Dim serializer As XmlSerializer = New XmlSerializer(GetType(LitwareLetter))
        serializer.Serialize(writer, letter)
        buffer.Position = 0
        Dim reader As New StreamReader(buffer)
        Dim xmlDoc As String = reader.ReadToEnd()
        writer.Dispose()
        reader.Dispose()
        buffer.Dispose()


        Return xmlDoc


    End Function

    Protected Sub cmdGenerateLetter_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerateLetter.Click

        '*** return the result
        Response.ClearContent()
        Me.Response.ContentType = "text/xml"
        Response.Output.Write(GetLetterXml)
        Response.Flush()
        Response.Close()

    End Sub
End Class
