#region Using directives

using System;
using System.IO;
using System.Security.Permissions;
using System.Text;
using System.Xml;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;

#endregion

namespace LitwareFieldTypes {

  // example of creating a custom field type
  public class CompanySizeField : SPFieldText {

    public CompanySizeField(SPFieldCollection fields, string fieldName)
      : base(fields, fieldName) { }

    public CompanySizeField(SPFieldCollection fields, string typeName, string displayName)
      : base(fields, typeName, displayName) { }

    public override Microsoft.SharePoint.WebControls.BaseFieldControl FieldRenderingControl {
      get {
        BaseFieldControl control = new CompanySizeFieldControl();
        control.FieldName = this.InternalName;
        return control;
      }
    }

    // Validate the string. If not valid, throw an SPFieldValidationException
    public override string GetValidatedString(object value) {
      if (this.Required || value.ToString().Equals(string.Empty)) {
        throw new SPFieldValidationException("Company size not assigned");
      }
      return base.GetValidatedString(value);
    }
  }

  // custom field type uses helper class to initialize and render control
  public class CompanySizeFieldControl : BaseFieldControl {
    protected DropDownList CompanySizeSelector;

    protected override string DefaultTemplateName {
      get {
        return @"CompanySizeFieldControl";
      }
    }

    public override object Value {
      get {
        this.EnsureChildControls();
        return this.CompanySizeSelector.SelectedValue;
      }
      set {
        EnsureChildControls();
        this.CompanySizeSelector.SelectedValue = (string)this.ItemFieldValue;
      }
    }

    protected override void CreateChildControls() {
      if (this.Field == null || this.ControlMode == SPControlMode.Display)
        return;
      base.CreateChildControls();

      this.CompanySizeSelector = (DropDownList)TemplateContainer.FindControl("CompanySizeSelector");

      if (this.CompanySizeSelector == null)
        throw new ConfigurationErrorsException("Corrupted CompanySizeFieldControl.ascx file.");

      if (!this.Page.IsPostBack) {
        this.CompanySizeSelector.Items.AddRange(new ListItem[]{ 
      new ListItem(string.Empty, null), 
      new ListItem("Mom and Pop Shop (1-20)", "1-20"), 
      new ListItem("Small Business (21-100)", "21-100"), 
      new ListItem("Medium-sized Business (101-1000)", "101-1000"), 
      new ListItem("Big Business (1001-20,000)", "1001-20000"),
      new ListItem("Enterprise Business (over 20,000)", "20000+")});
      }
    }
  }

}