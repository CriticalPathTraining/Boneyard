using System;
using System.Reflection;
using System.IO;

internal static class WebPartResources {
  
  internal static string GetNamedResource(object reference, string fileName) {
    Assembly thisApp = Assembly.GetExecutingAssembly();
    string resource = null;
    string resourceName = string.Format(@"{0}.{1}.{2}",
                                        thisApp.GetName().Name,
                                        reference.GetType().Namespace,
                                        fileName);
    using (Stream resStream = thisApp.GetManifestResourceStream(resourceName)) {
      using (StreamReader reader = new StreamReader(resStream)) {
        resource = reader.ReadToEnd();
      }
      resStream.Close();
    }
    return resource;
  }

  internal static Stream GetNamedResourceStream(object reference, string fileName) {
    Assembly thisApp = Assembly.GetExecutingAssembly();
    string resourceName = string.Format(@"{0}.{1}",
                                        reference.GetType().Namespace, 
                                        fileName);
    return thisApp.GetManifestResourceStream(resourceName);
  }

}