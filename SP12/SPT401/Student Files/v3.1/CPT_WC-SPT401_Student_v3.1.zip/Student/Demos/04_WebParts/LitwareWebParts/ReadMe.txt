You need to take the following steps to test the Web Parts inside this project.

1) Open install.bat and change the BINDIR variable to the path of the bin director for your target Web Application (e.g. c:\InetPub\MyWebApp)
2) Build the project which will compile the LitwareWebParts.dll and copy it into the target bin directory
3) Add the following SafeControl entry into the web.config file of the target Web Application
 
<SafeControl Assembly="LitwareWebParts, Version=1.0.0.0, Culture=neutral, PublicKeyToken=74bad7277fe0d19e" Namespace="LitwareWebParts" TypeName="*" Safe="True" />

4) Update the trust level to Full in web.config file of the target Web Application

<trust level="Full" originUrl="" />

5) Save web.config and run IISRESET
6) Go to the top-level site site located in the target Web Application navigate to the Site Collection features page. 
7) Activate the feature titled "Chapter 4: Litware Web Parts"
8) Place home page of site into edit mode and add Litware Web Parts to page for testing purposes
