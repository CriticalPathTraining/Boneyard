using System;
using System.Collections;
using System.Text;
using System.Data;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace LitwareWebParts {
  public class ContactViewer : WebPart {

    public ContactViewer() {
      this.Title = "Contact Viewer Web Part";
      this.ExportMode = WebPartExportMode.All;
    }


    private SPGridView grid;

    protected override void CreateChildControls() {
      base.CreateChildControls();
      // create and add the gridview control
      this.grid = new SPGridView();
      this.grid.AutoGenerateColumns = false;
      this.Controls.Add(this.grid);
    }

    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);
      SPWeb site = SPContext.Current.Web;
      SPSiteDataQuery query = new SPSiteDataQuery();

      query.Lists = @"<Lists ServerTemplate='105' />";
      
      query.ViewFields = @"<FieldRef Name='ID' />" + 
                          "<FieldRef Name='FirstName' />" + 
                          "<FieldRef Name='Title' />";
      
      query.Webs = @"<Webs Scope='Recursive' />";


      DataTable dtResults = site.GetSiteData(query);
      DataView dv = new DataView(dtResults);

      // set up the field bindings
      SPBoundField boundField = new SPBoundField();
      boundField.HeaderText = "Last Name";
      boundField.DataField = "Title";
      this.grid.Columns.Add(boundField);

      boundField = new SPBoundField();
      boundField.HeaderText = "First Name";
      boundField.DataField = "FirstName";
      this.grid.Columns.Add(boundField);

      this.grid.AutoGenerateColumns = false;
      this.grid.DataSource = dv;
      this.grid.DataBind();

      this.grid.AllowSorting = true;
      this.grid.HeaderStyle.Font.Bold = true;

    }

  }
}

