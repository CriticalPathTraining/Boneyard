using System;
using System.Collections;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareWebParts {
 
  // A very simple webpart 
  public class HelloWebPart : WebPart {
    protected override void RenderContents(HtmlTextWriter writer) {
      writer.Write("Hello {0}", Context.User.Identity.Name);
    }
  }  
}