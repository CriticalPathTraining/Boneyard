using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


namespace SmallTimeParts {
  public class JimBob : WebPart {

    protected override void RenderContents(HtmlTextWriter writer) {
      writer.Write(@"<span style='color:#800000;background-color:#99CCFF;width:100%;height:100%;font-size:18px;padding:4' >");
      writer.Write("Hey, y'all!");
      writer.Write("</span>");
    }
  }
}
