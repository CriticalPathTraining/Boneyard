using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;

namespace LitwareWebParts {
  public class RssViewWebPart3 : WebPart {

    private string xmlUrl;
    [Personalizable(PersonalizationScope.Shared),
     WebBrowsable(false)]
    public string XmlUrl {
      get { return xmlUrl; }
      set { xmlUrl = value; }
    }

    private RenderMode headlineMode = RenderMode.Full;
    [Personalizable(PersonalizationScope.User),
     WebBrowsable(false)]
    public RenderMode HeadlineMode {
      get { return headlineMode; }
      set { headlineMode = value; }
    }

    private Label lblDisplayUrl;
    private Label lblDisplayHeadlineMode;

    protected override void CreateChildControls() {
      // add label to display Feed ULR
      lblDisplayUrl = new Label();
      this.Controls.Add(lblDisplayUrl);
      // add line break
      Controls.Add(new LiteralControl("<br/>"));
      // add label to display Feed ULR
      lblDisplayHeadlineMode = new Label();
      this.Controls.Add(lblDisplayHeadlineMode);
    }

    protected override void OnPreRender(System.EventArgs e) {
      lblDisplayUrl.Text = this.xmlUrl;
      lblDisplayHeadlineMode.Text = this.HeadlineMode.ToString();
    }


    public override EditorPartCollection CreateEditorParts() {
      List<EditorPart> editorParts = new List<EditorPart>(1);
      EditorPart part = new RssViewEditorPart3();
      part.ID = this.ID + "_rssViewEditor";
      editorParts.Add(part);
      EditorPartCollection baseParts = base.CreateEditorParts();
      return new EditorPartCollection(baseParts, editorParts);
    }

  }

  public class RssViewEditorPart3 : EditorPart {

    public RssViewEditorPart3() {
      this.Title = "RSS View Custom Editor";
    }

    TextBox txtXmlUrl;
    RadioButtonList lstHeadlineMode;

    protected override void CreateChildControls() {
      Controls.Add(new LiteralControl("Feed Url:<br/>"));
      txtXmlUrl = new TextBox();
      txtXmlUrl.Width = new Unit("100%");
      txtXmlUrl.TextMode = TextBoxMode.MultiLine;
      txtXmlUrl.Rows = 3;
      // mark XmlUrl Textbox read-only in personalization mode
      if (WebPartManager.Personalization.Scope == PersonalizationScope.User)
        txtXmlUrl.Enabled = false;
      this.Controls.Add(txtXmlUrl);

      Controls.Add(new LiteralControl("Headline Model:<br/>"));
      lstHeadlineMode = new RadioButtonList();
      lstHeadlineMode.Items.Add(RenderMode.Full.ToString());
      lstHeadlineMode.Items.Add(RenderMode.Titles.ToString());
      this.Controls.Add(lstHeadlineMode);
    }


    public override void SyncChanges() {
      this.EnsureChildControls();
      RssViewWebPart3 targetPart;
      targetPart = (RssViewWebPart3)this.WebPartToEdit;
      string SelectedMode = targetPart.HeadlineMode.ToString();
      lstHeadlineMode.Items.FindByText(SelectedMode).Selected = true;
      txtXmlUrl.Text = targetPart.XmlUrl;
    }

    public override bool ApplyChanges() {
      this.EnsureChildControls();
      RssViewWebPart3 targetPart = (RssViewWebPart3)this.WebPartToEdit;
      targetPart.XmlUrl = txtXmlUrl.Text;
      if (lstHeadlineMode.SelectedValue.Equals("Full"))
        targetPart.HeadlineMode = RenderMode.Full;
      else
        targetPart.HeadlineMode = RenderMode.Titles;
      return true;
    }

  }

}
