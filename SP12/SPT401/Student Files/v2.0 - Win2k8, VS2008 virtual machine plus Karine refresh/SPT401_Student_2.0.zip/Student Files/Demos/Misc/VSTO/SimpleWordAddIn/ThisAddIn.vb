﻿Public Class ThisAddIn

    ' Demo 2: Definition of the custom task pane
    Friend productsTaskPane As Microsoft.Office.Tools.CustomTaskPane

    Private Sub ThisAddIn_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
        ' Demo 2: Collection of customer task panes is populated
        productsTaskPane = Me.CustomTaskPanes.Add(New MyPane(), "Products Info")
    End Sub

    Private Sub ThisAddIn_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub


End Class
