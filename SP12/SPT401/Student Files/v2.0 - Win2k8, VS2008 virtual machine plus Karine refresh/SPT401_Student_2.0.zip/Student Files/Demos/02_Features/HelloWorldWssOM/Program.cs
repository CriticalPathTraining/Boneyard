using System;
using Microsoft.SharePoint;

namespace Hello_WSS_OM
{
  class Program
  {
    static void Main()
    {
      string sitePath = "http://litwareinc.com/sites/operations";
      // enter object model through site collection.
      SPSite siteCollection = new SPSite(sitePath);
      // obtain reference to top-level site.
      SPWeb site = siteCollection.RootWeb;
      // enumerate through lists of site
      foreach (SPList list in site.Lists)
      {
        if (!list.Hidden)
        {
          Console.WriteLine(list.Title);
        }
      }
      // clean up by calling Dispose.
      site.Dispose();
      siteCollection.Dispose();
    }
  }
}
