using System;
using Microsoft.SharePoint;

namespace WssOmExploration {
  class FeatureReceiver : SPFeatureReceiver {

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      // fires upon feature activation
      SPWeb site = (SPWeb)properties.Feature.Parent;
      site.Properties["OriginalTitle"] = site.Title;
      site.Properties.Update();
      site.Title = "WSS OM Exploration Site";
      site.Update();
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      // fires upon feature deactivation
      SPWeb site = (SPWeb)properties.Feature.Parent;
      site.Title = site.Properties["OriginalTitle"];
      site.Update();
    }

    public override void FeatureInstalled(SPFeatureReceiverProperties properties){}

    public override void FeatureUninstalling(SPFeatureReceiverProperties properties){}

  }
}
