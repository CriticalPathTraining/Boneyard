// populate tree view with site folders and files

using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPages {

  public class ApplicationPage6 : LayoutsPageBase {

    // define fields with names to match controls on .ASPX page
    protected SPTreeView treeSitesFiles;

    const string SITE_IMG = @"\_layouts\images\FPWEB16.GIF";
    const string FOLDER_IMG = @"\_layouts\images\FOLDER16.GIF";
    const string GHOSTED_FILE_IMG = @"\_layouts\images\NEWDOC.GIF";
    const string UNGHOSTED_FILE_IMG = @"\_layouts\images\RAT16.GIF";

    protected override void OnLoad(EventArgs e) {
      SPWeb site = SPContext.Current.Web;
      SPFolder rootFolder = site.RootFolder;
      TreeNode rootNode = new TreeNode(site.Url, site.Url, SITE_IMG);
      LoadFolderNodes(rootFolder, rootNode);
      treeSitesFiles.Nodes.Add(rootNode);
      treeSitesFiles.ExpandDepth = 1;
    }

    protected void LoadFolderNodes(SPFolder folder, TreeNode folderNode) {

      foreach (SPFolder childFolder in folder.SubFolders) {
        TreeNode childFolderNode = new TreeNode(childFolder.Name, childFolder.Name, FOLDER_IMG);
        childFolderNode.NavigateUrl = Site.MakeFullUrl(childFolder.Url);
        LoadFolderNodes(childFolder, childFolderNode);        
        folderNode.ChildNodes.Add(childFolderNode);
      }

      foreach (SPFile file in folder.Files) {
        TreeNode fileNode;
        if (file.CustomizedPageStatus == SPCustomizedPageStatus.Uncustomized) {
          fileNode = new TreeNode(file.Name, file.Name, GHOSTED_FILE_IMG);          
        }
        else {
          fileNode = new TreeNode(file.Name, file.Name, UNGHOSTED_FILE_IMG);
        }
        fileNode.NavigateUrl = Site.MakeFullUrl(file.Url);
        folderNode.ChildNodes.Add(fileNode);
      }


    }

 
  }
}
