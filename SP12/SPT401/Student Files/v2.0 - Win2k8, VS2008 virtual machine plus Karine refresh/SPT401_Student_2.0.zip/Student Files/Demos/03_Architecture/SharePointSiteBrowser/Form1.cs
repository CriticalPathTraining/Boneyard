// Demoware by Ted Pattison Group, Inc
// http://www.TedPattison.net


using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Net;
using System.Windows.Forms;
using System.Data;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;


namespace SharePointSiteBrowser {
  public class Form1 : System.Windows.Forms.Form {

    #region Control Fields

    private System.Windows.Forms.ImageList imgList;
    private System.Windows.Forms.TextBox txtLocalMachineName;
    private System.Windows.Forms.TabPage tabWebApplicationInfo;
    private System.Windows.Forms.TextBox txtWebApplicationID;
    private System.Windows.Forms.TextBox txtWebApplicationUrl;
    private System.Windows.Forms.TabPage tabSiteCollectionInfo;
    private System.Windows.Forms.TabPage tabSiteInfo;
    private System.Windows.Forms.TabControl tabProperties;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.TreeView treeSites;
    private System.Windows.Forms.Button btnShowAllSites;
    private System.Windows.Forms.Button btnShowTopLevelSites;
    private System.Windows.Forms.Button btnShowWebApplications;
    private System.Windows.Forms.ListBox lstMachineIPAddresses;
    private System.Windows.Forms.Label lblWebApplicationUrl;
    private System.Windows.Forms.Label lblWebApplicationID;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label lblLocalMachineName;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.TextBox txtConfigDBServer;
    private System.Windows.Forms.Label lblConfigDBServer;
    private System.Windows.Forms.Label lblConfigDBName;
    private System.Windows.Forms.TextBox txtConfigDBName;
    private System.Windows.Forms.ListBox lstContentDatabases;
    private System.Windows.Forms.Label lblContentDatabases;
    private System.Windows.Forms.Button btnReloadSites;
    private System.Windows.Forms.TabPage tabFarmInfo;
    private System.Windows.Forms.TextBox txtWebServerName;
    private System.Windows.Forms.Label lblWebServerName;
    private System.Windows.Forms.Label lblWebServerID;
    private System.Windows.Forms.TextBox txtWebServerID;
    private System.Windows.Forms.TextBox txtIISAppPool;
    private System.Windows.Forms.Label lblIISWebSite;
    private System.Windows.Forms.TextBox txtIISWebSite;
    private System.Windows.Forms.Label lblWebApplicationPort;
    private System.Windows.Forms.TextBox txtWebApplicationPort;
    private System.Windows.Forms.TextBox txtSiteCollectionOwnerEmail;
    private System.Windows.Forms.Label lblSiteCollectionOwnerEmail;
    private System.Windows.Forms.Label lblSiteCollectionOwner;
    private System.Windows.Forms.TextBox txtSiteCollectionOwner;
    private System.Windows.Forms.Label lblSiteCollectionID;
    private System.Windows.Forms.Label lblSiteCollectionUrl;
    private System.Windows.Forms.TextBox txtSiteCollectionID;
    private System.Windows.Forms.TextBox txtSiteCollectionUrl;
    private System.Windows.Forms.TextBox txtSiteCollectionLastModified;
    private System.Windows.Forms.Label lblSiteCollectionLastModified;
    private System.Windows.Forms.Label lblSiteID;
    private System.Windows.Forms.Label lblSiteUrl;
    private System.Windows.Forms.TextBox txtSiteID;
    private System.Windows.Forms.TextBox txtSiteUrl;
    private System.Windows.Forms.Label lblSiteTitle;
    private System.Windows.Forms.TextBox txtSiteTitle;
    private System.Windows.Forms.ListBox lstSiteLists;
    private System.Windows.Forms.ListBox lstSiteMembers;
    private System.Windows.Forms.Label lblSiteLists;
    private System.Windows.Forms.Label lblSiteMembers;
    private System.Windows.Forms.TextBox txtParentSIteID;
    private System.Windows.Forms.Label lblParentSiteID;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox txtSiteTemplateName;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtSiteTemplateTitle;
    private System.ComponentModel.IContainer components;
    #endregion

    #region Windows Form Designer generated code
    public Form1() {
      // WinForm Stuff
      InitializeComponent();
    }

    protected override void Dispose(bool disposing) {
      if (disposing) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose(disposing);
    }

    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.imgList = new System.Windows.Forms.ImageList(this.components);
      this.tabFarmInfo = new System.Windows.Forms.TabPage();
      this.txtWebServerID = new System.Windows.Forms.TextBox();
      this.txtWebServerName = new System.Windows.Forms.TextBox();
      this.lblWebServerID = new System.Windows.Forms.Label();
      this.lblWebServerName = new System.Windows.Forms.Label();
      this.lblConfigDBName = new System.Windows.Forms.Label();
      this.lblConfigDBServer = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.lblLocalMachineName = new System.Windows.Forms.Label();
      this.txtConfigDBServer = new System.Windows.Forms.TextBox();
      this.lstMachineIPAddresses = new System.Windows.Forms.ListBox();
      this.txtConfigDBName = new System.Windows.Forms.TextBox();
      this.txtLocalMachineName = new System.Windows.Forms.TextBox();
      this.tabWebApplicationInfo = new System.Windows.Forms.TabPage();
      this.lstContentDatabases = new System.Windows.Forms.ListBox();
      this.txtIISAppPool = new System.Windows.Forms.TextBox();
      this.txtIISWebSite = new System.Windows.Forms.TextBox();
      this.lblContentDatabases = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.lblIISWebSite = new System.Windows.Forms.Label();
      this.lblWebApplicationPort = new System.Windows.Forms.Label();
      this.txtWebApplicationPort = new System.Windows.Forms.TextBox();
      this.lblWebApplicationID = new System.Windows.Forms.Label();
      this.lblWebApplicationUrl = new System.Windows.Forms.Label();
      this.txtWebApplicationID = new System.Windows.Forms.TextBox();
      this.txtWebApplicationUrl = new System.Windows.Forms.TextBox();
      this.tabSiteCollectionInfo = new System.Windows.Forms.TabPage();
      this.txtSiteCollectionLastModified = new System.Windows.Forms.TextBox();
      this.txtSiteCollectionOwnerEmail = new System.Windows.Forms.TextBox();
      this.lblSiteCollectionLastModified = new System.Windows.Forms.Label();
      this.lblSiteCollectionOwnerEmail = new System.Windows.Forms.Label();
      this.lblSiteCollectionOwner = new System.Windows.Forms.Label();
      this.txtSiteCollectionOwner = new System.Windows.Forms.TextBox();
      this.lblSiteCollectionID = new System.Windows.Forms.Label();
      this.lblSiteCollectionUrl = new System.Windows.Forms.Label();
      this.txtSiteCollectionID = new System.Windows.Forms.TextBox();
      this.txtSiteCollectionUrl = new System.Windows.Forms.TextBox();
      this.tabSiteInfo = new System.Windows.Forms.TabPage();
      this.txtSiteTemplateTitle = new System.Windows.Forms.TextBox();
      this.txtSiteTemplateName = new System.Windows.Forms.TextBox();
      this.lstSiteMembers = new System.Windows.Forms.ListBox();
      this.lstSiteLists = new System.Windows.Forms.ListBox();
      this.txtParentSIteID = new System.Windows.Forms.TextBox();
      this.txtSiteTitle = new System.Windows.Forms.TextBox();
      this.txtSiteID = new System.Windows.Forms.TextBox();
      this.txtSiteUrl = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.lblSiteMembers = new System.Windows.Forms.Label();
      this.lblSiteLists = new System.Windows.Forms.Label();
      this.lblParentSiteID = new System.Windows.Forms.Label();
      this.lblSiteTitle = new System.Windows.Forms.Label();
      this.lblSiteID = new System.Windows.Forms.Label();
      this.lblSiteUrl = new System.Windows.Forms.Label();
      this.tabProperties = new System.Windows.Forms.TabControl();
      this.panel2 = new System.Windows.Forms.Panel();
      this.panel3 = new System.Windows.Forms.Panel();
      this.treeSites = new System.Windows.Forms.TreeView();
      this.panel1 = new System.Windows.Forms.Panel();
      this.btnReloadSites = new System.Windows.Forms.Button();
      this.btnShowAllSites = new System.Windows.Forms.Button();
      this.btnShowTopLevelSites = new System.Windows.Forms.Button();
      this.btnShowWebApplications = new System.Windows.Forms.Button();
      this.tabFarmInfo.SuspendLayout();
      this.tabWebApplicationInfo.SuspendLayout();
      this.tabSiteCollectionInfo.SuspendLayout();
      this.tabSiteInfo.SuspendLayout();
      this.tabProperties.SuspendLayout();
      this.panel2.SuspendLayout();
      this.panel3.SuspendLayout();
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // imgList
      // 
      this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
      this.imgList.TransparentColor = System.Drawing.Color.Transparent;
      this.imgList.Images.SetKeyName(0, "");
      this.imgList.Images.SetKeyName(1, "");
      this.imgList.Images.SetKeyName(2, "");
      this.imgList.Images.SetKeyName(3, "");
      // 
      // tabFarmInfo
      // 
      this.tabFarmInfo.Controls.Add(this.txtWebServerID);
      this.tabFarmInfo.Controls.Add(this.txtWebServerName);
      this.tabFarmInfo.Controls.Add(this.lblWebServerID);
      this.tabFarmInfo.Controls.Add(this.lblWebServerName);
      this.tabFarmInfo.Controls.Add(this.lblConfigDBName);
      this.tabFarmInfo.Controls.Add(this.lblConfigDBServer);
      this.tabFarmInfo.Controls.Add(this.label8);
      this.tabFarmInfo.Controls.Add(this.lblLocalMachineName);
      this.tabFarmInfo.Controls.Add(this.txtConfigDBServer);
      this.tabFarmInfo.Controls.Add(this.lstMachineIPAddresses);
      this.tabFarmInfo.Controls.Add(this.txtConfigDBName);
      this.tabFarmInfo.Controls.Add(this.txtLocalMachineName);
      this.tabFarmInfo.ImageIndex = 0;
      this.tabFarmInfo.Location = new System.Drawing.Point(4, 23);
      this.tabFarmInfo.Name = "tabFarmInfo";
      this.tabFarmInfo.Size = new System.Drawing.Size(376, 370);
      this.tabFarmInfo.TabIndex = 0;
      this.tabFarmInfo.Text = "Local Farm";
      this.tabFarmInfo.UseVisualStyleBackColor = true;
      // 
      // txtWebServerID
      // 
      this.txtWebServerID.Location = new System.Drawing.Point(112, 208);
      this.txtWebServerID.Name = "txtWebServerID";
      this.txtWebServerID.Size = new System.Drawing.Size(232, 20);
      this.txtWebServerID.TabIndex = 11;
      // 
      // txtWebServerName
      // 
      this.txtWebServerName.Location = new System.Drawing.Point(112, 176);
      this.txtWebServerName.Name = "txtWebServerName";
      this.txtWebServerName.Size = new System.Drawing.Size(232, 20);
      this.txtWebServerName.TabIndex = 9;
      // 
      // lblWebServerID
      // 
      this.lblWebServerID.Location = new System.Drawing.Point(8, 208);
      this.lblWebServerID.Name = "lblWebServerID";
      this.lblWebServerID.Size = new System.Drawing.Size(104, 23);
      this.lblWebServerID.TabIndex = 12;
      this.lblWebServerID.Text = "Web Server ID:";
      // 
      // lblWebServerName
      // 
      this.lblWebServerName.Location = new System.Drawing.Point(8, 176);
      this.lblWebServerName.Name = "lblWebServerName";
      this.lblWebServerName.Size = new System.Drawing.Size(104, 23);
      this.lblWebServerName.TabIndex = 10;
      this.lblWebServerName.Text = "Web Server Name:";
      // 
      // lblConfigDBName
      // 
      this.lblConfigDBName.Location = new System.Drawing.Point(8, 144);
      this.lblConfigDBName.Name = "lblConfigDBName";
      this.lblConfigDBName.Size = new System.Drawing.Size(96, 16);
      this.lblConfigDBName.TabIndex = 8;
      this.lblConfigDBName.Text = "Config DB Name:";
      // 
      // lblConfigDBServer
      // 
      this.lblConfigDBServer.Location = new System.Drawing.Point(8, 112);
      this.lblConfigDBServer.Name = "lblConfigDBServer";
      this.lblConfigDBServer.Size = new System.Drawing.Size(96, 16);
      this.lblConfigDBServer.TabIndex = 6;
      this.lblConfigDBServer.Text = "Config DB Server:";
      // 
      // label8
      // 
      this.label8.Location = new System.Drawing.Point(8, 48);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(80, 16);
      this.label8.TabIndex = 5;
      this.label8.Text = "IP Addresses:";
      // 
      // lblLocalMachineName
      // 
      this.lblLocalMachineName.Location = new System.Drawing.Point(8, 16);
      this.lblLocalMachineName.Name = "lblLocalMachineName";
      this.lblLocalMachineName.Size = new System.Drawing.Size(64, 16);
      this.lblLocalMachineName.TabIndex = 4;
      this.lblLocalMachineName.Text = "Host Name:";
      // 
      // txtConfigDBServer
      // 
      this.txtConfigDBServer.Location = new System.Drawing.Point(112, 112);
      this.txtConfigDBServer.Name = "txtConfigDBServer";
      this.txtConfigDBServer.Size = new System.Drawing.Size(232, 20);
      this.txtConfigDBServer.TabIndex = 3;
      // 
      // lstMachineIPAddresses
      // 
      this.lstMachineIPAddresses.Location = new System.Drawing.Point(112, 48);
      this.lstMachineIPAddresses.Name = "lstMachineIPAddresses";
      this.lstMachineIPAddresses.Size = new System.Drawing.Size(232, 56);
      this.lstMachineIPAddresses.TabIndex = 2;
      // 
      // txtConfigDBName
      // 
      this.txtConfigDBName.Location = new System.Drawing.Point(112, 144);
      this.txtConfigDBName.Name = "txtConfigDBName";
      this.txtConfigDBName.Size = new System.Drawing.Size(232, 20);
      this.txtConfigDBName.TabIndex = 1;
      // 
      // txtLocalMachineName
      // 
      this.txtLocalMachineName.Location = new System.Drawing.Point(112, 16);
      this.txtLocalMachineName.Name = "txtLocalMachineName";
      this.txtLocalMachineName.Size = new System.Drawing.Size(232, 20);
      this.txtLocalMachineName.TabIndex = 0;
      // 
      // tabWebApplicationInfo
      // 
      this.tabWebApplicationInfo.Controls.Add(this.lstContentDatabases);
      this.tabWebApplicationInfo.Controls.Add(this.txtIISAppPool);
      this.tabWebApplicationInfo.Controls.Add(this.txtIISWebSite);
      this.tabWebApplicationInfo.Controls.Add(this.lblContentDatabases);
      this.tabWebApplicationInfo.Controls.Add(this.label6);
      this.tabWebApplicationInfo.Controls.Add(this.lblIISWebSite);
      this.tabWebApplicationInfo.Controls.Add(this.lblWebApplicationPort);
      this.tabWebApplicationInfo.Controls.Add(this.txtWebApplicationPort);
      this.tabWebApplicationInfo.Controls.Add(this.lblWebApplicationID);
      this.tabWebApplicationInfo.Controls.Add(this.lblWebApplicationUrl);
      this.tabWebApplicationInfo.Controls.Add(this.txtWebApplicationID);
      this.tabWebApplicationInfo.Controls.Add(this.txtWebApplicationUrl);
      this.tabWebApplicationInfo.ImageIndex = 1;
      this.tabWebApplicationInfo.Location = new System.Drawing.Point(4, 23);
      this.tabWebApplicationInfo.Name = "tabWebApplicationInfo";
      this.tabWebApplicationInfo.Size = new System.Drawing.Size(376, 370);
      this.tabWebApplicationInfo.TabIndex = 1;
      this.tabWebApplicationInfo.Text = "Web Application";
      this.tabWebApplicationInfo.UseVisualStyleBackColor = true;
      // 
      // lstContentDatabases
      // 
      this.lstContentDatabases.Location = new System.Drawing.Point(8, 192);
      this.lstContentDatabases.Name = "lstContentDatabases";
      this.lstContentDatabases.Size = new System.Drawing.Size(336, 95);
      this.lstContentDatabases.TabIndex = 10;
      // 
      // txtIISAppPool
      // 
      this.txtIISAppPool.Location = new System.Drawing.Point(80, 144);
      this.txtIISAppPool.Name = "txtIISAppPool";
      this.txtIISAppPool.Size = new System.Drawing.Size(264, 20);
      this.txtIISAppPool.TabIndex = 8;
      // 
      // txtIISWebSite
      // 
      this.txtIISWebSite.Location = new System.Drawing.Point(80, 112);
      this.txtIISWebSite.Name = "txtIISWebSite";
      this.txtIISWebSite.Size = new System.Drawing.Size(264, 20);
      this.txtIISWebSite.TabIndex = 6;
      // 
      // lblContentDatabases
      // 
      this.lblContentDatabases.Location = new System.Drawing.Point(8, 176);
      this.lblContentDatabases.Name = "lblContentDatabases";
      this.lblContentDatabases.Size = new System.Drawing.Size(128, 16);
      this.lblContentDatabases.TabIndex = 11;
      this.lblContentDatabases.Text = "Content Databases:";
      // 
      // label6
      // 
      this.label6.Location = new System.Drawing.Point(8, 144);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(72, 16);
      this.label6.TabIndex = 9;
      this.label6.Text = "IIS App Pool:";
      // 
      // lblIISWebSite
      // 
      this.lblIISWebSite.Location = new System.Drawing.Point(8, 112);
      this.lblIISWebSite.Name = "lblIISWebSite";
      this.lblIISWebSite.Size = new System.Drawing.Size(72, 16);
      this.lblIISWebSite.TabIndex = 7;
      this.lblIISWebSite.Text = "IIS Web Site:";
      // 
      // lblWebApplicationPort
      // 
      this.lblWebApplicationPort.Location = new System.Drawing.Point(8, 80);
      this.lblWebApplicationPort.Name = "lblWebApplicationPort";
      this.lblWebApplicationPort.Size = new System.Drawing.Size(32, 16);
      this.lblWebApplicationPort.TabIndex = 5;
      this.lblWebApplicationPort.Text = "Port:";
      // 
      // txtWebApplicationPort
      // 
      this.txtWebApplicationPort.Location = new System.Drawing.Point(80, 80);
      this.txtWebApplicationPort.Name = "txtWebApplicationPort";
      this.txtWebApplicationPort.Size = new System.Drawing.Size(264, 20);
      this.txtWebApplicationPort.TabIndex = 4;
      // 
      // lblWebApplicationID
      // 
      this.lblWebApplicationID.Location = new System.Drawing.Point(8, 16);
      this.lblWebApplicationID.Name = "lblWebApplicationID";
      this.lblWebApplicationID.Size = new System.Drawing.Size(32, 16);
      this.lblWebApplicationID.TabIndex = 3;
      this.lblWebApplicationID.Text = "ID:";
      // 
      // lblWebApplicationUrl
      // 
      this.lblWebApplicationUrl.Location = new System.Drawing.Point(8, 48);
      this.lblWebApplicationUrl.Name = "lblWebApplicationUrl";
      this.lblWebApplicationUrl.Size = new System.Drawing.Size(32, 16);
      this.lblWebApplicationUrl.TabIndex = 2;
      this.lblWebApplicationUrl.Text = "URL:";
      // 
      // txtWebApplicationID
      // 
      this.txtWebApplicationID.Location = new System.Drawing.Point(80, 16);
      this.txtWebApplicationID.Name = "txtWebApplicationID";
      this.txtWebApplicationID.Size = new System.Drawing.Size(264, 20);
      this.txtWebApplicationID.TabIndex = 1;
      // 
      // txtWebApplicationUrl
      // 
      this.txtWebApplicationUrl.Location = new System.Drawing.Point(80, 48);
      this.txtWebApplicationUrl.Name = "txtWebApplicationUrl";
      this.txtWebApplicationUrl.Size = new System.Drawing.Size(264, 20);
      this.txtWebApplicationUrl.TabIndex = 0;
      // 
      // tabSiteCollectionInfo
      // 
      this.tabSiteCollectionInfo.Controls.Add(this.txtSiteCollectionLastModified);
      this.tabSiteCollectionInfo.Controls.Add(this.txtSiteCollectionOwnerEmail);
      this.tabSiteCollectionInfo.Controls.Add(this.lblSiteCollectionLastModified);
      this.tabSiteCollectionInfo.Controls.Add(this.lblSiteCollectionOwnerEmail);
      this.tabSiteCollectionInfo.Controls.Add(this.lblSiteCollectionOwner);
      this.tabSiteCollectionInfo.Controls.Add(this.txtSiteCollectionOwner);
      this.tabSiteCollectionInfo.Controls.Add(this.lblSiteCollectionID);
      this.tabSiteCollectionInfo.Controls.Add(this.lblSiteCollectionUrl);
      this.tabSiteCollectionInfo.Controls.Add(this.txtSiteCollectionID);
      this.tabSiteCollectionInfo.Controls.Add(this.txtSiteCollectionUrl);
      this.tabSiteCollectionInfo.ImageIndex = 2;
      this.tabSiteCollectionInfo.Location = new System.Drawing.Point(4, 23);
      this.tabSiteCollectionInfo.Name = "tabSiteCollectionInfo";
      this.tabSiteCollectionInfo.Size = new System.Drawing.Size(376, 370);
      this.tabSiteCollectionInfo.TabIndex = 2;
      this.tabSiteCollectionInfo.Text = "Site Collection";
      this.tabSiteCollectionInfo.UseVisualStyleBackColor = true;
      // 
      // txtSiteCollectionLastModified
      // 
      this.txtSiteCollectionLastModified.Location = new System.Drawing.Point(80, 144);
      this.txtSiteCollectionLastModified.Name = "txtSiteCollectionLastModified";
      this.txtSiteCollectionLastModified.Size = new System.Drawing.Size(264, 20);
      this.txtSiteCollectionLastModified.TabIndex = 20;
      // 
      // txtSiteCollectionOwnerEmail
      // 
      this.txtSiteCollectionOwnerEmail.Location = new System.Drawing.Point(80, 112);
      this.txtSiteCollectionOwnerEmail.Name = "txtSiteCollectionOwnerEmail";
      this.txtSiteCollectionOwnerEmail.Size = new System.Drawing.Size(264, 20);
      this.txtSiteCollectionOwnerEmail.TabIndex = 18;
      // 
      // lblSiteCollectionLastModified
      // 
      this.lblSiteCollectionLastModified.Location = new System.Drawing.Point(8, 144);
      this.lblSiteCollectionLastModified.Name = "lblSiteCollectionLastModified";
      this.lblSiteCollectionLastModified.Size = new System.Drawing.Size(80, 16);
      this.lblSiteCollectionLastModified.TabIndex = 21;
      this.lblSiteCollectionLastModified.Text = "Last Modified:";
      // 
      // lblSiteCollectionOwnerEmail
      // 
      this.lblSiteCollectionOwnerEmail.Location = new System.Drawing.Point(8, 112);
      this.lblSiteCollectionOwnerEmail.Name = "lblSiteCollectionOwnerEmail";
      this.lblSiteCollectionOwnerEmail.Size = new System.Drawing.Size(72, 16);
      this.lblSiteCollectionOwnerEmail.TabIndex = 19;
      this.lblSiteCollectionOwnerEmail.Text = "Owner Email:";
      // 
      // lblSiteCollectionOwner
      // 
      this.lblSiteCollectionOwner.Location = new System.Drawing.Point(8, 80);
      this.lblSiteCollectionOwner.Name = "lblSiteCollectionOwner";
      this.lblSiteCollectionOwner.Size = new System.Drawing.Size(40, 16);
      this.lblSiteCollectionOwner.TabIndex = 17;
      this.lblSiteCollectionOwner.Text = "Owner:";
      // 
      // txtSiteCollectionOwner
      // 
      this.txtSiteCollectionOwner.Location = new System.Drawing.Point(80, 80);
      this.txtSiteCollectionOwner.Name = "txtSiteCollectionOwner";
      this.txtSiteCollectionOwner.Size = new System.Drawing.Size(264, 20);
      this.txtSiteCollectionOwner.TabIndex = 16;
      // 
      // lblSiteCollectionID
      // 
      this.lblSiteCollectionID.Location = new System.Drawing.Point(8, 16);
      this.lblSiteCollectionID.Name = "lblSiteCollectionID";
      this.lblSiteCollectionID.Size = new System.Drawing.Size(32, 16);
      this.lblSiteCollectionID.TabIndex = 15;
      this.lblSiteCollectionID.Text = "ID:";
      // 
      // lblSiteCollectionUrl
      // 
      this.lblSiteCollectionUrl.Location = new System.Drawing.Point(8, 48);
      this.lblSiteCollectionUrl.Name = "lblSiteCollectionUrl";
      this.lblSiteCollectionUrl.Size = new System.Drawing.Size(32, 16);
      this.lblSiteCollectionUrl.TabIndex = 14;
      this.lblSiteCollectionUrl.Text = "URL:";
      // 
      // txtSiteCollectionID
      // 
      this.txtSiteCollectionID.Location = new System.Drawing.Point(80, 16);
      this.txtSiteCollectionID.Name = "txtSiteCollectionID";
      this.txtSiteCollectionID.Size = new System.Drawing.Size(264, 20);
      this.txtSiteCollectionID.TabIndex = 13;
      // 
      // txtSiteCollectionUrl
      // 
      this.txtSiteCollectionUrl.Location = new System.Drawing.Point(80, 48);
      this.txtSiteCollectionUrl.Name = "txtSiteCollectionUrl";
      this.txtSiteCollectionUrl.Size = new System.Drawing.Size(264, 20);
      this.txtSiteCollectionUrl.TabIndex = 12;
      // 
      // tabSiteInfo
      // 
      this.tabSiteInfo.Controls.Add(this.txtSiteTemplateTitle);
      this.tabSiteInfo.Controls.Add(this.txtSiteTemplateName);
      this.tabSiteInfo.Controls.Add(this.lstSiteMembers);
      this.tabSiteInfo.Controls.Add(this.lstSiteLists);
      this.tabSiteInfo.Controls.Add(this.txtParentSIteID);
      this.tabSiteInfo.Controls.Add(this.txtSiteTitle);
      this.tabSiteInfo.Controls.Add(this.txtSiteID);
      this.tabSiteInfo.Controls.Add(this.txtSiteUrl);
      this.tabSiteInfo.Controls.Add(this.label2);
      this.tabSiteInfo.Controls.Add(this.label1);
      this.tabSiteInfo.Controls.Add(this.lblSiteMembers);
      this.tabSiteInfo.Controls.Add(this.lblSiteLists);
      this.tabSiteInfo.Controls.Add(this.lblParentSiteID);
      this.tabSiteInfo.Controls.Add(this.lblSiteTitle);
      this.tabSiteInfo.Controls.Add(this.lblSiteID);
      this.tabSiteInfo.Controls.Add(this.lblSiteUrl);
      this.tabSiteInfo.ImageIndex = 3;
      this.tabSiteInfo.Location = new System.Drawing.Point(4, 23);
      this.tabSiteInfo.Name = "tabSiteInfo";
      this.tabSiteInfo.Size = new System.Drawing.Size(376, 370);
      this.tabSiteInfo.TabIndex = 3;
      this.tabSiteInfo.Text = "Site";
      this.tabSiteInfo.UseVisualStyleBackColor = true;
      // 
      // txtSiteTemplateTitle
      // 
      this.txtSiteTemplateTitle.Location = new System.Drawing.Point(96, 136);
      this.txtSiteTemplateTitle.Name = "txtSiteTemplateTitle";
      this.txtSiteTemplateTitle.Size = new System.Drawing.Size(264, 20);
      this.txtSiteTemplateTitle.TabIndex = 38;
      // 
      // txtSiteTemplateName
      // 
      this.txtSiteTemplateName.Location = new System.Drawing.Point(96, 112);
      this.txtSiteTemplateName.Name = "txtSiteTemplateName";
      this.txtSiteTemplateName.Size = new System.Drawing.Size(264, 20);
      this.txtSiteTemplateName.TabIndex = 36;
      // 
      // lstSiteMembers
      // 
      this.lstSiteMembers.Location = new System.Drawing.Point(96, 272);
      this.lstSiteMembers.Name = "lstSiteMembers";
      this.lstSiteMembers.Size = new System.Drawing.Size(264, 95);
      this.lstSiteMembers.TabIndex = 33;
      // 
      // lstSiteLists
      // 
      this.lstSiteLists.Location = new System.Drawing.Point(96, 160);
      this.lstSiteLists.Name = "lstSiteLists";
      this.lstSiteLists.Size = new System.Drawing.Size(264, 108);
      this.lstSiteLists.TabIndex = 32;
      // 
      // txtParentSIteID
      // 
      this.txtParentSIteID.Location = new System.Drawing.Point(96, 40);
      this.txtParentSIteID.Name = "txtParentSIteID";
      this.txtParentSIteID.Size = new System.Drawing.Size(264, 20);
      this.txtParentSIteID.TabIndex = 28;
      // 
      // txtSiteTitle
      // 
      this.txtSiteTitle.Location = new System.Drawing.Point(96, 88);
      this.txtSiteTitle.Name = "txtSiteTitle";
      this.txtSiteTitle.Size = new System.Drawing.Size(264, 20);
      this.txtSiteTitle.TabIndex = 26;
      // 
      // txtSiteID
      // 
      this.txtSiteID.Location = new System.Drawing.Point(96, 16);
      this.txtSiteID.Name = "txtSiteID";
      this.txtSiteID.Size = new System.Drawing.Size(264, 20);
      this.txtSiteID.TabIndex = 23;
      // 
      // txtSiteUrl
      // 
      this.txtSiteUrl.Location = new System.Drawing.Point(96, 64);
      this.txtSiteUrl.Name = "txtSiteUrl";
      this.txtSiteUrl.Size = new System.Drawing.Size(264, 20);
      this.txtSiteUrl.TabIndex = 22;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(8, 136);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(88, 16);
      this.label2.TabIndex = 39;
      this.label2.Text = "Template Title:";
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(8, 112);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(88, 16);
      this.label1.TabIndex = 37;
      this.label1.Text = "Template Name:";
      // 
      // lblSiteMembers
      // 
      this.lblSiteMembers.Location = new System.Drawing.Point(8, 280);
      this.lblSiteMembers.Name = "lblSiteMembers";
      this.lblSiteMembers.Size = new System.Drawing.Size(72, 16);
      this.lblSiteMembers.TabIndex = 35;
      this.lblSiteMembers.Text = "Members:";
      // 
      // lblSiteLists
      // 
      this.lblSiteLists.Location = new System.Drawing.Point(8, 168);
      this.lblSiteLists.Name = "lblSiteLists";
      this.lblSiteLists.Size = new System.Drawing.Size(72, 16);
      this.lblSiteLists.TabIndex = 34;
      this.lblSiteLists.Text = "Lists:";
      // 
      // lblParentSiteID
      // 
      this.lblParentSiteID.Location = new System.Drawing.Point(8, 40);
      this.lblParentSiteID.Name = "lblParentSiteID";
      this.lblParentSiteID.Size = new System.Drawing.Size(72, 16);
      this.lblParentSiteID.TabIndex = 29;
      this.lblParentSiteID.Text = "Parent ID:";
      // 
      // lblSiteTitle
      // 
      this.lblSiteTitle.Location = new System.Drawing.Point(8, 88);
      this.lblSiteTitle.Name = "lblSiteTitle";
      this.lblSiteTitle.Size = new System.Drawing.Size(40, 16);
      this.lblSiteTitle.TabIndex = 27;
      this.lblSiteTitle.Text = "Title:";
      // 
      // lblSiteID
      // 
      this.lblSiteID.Location = new System.Drawing.Point(8, 16);
      this.lblSiteID.Name = "lblSiteID";
      this.lblSiteID.Size = new System.Drawing.Size(32, 16);
      this.lblSiteID.TabIndex = 25;
      this.lblSiteID.Text = "ID:";
      // 
      // lblSiteUrl
      // 
      this.lblSiteUrl.Location = new System.Drawing.Point(8, 64);
      this.lblSiteUrl.Name = "lblSiteUrl";
      this.lblSiteUrl.Size = new System.Drawing.Size(32, 16);
      this.lblSiteUrl.TabIndex = 24;
      this.lblSiteUrl.Text = "URL:";
      // 
      // tabProperties
      // 
      this.tabProperties.Controls.Add(this.tabFarmInfo);
      this.tabProperties.Controls.Add(this.tabWebApplicationInfo);
      this.tabProperties.Controls.Add(this.tabSiteCollectionInfo);
      this.tabProperties.Controls.Add(this.tabSiteInfo);
      this.tabProperties.Dock = System.Windows.Forms.DockStyle.Right;
      this.tabProperties.ImageList = this.imgList;
      this.tabProperties.ItemSize = new System.Drawing.Size(75, 19);
      this.tabProperties.Location = new System.Drawing.Point(408, 0);
      this.tabProperties.Name = "tabProperties";
      this.tabProperties.SelectedIndex = 0;
      this.tabProperties.Size = new System.Drawing.Size(384, 397);
      this.tabProperties.TabIndex = 5;
      // 
      // panel2
      // 
      this.panel2.Controls.Add(this.panel3);
      this.panel2.Controls.Add(this.panel1);
      this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel2.Location = new System.Drawing.Point(0, 0);
      this.panel2.Name = "panel2";
      this.panel2.Size = new System.Drawing.Size(408, 397);
      this.panel2.TabIndex = 8;
      // 
      // panel3
      // 
      this.panel3.Controls.Add(this.treeSites);
      this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel3.Location = new System.Drawing.Point(0, 0);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(408, 349);
      this.panel3.TabIndex = 9;
      // 
      // treeSites
      // 
      this.treeSites.Dock = System.Windows.Forms.DockStyle.Fill;
      this.treeSites.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.treeSites.ImageIndex = 0;
      this.treeSites.ImageList = this.imgList;
      this.treeSites.Location = new System.Drawing.Point(0, 0);
      this.treeSites.Name = "treeSites";
      this.treeSites.SelectedImageIndex = 0;
      this.treeSites.Size = new System.Drawing.Size(408, 349);
      this.treeSites.TabIndex = 6;
      this.treeSites.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeSites_AfterSelect);
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.btnReloadSites);
      this.panel1.Controls.Add(this.btnShowAllSites);
      this.panel1.Controls.Add(this.btnShowTopLevelSites);
      this.panel1.Controls.Add(this.btnShowWebApplications);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panel1.Location = new System.Drawing.Point(0, 349);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(408, 48);
      this.panel1.TabIndex = 8;
      // 
      // btnReloadSites
      // 
      this.btnReloadSites.Location = new System.Drawing.Point(0, 24);
      this.btnReloadSites.Name = "btnReloadSites";
      this.btnReloadSites.Size = new System.Drawing.Size(408, 23);
      this.btnReloadSites.TabIndex = 5;
      this.btnReloadSites.Text = "Reload Sites";
      this.btnReloadSites.Click += new System.EventHandler(this.btnReloadSites_Click);
      // 
      // btnShowAllSites
      // 
      this.btnShowAllSites.Location = new System.Drawing.Point(272, 0);
      this.btnShowAllSites.Name = "btnShowAllSites";
      this.btnShowAllSites.Size = new System.Drawing.Size(136, 23);
      this.btnShowAllSites.TabIndex = 4;
      this.btnShowAllSites.Text = "Show All Sites";
      this.btnShowAllSites.Click += new System.EventHandler(this.btnShowAllSites_Click);
      // 
      // btnShowTopLevelSites
      // 
      this.btnShowTopLevelSites.Location = new System.Drawing.Point(136, 0);
      this.btnShowTopLevelSites.Name = "btnShowTopLevelSites";
      this.btnShowTopLevelSites.Size = new System.Drawing.Size(136, 23);
      this.btnShowTopLevelSites.TabIndex = 2;
      this.btnShowTopLevelSites.Text = "Show Top-level Sites";
      this.btnShowTopLevelSites.Click += new System.EventHandler(this.btnShowTopLevelSites_Click);
      // 
      // btnShowWebApplications
      // 
      this.btnShowWebApplications.Location = new System.Drawing.Point(0, 0);
      this.btnShowWebApplications.Name = "btnShowWebApplications";
      this.btnShowWebApplications.Size = new System.Drawing.Size(136, 23);
      this.btnShowWebApplications.TabIndex = 1;
      this.btnShowWebApplications.Text = "Show Web Applications";
      this.btnShowWebApplications.Click += new System.EventHandler(this.btnShowWebApplications_Click);
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(792, 397);
      this.Controls.Add(this.panel2);
      this.Controls.Add(this.tabProperties);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "TPG SharePoint Site Browser";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.tabFarmInfo.ResumeLayout(false);
      this.tabFarmInfo.PerformLayout();
      this.tabWebApplicationInfo.ResumeLayout(false);
      this.tabWebApplicationInfo.PerformLayout();
      this.tabSiteCollectionInfo.ResumeLayout(false);
      this.tabSiteCollectionInfo.PerformLayout();
      this.tabSiteInfo.ResumeLayout(false);
      this.tabSiteInfo.PerformLayout();
      this.tabProperties.ResumeLayout(false);
      this.panel2.ResumeLayout(false);
      this.panel3.ResumeLayout(false);
      this.panel1.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region EventHandlers

    private void Form1_Load(object sender, System.EventArgs e) {
      GlobalErrors.Clear();
      TreeNode TopNode = FarmManager.LoadWebAppNodes();
      treeSites.Nodes.Add(TopNode);
      if (GlobalErrors.ErrorsOccurred) {
        MessageBox.Show(GlobalErrors.Errors, "Error during startup");
      }
    }

    private void btnShowWebApplications_Click(object sender, System.EventArgs e) {
      treeSites.SuspendLayout();
      treeSites.TopNode.Collapse();
      treeSites.TopNode.Expand();
      treeSites.ResumeLayout();
    }

    private void btnShowTopLevelSites_Click(object sender, System.EventArgs e) {
      this.SuspendLayout();
      treeSites.TopNode.Collapse();
      treeSites.TopNode.Expand();
      foreach (TreeNode SiteCollectionNode in treeSites.TopNode.Nodes) {
        SiteCollectionNode.Expand();
        foreach (TreeNode TopLevelSiteNode in SiteCollectionNode.Nodes) {
          TopLevelSiteNode.Expand();
        }
      }
      ResumeLayout();
    }

    private void btnShowAllSites_Click(object sender, System.EventArgs e) {
      SuspendLayout();
      treeSites.TopNode.ExpandAll();
      ResumeLayout();
    }

    private void btnReloadSites_Click(object sender, System.EventArgs e) {
      SuspendLayout();
      TreeNode TopNode = FarmManager.LoadWebAppNodes();
      treeSites.Nodes.Clear();
      treeSites.Nodes.Add(TopNode);
      ResumeLayout();
    }

    private void btnCreateSiteCollection_Click(object sender, System.EventArgs e) {
      MessageBox.Show("Feature not implemented!");
    }

    private void btnCreateSite_Click(object sender, System.EventArgs e) {
      MessageBox.Show("Feature not implemented!");
    }

    private void treeSites_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e) {
      NodeInfo info = (NodeInfo)e.Node.Tag;
      switch (info.Type) {
        case NodeType.Farm:
          DisplayLocalMachineInfo(info);
          break;
        case NodeType.WebApplication:
          DisplayWebApplicationInfo(info);
          break;
        case NodeType.SiteCollection:
          DisplaySiteCollectionInfo(info);
          break;
        case NodeType.Site:
          DisplaySiteInfo(info);
          break;
      }
    }

    #endregion

    #region Helper Methods

    void DisplayLocalMachineInfo(NodeInfo info) {
      this.tabProperties.SelectedTab = tabFarmInfo;
      // get local machine info
      txtLocalMachineName.Text = Environment.MachineName;
      IPHostEntry entry = Dns.GetHostEntry(Environment.MachineName);
      lstMachineIPAddresses.Items.Clear();
      IPAddress[] addresses = entry.AddressList;
      foreach (IPAddress address in addresses) {
        lstMachineIPAddresses.Items.Add(address.ToString());
      }
      SPFarm CurrentFarm = SPFarm.Local;
      txtConfigDBServer.Text = CurrentFarm.PairConnectionString;
      txtConfigDBName.Text = CurrentFarm.DisplayName;
      txtWebServerName.Text = CurrentFarm.Status.ToString();
      txtWebServerID.Text = CurrentFarm.Servers.Count.ToString();

    }

    void DisplayWebApplicationInfo(NodeInfo info) {
      this.tabProperties.SelectedTab = tabWebApplicationInfo;

      SPFarm CurrentFarm = SPFarm.Local;
      SPWebService CurrentWebService = CurrentFarm.Services.GetValue<SPWebService>();
      SPWebApplication WebApp = CurrentWebService.WebApplications.GetValue<SPWebApplication>(info.ID);

      this.txtWebApplicationID.Text = WebApp.Id.ToString().ToUpper();
      this.txtWebApplicationUrl.Text = WebApp.AlternateUrls[0].IncomingUrl;
      this.txtIISAppPool.Text = WebApp.ApplicationPool.DisplayName;

      lstContentDatabases.Items.Clear();
      foreach (SPContentDatabase ContentDB in WebApp.ContentDatabases) {
        lstContentDatabases.Items.Add(ContentDB.Name);
      }
    }

    void DisplaySiteCollectionInfo(NodeInfo info) {
      this.tabProperties.SelectedTab = tabSiteCollectionInfo;
      SPSite SiteCollection = new SPSite(info.ID);
      txtSiteCollectionID.Text = SiteCollection.ID.ToString().ToUpper();
      txtSiteCollectionUrl.Text = SiteCollection.Url;
      txtSiteCollectionOwner.Text = SiteCollection.Owner.LoginName;
      txtSiteCollectionOwnerEmail.Text = SiteCollection.Owner.Email;
      txtSiteCollectionLastModified.Text = SiteCollection.LastContentModifiedDate.ToString();

    }

    void DisplaySiteInfo(NodeInfo info) {
      this.tabProperties.SelectedTab = tabSiteInfo;

      SPSite SiteCollection = new SPSite(info.URL);
      SPWeb Site = SiteCollection.OpenWeb();
      txtSiteID.Text = Site.ID.ToString().ToUpper();
      txtParentSIteID.Text = (Site.ParentWeb != null) ? Site.ParentWeb.ID.ToString().ToUpper() : "No parent site";
      txtSiteUrl.Text = Site.Url;
      txtSiteTitle.Text = Site.Title;
      string TemplateName = Site.WebTemplate + "#" + Site.Configuration.ToString();
      txtSiteTemplateName.Text = TemplateName;
      SPWebTemplateCollection Templates = SiteCollection.GetWebTemplates(1033);
      txtSiteTemplateTitle.Text = Templates[TemplateName].Title;

      lstSiteLists.Items.Clear();
      foreach (SPList List in Site.Lists) {
        lstSiteLists.Items.Add(List.Title);
      }

      lstSiteMembers.Items.Clear();
      foreach (SPUser User in Site.Users) {
        lstSiteMembers.Items.Add(User.LoginName);
      }
    }

    #endregion
  }

  class MyApp {
    static void Main() {
      Application.Run(new Form1());
    }
  }
}
