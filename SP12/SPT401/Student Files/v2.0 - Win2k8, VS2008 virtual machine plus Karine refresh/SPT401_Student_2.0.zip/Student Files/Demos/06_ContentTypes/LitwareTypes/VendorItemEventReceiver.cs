using System;
using Microsoft.SharePoint;

namespace LitwareTypes {
public class VendorItemEventReceiver : SPItemEventReceiver {

  string PhoneInvalidErrorMessage = @"LITWARE VALIDATION ERROR: Phone must be at least 7 digits. Press the back arrow to return to the previous page to fix your error.";

  private bool PhoneIsValid(string Phone) {
    if ((Phone == null) || (Phone.Length < 7))
      return false;
    else
      return true;
  }

  public override void ItemAdding(SPItemEventProperties properties) {
    // validate Phone column for new vendor item
    string Phone = properties.AfterProperties["WorkPhone"].ToString();
    if (!PhoneIsValid(Phone)) {
      properties.Status = SPEventReceiverStatus.CancelWithError;
      properties.ErrorMessage = PhoneInvalidErrorMessage;
      properties.Cancel = true;
    }
  }

  public override void ItemUpdating(SPItemEventProperties properties) {
    // validate Phone column for update to vendor item
    string Phone = properties.AfterProperties["WorkPhone"].ToString();
    if (!PhoneIsValid(Phone)) {
      properties.Status = SPEventReceiverStatus.CancelWithError;
      properties.ErrorMessage = PhoneInvalidErrorMessage;
      properties.Cancel = true;
    }
  }

 
  public override void ItemDeleting(SPItemEventProperties properties) {
    if (!properties.OpenWeb().CurrentUser.IsSiteAdmin) {
      properties.Status = SPEventReceiverStatus.CancelWithError;
      properties.ErrorMessage = "Vendor can only be deleted by site administrator";
      properties.Cancel = true;
    }
  }
}
}
