Imports System
Imports System.IO
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Xml

Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls
Imports Microsoft.SharePoint.Navigation
Imports Microsoft.SharePoint.Utilities
Imports Microsoft.SharePoint.WebPartPages



Public Class SitePageCreator
    Inherits LayoutsPageBase

    ' add control fields to match controls tags on .aspx page
    Protected txtPageName As TextBox
    Protected txtPageTitle As TextBox
    Protected txtPageContent As TextBox


    Protected Overrides Sub OnLoad(ByVal e As EventArgs)

        ' get current site and web
        Dim siteCollection As SPSite = Me.Site
        Dim site As SPWeb = Me.Web
    End Sub 'OnLoad


    Protected Sub btnCreateStandardPage_Click(ByVal sender As Object, ByVal e As EventArgs)

        Dim stream As New MemoryStream()
        Dim writer As New StreamWriter(stream)
        writer.WriteLine("<%@ Page MasterPageFile='~masterurl/default.master' meta:progid='SharePoint.WebPartPage.Document' %>")
        writer.WriteLine("<asp:Content runat='server' ContentPlaceHolderID='PlaceHolderMain'>")
        writer.WriteLine(("<h3>" + txtPageTitle.Text + "</h3>"))
        writer.WriteLine(txtPageContent.Text)
        writer.WriteLine("</asp:Content>")
        writer.Flush()

        Dim NewPageUrl As String = "SitePages/" + txtPageName.Text + ".aspx"
        Me.Web.Files.Add(NewPageUrl, stream)

        ' grab the existing site TopNavigationBar for our use
        Dim topNav As SPNavigationNodeCollection = Me.Web.Navigation.TopNavigationBar

        ' create dropdown menu for custom site pages
        Dim node As SPNavigationNode
        For Each node In topNav(0).Children
            If node.Title.Equals("Site Pages") Then
                Dim newNode As New SPNavigationNode(txtPageName.Text, NewPageUrl)
                node.Children.AddAsLast(newNode)
            End If
        Next node

        SPUtility.Redirect(Web.Url + "/" + NewPageUrl, SPRedirectFlags.Default, Me.Context)

    End Sub 'btnCreateStandardPage_Click


    Protected Sub btnCreateWebPartPage_Click(ByVal sender As Object, ByVal e As EventArgs)


        ' clone Web Part Page template to create new Web Part Page
        Dim NewPageUrl As String = "SitePages/" + txtPageName.Text + ".aspx"
        Dim template As SPFile = Web.GetFile("Template\WebPartPage.aspx")
        template.CopyTo(NewPageUrl)

        ' add Content Editor Web Part
        Dim NewPage As SPFile = Web.GetFile(NewPageUrl)
        Dim mgr As SPLimitedWebPartManager
        mgr = NewPage.GetLimitedWebPartManager(PersonalizationScope.Shared)

        Dim wp1 As New ContentEditorWebPart()
        wp1.Title = txtPageTitle.Text
        wp1.ChromeType = PartChromeType.TitleOnly
        wp1.AllowClose = False
        Dim doc As New XmlDocument()
        Dim ns1 As String = "http://schemas.microsoft.com/WebPart/v2/ContentEditor"
        Dim elm As XmlElement = doc.CreateElement("Content", ns1)
        elm.InnerText = txtPageContent.Text
        wp1.Content = elm

        ' add Web Part to Left Zone
        mgr.AddWebPart(wp1, "Left", 0)

        ' add naviation node
        Dim topNav As SPNavigationNodeCollection = Me.Web.Navigation.TopNavigationBar
        Dim node As SPNavigationNode
        For Each node In topNav(0).Children
            If node.Title.Equals("Site Pages") Then
                Dim newNode As New SPNavigationNode(txtPageName.Text, NewPageUrl)
                node.Children.AddAsLast(newNode)
            End If
        Next node

        ' navigate directly to the newly created Web Part Page
        SPUtility.Redirect(Web.Url + "/" + NewPageUrl, SPRedirectFlags.Default, Me.Context)

    End Sub 'btnCreateWebPartPage_Click

End Class 'SitePageCreator
