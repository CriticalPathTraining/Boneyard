Imports System
Imports System.IO
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Xml

Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls
Imports Microsoft.SharePoint.Navigation
Imports Microsoft.SharePoint.Utilities
Imports Microsoft.SharePoint.WebPartPages

Public Class SitePageCreator
    Inherits LayoutsPageBase

    ' add control fields to match controls tags on .aspx page
    Protected txtPageName As TextBox
    Protected txtPageTitle As TextBox
    Protected txtPageContent As TextBox


    Protected Overrides Sub OnLoad(ByVal e As EventArgs)

        ' get current site and web
        Dim siteCollection As SPSite = Me.Site
        Dim site As SPWeb = Me.Web
    End Sub 'OnLoad


    Protected Sub btnCreateStandardPage_Click(ByVal sender As Object, ByVal e As EventArgs)

    End Sub 'btnCreateStandardPage_Click


    Protected Sub btnCreateWebPartPage_Click(ByVal sender As Object, ByVal e As EventArgs)

    End Sub 'btnCreateWebPartPage_Click

End Class 'SitePageCreator
