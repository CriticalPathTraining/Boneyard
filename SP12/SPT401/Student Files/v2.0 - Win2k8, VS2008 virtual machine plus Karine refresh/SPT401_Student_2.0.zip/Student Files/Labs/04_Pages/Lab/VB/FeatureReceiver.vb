Imports System
Imports System.Web.UI.WebControls.WebParts
Imports System.Xml
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls
Imports Microsoft.SharePoint.WebPartPages
Imports Microsoft.SharePoint.Navigation

Public Class FeatureReceiver
    Inherits SPFeatureReceiver

    Public Overrides Sub FeatureActivated(ByVal properties As SPFeatureReceiverProperties)

        ' get a hold off current site in context of feature activation
        Dim site As SPWeb = CType(properties.Feature.Parent, SPWeb)
        Dim topNav As SPNavigationNodeCollection = site.Navigation.TopNavigationBar

        ' create dropdown menu for custom site pages
        Dim DropDownMenu1 As New SPNavigationNode("Site Pages", "", False)
        topNav(0).Children.AddAsLast(DropDownMenu1)
        DropDownMenu1.Children.AddAsLast(New SPNavigationNode("Site Page 1", "SitePages/Page01.aspx"))

        DropDownMenu1.Children.AddAsLast(New SPNavigationNode("Site Page 2", "SitePages/Page02.aspx"))
        DropDownMenu1.Children.AddAsLast(New SPNavigationNode("Site Page 3", "SitePages/Page03.aspx"))
        DropDownMenu1.Children.AddAsLast(New SPNavigationNode("Site Page 4", "SitePages/Page04.aspx"))
    End Sub 'FeatureActivated

    Public Overrides Sub FeatureDeactivating(ByVal properties As SPFeatureReceiverProperties)

        Dim site As SPWeb = CType(properties.Feature.Parent, SPWeb)
        ' delete folder of site pages provisioned during activation
        Dim sitePagesFolder As SPFolder = site.GetFolder("SitePages")
        sitePagesFolder.Delete()

        Dim topNav As SPNavigationNodeCollection = site.Navigation.TopNavigationBar

        Dim i As Integer
        For i = topNav(0).Children.Count - 1 To 0 Step -1
            If topNav(0).Children(i).Title = "Site Pages" Then
                ' delete node
                topNav(0).Children(i).Delete()
            End If
        Next i
    End Sub 'FeatureDeactivating

    Public Overrides Sub FeatureInstalled(ByVal properties As SPFeatureReceiverProperties) ' no op 

    End Sub 'FeatureInstalled

    Public Overrides Sub FeatureUninstalling(ByVal properties As SPFeatureReceiverProperties) ' no op 

    End Sub 'FeatureUninstalling 

End Class 'FeatureReceiver

