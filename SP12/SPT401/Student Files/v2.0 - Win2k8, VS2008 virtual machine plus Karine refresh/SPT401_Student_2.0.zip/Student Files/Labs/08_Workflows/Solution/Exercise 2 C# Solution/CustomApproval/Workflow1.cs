﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Xml;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.Office.Workflow.Utility;

namespace CustomApproval
{
    public sealed partial class Workflow1 : SequentialWorkflowActivity
    {
        public Workflow1()
        {
            InitializeComponent();
        }

        public Guid workflowId = default(System.Guid);
        public SPWorkflowActivationProperties workflowProperties = new SPWorkflowActivationProperties();

        public string user = default(string);
        public string comments = default(string);
        public string taskStatus = default(string);

        public Guid taskId = default(System.Guid);
        public SPWorkflowTaskProperties taskProperties =
           new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties beforeProperties =
           new SPWorkflowTaskProperties();
        public SPWorkflowTaskProperties afterProperties =
           new SPWorkflowTaskProperties();

        private void onWorkflowActivated1_Invoked(object sender, ExternalDataEventArgs e)
        {
            // store the new workflow's id
            workflowId = workflowProperties.WorkflowId;

            // http://schemas.microsoft.com/office/infopath/2003/myXSD/2007-07-13T02:58:42
            // InitiationData now contains the data that came from the form. 
            // We can store this data into local variables.
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(workflowProperties.InitiationData);

            //BE SURE TO REPLACE THE FOLLOWING NAMESPACE WITH THE ONE YOU COPIED IN STEP A OR //THE SOLUTION WILL NOT WORK!!!

            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("my",
             "http://schemas.microsoft.com/office/infopath/2003/myXSD/2007-07-13T02:58:42");

            user = doc.SelectSingleNode("my:myFields/my:User", nsmgr).InnerText;
            comments = doc.SelectSingleNode("my:myFields/my:Comments", nsmgr).InnerText;


        }

        private void createTask1_MethodInvoking(object sender, EventArgs e)
        {
            // initialize the task ID
            taskId = Guid.NewGuid();

            // populate the properties of the task
            taskProperties.AssignedTo = user;
            taskProperties.Description = "Approve the document.";
            taskProperties.Title = "Timesheet Approval";

            // populate the type of the form and extended properties
            taskProperties.ExtendedProperties["User"] = user;
            taskProperties.ExtendedProperties["Comments"] = comments;

        }

        private void onTaskChanged1_Invoked(object sender, ExternalDataEventArgs e)
        {
            // retrieve the TaskStatus property from the infopath form
            taskStatus = this.afterProperties.ExtendedProperties["TaskStatus"].ToString();
        }
    }
}
