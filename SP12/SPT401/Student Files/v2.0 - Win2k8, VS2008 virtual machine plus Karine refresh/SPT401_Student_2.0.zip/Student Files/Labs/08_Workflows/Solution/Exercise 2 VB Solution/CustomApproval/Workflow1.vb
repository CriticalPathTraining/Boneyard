Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.Workflow
Imports Microsoft.SharePoint.WorkflowActions
Imports Microsoft.Office.Workflow.Utility

'NOTE: When changing the namespace; please update XmlnsDefinitionAttribute in AssemblyInfo.vb
Public Class Workflow1
    Inherits SharePointSequentialWorkflowActivity

    Public Sub New()
        MyBase.New()
        InitializeComponent()
    End Sub
    Public workflowProperties As SPWorkflowActivationProperties = New Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties
    Public user As String
    Public comments As String
    Public taskStatus As String
    Public workflowId As Guid

    Public taskID As Guid
    Public taskProperties As New SPWorkflowTaskProperties()
    Public beforeProperties As New SPWorkflowTaskProperties()
    Public afterProperties As New SPWorkflowTaskProperties()

    Private Sub onWorkflowActivated1_Invoked(ByVal sender As Object, ByVal e As ExternalDataEventArgs)
        ' store the new workflow's id
        workflowId = workflowProperties.WorkflowId
        ' InitiationData now contains the data that came from the form. 
        ' We can store this data into local variables.
        Dim doc As New Xml.XmlDocument()
        doc.LoadXml(workflowProperties.InitiationData)

        Dim nsmgr As New Xml.XmlNamespaceManager(doc.NameTable)
        nsmgr.AddNamespace("my", _
         "http://schemas.microsoft.com/office/infopath/2003/myXSD/2007-07-13T02:58:42")

        user = doc.SelectSingleNode("my:myFields/my:User", nsmgr).InnerText
        comments = doc.SelectSingleNode("my:myFields/my:Comments", nsmgr).InnerText
    End Sub

    Private Sub createTask1_MethodInvoking(ByVal sender As Object, ByVal e As EventArgs)
        ' initialize the task ID
        taskID = Guid.NewGuid()

        ' populate the properties of the task
        taskProperties.AssignedTo = user
        taskProperties.Description = "Approve the document."
        taskProperties.Title = "Timesheet Approval"

        ' populate the type of the form and extended properties
        taskProperties.ExtendedProperties("User") = user
        taskProperties.ExtendedProperties("Comments") = comments
    End Sub 'createTask1_MethodInvoking

    Private Sub onTaskChanged1_Invoked(ByVal sender As Object, ByVal e As ExternalDataEventArgs)
        ' retrieve the TaskStatus property from the infopath form
        taskStatus = Me.afterProperties.ExtendedProperties("TaskStatus").ToString()
    End Sub 'onTaskChanged1_Invoked
End Class
