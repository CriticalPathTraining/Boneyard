﻿using System.Reflection;

// If needed, copy Assembly format name from below to paste elsewhere
// LitwareWebPartsLab, Version=1.0.0.0, Culture=neutral, PublicKeyToken=d4e5777b16a5749f
[assembly: AssemblyVersion("1.0.0.0")]


// this is used to get around a beta 1 bug for importing Web Parts
[assembly: System.Security.AllowPartiallyTrustedCallers()]
