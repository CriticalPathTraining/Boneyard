using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Office.Server;
using Microsoft.Office.Server.Administration;
using Microsoft.Office.Server.UserProfiles;
using Microsoft.SharePoint;
using System.Web;

namespace UserProfilesOMApp
{
    class Program
    { 
        static void Main(string[] args)
        {
            //Code example adds a new property called Marital Status.
            using (SPSite site = new SPSite("http://Litwareinc.com"))
            {
                ServerContext context =
                    ServerContext.GetContext(site);
                UserProfileManager profileManager = new
                    UserProfileManager(context);
                try
                {
                    //Get the properties
                    PropertyCollection pc = profileManager.Properties;
                    Property p = pc.Create(false);
                    p.Name = "HourlyRate";
                    p.DisplayName = "Hourly Rate";
                    p.Type = "Integer";
                    p.PrivacyPolicy = PrivacyPolicy.OptIn;
                    p.DefaultPrivacy = Privacy.Organization;
                    pc.Add(p);

                 foreach (UserProfile profile in profileManager)
                 {
                     switch (profile[PropertyConstants.AccountName].ToString())
                     {
                         case @"LITWAREINC\Administrator":
                             profile["HourlyRate"].Value = 300;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\AngelaB" :
                             profile["HourlyRate"].Value= 140;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\BrianC":
                             profile["HourlyRate"].Value = 100;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\BarbaraD":
                             profile["HourlyRate"].Value = 150;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\HollyH":
                             profile["HourlyRate"].Value = 150;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\DeniseS":
                             profile["HourlyRate"].Value = 200;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\MikeF":
                             profile["HourlyRate"].Value = 250;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\PatriciaD":
                             profile["HourlyRate"].Value = 175;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\QiangW":
                             profile["HourlyRate"].Value = 125;
                             profile.Commit();
                             break;
                         case @"LITWAREINC\JayH":
                             profile["HourlyRate"].Value = 250;
                             profile.Commit();
                             break;
                     }

                  
                 }
                 Console.WriteLine("HourlyRate Updates complete");
                 Console.ReadLine();
                }
                catch (DuplicateEntryException e)
                {
                    Console.WriteLine(e.Message);
                    Console.Read();
                }
                catch (UserNotFoundException e3)
                {
                    Console.WriteLine(e3.ToString());
                }

                catch (System.Exception e2)
                {
                    Console.WriteLine(e2.Message);
                    Console.Read();
                }
            }
        }
    }
}



//using System;
//using Microsoft.Office.Server;
//using Microsoft.Office.Server.Administration;
//using Microsoft.Office.Server.UserProfiles;
//using Microsoft.SharePoint;
//using System.IO;

//namespace AccountNameDump
//{
//    public class Program
//    {
//        public static void Main(string[] args)
//        {
//            try
//            {
//                using (SPSite site = new SPSite("http://Litwareinc.com/"))
//                {
//                    ServerContext context = 
//                        ServerContext.GetContext(site);
//                    UserProfileManager profileManager = new 
//                        UserProfileManager(context);
//                    Microsoft.Office.Server.UserProfiles.Property.
//                    foreach (UserProfile profile in profileManager)
//                    {
//             Console.WriteLine(profile[PropertyConstants.AccountName]);
//                    }
//                }
//            }
//            catch (FileNotFoundException exception)
//            {
//                Console.WriteLine(exception.ToString());
//            }
//        }
//    }
//}
