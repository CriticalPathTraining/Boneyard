
using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;

namespace CustomBranding
{
  public class FeatureReceiver : SPFeatureReceiver
  {
    public override void FeatureActivated(SPFeatureReceiverProperties properties)  {
      
      // possible to add code here to apply branding upon activation
    }

    public override void FeatureInstalled(SPFeatureReceiverProperties properties){ /* no op */}
    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) { /* no op */}
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { /* no op */}

  }
}
