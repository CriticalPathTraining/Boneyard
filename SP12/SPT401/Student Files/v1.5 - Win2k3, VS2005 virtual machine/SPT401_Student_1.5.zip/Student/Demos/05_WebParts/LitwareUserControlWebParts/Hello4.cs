using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts {
  public class Hello4 : WebPart {

    #region "Custom Properties"

    public enum BackgroundColorEnum {
      White,
      Gray,
      Teal,
      Yellow
    }

    private BackgroundColorEnum _BackgroundColor;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public BackgroundColorEnum BackgroundColor {
      get { return _BackgroundColor; }
      set { _BackgroundColor = value; }
    }


    public enum FontColorEnum {
      Black,
      Red,
      Green,
      Blue
    }

    private FontColorEnum _FontColor = FontColorEnum.Blue;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public FontColorEnum FontColor {
      get { return _FontColor; }
      set { _FontColor = value; }
    }
	

    private double _Number1Default;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public double Number1Default {
      get { return _Number1Default; }
      set { _Number1Default = value; }
    }
    

    private double _Number2Default;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public double Number2Default {
      get { return _Number2Default; }
      set { _Number2Default = value; }
    }

    private bool _PersistUserEntries;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public bool PersistUserEntries {
      get { return _PersistUserEntries; }
      set { _PersistUserEntries = value; }
    }

    #endregion

    // field to hold onto UserControl instance
    protected Hello4UserControlBase userControl;
    
    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      this.Controls.Clear();
      userControl = (Hello4UserControlBase)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello4.ascx");
      this.Controls.Add(userControl);      
      // pass back-pointer reference to user control base class
      userControl.SetWebPartReference(this, _PersistUserEntries);
    }

    public override EditorPartCollection CreateEditorParts() {
      EditorPart part = new Hello4Editor();
      part.ID = this.ID + "_Editor";
      EditorPart[] parts = { part };
      return new EditorPartCollection(parts);
    }

    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);
      // pass peristed property values to user control base class
      userControl.SetBackgroundColor(this.BackgroundColor.ToString());
      userControl.SetFontColor(this.FontColor.ToString());            
      userControl.SetControlValues(_Number1Default, _Number2Default);
    }

  }
}
