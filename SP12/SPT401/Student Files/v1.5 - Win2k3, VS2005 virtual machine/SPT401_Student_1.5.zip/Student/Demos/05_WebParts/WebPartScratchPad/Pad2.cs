using System;
using System.ComponentModel;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace WebPartScratchPad {
  public class Pad2 : WebPart {

    private const string UserControlTemplateName = "WebPartScratchPad/Pad2.ascx";

    // field to hold onto UserControl instance
    protected Pad2UserControlBase userControl;

    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      this.Controls.Clear();
      // if AJAX is installed on Web server wrapper control in UpdatePanel
      if (AjaxIsInstalled()) {
        EnsureScriptManager();
        EnsureUpdatePanelFixups();
        UpdatePanel up = new UpdatePanel();
        up.ID = this.ID + "_AjaxUpdatePanel";
        up.ChildrenAsTriggers = true;
        up.UpdateMode = UpdatePanelUpdateMode.Conditional;
        this.Controls.Add(up);
        userControl = (Pad2UserControlBase)this.Page.LoadControl(@"/_controltemplates/" + UserControlTemplateName);
        up.ContentTemplateContainer.Controls.Add(userControl);
      } // if AJAX is not installed add user
      else {
        userControl = (Pad2UserControlBase)this.Page.LoadControl(@"/_controltemplates/" + UserControlTemplateName);
        this.Controls.Add(userControl);
      }
    }

    #region "AJAX integration helper methods

    private bool AjaxIsInstalled() {
      try {
        string asmNameAjax = "System.Web.Extensions, Version=1.0.61025.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35";
        Assembly asmAjax = Assembly.Load(asmNameAjax);
        return (asmAjax != null);
      }
      catch {
        return false;
      }
    }

    private void EnsureScriptManager() {
      if (ScriptManager.GetCurrent(this.Page) == null) {
        this.Controls.Add(new ScriptManager());
      }
    }

    private void EnsureUpdatePanelFixups() {
      if (this.Page.Form != null) {
        string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
        if (formOnSubmitAtt == "return _spFormOnSubmitWrapper();") {
          this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
        }
      }
      ScriptManager.RegisterStartupScript(this, this.GetType(), "UpdatePanelFixup", "_spOriginalFormAction = document.forms[0].action; _spSuppressFormOnSubmitWrapper=true;", true);
    }

    #endregion

  }
}
