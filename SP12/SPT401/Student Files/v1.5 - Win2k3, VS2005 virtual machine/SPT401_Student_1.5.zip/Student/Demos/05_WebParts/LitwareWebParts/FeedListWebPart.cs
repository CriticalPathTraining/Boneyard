using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace LitwareWebParts {

public class FeedListWebPart : WebPart, IWebPartField {

  private SPGridView listsView;
  private DataTable dt;

  protected override void CreateChildControls() {
    base.CreateChildControls();

    List<SPList> lists = new List<SPList>();
    AddLists(lists, SPContext.Current.Web);

    listsView = new SPGridView();
    listsView.AutoGenerateColumns = false;
    this.Controls.Add(listsView);

    BoundField colTitle = new BoundField();
    colTitle.DataField = "Title";
    colTitle.HeaderText = "Title";
    listsView.Columns.Add(colTitle);

    BoundField colXml = new BoundField();
    colXml.DataField = "ItemCount";
    colXml.HeaderText = "Item Count";
    listsView.Columns.Add(colXml);

    CommandField colSelectButton = new CommandField();
    colSelectButton.HeaderText = "Action";
    colSelectButton.ControlStyle.Width = new Unit(75);
    colSelectButton.SelectText = "Show RSS";
    colSelectButton.ShowSelectButton = true;
    listsView.Columns.Add(colSelectButton);

    listsView.SelectedIndexChanged += new EventHandler(view_SelectedIndexChanged);

    if (!this.Page.IsPostBack) {

      dt = new DataTable();
      dt.Columns.Add("Title");
      dt.Columns.Add("ItemCount");
      dt.Columns.Add("XmlUrl");
      dt.Columns.Add("ID");

      foreach (SPList list in lists) {
        DataRow dr = dt.NewRow();
        dr["Title"] = list.Title;
        dr["ItemCount"] = list.ItemCount.ToString();

        dr["ID"] = list.ID;
        string url = this.Page.Request.Url.GetLeftPart(UriPartial.Authority)
        + SPUtility.MapWebURLToVirtualServerURL(
            list.ParentWeb,
            string.Format("{0}/_layouts/listfeed.aspx?List={1}",
            list.ParentWebUrl, list.ID.ToString()));
        dr["XmlUrl"] = url;
        dt.Rows.Add(dr);
      }     

      listsView.DataKeyNames = new string[] { "XmlUrl" };
      listsView.DataSource = dt;
      listsView.DataBind();
    }
  }

  void view_SelectedIndexChanged(object sender, EventArgs e) {
    GridViewRow row = listsView.SelectedRow;
    this.xmlUrl = listsView.SelectedValue.ToString();
  }

  private void AddLists(List<SPList> lists, SPWeb web) {
    foreach (SPList list in web.Lists)
      if (list.AllowRssFeeds && list.EnableSyndication &&
              list.BaseTemplate != SPListTemplateType.Categories &&
              list.BaseTemplate != SPListTemplateType.ListTemplateCatalog &&
              list.BaseTemplate != SPListTemplateType.MasterPageCatalog &&
              list.BaseTemplate != SPListTemplateType.WebPageLibrary &&
              list.BaseTemplate != SPListTemplateType.WebPartCatalog &&
              list.BaseTemplate != SPListTemplateType.WebTemplateCatalog &&
              list.BaseTemplate != SPListTemplateType.UserInformation &&
              list.DoesUserHavePermissions(SPBasePermissions.ViewListItems))
        lists.Add(list);


    foreach (SPWeb subweb in web.Webs) {
      if (web.DoesUserHavePermissions(SPBasePermissions.ViewListItems))
        AddLists(lists, subweb);
    }
  }

    private string xmlUrl = "";
    /// <summary>Gets or sets the XmlUrl string property</summary>
    /// <remarks>Checks the validity of the URI on the Set method.</remarks>
    [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.User),
        DefaultValue(""),
        WebDisplayName("Xml Url"),
        WebDescription("RSS Feed XML URL")]
    public string XmlUrl {
      get { return xmlUrl; }
      set {
        if (!string.IsNullOrEmpty(xmlUrl)) {
          Uri xmlUri = new Uri(value);
          xmlUrl = xmlUri.AbsolutePath;
        }
        else
          xmlUrl = null;
      }
    }

    #region IWebPartField Members

    //Allows the consumer webpart to consume this data
    public void GetFieldValue(FieldCallback callback) {
      callback(Schema.GetValue(this));
    }

    // Gets a PropertyDescriptor for this connection
    public System.ComponentModel.PropertyDescriptor Schema {
      get {
        PropertyDescriptorCollection properties =
            TypeDescriptor.GetProperties(this);
        return properties.Find("XmlUrl", false);
      }
    }

    [ConnectionProvider("XmlUrl Provider")]
    public IWebPartField GetConnectionInterface() {
      return this;
    }

    #endregion
  }
}
