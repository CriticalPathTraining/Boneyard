using System;
using System.Web.UI;

[assembly: WebResource(@"HelloAjaxWebParts.WebPartResources.Hello2Script.js", @"text/javascript")]

[assembly: WebResource(@"HelloAjaxWebParts.WebPartResources.EditableControl.js", @"text/javascript")]
[assembly: WebResource(@"HelloAjaxWebParts.WebPartResources.WikiControl.js", @"text/javascript")]


