﻿/// <reference name="MicrosoftAjax.debug.js" />

if (typeof(Litware) == 'undefined')
    Type.registerNamespace('Litware');
    
// Defines the EditableControl Component
// A control-based component for a simple editable control    

if (typeof(Litware) == 'undefined')
    Type.registerNamespace('Litware');
    
Litware.EditableControl = function(element){
    element.editControl = this;
    this.element = element;     
}

Litware.EditableControl.prototype = {
	element : null,
	editElement : null,
	saveButton : null,
	toolbar : null,
   // initializes the control
   initialize : function(text){
        this.toolbar = document.createElement('DIV'); 
        this.toolbar.style.border = '1px solid silver';
        this.element.appendChild(this.toolbar);
        this.toolbar.style.visibility='hidden';
        
        this.saveButton = document.createElement('IMG');
        this.saveButton.src = '/_layouts/images/save.gif';
         this.saveButton.style.top='3px';
         this.saveButton.style.left='3px';
         this.saveButton.style.zIndex=100;
         this.toolbar.appendChild(this.saveButton);       
        
        this.editElement = document.createElement('DIV');
        this.editElement.style.border = '1px solid';
        this.editElement.style.padding='3px';
        this.editElement.innerHTML = text;
        this.element.appendChild(this.editElement);
        
        $addHandler(this.editElement,'dblclick',
            Litware.EditableControl.MakeEditable);       
    },
   // makes it editable
   makeEditable : function(){  
        if (this.editElement.contentEditable == 'true'){
             this.saveContent();             
             $addHandler(this.editElement,'dblclick',
                  Litware.EditableControl.MakeEditable);
             $clearHandlers(this.saveButton);
             this.toolbar.style.visibility='hidden';
        }else{
            document.designMode = "On";
            this.editElement.contentEditable = 'true'; 
            this.editElement.style.backgroundColor='yellow';
            $clearHandlers(this.editElement);
                          
             this.toolbar.style.visibility='visible';
            $addHandler(this.saveButton,'click',
              Litware.EditableControl.MakeEditable);            
        }
   },
   // Saves the content   
   saveContent : function() {
      document.designMode = "Off";
      this.editElement.contentEditable = 'false'; 
      this.editElement.style.backgroundColor='';
   },
   
   // converts the HTML format to WIKI text
   convertToWiki : function(element){
      var links = element.getElementsByTagName('span');
      var placeholders = new Array();
      for(var i=0;i<links.length;i++){
         if (links[i].className=='WIKILINK')            
            Array.add(placeholders, links[i]);
      }      
      for(var i=0;i<placeholders.length;i++){
         var wik = document.createTextNode( String.format('[[{0}]]',this.getText(placeholders[i])) );        
         var old = placeholders[i].parentNode.replaceChild(wik, placeholders[i]); 
         placeholders[i] = null;
      }     
   },
    
   // Converts WIKI text to HTML format  
   wikiToHtml : function(wikiText){
      var rex = new RegExp('\\[\\[([^\\]]+)\\]\\]',"mg");
      var match = rex.exec(wikiText);   
      while (match){
         var linked = String.format("<span class=\"WIKILINK\">{0}</span>",match[1]);
         wikiText = wikiText.replace(match[0],linked);
         match = rex.exec(wikiText);  
      }
      return wikiText;
   },
   
   // Gets the text content of a DOM node
   getText : function(node){
      if (node == null) return '';
      if (node.innerText) return node.innerText;
      else if (node.textContent) return node.textContent;
      else return '';
   }
}

Litware.EditableControl.registerClass('Litware.EditableControl');

// anonymous method that calls into the Litware.editControl
Litware.EditableControl.MakeEditable = function(evt){    
   var editControl = findParentEditElement(evt.target);    
   if (editControl != null)
        editControl.makeEditable();
   else alert('Could not enable wiki!');
}

// Finds the parent editable element
function findParentEditElement(element){
    while (element.editControl == null || element == null){
        if (element.parentNode) element = element.parentNode;
        else if (element.parentElement) element = element.parentElement;
        else {
            var err = Error.invalidOperation();
            throw err;
        } 
    }
    if (element != null) return element.editControl;   
}
