using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Services;
using System.Web.Script.Services;
using Microsoft.SharePoint;
using System.Security.Permissions;

namespace HelloAjaxWebParts {

   // An example Web Service API for a TPG MicroWiki. 
  [WebService(Namespace = "http://litwareinc.com/HelloAjaxWebParts")]
   [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
   [ScriptService]
   public class WikiWebService : System.Web.Services.WebService {

      private const string wikiName = "__MicroWiki";
      private const string DefaultContent = "&nbsp;";

      [ScriptMethod(ResponseFormat=ResponseFormat.Json)]
      [WebMethod]
      public string GetContent(string wikiID) {
         SPList wiki = this.GetWikiList(wikiID);
         if (wiki == null)
            return "Welcome to the MicroWiki!";
         SPQuery query = new SPQuery();
         query.ViewFields = @"<FieldRef Name='Content'/><FieldRef Name='Title'/>";
         query.Query = string.Format(
             @"<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>{0}</Value></Eq></Where>",
             wikiID);
         SPListItemCollection items = wiki.GetItems(query);
         if (items.Count > 0)
            return ((string)items[0]["Content"]);
         else
            return DefaultContent;
      }

      [WebMethod]
      public void SetContent(string wikiID, string wikiContent) {
         SPContext.Current.Web.AllowUnsafeUpdates = true;
         SPList wiki = this.GetWikiList(wikiID);
         SPQuery query = new SPQuery();
         query.ViewFields = @"<FieldRef Name='Content'/><FieldRef Name='Title'/>";
         query.Query = string.Format(
             @"<Where><Eq><FieldRef Name='Title'/><Value Type='Text'>{0}</Value></Eq></Where>",
             wikiID);
         SPListItemCollection items = wiki.GetItems(query);
         if (items.Count > 0){
            SPListItem item = wiki.Items[items[0].UniqueId];
            item["Content"] = wikiContent;
            item.Update();
            // wiki.Update();
         }
         else {
            SPListItem item = wiki.Items.Add();
            item["Content"] = wikiContent;
            item["Title"] = wikiID;
            item.Update();
         }
      }

      // Returns the wiki list for this site.         
      private SPList GetWikiList(string wikiID) {
         SPWeb site = SPContext.Current.Web;

         SPList list = null;

         foreach (SPList alist in site.Lists) {
            if (alist.Title.Equals(wikiName,
              StringComparison.InvariantCultureIgnoreCase)) {
               list = alist;
               break;
            }
         }
         if (list != null)
            return list;
         else {
            SPSecurity.RunWithElevatedPrivileges(
            delegate() {
             // See chapter 10 for more details on RunWithElevatedPrivileges
             using (SPSite siteCollection =
                 new SPSite(SPContext.Current.Site.ID)) {
                using (SPWeb elevatedSite =
                        siteCollection.OpenWeb(SPContext.Current.Web.ID)) {
                   elevatedSite.AllowUnsafeUpdates = true;
                   Guid listID = elevatedSite.Lists.Add(wikiName,
                       "A micro wiki", SPListTemplateType.GenericList);
                   SPList wikiList = elevatedSite.Lists[listID];
                   wikiList.WriteSecurity = 1; // All users can modify all items. 
                   wikiList.ReadSecurity = 1; // All users can modify all items.                                
                   //wikiList.Hidden = true;
                   wikiList.Fields.Add("Content", SPFieldType.Note, true);
                   wikiList.Update();
                   SPListItem homeWiki = wikiList.Items.Add();
                   homeWiki["Content"] = "Welcome to the MicroWiki!";
                   homeWiki["Title"] = wikiID;
                   homeWiki.Update();

                   elevatedSite.Update();
                }
             }
            });
         }
         return null;
      }

   }
}
