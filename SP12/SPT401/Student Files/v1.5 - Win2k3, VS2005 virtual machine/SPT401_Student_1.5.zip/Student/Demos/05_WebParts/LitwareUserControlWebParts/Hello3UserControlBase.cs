using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

namespace LitwareUserControlWebParts {

  public class Hello3UserControlBase : UserControl {

    // fields to sync with control tages in .ascx file
    protected HtmlTable tableMain;
    protected TextBox txtNumber1;
    protected TextBox txtNumber2;
    protected Button cmdAdd;
    protected Label lblSum;

    #region "Initialize User Control colors"

    public void SetBackgroundColor(string BackgroundColor) {
      tableMain.Style.Add(HtmlTextWriterStyle.BackgroundColor, BackgroundColor);
    }

    public void SetFontColor(string FontColor) {
      foreach (Control control in this.Controls) {
        SetControlFontColor(control, FontColor);
      }
    }

    private void SetControlFontColor(Control control, string FontColor) {
      if (control is WebControl) {
        ((WebControl)control).ForeColor = System.Drawing.Color.FromName(FontColor);
      }
      foreach (Control innerControl in control.Controls) {
        SetControlFontColor(innerControl, FontColor);
      }
    }

    #endregion

    protected override void OnLoad(EventArgs e) {
      txtNumber1.Focus();
    }

    // add back pointer to Web Part class
    protected Hello3 WebPartHost;
    protected bool PersistUserEntries;

    // expose public method to allow Web Part to transfer persisted values
    public void SetControlValues(double Number1, double Number2) {
      txtNumber1.Text = Number1.ToString();
      txtNumber2.Text = Number2.ToString();
    }

    // Allow Web Part to pass back-pointer to itself
    public void SetWebPartReference(Hello3 WebPartHost, bool PersistUserEntries) {
      this.WebPartHost = WebPartHost;
      this.PersistUserEntries = PersistUserEntries;
    }

    // write values entered by users into Web Part storage
    protected void PersistUserEntriesToWebPart() {
      SPWeb site = SPContext.Current.Web;
      string pageUrl = this.Context.Request.Url.AbsolutePath;
      SPFile page = site.Files[pageUrl];
      SPLimitedWebPartManager mgr = page.GetLimitedWebPartManager(PersonalizationScope.User);
      Hello3 webpart = (Hello3)mgr.WebParts[WebPartHost.ID];
      webpart.Number1Default = System.Convert.ToDouble(txtNumber1.Text);
      webpart.Number2Default = System.Convert.ToDouble(txtNumber2.Text);
      mgr.SaveChanges(webpart);
    }


    protected void cmdAdd_Click(object sender, EventArgs e) {
      double x1 = System.Convert.ToDouble(txtNumber1.Text);
      double x2 = System.Convert.ToDouble(txtNumber2.Text);
      double sum = x1 + x2;
      lblSum.Text = sum.ToString();
      txtNumber1.Focus();
      // pass values back to Web Part
      WebPartHost.Number1Default = x1;
      WebPartHost.Number2Default = x2;
      // persist new entries if requested by user
      if (PersistUserEntries) {
        PersistUserEntriesToWebPart();
      }
    }
 
  }
}
