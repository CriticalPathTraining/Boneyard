using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

namespace WebPartScratchPad {

  public class Pad1UserControlBase : UserControl {

    protected Label lblHello;
    protected Button cmdPressMe;
    protected Calendar Calendar1;

    protected override void OnLoad(EventArgs e) {
      lblHello.Text = "AJAX and SharePoint and Bears, Oh My!";
    }

    protected void cmdPressMe_Click(object sender, EventArgs e) {
      lblHello.Text = "The last AJAX postback was processed at " + DateTime.Now.ToLongTimeString();
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e) {
      lblHello.Text = Calendar1.SelectedDate.ToLongDateString();
    }
    
  }
}
