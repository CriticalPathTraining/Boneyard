using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace HelloAjaxWebParts {
  public class Hello1 : WebPart {

    private UpdatePanel updPanel;
    private Button btn;
    private Label lbl;
   
    protected override void CreateChildControls() {
      EnsureScriptManager();
      EnsureUpdatePanelFixups();

      // add update panel as child to web part
      updPanel = new UpdatePanel();
      updPanel.ID = this.ID + "_AjaxUpdatePanel";
      updPanel.ChildrenAsTriggers = true;
      updPanel.UpdateMode = UpdatePanelUpdateMode.Conditional;
      this.Controls.Add(updPanel);
      
      // add other controls as children of update panel
      btn = new Button();
      btn.Text = "Press for current time";
      btn.Click+=new EventHandler(btn_Click);
      updPanel.ContentTemplateContainer.Controls.Add(btn);
      updPanel.ContentTemplateContainer.Controls.Add(new LiteralControl("<br/><br/>"));
      lbl = new Label();
      lbl.Font.Size = new FontUnit(14);
      if (!this.Page.IsPostBack) {
        lbl.Text = DateTime.Now.ToLongTimeString();
      }
      updPanel.ContentTemplateContainer.Controls.Add(lbl);     
    }

    void btn_Click(object sender, EventArgs e) {
      lbl.Text = DateTime.Now.ToLongTimeString();
    }

    #region "AJAX integration helper methods

    private void EnsureScriptManager() {
      if (ScriptManager.GetCurrent(this.Page) == null) {
        this.Controls.Add(new ScriptManager());
      }
    }

    private void EnsureUpdatePanelFixups() {
      if (this.Page.Form != null) {
        string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
        if (formOnSubmitAtt == "return _spFormOnSubmitWrapper();") {
          this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
        }
      }
      ScriptManager.RegisterStartupScript(this, this.GetType(), "UpdatePanelFixup", "_spOriginalFormAction = document.forms[0].action; _spSuppressFormOnSubmitWrapper=true;", true);
    }

    #endregion

  }
}
