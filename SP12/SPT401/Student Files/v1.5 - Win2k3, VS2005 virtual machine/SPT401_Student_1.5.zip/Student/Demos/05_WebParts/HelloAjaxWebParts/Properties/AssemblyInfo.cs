﻿using System.Reflection;
using System.Security;

[assembly: AllowPartiallyTrustedCallers()]
[assembly: AssemblyVersion("1.0.0.0")]

