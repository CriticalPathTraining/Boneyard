
function CallWebService() {  
    HelloAjaxWebParts.HelloWebService.set_path(window.wsUrl);
    HelloAjaxWebParts.HelloWebService.HelloWorld(WebServiceCallback);
}
  
function WebServiceCallback(result) {
    var display = document.getElementById("DisplaySpan");
    display.innerHTML = result;
}