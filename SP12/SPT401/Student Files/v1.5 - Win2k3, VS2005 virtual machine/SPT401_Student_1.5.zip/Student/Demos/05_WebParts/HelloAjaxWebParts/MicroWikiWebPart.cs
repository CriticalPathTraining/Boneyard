using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint;
using System.Web.UI.WebControls.WebParts;

namespace HelloAjaxWebParts {
   public class MicroWikiWebPart : WebPart {

      private ScriptManager scriptMan;
      public ScriptManager CurrentScriptManager {
         get {
            if (scriptMan == null) {
               scriptMan = ScriptManager.GetCurrent(this.Page);
               if (scriptMan == null) {
                  scriptMan = new ScriptManager();
                  this.Controls.Add(scriptMan);
               }
            }
            return scriptMan;
         }
      }

      private const string scriptFormat = @"if (window.WikiControlTemplates == null){{
    window.WikiControlTemplates = new Array();
    }}
    var xc = new Object();
    xc.Control = 'WikiComponentControl{0}';
    xc.WikiID = 'home';   
    window.WikiControlTemplates.push(xc);
    ";

      // Register controls and scripts
      protected override void CreateChildControls() {        
         base.CreateChildControls();
         ScriptReference editableControlScript = new ScriptReference(
             "HelloAjaxWebParts.WebPartResources.EditableControl.js", this.GetType().Assembly.FullName);
         this.CurrentScriptManager.Scripts.Add(editableControlScript);

         ScriptReference wikiControlScript = new ScriptReference(
             "HelloAjaxWebParts.WebPartResources.WikiControl.js", this.GetType().Assembly.FullName);
         this.CurrentScriptManager.Scripts.Add(wikiControlScript);

         ServiceReference serviceReference = new ServiceReference(
             SPContext.Current.Web.Url + "/_vti_bin/TPG/WikiWebService.asmx");
         this.CurrentScriptManager.Services.Add(serviceReference);

         this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "spweburl",
            string.Format("window.spWebUrl='{0}';", SPContext.Current.Web.Url), true);

         this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "css",
            @"<style type='text/css'>.WIKILINK {color:blue;cursor:pointer;}</style>", false);
      }

      protected override void RenderContents(HtmlTextWriter writer) {
         base.RenderContents(writer);

         writer.Write(@"<div id=""WikiComponentControl{0}"" ></div>", this.ClientID);
         writer.Write(@"<script type=""text/javascript"" language=""javascript"">");
         writer.Write(scriptFormat, this.ClientID);
         writer.Write(@"</script>");
      }
   }
}
