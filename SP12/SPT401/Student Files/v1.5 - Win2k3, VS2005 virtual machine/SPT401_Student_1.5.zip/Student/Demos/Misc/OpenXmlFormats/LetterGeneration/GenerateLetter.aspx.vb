Imports System.Data
Imports System.IO
Imports System.IO.Packaging
Imports System.Text
Imports System.Xml
Imports System.Xml.Serialization

Partial Class GenerateLetter
  Inherits System.Web.UI.Page

  Private Shared strRelDataStore As String = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml"
  Private Shared strRelRoot As String = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"


  Sub GenerateLetterDocument()
    '*** read template .docx file into memory stream
    Dim strDocument As Stream = New MemoryStream
    Dim strDocTemplate As Stream = New FileStream(Server.MapPath("App_Data/LetterTemplate.docx"), FileMode.Open)
    Dim DocTemplateReader As BinaryReader = New BinaryReader(strDocTemplate)
    Dim DocumentWriter As BinaryWriter = New BinaryWriter(strDocument)
    DocumentWriter.Write(DocTemplateReader.ReadBytes(CInt(strDocTemplate.Length)))
    DocumentWriter.Flush()
    DocTemplateReader.Close()
    strDocTemplate.Dispose()
    '*** open .docx file in memory stream as package file
    Dim pkgFile As Package = Package.Open(strDocument, FileMode.Open, FileAccess.ReadWrite)
    '*** retrieve package part with XML data
    Dim uriData As Uri = New Uri("/customXML/item1.xml", UriKind.Relative)
    Dim pkgprtData As PackagePart = pkgFile.GetPart(uriData)
    '*** replace package part with request-specific XML data
    Dim targetStream As Stream = pkgprtData.GetStream()
    targetStream.SetLength(0)
    Dim writer As New StreamWriter(targetStream)
    writer.Write(GetLetterXml)
    writer.Flush()
    targetStream.Close()
    '*** close package file to finalize writing to memory buffer
    pkgFile.Close()
    '*** transfer package file memory buffer to output stream
    Response.ClearContent()
    Response.ClearHeaders()
    Response.AddHeader("content-disposition", "attachment; filename=document.docx")
    Me.Response.ContentType = "application/vnd.ms-word.document.12"
    Response.ContentEncoding = System.Text.Encoding.UTF8
    strDocument.Position = 0
    Litware.Utilties.CopyStream(strDocument, Response.OutputStream)
    Response.Flush()
    Response.Close()

  End Sub

  Function GetLetterXml() As String

    '*** get user input data
    Dim CustomerID As String = cboCustomer.SelectedValue
    Dim LetterTypeTitle As String = cboLetterType.SelectedValue
    Dim EmployeeID As String = cboEmployee.SelectedValue

    '*** create customer letter object
    Dim letter As New LitwareLetter

    letter.Customer = New LitwareLetterCustomer
    For Each row As DataRowView In CustomerDataSource.Select(New DataSourceSelectArguments())
      If CustomerID = row("CustomerID") Then
        letter.Customer.Company = row("Company")
        letter.Customer.ContactFirstName = row("ContactFirstName")
        letter.Customer.ContactLastName = row("ContactLastName")
        letter.Customer.Address = row("Address")
        letter.Customer.City = row("City")
        letter.Customer.State = row("State")
        letter.Customer.Zip = row("Zipcode")
        Exit For
      End If
    Next

    letter.Date = DateTime.Today.ToString("MMMM d, yyyy")
    For Each row As DataRowView In LetterDataSource.Select(New DataSourceSelectArguments())
      If LetterTypeTitle = row("Title") Then
        letter.Body = row("Body")
        Exit For
      End If
    Next


    letter.Employee = New LitwareLetterEmployee
    For Each row As DataRowView In EmployeeDataSource.Select(New DataSourceSelectArguments())
      If EmployeeID = row("EmployeeID") Then
        letter.Employee.Name = row("Name")
        letter.Employee.Title = row("Title")
        Exit For
      End If
    Next



    Dim buffer As New MemoryStream
    Dim writer As New StreamWriter(buffer, Encoding.UTF8)
    Dim serializer As XmlSerializer = New XmlSerializer(GetType(LitwareLetter))
    serializer.Serialize(writer, letter)
    buffer.Position = 0
    Dim reader As New StreamReader(buffer)
    Dim xmlDoc As String = reader.ReadToEnd()
    writer.Dispose()
    reader.Dispose()
    buffer.Dispose()


    Return xmlDoc


  End Function

  Protected Sub cmdGenerateLetter_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGenerateLetter.Click

    GenerateLetterDocument()

  End Sub
End Class
