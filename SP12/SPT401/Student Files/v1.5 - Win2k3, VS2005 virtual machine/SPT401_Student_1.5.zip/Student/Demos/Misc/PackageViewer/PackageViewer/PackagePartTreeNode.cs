using System;
using System.Collections.Generic;
using System.Text;

namespace PackageViewer {
  class PackagePartTreeNode : UriTreeNode {
    #region Private Fields
    public string m_contentType;
    public string m_relationshipType;
    public string m_relationshipId;
    #endregion

    #region Constructor
    public PackagePartTreeNode(Uri relativeUri, Uri partUri, string contentType, string relationshipType, string relationshipId)
      : base(partUri) {
      base.Text = relativeUri.ToString();
      base.ImageIndex = 1;
      base.SelectedImageIndex = 1;

      m_contentType = contentType;
      m_relationshipType = relationshipType;
      m_relationshipId = relationshipId;
    }
    #endregion

    #region Public Properties
    public string ContentType {
      get { return m_contentType; }
    }

    public string RelationshipType {
      get { return m_relationshipType; }
    }

    public string RelationshipId {
      get { return m_relationshipId; }
    }
    #endregion
  }
}
