Public Class PainControl

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

    Dim doc As Word.Document = ThisAddIn.App.ActiveDocument
    doc.Range.InsertParagraphAfter()
    doc.Range.InsertParagraphAfter()
    doc.Range.InsertAfter("Company: " & Me.TextBox1.Text)
    doc.Range.InsertParagraphAfter()
    doc.Range.InsertAfter("Date: " & Me.MonthCalendar1.SelectionStart.ToLongDateString())

  End Sub

End Class
