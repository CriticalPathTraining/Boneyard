<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PainControl
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.Button1 = New System.Windows.Forms.Button
    Me.MonthCalendar1 = New System.Windows.Forms.MonthCalendar
    Me.TextBox1 = New System.Windows.Forms.TextBox
    Me.Label1 = New System.Windows.Forms.Label
    Me.SuspendLayout()
    '
    'Button1
    '
    Me.Button1.Location = New System.Drawing.Point(14, 18)
    Me.Button1.Name = "Button1"
    Me.Button1.Size = New System.Drawing.Size(173, 23)
    Me.Button1.TabIndex = 0
    Me.Button1.Text = "Generate PO"
    Me.Button1.UseVisualStyleBackColor = True
    '
    'MonthCalendar1
    '
    Me.MonthCalendar1.Location = New System.Drawing.Point(9, 81)
    Me.MonthCalendar1.Name = "MonthCalendar1"
    Me.MonthCalendar1.TabIndex = 1
    '
    'TextBox1
    '
    Me.TextBox1.Location = New System.Drawing.Point(58, 49)
    Me.TextBox1.Name = "TextBox1"
    Me.TextBox1.Size = New System.Drawing.Size(129, 20)
    Me.TextBox1.TabIndex = 2
    Me.TextBox1.Text = "Acme Corp"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(11, 52)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(41, 13)
    Me.Label1.TabIndex = 3
    Me.Label1.Text = "Vendor"
    '
    'PainControl
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.TextBox1)
    Me.Controls.Add(Me.MonthCalendar1)
    Me.Controls.Add(Me.Button1)
    Me.Name = "PainControl"
    Me.Size = New System.Drawing.Size(206, 399)
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents Button1 As System.Windows.Forms.Button
  Friend WithEvents MonthCalendar1 As System.Windows.Forms.MonthCalendar
  Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
  Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
