Imports Tools = Microsoft.Office.Tools


Public Class ThisAddIn

  Public Shared App As Word.Application

  Shared AddInInst As ThisAddIn

  Shared Sub AddTaskPane(ByVal uc As UserControl, ByVal caption As String)
    Dim tp As Tools.CustomTaskPane = AddInInst.CustomTaskPanes.Add(uc, caption)
    tp.Visible = True
  End Sub

  Private Sub ThisAddIn_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup

    App = Me.Application
    AddInInst = Me

  End Sub

  Private Sub ThisAddIn_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

  End Sub

  Private Sub Application_DocumentOpen(ByVal Doc As Microsoft.Office.Interop.Word.Document) Handles Application.DocumentOpen

  End Sub
End Class
