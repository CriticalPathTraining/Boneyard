using System;
using Microsoft.SharePoint;
using System.IO;
using System.Xml.Serialization;

namespace DocumentManager {
  public class ItemEventHandler : SPItemEventReceiver {
public override void ItemAdded(SPItemEventProperties properties) {

  XmlSerializer serializer = new XmlSerializer(typeof(LeadSheet));
  SPWeb site = properties.OpenWeb();
  SPList targetList = site.Lists["Sales Leads"];
  SPFile docFile = properties.ListItem.File;
  using (Stream documentStream = docFile.OpenBinaryStream()) {
    LeadSheet sheet = (LeadSheet)serializer.Deserialize(documentStream);
    foreach (Lead lead in sheet.Lead) {
      SPListItem newItem = targetList.Items.Add();
      newItem["Lead Name"] = lead.Name;
      newItem["Phone"] = lead.Phone;
      newItem["Email"] = lead.Email;
      newItem.Update();
    }
  }
}
  }
}
