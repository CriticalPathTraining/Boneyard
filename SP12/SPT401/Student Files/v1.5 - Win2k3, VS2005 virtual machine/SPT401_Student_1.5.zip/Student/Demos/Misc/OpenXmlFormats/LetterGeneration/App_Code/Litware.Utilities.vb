Imports System.IO

Namespace Litware
    Public Class Utilties
        Shared Sub CopyStream(ByVal source As Stream, ByVal target As Stream)
            Dim b As Integer = source.ReadByte()
            While b <> -1
                target.WriteByte(CByte(b))
                b = source.ReadByte()
            End While
        End Sub
    End Class
End Namespace
