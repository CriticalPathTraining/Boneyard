using System;
using System.IO;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;

namespace LitwareWorkflows {
  public class LitwareApprovalModificationForm : LayoutsPageBase {

    // controls
    protected PeopleEditor pickerApprover;
    protected RadioButton radInternalApproval;
    protected RadioButton radExternalApproval;
    protected InputFormTextBox txtInstructions;

    // form-level variables
    protected SPList List;
    protected SPListItem ListItem;
    protected SPWorkflow WorkflowInstance;
    protected Guid ModificationID;
    protected SPWorkflowModification Modification;
    protected string ContextData;
    protected string ListItemName;
    protected string ListItemUrl;
    protected SPContentType CType;
    protected SPWorkflowAssociation WorkflowAssociation;
    protected SPWorkflowTemplate WorkflowTemplate;
    protected string WorkflowAssociationName;

    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected override void OnLoad(EventArgs e) {

      // Get Form Parameters
      string paramList = Request.Params["List"];
      string paramID = Request.Params["ID"];
      string paramWorkflowInstanceID = Request.Params["WorkflowInstanceID"];
      string paramModificationID = Request.Params["ModificationID"];

      // create WSS object
      List = Web.Lists[new Guid(paramList)];
      ListItem = List.GetItemById(Convert.ToInt32(paramID));
      WorkflowInstance = ListItem.Workflows[new Guid(paramWorkflowInstanceID)];
      ModificationID = new Guid(paramModificationID);
      Modification = WorkflowInstance.Modifications[ModificationID];
      ContextData = Modification.ContextData;

      WorkflowAssociation = List.WorkflowAssociations[WorkflowInstance.AssociationId];
      if (WorkflowAssociation == null) { // it is an association on a content type
        SPContentTypeId CTypeID = (SPContentTypeId)ListItem["ContentTypeId"];
        CType = List.ContentTypes[CTypeID];
        WorkflowAssociation = CType.WorkflowAssociations[WorkflowInstance.AssociationId];
      }

      // ensure there is a valid WorkflowAssociation
      if (WorkflowAssociation == null) {
        throw new SPException("Error loading modification form: could not find workflow association");
      }

      // get more info on workflow association and workflow template
      WorkflowAssociationName = WorkflowAssociation.Name;
      WorkflowTemplate = Web.WorkflowTemplates[WorkflowAssociation.BaseId];

      // set URL for workflow item
      if (ListItem.File == null)
        ListItemUrl = Web.Url + ListItem.ParentList.Forms[PAGETYPE.PAGE_DISPLAYFORM].ServerRelativeUrl + "?ID=" + ListItem.ID.ToString();
      else
        ListItemUrl = Web.Url + "/" + ListItem.File.Url;

      // set Item Name
      if (List.BaseType == SPBaseType.DocumentLibrary) {
        // if this is a doc lib, remove the extension of the file
        ListItemName = (string)ListItem["Name"];
        int i = ListItemName.LastIndexOf('.');
        if (i > 0)
          ListItemName = ListItemName.Substring(0, i);
      }
      else
        ListItemName = (string)ListItem["Title"];

      PageTitle = "Modify Workflow Instance";
      PageTitleInArea = "Modify Litware Approval Workflow Instance on " + ListItemName;
      PageDescription = "Make changes and click OK to modify this workflow instance on the item " + ListItemName;

    }

    protected void PopulateFormDataFromString(string ContextData) {
      XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
      XmlTextReader reader = new XmlTextReader(new StringReader(ContextData));
      LitwareApprovalWorkflowData FormData = (LitwareApprovalWorkflowData)serializer.Deserialize(reader);

      pickerApprover.CommaSeparatedAccounts = FormData.Approver;

      if (FormData.ApprovalScope.Equals("Internal")) {
        radInternalApproval.Checked = true;
      }
      else {
        radExternalApproval.Checked = true;
      }
      txtInstructions.Text = FormData.Instructions;
    }

    protected string SerializeFormDataToString() {

      LitwareApprovalWorkflowData FormData = new LitwareApprovalWorkflowData();

      PickerEntity ApproverEntity = (PickerEntity)pickerApprover.Entities[0];
      FormData.Approver = ApproverEntity.Key;

      if (radInternalApproval.Checked) {
        FormData.ApprovalScope = "Internal";
      }
      else {
        FormData.ApprovalScope = "External";
      }
      FormData.Instructions = txtInstructions.Text;
      FormData.Comments = "";

      using (MemoryStream stream = new MemoryStream()) {
        XmlSerializer serializer = new XmlSerializer(typeof(LitwareApprovalWorkflowData));
        serializer.Serialize(stream, FormData);
        stream.Position = 0;
        byte[] bytes = new byte[stream.Length];
        stream.Read(bytes, 0, bytes.Length);
        return Encoding.UTF8.GetString(bytes);
      }
    }

    public void cmdCancel_OnClick(object sender, EventArgs e) {
      SPUtility.Redirect(List.DefaultViewUrl,
                         SPRedirectFlags.Default,
                         HttpContext.Current);
    }

    public void cmdSubmit_OnClick(object sender, EventArgs e) {

      try {
        ContextData = SerializeFormDataToString();
        Web.Site.WorkflowManager.ModifyWorkflow(WorkflowInstance,
                                                Modification,
                                                ContextData);        
      }
      catch (Exception ex) {
        SPException spEx = ex as SPException;

        string errorString;

        if (spEx != null && spEx.ErrorCode == -2130575205 /* SPErrorCode.TP_E_WORKFLOW_ALREADY_RUNNING */)
          errorString = SPResource.GetString(Strings.WorkflowFailedAlreadyRunningMessage);
        else if (spEx != null && spEx.ErrorCode == -2130575339 /* SPErrorCode.TP_E_VERSIONCONFLICT */)
          errorString = SPResource.GetString(Strings.ListVersionMismatch);
        else if (spEx != null && spEx.ErrorCode == -2130575338 /* SPErrorCode.TP_E_LISTITEMDELETED */)
          errorString = spEx.Message;
        else
          errorString = SPResource.GetString(Strings.WorkflowFailedStartMessage);

        SPUtility.Redirect("Error.aspx",
                           SPRedirectFlags.RelativeToLayoutsPage,
                           HttpContext.Current,
                           "ErrorText=" + SPHttpUtility.UrlKeyValueEncode(errorString));
      }

      SPUtility.Redirect(List.DefaultViewUrl,
                        SPRedirectFlags.Default,
                        HttpContext.Current);
    }

    protected override void OnPreRender(EventArgs e) {
      this.PopulateFormDataFromString(ContextData);
    }


  }
}
