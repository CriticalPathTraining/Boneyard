using System;

namespace LitwareWebPartsLab
{
  public class RevenueWebPart
  {

  }
}
