using System;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;

namespace LitwareWebPartsLab
{
    public class RevenueWebPart: WebPart
    {

        protected bool _ShowTextAsBold = true;

        [
         Personalizable(),
         WebBrowsable(true),
         WebDisplayName("Show Text As Bold"),
         WebDescription("Enable to turn on bold font output")
        ]
        public bool ShowTextAsBold
        {
            get { return _ShowTextAsBold; }
            set { _ShowTextAsBold = value; }
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            SPWeb ProjectManagementSite = SPContext.Current.Web;
            SPList Projects = ProjectManagementSite.Lists["Projects"];
            decimal TotalRevenue = 0;
            foreach (SPListItem Project in Projects.Items)
            {
                TotalRevenue += Convert.ToDecimal(Project["Contract Amount"]);
            }

            if (_ShowTextAsBold)
            {
                writer.AddStyleAttribute(HtmlTextWriterStyle.FontWeight, "Bold");
                writer.AddStyleAttribute(HtmlTextWriterStyle.FontSize, "12pt");
                writer.AddStyleAttribute(HtmlTextWriterStyle.Color, "Red");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write("Total Revenue: " + TotalRevenue.ToString("$#,###"));
                writer.RenderEndTag(); // </Span>
            }
            else
            {
                writer.Write("Total Revenue: " + TotalRevenue.ToString("$#,###"));
            }
        }
    }
}
