using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Lab3 {

  public class DocumentInfo : LayoutsPageBase {

    // add control fields to match controls tags on .aspx page
    protected SPGridView grdSiteProperties;

    protected override void OnLoad(EventArgs e) {
      
      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      
      // program against controls on .aspx page
      PropertyCollectionBinder binder = new PropertyCollectionBinder();

      // remove the next line and begin your work here

      // get list information
      string ListId = Request.QueryString["ListId"];
      binder.AddProperty("List ID", ListId);
      SPList list = site.Lists[new Guid(ListId)];
      binder.AddProperty("List Title", list.Title);
      binder.AddProperty("List Root Folder", list.RootFolder.Url);

      // get list item information
      string ItemId = Request.QueryString["ItemId"];
      binder.AddProperty("Item ID", ItemId);
      SPListItem item = list.Items.GetItemById(Convert.ToInt32(ItemId));
      binder.AddProperty("Item Name", item.Name);
      binder.AddProperty("Item URL", item.Url);

      // provided the list is a Document Library, get the fine info for the list item
      if (list is SPDocumentLibrary)
      {
          SPDocumentLibrary documentLibrary = (SPDocumentLibrary)list;
          binder.AddProperty("Document Template Url", documentLibrary.DocumentTemplateUrl);
          SPFile file = site.GetFile(item.Url);
          binder.AddProperty("Document Author", file.Author.Name);
          binder.AddProperty("Document Size", file.TotalLength.ToString("0,###") + " bits");
          binder.AddProperty("Last Modified", "By " + file.ModifiedBy.Name +
                                              " on " + file.TimeLastModified.ToLocalTime().ToString());
          binder.AddProperty("File Checkout Status", file.CheckOutStatus.ToString());
      }


      binder.BindGrid(grdSiteProperties);

    }

  }
}
