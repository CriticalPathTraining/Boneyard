Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls

Public Class DocumentInfo
    Inherits LayoutsPageBase

' add control fields to match controls tags on .aspx page
    Protected grdSiteProperties As SPGridView

    Protected Overrides Sub OnLoad(ByVal e As EventArgs)

        ' get current site and web
        Dim siteCollection As SPSite = Me.Site
        Dim site As SPWeb = Me.Web

        ' program against controls on .aspx page
        Dim binder As PropertyCollectionBinder = New PropertyCollectionBinder()

        ' remove the next line and begin your work here
        binder.AddProperty("Test Property", "Test Value")

        binder.BindGrid(grdSiteProperties)


    End Sub
End Class

