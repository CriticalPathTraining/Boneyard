﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using ECM401.ContentTypes;
using Microsoft.SharePoint;

namespace SampleContentTypes
{
    [ SharePointContentType(BaseType="Document",
        Description="My Sample Content Type",
        Group="ECM401",
        Name="MyContentType",
        Sealed=false) ]
    public class SampleContentType : SPItemEventReceiver
    {
        [FieldRef("Dept",Description="The name of the department",DisplayName="Sample Department")]
        public string Department { get; set; }
        public string Manager { get; set; }

        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            Trace.WriteLine("SampleContentType - ItemAdded");
        }
    }
}
