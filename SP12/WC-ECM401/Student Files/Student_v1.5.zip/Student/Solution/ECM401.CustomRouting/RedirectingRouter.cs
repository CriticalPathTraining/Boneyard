﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using RM=Microsoft.Office.RecordsManagement.RecordsRepository;
using Microsoft.SharePoint;
using ECM401.RecordsManagement;

namespace ECM401.CustomRouting
{
    [Name("ECM401 Redirecting Router")]
    public class RedirectingRouter : SharePointRouter
    {
        // Write exceptions to the trace log.
        void HandleException(Exception x)
        {
            Log(string.Format("Exception occurred: {0}", x.ToString()));
        }
        
        /// <summary>
        /// Custom implementation that redirects incoming records
        /// based on the metadata properties attached to the file.
        /// </summary>
        protected override RM.RouterResult OnSubmitFile(
            string recordSeries, 
            string sourceUrl, 
            string userName, 
            ref byte[] fileToSubmit,
            ref RM.RecordsRepositoryProperty[] properties, 
            ref SPList destination, 
            ref string resultDetails)
        {
            // setup the default result...
            RM.RouterResult result = RM.RouterResult.SuccessContinueProcessing;
            try
            {
                // get the content type from the property array
                string contentTypeName = string.Empty;
                foreach (RM.RecordsRepositoryProperty property in properties)
                    if (property.Name.Equals("ContentType")) contentTypeName = property.Value;

                // use the content type name and properties to determine the correct destination
                SPList newDestination = destination;
                if (AdjustDestination(contentTypeName, sourceUrl, userName, ref properties, ref newDestination))
                {
                    string sourceFileName = Path.GetFileNameWithoutExtension(sourceUrl);

                    // store the file into the new destination
                    if (SaveDocument(contentTypeName, sourceUrl, userName, ref fileToSubmit,
                        ref properties, ref newDestination, ref resultDetails))
                    {
                        // succeeded in saving the document...
                        Log(string.Format("Saved '{0}' to '{1}'", sourceFileName, destination.Title));
                    }
                    else
                    {
                        // failed to save the document...
                        Log(string.Format("Document save failed for '{0}'", sourceFileName));
                    }

                    // return success but cancel further processing, since we
                    // are taking responsibility for storing the file...
                    result = RM.RouterResult.SuccessCancelFurtherProcessing;
                }
                else
                {
                    // redirection is not required
                    // continue processing normally
                    Log(string.Format("Redirection not required for content type '{0}'", contentTypeName));
                    result = RM.RouterResult.SuccessContinueProcessing;
                }
            }
            catch (Exception x)
            {
                // cancel processing if we encounter an error...
                HandleException(x);
                result = RM.RouterResult.SuccessCancelFurtherProcessing;
            }
            return result;
        }

        // Attempts to adjust the destination list based on incoming metadata.
        bool AdjustDestination(string contentTypeName, string sourceUrl, string userName,
            ref RM.RecordsRepositoryProperty[] properties,
            ref SPList destination)
        {
            // if no content type name was provided, then no special processing is possible...
            if (string.IsNullOrEmpty(contentTypeName))
                return false;

            // if the content type name matches an existing document library, then use that
            // as the new destination library...
            SPList targetList = SharePointList.Find(destination.ParentWeb, contentTypeName);
            if (targetList != null)
            {
                Log(string.Format("Reusing existing list '{0}'", targetList.Title));
                destination = targetList;
            }
            else
            {
                // target list does not exist, so create a new document library...
                destination = SharePointList.Create(destination.ParentWeb,
                    SPListTemplateType.DocumentLibrary, contentTypeName, "Created by the RedirectingRouter");
                // no special fields added to the default "Document" content type
                destination.ContentTypesEnabled = true;
                destination.OnQuickLaunch = true;
                destination.Update();
            }

            return true;
        }

        // Stores the document using metadata to determine where to place it within the target list.
        bool SaveDocument(string contentTypeName, string sourceUrl, string userName,
            ref byte[] fileToSubmit, ref Microsoft.Office.RecordsManagement.RecordsRepository.RecordsRepositoryProperty[] properties,
            ref SPList destination, ref string resultDetails)
        {
            SPFolder targetFolder = null;
            SPListItem item = null;
            SPFile file = null;
            string fileName = Path.GetFileNameWithoutExtension(sourceUrl);

            try
            {
                // get a folder in the destination list using the user name
                int pos = userName.LastIndexOf('\\');
                string actualUserName = userName.Substring(pos >= 0 ? pos : 0);
                targetFolder = SharePointList.CreateFolder(destination, actualUserName);
            }
            catch (Exception x1)
            {
                HandleException(new Exception("Failed to get target folder", x1));
            }

            try
            {
                // add the document to the folder
                file = targetFolder.Files.Add(fileName, fileToSubmit);
                item = file.Item;
            }
            catch (Exception x2)
            {
                HandleException(new Exception("Failed to add document to folder", x2));
            }

            // set the content type if recognized...
            try
            {
                SPContentType ct = destination.ContentTypes[contentTypeName];
                item["ContentTypeId"] = ct.Id;
                item.Update();
            }
            catch (Exception x3)
            {
                HandleException(new Exception("Failed to update content type id", x3));
            }

            // copy any matching properties into the new item...
            foreach (RM.RecordsRepositoryProperty property in properties)
            {
                if (item.Fields.ContainsField(property.Name))
                {
                    try
                    {
                        // check the validity of the target field...
                        SPField field = item.Fields.GetField(property.Name);
                        if (field != null && !field.ReadOnlyField &&
                            (field.Type != SPFieldType.Invalid) &&
                            (field.Type != SPFieldType.WorkflowStatus) &&
                            (field.Type != SPFieldType.File) &&
                            (field.Type != SPFieldType.Computed) &&
                            (field.Type != SPFieldType.User) &&
                            (field.Type != SPFieldType.Lookup) &&
                            (!field.InternalName.Equals("ContentType")))
                        {
                            item[property.Name] = property.Value;
                        }
                    }
                    catch (Exception x)
                    {
                        resultDetails = string.Format("Exception occurred while saving '{0}': {1}", fileName, x.Message);
                        return false;
                    }
                }
            }

            item.Update();
            return true;
        }

    }
}
