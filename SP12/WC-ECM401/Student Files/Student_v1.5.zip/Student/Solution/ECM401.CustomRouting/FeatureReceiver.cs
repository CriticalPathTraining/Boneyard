﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using ECM401.RecordsManagement;

namespace ECM401.CustomRouting
{
    /// <summary>
    /// Handles events during feature installation and activation.
    /// </summary>
    public class FeatureReceiver : SPFeatureReceiver
    {
        /// <summary>
        /// Override the feature activation event to declare custom routers.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties) 
        {
            using (SPWeb web = properties.Feature.Parent as SPWeb)
            {
                SharePointRouter.AddRouter(web, typeof(FilteringRouter));
                SharePointRouter.AddRouter(web, typeof(TrackingRouter));
                SharePointRouter.AddRouter(web, typeof(RedirectingRouter));
            }
        }

        /// <summary>
        /// Override the feature deactivating event to remove custom routers.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
            using (SPWeb web = properties.Feature.Parent as SPWeb)
            {
                SharePointRouter.RemoveRouter(web, typeof(FilteringRouter));
                SharePointRouter.RemoveRouter(web, typeof(TrackingRouter));
                SharePointRouter.RemoveRouter(web, typeof(RedirectingRouter));
            }
        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    }
}
