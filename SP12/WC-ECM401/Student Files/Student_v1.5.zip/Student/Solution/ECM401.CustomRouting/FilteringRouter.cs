﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Office.RecordsManagement.RecordsRepository;
using WSS=Microsoft.SharePoint;
using ECM401.RecordsManagement;

namespace ECM401.CustomRouting
{
    [Name("ECM401 Filtering Router")]
    public class FilteringRouter : SharePointRouter
    {
        /// <summary>
        /// Custom implementation that validates the submitted files contents.
        /// </summary>
        protected override RouterResult OnSubmitFile(
            string recordSeries, 
            string sourceUrl, 
            string userName, 
            ref byte[] fileToSubmit, 
            ref RecordsRepositoryProperty[] properties, 
            ref WSS.SPList destination, 
            ref string resultDetails)
        {
            // setup the default result...
            RouterResult result = RouterResult.SuccessContinueProcessing;
            try
            {
                if (!(ValidateContent(ref resultDetails, ref fileToSubmit)
                    && ValidateMetadata(ref resultDetails, ref properties)))
                {
                    result = RouterResult.RejectFile;
                }
            }
            catch (Exception x)
            {
                EventLog.WriteEntry("FilteringRouter", String.Format("Exception occurred: {0}", x.Message));
                // Cancel if we encounter problems.
                result = RouterResult.SuccessCancelFurtherProcessing;
            }
            return result;
        }

        /// <summary>
        /// Checks the file content for validity.  This can be any algorithm you like.
        /// </summary>
        /// <param name="resultDetails"></param>
        /// <param name="fileToSubmit"></param>
        /// <returns></returns>
        bool ValidateContent(ref string resultDetails, ref byte[] fileToSubmit)
        {
            return true;
        }

        /// <summary>
        /// Checks the metadata properties for validity and consistency.
        /// </summary>
        /// <param name="resultDetails"></param>
        /// <param name="properties"></param>
        /// <returns></returns>
        bool ValidateMetadata(ref string resultDetails, ref RecordsRepositoryProperty[] properties)
        {
            foreach (RecordsRepositoryProperty property in properties)
            {
                if (property.Name.Equals("ContentType"))
                {
                    // Only accept certain content types?
                    if (property.Value.Equals("Document"))
                    {
                        Log("Rejecting generic document.");
                        resultDetails = "Generic documents are not allowed.";
                        return false;
                    }
                }
                else if (property.Name.Equals("File_x0020_Type"))
                {
                    // Only accept certain file extensions?
                    if (property.Value.Equals("xls"))
                    {
                        Log("Rejecting Excel file.");
                        resultDetails = "Excel Files are not allowed.";
                        return false;
                    }
                }
                else if (property.Name.Equals("_IsCurrentVersion"))
                {
                    // Only accept current versions of documents.
                    if (!property.Value.Equals("True"))
                    {
                        Log("Rejecting older version.");
                        resultDetails = "Only current versions of documents can be stored in the repository.";
                        return false;
                    }
                }
            }
            return true;
        }

    }
}
