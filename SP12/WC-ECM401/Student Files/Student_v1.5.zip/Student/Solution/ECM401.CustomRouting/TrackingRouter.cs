﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.Office.RecordsManagement.RecordsRepository;
using WSS=Microsoft.SharePoint;
using ECM401.RecordsManagement;

namespace ECM401.CustomRouting
{
    [Name("ECM401 Tracking Router")]
    public class TrackingRouter : SharePointRouter
    {
        /// <summary>
        /// A custom router implementation that facilitates creating a list
        /// and writing an entry to it.
        /// </summary>
        internal class RecordRouterHistoryList
        {
            const string listTitle = "Record Routing History";
            const string listDescription = "This list is used by the TrackingRouter to record incoming parameter values.";

            const string colRecordSeries = "Record Series";
            const string colSourceUrl = "Source Url";
            const string colUserName = "User Name";
            const string colFileSize = "File Size";
            const string colDestination = "Destination";

            private WSS.SPList m_list = null;

            public RecordRouterHistoryList(WSS.SPList sourceList)
            {
                // Create the list in the same web as the source list.
                WSS.SPWeb web = sourceList.ParentWeb;

                // Create or open a custom list
                try { m_list = web.Lists[listTitle]; }
                catch { }
                if (m_list == null)
                {
                    try
                    {
                        m_list = web.Lists[
                            web.Lists.Add(listTitle, listDescription, WSS.SPListTemplateType.GenericList)
                            ];

                        m_list.Fields.Add(colRecordSeries, WSS.SPFieldType.Text, false);
                        m_list.Fields.Add(colSourceUrl, WSS.SPFieldType.URL, false);
                        m_list.Fields.Add(colUserName, WSS.SPFieldType.Text, false);
                        m_list.Fields.Add(colFileSize, WSS.SPFieldType.Number, false);
                        m_list.Fields.Add(colDestination, WSS.SPFieldType.Text, false);
                        m_list.OnQuickLaunch = true;
                        m_list.Update();
                    }
                    catch { }
                }
            }

            /// <summary>
            /// Writes an entry to the list.
            /// </summary>
            public void WriteEntry(
                string recordSeries,
                string sourceUrl,
                string userName,
                int fileSize,
                string destination)
            {
                try
                {
                    WSS.SPListItem item = m_list.Items.Add();
                    item[colRecordSeries] = recordSeries;
                    item[colSourceUrl] = sourceUrl;
                    item[colUserName] = userName;
                    item[colFileSize] = fileSize;
                    item[colDestination] = destination;
                    item.Update();
                }
                catch { }
            }

        }

        /// <summary>
        /// Custom implementation that writes incoming parameters
        /// to a custom list.  Creates the list if it does not exist.
        /// </summary>
        protected override RouterResult OnSubmitFile(
            string recordSeries, 
            string sourceUrl, 
            string userName, 
            ref byte[] fileToSubmit, 
            ref RecordsRepositoryProperty[] properties, 
            ref WSS.SPList destination, 
            ref string resultDetails)
        {
            // setup the default result...
            RouterResult result = RouterResult.SuccessContinueProcessing;
            try
            {
                // Write an entry to the history list.
                new RecordRouterHistoryList(destination).WriteEntry(
                    recordSeries, sourceUrl, userName, fileToSubmit.Length, destination.Title);

                // Write an event log entry to capture the properties.
                EventLog.WriteEntry("TrackingRouter Properties",
                    string.Format("Source Url = '{0}'\nProperties:\n{1}",
                    sourceUrl, ExtractProperties(properties)));
            }
            catch (Exception x)
            {
                // Cancel if we encounter problems writing to the list.
                // (could reject with resultDetails)
                EventLog.WriteEntry("TrackingRouter", String.Format("Exception occurred: {0}", x.Message));
                result = RouterResult.SuccessCancelFurtherProcessing;
            }
            return result;
        }

        /// <summary>
        /// Returns a string containing all of the properties in the array.
        /// </summary>
        /// <param name="properties"></param>
        /// <returns></returns>
        string ExtractProperties(RecordsRepositoryProperty[] properties)
        {
            StringBuilder sb = new StringBuilder();
            foreach (RecordsRepositoryProperty property in properties)
                sb.AppendFormat("{2}{0}={1}", property.Name, property.Value, sb.Length > 0 ? " ;" : "");
            return sb.ToString();
        }

    }
}
