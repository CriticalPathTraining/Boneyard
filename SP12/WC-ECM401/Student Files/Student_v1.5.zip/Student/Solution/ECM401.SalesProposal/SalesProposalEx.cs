﻿using System;
using System.Collections.Generic;
using System.Text;
using ECM401.ContentTypes;
using Microsoft.SharePoint;

namespace ECM401.SalesProposal
{
    /// <summary>
    /// Declare the SalesProposal class as a content type by marking
    /// it up with the SharePointContentType attribute.  Since this is
    /// a generated class, we don't have direct access to its public
    /// properties.  In order for the attribute to reflect over the fields
    /// to automatically build the columns of the content type, we need
    /// a separate.
    /// </summary>
    [
        SharePointContentType(
            Name="Sales Proposal",
            Description="This content type was construced from a generated schema.",
            BaseType="Form",
            Group="ECM401",
            DocumentTemplate="res://Forms/SalesProposalForm.xsn"
            )
    ]
    public partial class SalesProposal : SPItemEventReceiver
    {
        #region Field References

        [FieldRef("DateCreated", DisplayName = "Date Created", Group = "ECM401")]
        public DateTime DateCreatedField { get { return this.DateCreated; } set { this.DateCreated = value; } }

        [FieldRef("ClientCity",DisplayName="Client City",Group="ECM401")]
        public string ClientCity { get { return this.ClientInfo.Address.City; } set { this.ClientInfo.Address.City=value; }}

        #endregion

        /// <summary>
        /// Handle the ItemAdded event to extract data from the form.
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }
    }
}
