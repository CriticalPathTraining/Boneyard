﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using ECM401.ContentTypes;

namespace ECM401.SalesProposal
{
    /// <summary>
    /// Handles events during feature installation and activation.
    /// </summary>
    public class FeatureReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties) {
            SPWeb web = properties.Feature.Parent as SPWeb;
            SharePointContentType.Create(web, typeof(SalesProposal));
        }
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties) { }
        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    }
}
