﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Word;
using Microsoft.Office.Tools.Word.Extensions;

namespace ECM401.PrintMonitorAddin
{
    public partial class ThisAddIn
    {
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            // install a handler for the print event
            this.Application.DocumentBeforePrint 
                += new Word.ApplicationEvents4_DocumentBeforePrintEventHandler(
                    Application_DocumentBeforePrint);
        }

        /// <summary>
        /// This event handler gets the name of the printer the user is
        /// attempting to use.  It then obtains the list of "trusted" printers
        /// as defined by the PrintControl policy associated with the document.
        /// If the current printer is not trusted, then a message is displayed
        /// and the operation is cancelled.
        /// </summary>
        /// <param name="Doc"></param>
        /// <param name="Cancel"></param>
        void Application_DocumentBeforePrint(Word.Document Doc, ref bool Cancel)
        {
            if (!PrinterIsTrusted(Application.ActivePrinter))
            {
                MessageBox.Show(String.Format(
                    "Sorry. Big Brother does not want you to print this document " + 
                    "on printer '{0}'!  Please select a different printer.", 
                    Application.ActivePrinter),
                    "Printer Is Not Trusted");
                Cancel = true;
            }
        }

        /// <summary>
        /// Determines whether a specified printer is trusted.
        /// </summary>
        /// <param name="printerName"></param>
        /// <returns>true if the specified printer is in the list of trusted printers</returns>
        bool PrinterIsTrusted(string printerName)
        {
            // Retrieve the list of trusted printers from the attached policy.
            List<string> trustedPrinters = GetTrustedPrintersList();
            // Check whether the specified printer is in the list.
            if (trustedPrinters.Count == 0)
                return true;
            return trustedPrinters.Contains(printerName);
        }

        /// <summary>
        /// Retrieves the list of trusted printers from the PrintControl policy
        /// associated with the document.
        /// </summary>
        /// <remarks>
        /// This method searches through the list of custom XML parts in
        /// the document until it finds one matching the PrintControl policy URN.
        /// </remarks>
        /// <returns>the list of trusted printers from the attached policy</returns>
        List<string> GetTrustedPrintersList()
        {
            List<string> result = new List<string>();
            const string policyNamespace = "urn:ecm401:policy.printcontrol";
            Office.CustomXMLParts parts = Application.ActiveDocument.CustomXMLParts;
            foreach (Office.CustomXMLPart part in parts)
            {
                if (part.XML.Contains(policyNamespace))
                {
                    // extract the list of trusted printers.
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(part.XML);
                    XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
                    nsmgr.AddNamespace("p", policyNamespace);
                    XmlNode node = xmlDoc.SelectSingleNode("p:data/p:printers", nsmgr);
                    if (node != null)
                    {
                        string[] printers = node.InnerText.Split(";".ToCharArray());
                        foreach (string printer in printers)
                            result.Add(printer);
                        break;
                    }
                }
            }
            return result;
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
