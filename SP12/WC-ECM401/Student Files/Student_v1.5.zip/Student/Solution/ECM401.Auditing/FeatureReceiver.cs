﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Auditing
{
    /// <summary>
    /// Handles events during feature installation and activation.
    /// </summary>
    public class FeatureReceiver : SPFeatureReceiver
    {
        // Used to store and retrieve the site title.
        const string TitleKey = "OriginalTitle";

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;
            if (site != null)
            {
                // Enable auditing for all items in the site collection.
                site.Audit.AuditFlags = SPAuditMaskType.All;
                site.Audit.Update();

                // Modify the top-level website title to indicate that auditing is on.
                // Save the title in the property bag for the site.
                SPWeb web = site.RootWeb;
                web.Properties[TitleKey] = web.Title;
                web.Properties.Update();
                web.Title = string.Format("{0} - Audited", web.Title);
                web.Update();
            }
        }
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;
            if (site != null)
            {
                // Disable auditing.
                site.Audit.AuditFlags = SPAuditMaskType.None;

                // Restore the original title.
                SPWeb web = site.RootWeb;
                web.Title = web.Properties[TitleKey];
                web.Update();
            }
        }
        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    }
}
