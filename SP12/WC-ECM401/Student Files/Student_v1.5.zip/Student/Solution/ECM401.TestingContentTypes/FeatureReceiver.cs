﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using SampleContentTypes;
using ECM401.ContentTypes;

namespace TestingContentTypes
{
    /// <summary>
    /// Handles events during feature installation and activation.
    /// </summary>
    public class FeatureReceiver : SPFeatureReceiver
    {
        public override void FeatureActivated(SPFeatureReceiverProperties properties) 
        {
            using (SPWeb web = properties.Feature.Parent as SPWeb)
            {
                SPContentType ctSample = SharePointContentType.Create(web, typeof(SampleContentType));
            }
        }
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties) { }
        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    }
}
