﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;

namespace ECM401
{
    public partial class FeatureDetailsForm : Form
    {
        public bool Hidden = false;
        public string FeatureName = string.Empty;
        public string FeatureTitle = string.Empty;
        public string FeaturePrefix = string.Empty;
        public string FeatureDescription = string.Empty;
        public SPFeatureScope FeatureScope = SPFeatureScope.Web;

        private void TransferData(bool saveAndValidate)
        {
            if (saveAndValidate)
            {
                Hidden = chkHidden.Checked;
                FeatureName = txtFeatureName.Text;
                FeatureTitle = txtFeatureTitle.Text;
                FeaturePrefix = txtFeaturePrefix.Text;
                FeatureDescription = txtFeatureDescription.Text;
                FeatureScope = btnFarm.Checked ? SPFeatureScope.Farm :
                    btnWebApplication.Checked ? SPFeatureScope.WebApplication :
                    btnSite.Checked ? SPFeatureScope.Site :
                    SPFeatureScope.Web;
            }
            else
            {
                chkHidden.Checked = Hidden;
                txtFeatureName.Text = FeatureName;
                txtFeatureTitle.Text = FeatureTitle;
                txtFeaturePrefix.Text = FeaturePrefix;
                txtFeatureDescription.Text = FeatureDescription;
                switch (FeatureScope)
                {
                    case SPFeatureScope.Farm:
                        btnFarm.Checked = true;
                        break;
                    case SPFeatureScope.WebApplication:
                        btnWebApplication.Checked = true;
                        break;
                    case SPFeatureScope.Site:
                        btnSite.Checked = true;
                        break;
                    case SPFeatureScope.Web:
                        btnWeb.Checked = true;
                        break;
                }
            }
        }

        public FeatureDetailsForm()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            TransferData(false);
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            TransferData(true);
            Close();
        }
    }
}
