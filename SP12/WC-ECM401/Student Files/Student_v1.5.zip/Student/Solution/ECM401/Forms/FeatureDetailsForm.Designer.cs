﻿namespace ECM401
{
    partial class FeatureDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnFarm = new System.Windows.Forms.RadioButton();
            this.txtFeatureDescription = new System.Windows.Forms.TextBox();
            this.txtFeatureTitle = new System.Windows.Forms.TextBox();
            this.txtFeatureName = new System.Windows.Forms.TextBox();
            this.btnWebApplication = new System.Windows.Forms.RadioButton();
            this.btnSite = new System.Windows.Forms.RadioButton();
            this.btnWeb = new System.Windows.Forms.RadioButton();
            this.btnOK = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.chkHidden = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtFeaturePrefix = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(90, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(65, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Description:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(98, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Title:";
            // 
            // btnFarm
            // 
            this.btnFarm.AutoSize = true;
            this.btnFarm.BackColor = System.Drawing.Color.Transparent;
            this.btnFarm.Location = new System.Drawing.Point(23, 19);
            this.btnFarm.Name = "btnFarm";
            this.btnFarm.Size = new System.Drawing.Size(48, 17);
            this.btnFarm.TabIndex = 4;
            this.btnFarm.TabStop = true;
            this.btnFarm.Text = "Farm";
            this.btnFarm.UseVisualStyleBackColor = false;
            // 
            // txtFeatureDescription
            // 
            this.txtFeatureDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFeatureDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeatureDescription.Location = new System.Drawing.Point(132, 131);
            this.txtFeatureDescription.Multiline = true;
            this.txtFeatureDescription.Name = "txtFeatureDescription";
            this.txtFeatureDescription.Size = new System.Drawing.Size(399, 168);
            this.txtFeatureDescription.TabIndex = 5;
            // 
            // txtFeatureTitle
            // 
            this.txtFeatureTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFeatureTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeatureTitle.Location = new System.Drawing.Point(132, 104);
            this.txtFeatureTitle.Name = "txtFeatureTitle";
            this.txtFeatureTitle.Size = new System.Drawing.Size(399, 21);
            this.txtFeatureTitle.TabIndex = 4;
            // 
            // txtFeatureName
            // 
            this.txtFeatureName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFeatureName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFeatureName.Location = new System.Drawing.Point(223, 78);
            this.txtFeatureName.Name = "txtFeatureName";
            this.txtFeatureName.Size = new System.Drawing.Size(237, 20);
            this.txtFeatureName.TabIndex = 2;
            // 
            // btnWebApplication
            // 
            this.btnWebApplication.AutoSize = true;
            this.btnWebApplication.BackColor = System.Drawing.Color.Transparent;
            this.btnWebApplication.Location = new System.Drawing.Point(77, 19);
            this.btnWebApplication.Name = "btnWebApplication";
            this.btnWebApplication.Size = new System.Drawing.Size(103, 17);
            this.btnWebApplication.TabIndex = 5;
            this.btnWebApplication.TabStop = true;
            this.btnWebApplication.Text = "Web Application";
            this.btnWebApplication.UseVisualStyleBackColor = false;
            // 
            // btnSite
            // 
            this.btnSite.AutoSize = true;
            this.btnSite.BackColor = System.Drawing.Color.Transparent;
            this.btnSite.Location = new System.Drawing.Point(186, 19);
            this.btnSite.Name = "btnSite";
            this.btnSite.Size = new System.Drawing.Size(43, 17);
            this.btnSite.TabIndex = 6;
            this.btnSite.TabStop = true;
            this.btnSite.Text = "Site";
            this.btnSite.UseVisualStyleBackColor = false;
            // 
            // btnWeb
            // 
            this.btnWeb.AutoSize = true;
            this.btnWeb.BackColor = System.Drawing.Color.Transparent;
            this.btnWeb.Location = new System.Drawing.Point(235, 19);
            this.btnWeb.Name = "btnWeb";
            this.btnWeb.Size = new System.Drawing.Size(48, 17);
            this.btnWeb.TabIndex = 7;
            this.btnWeb.TabStop = true;
            this.btnWeb.Text = "Web";
            this.btnWeb.UseVisualStyleBackColor = false;
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.Location = new System.Drawing.Point(399, 305);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(132, 23);
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "Create Project";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ECM401.Resources.FeatureDetails;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 336);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // chkHidden
            // 
            this.chkHidden.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkHidden.AutoSize = true;
            this.chkHidden.Location = new System.Drawing.Point(471, 80);
            this.chkHidden.Name = "chkHidden";
            this.chkHidden.Size = new System.Drawing.Size(60, 17);
            this.chkHidden.TabIndex = 3;
            this.chkHidden.Text = "Hidden";
            this.chkHidden.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnFarm);
            this.groupBox1.Controls.Add(this.btnWebApplication);
            this.groupBox1.Controls.Add(this.btnSite);
            this.groupBox1.Controls.Add(this.btnWeb);
            this.groupBox1.Location = new System.Drawing.Point(132, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(397, 52);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Scope";
            // 
            // txtFeaturePrefix
            // 
            this.txtFeaturePrefix.Location = new System.Drawing.Point(132, 78);
            this.txtFeaturePrefix.Name = "txtFeaturePrefix";
            this.txtFeaturePrefix.Size = new System.Drawing.Size(71, 20);
            this.txtFeaturePrefix.TabIndex = 1;
            this.txtFeaturePrefix.Text = "Custom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(205, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 24);
            this.label2.TabIndex = 12;
            this.label2.Text = ".";
            // 
            // FeatureDetailsForm
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(558, 336);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFeaturePrefix);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chkHidden);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txtFeatureName);
            this.Controls.Add(this.txtFeatureTitle);
            this.Controls.Add(this.txtFeatureDescription);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Location = new System.Drawing.Point(100, 100);
            this.Name = "FeatureDetailsForm";
            this.Text = "Enter Feature Details";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton btnFarm;
        private System.Windows.Forms.TextBox txtFeatureDescription;
        private System.Windows.Forms.TextBox txtFeatureTitle;
        private System.Windows.Forms.TextBox txtFeatureName;
        private System.Windows.Forms.RadioButton btnWebApplication;
        private System.Windows.Forms.RadioButton btnSite;
        private System.Windows.Forms.RadioButton btnWeb;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox chkHidden;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtFeaturePrefix;
        private System.Windows.Forms.Label label2;
    }
}