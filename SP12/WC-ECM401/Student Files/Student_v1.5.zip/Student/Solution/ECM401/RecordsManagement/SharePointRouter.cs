﻿#region Copyright © 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright © 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  9/1/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.ComponentModel;
using System.Configuration.Install;
using WSS=Microsoft.SharePoint;
using Microsoft.Office.RecordsManagement.RecordsRepository;
using ECM401.Utilities;

namespace ECM401.RecordsManagement
{
    /// <summary>
    /// Base class for building custom routers.
    /// </summary>
    public abstract class SharePointRouter : SharePointObject, IRouter
    {
        protected void Log(string message)
        {
            string category = string.Format("ECM401.RecordsManagement - {0}",this.RouterName);
            Trace.WriteLine(message, category);
        }

        /// <summary>
        /// Returns the name of the router.
        /// </summary>
        protected virtual string RouterName
        {
            get { return this.Name; }
        }

        /// <summary>
        /// Default implementation returns success.
        /// </summary>
        /// <param name="recordSeries"></param>
        /// <param name="sourceUrl"></param>
        /// <param name="userName"></param>
        /// <param name="fileToSubmit"></param>
        /// <param name="properties"></param>
        /// <param name="destination"></param>
        /// <param name="resultDetails"></param>
        /// <returns></returns>
        protected virtual RouterResult OnSubmitFile(
            string recordSeries, 
            string sourceUrl, 
            string userName, 
            ref byte[] fileToSubmit, 
            ref RecordsRepositoryProperty[] properties, 
            ref WSS.SPList destination, 
            ref string resultDetails)
        {
            Trace.WriteLine(string.Format("[ {0} ] routing record '{1}' of type '{2}' from user '{3}'", 
                this.RouterName, sourceUrl, recordSeries, userName));
            return RouterResult.SuccessContinueProcessing;
        }
        

        /// <summary>
        /// Installs the router into the local farm.
        /// </summary>
        /// <remarks>
        /// Since routers must be configured in an existing record center
        /// site, the InstallUtil command line must specify the target url
        /// using a 'url' option.
        /// </remarks>
        /// <param name="stateSaver"></param>
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);
            Console.WriteLine("Installing custom router: {0}", this.RouterName);

            // get the target url from the install parameters
            if (!Context.Parameters.ContainsKey("url"))
                throw new InstallException(string.Format(
                    "Installation failed for custom router '{0}' - no target url provided.", this.RouterName));

            using (WSS.SPSite site = new WSS.SPSite(Context.Parameters["url"]))
            using (WSS.SPWeb web = site.OpenWeb())
                try
                {
                    RecordSeriesCollection seriesCollection = new RecordSeriesCollection(web);
                    seriesCollection.AddRouter(this.RouterName, this.AssemblyName, this.ClassName);
                }
                catch (Exception x)
                {
                    throw new InstallException(string.Format(
                        "SharePointRouter installation failed - {0}",x.Message),x);
                }
        }

        /// <summary>
        /// Removes the router from the local farm.
        /// </summary>
        /// <remarks>
        /// Requires a 'url' command line option to specify the target record center site.
        /// </remarks>
        /// <param name="savedState"></param>
        public override void Uninstall(System.Collections.IDictionary savedState)
        {
            base.Uninstall(savedState);
            Console.WriteLine("Removing custom router: {0}", this.RouterName);

            // get the target url from the install parameters
            if (!Context.Parameters.ContainsKey("url"))
                throw new InstallException(string.Format(
                    "Failed to remove custom router '{0}'- no target url provided.", this.RouterName));

            using (WSS.SPSite site = new WSS.SPSite(Context.Parameters["url"]))
            using (WSS.SPWeb web = site.OpenWeb())
                try
                {
                    RecordSeriesCollection seriesCollection = new RecordSeriesCollection(web);
                    seriesCollection.RemoveRouter(this.RouterName);
                }
                catch (Exception x)
                {
                    throw new InstallException(string.Format(
                        "SharePointRouter installation failed - {0}",x.Message),x);
                }
        }

        /// <summary>
        /// Adds a custom router to the website.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="routerClass"></param>
        /// <returns></returns>
        public static bool AddRouter(WSS.SPWeb web, Type routerClass)
        {
            string routerName = routerClass.Name;
            NameAttribute name = Helpers.FindAttribute<NameAttribute>(routerClass, false);
            if (name != null) routerName = name.Name;

            string assemblyName = routerClass.Assembly.FullName;
            string className = routerClass.FullName;

            try
            {
                RecordSeriesCollection seriesCollection = new RecordSeriesCollection(web);
                seriesCollection.AddRouter(routerName, assemblyName, className);
                return true;
            }
            catch (Exception x)
            {
                Trace.WriteLine(string.Format(
                    "Failed to add router '{0}' to web '{1}' - {2}",
                    routerName, web.Title, x.ToString()));
            }
            return false;
        }

        /// <summary>
        /// Removes a custom router from the website.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="routerClass"></param>
        /// <returns></returns>
        public static bool RemoveRouter(WSS.SPWeb web, Type routerClass)
        {
            string routerName = routerClass.Name;
            NameAttribute name = Helpers.FindAttribute<NameAttribute>(routerClass, false);
            if (name != null) routerName = name.Name;

            try
            {
                RecordSeriesCollection seriesCollection = new RecordSeriesCollection(web);
                seriesCollection.RemoveRouter(routerName);
                return true;
            }
            catch (Exception x)
            {
                Trace.WriteLine(string.Format(
                    "Failed to remove router '{0}' from web '{1}' - {2}",
                    routerName, web.Title, x.ToString()));
            }
            return false;
        }

        #region IRouter Members

        /// <summary>
        /// Default implementation delegates to derived class.
        /// </summary>
        RouterResult IRouter.OnSubmitFile(
            string recordSeries, 
            string sourceUrl, 
            string userName, 
            ref byte[] fileToSubmit, 
            ref RecordsRepositoryProperty[] properties, 
            ref WSS.SPList destination, 
            ref string resultDetails)
        {
            return this.OnSubmitFile(recordSeries, sourceUrl, userName, 
                ref fileToSubmit, ref properties, ref destination, ref resultDetails);
        }

        #endregion
    }
}
