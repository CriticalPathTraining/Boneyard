﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Microsoft.SharePoint;

namespace ECM401.Controls
{
    /// <summary>
    /// Provides a generic wrapper for a tree of objects of type T.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class SPObjectTree<T> : TreeView
    {
        List<T> m_objects = null;
        string m_groupMember = string.Empty;
        string m_displayMember = string.Empty;
        Thread m_readThread = null;

        /// <summary>
        /// Generic constructor.
        /// </summary>
        /// <param name="displayMember">the field used to create object nodes</param>
        /// <param name="groupMember">the field used to create group nodes</param>
        public SPObjectTree(string displayMember, string groupMember)
        {
            m_displayMember = displayMember;
            m_groupMember = groupMember;
            m_objects = GetObjectList();
            this.FullRowSelect = true;
            this.ShowRootLines = true;
            this.ShowPlusMinus = true;
            this.ShowNodeToolTips = true;
            this.ShowLines = true;
        }

        /// <summary>
        /// Called when the control is created.
        /// </summary>
        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            if (!DesignMode)
                FillTree();
        }

        /// <summary>
        /// Overridden by derived classes.
        /// </summary>
        /// <returns></returns>
        protected virtual List<T> GetObjectList()
        {
            return null;
        }

        /// <summary>
        /// Forces a reload of the object list.
        /// </summary>
        public virtual void Reload()
        {
            m_objects = GetObjectList();
            FillTree();
        }

        /// <summary>
        /// Fills the tree in a separate thread.
        /// </summary>
        void FillTree()
        {
            this.Nodes.Clear();
            // Fill the tree in a separate thread.
            m_readThread = new Thread(new ThreadStart(FillTreeHelper));
            m_readThread.Priority = ThreadPriority.BelowNormal;
            m_readThread.Start();
        }

        #region Helper Methods

        /// <summary>
        /// Retrieves a named property from an object.
        /// </summary>
        /// <param name="target"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        object GetProperty(object target, string propertyName)
        {
            PropertyInfo propInfo = typeof(T).GetProperty(propertyName);
            if (propInfo != null)
                return propInfo.GetValue(target, null);
            return string.Empty;
        }

        /// <summary>
        /// Adds a group node to the tree.
        /// </summary>
        /// <param name="groupName"></param>
        /// <returns></returns>
        TreeNode AddGroupNode(string groupName)
        {
            return this.Nodes.Add(groupName);
        }

        /// <summary>
        /// Adds an object node to the tree.
        /// </summary>
        /// <param name="obj">the object to be added to the tree</param>
        /// <param name="fieldName">the field to retrieve for display in the node</param>
        /// <param name="parentNode">the node to which the object should be added</param>
        void AddObjectNode(T obj, string fieldName, TreeNode parentNode)
        {
            string label = GetProperty(obj, fieldName).ToString();
            if (string.IsNullOrEmpty(label))
                label = GetProperty(obj, "Title").ToString();
            if (string.IsNullOrEmpty(label))
                label = GetProperty(obj, "Name").ToString();
            if (string.IsNullOrEmpty(label))
                label = "undefined";
            TreeNode node = parentNode.Nodes.Add(label);
            node.Tag = obj;
        }

        // Asynchronous callback delegates.
        public delegate void AsyncBeginUnboundLoad();
        public delegate void AsyncEndUnboundLoad();
        public delegate void AsyncAddObjectNode(T obj, string displayMember, TreeNode parentNode);
        public delegate TreeNode AsyncAddGroupNode(string groupName);

        /// <summary>
        /// Called on a separate thread to fill the tree.
        /// </summary>
        void FillTreeHelper()
        {
            this.Invoke(new AsyncBeginUnboundLoad(BeginUpdate));
            try
            {
                if (!string.IsNullOrEmpty(m_groupMember))
                {
                    // Group nodes using the specified property.
                    Dictionary<string, List<T>> groups = new Dictionary<string, List<T>>();
                    foreach (T obj in m_objects)
                    {
                        string groupName = GetProperty(obj, m_groupMember).ToString();
                        if (!groups.ContainsKey(groupName))
                            groups[groupName] = new List<T>();
                        groups[groupName].Add(obj);
                    }
                    // Process each group, adding nodes to the tree.
                    foreach (string group in groups.Keys)
                    {
                        List<T> objects = groups[group];
                        TreeNode groupNode = (TreeNode)Invoke(new AsyncAddGroupNode(AddGroupNode), new object[] { group });
                        foreach (T target in objects)
                            Invoke(new AsyncAddObjectNode(AddObjectNode), new object[] { target, m_displayMember, groupNode });
                    }
                }
                else
                {
                    // Add the objects without any grouping.
                    foreach (T target in m_objects)
                        Invoke(new AsyncAddObjectNode(AddObjectNode), new object[] { target, null });
                }
            }
            catch
            {
            }
            this.Invoke(new AsyncEndUnboundLoad(EndUpdate));
        }
        #endregion
    }
}
