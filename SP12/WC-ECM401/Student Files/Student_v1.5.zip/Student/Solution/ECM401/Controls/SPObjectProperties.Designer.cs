﻿namespace ECM401.Controls
{
    partial class SPObjectProperties
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_properties = new System.Windows.Forms.PropertyGrid();
            this.SuspendLayout();
            // 
            // m_properties
            // 
            this.m_properties.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_properties.HelpVisible = false;
            this.m_properties.Location = new System.Drawing.Point(0, 0);
            this.m_properties.Name = "m_properties";
            this.m_properties.PropertySort = System.Windows.Forms.PropertySort.Alphabetical;
            this.m_properties.Size = new System.Drawing.Size(394, 352);
            this.m_properties.TabIndex = 0;
            this.m_properties.ToolbarVisible = false;
            // 
            // SPObjectProperties
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.m_properties);
            this.Name = "SPObjectProperties";
            this.Size = new System.Drawing.Size(394, 352);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PropertyGrid m_properties;
    }
}
