﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Xml;
using System.Xml.Xsl;
using System.IO;
using System.Text;
using System.Windows.Forms;
using ECM401.Utilities;

namespace ECM401.Controls
{
    public partial class SPObjectDetail : UserControl
    {
        public SPObjectDetail()
        {
            InitializeComponent();
        }

        public void SetObject(ISharePointObject spObject)
        {
            m_browser.DocumentText = GetHtml(spObject);
        }

        string GetHtml(ISharePointObject spObject)
        {
            string result = EmbeddedResource.LoadString("Resources.default.htm");
            try
            {
                if (spObject != null && !string.IsNullOrEmpty(spObject.SchemaXml))
                {
                    // Create a string builder to receive the html.
                    StringBuilder sb = new StringBuilder();
                    XmlWriter xmlWriter = new XmlTextWriter(new StringWriter(sb));

                    // Create a reader for the raw CAML.
                    XmlReader xmlReader = new XmlTextReader(new StringReader(spObject.SchemaXml));

                    // Create an object to perform the transform.
                    XslCompiledTransform xslt = new XslCompiledTransform();

                    // Load the stylesheet from the compiled resources.
                    string stylesheet = EmbeddedResource.LoadString("Resources.xml.xslt");
                    xslt.Load(new XmlTextReader(new StringReader(stylesheet)));

                    // Perform the transform and get the result.
                    xslt.Transform(xmlReader, xmlWriter);
                    result = sb.ToString();
                }
                else
                {
                    result = EmbeddedResource.LoadString("Resources.default.htm");
                }
            }
            catch (Exception x)
            {
                result = x.ToString();
            }
            return result;
        }
    }
}
