﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using ECM401.ContentTypes;

namespace ECM401.Controls
{
    /// <summary>
    /// A tree control for displaying content types in the local farm.
    /// </summary>
    public partial class ContentTypeTree : UserControl
    {
        private SPContentTypeTree m_tree = null;
        public event EventHandler<SharePointObjectEventArgs> SelectionChanged;

        /// <summary>
        /// Nested class that retrieves all content types in the local farm.
        /// </summary>
        public class SPContentTypeTree : SPObjectTree<SPContentType>
        {
            /// <summary>
            /// Default constructor.
            /// </summary>
            public SPContentTypeTree()
                : base("Title", "Group")
            {
            }

            /// <summary>
            /// Worker method to retrieve the object list.
            /// </summary>
            protected override List<SPContentType> GetObjectList()
            {
                return SharePointContentType.GetAllContentTypes(true);
            }
        }

        /// <summary>
        /// Default constructor.
        /// </summary>
        public ContentTypeTree()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Re-fill the tree with content types.
        /// </summary>
        public void RefreshTypes()
        {
            m_tree.Reload();
        }

        /// <summary>
        /// Called after the control is created.
        /// </summary>
        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            if (!this.DesignMode)
            {
                m_tree = new SPContentTypeTree();
                m_tree.Dock = DockStyle.Fill;
                m_tree.AfterSelect += new TreeViewEventHandler(tree_AfterSelect);
                this.Controls.Add(m_tree);
            }
        }

        /// <summary>
        /// Handles user selection in the tree.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void tree_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node != null)
            {
                ISharePointObject spObject = new SharePointContentType(e.Node.Tag as SPContentType);
                if (SelectionChanged != null)
                    SelectionChanged(this, new SharePointObjectEventArgs(spObject));
            }
        }

    }
}
