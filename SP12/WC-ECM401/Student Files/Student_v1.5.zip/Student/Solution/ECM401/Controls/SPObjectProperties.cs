﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ECM401.Controls
{
    public partial class SPObjectProperties : UserControl
    {
        public SPObjectProperties()
        {
            InitializeComponent();
        }

        public void SetObject(ISharePointObject spObject)
        {
            if (HasProperties(spObject))
            {
                //m_properties.Show();
                m_properties.SelectedObject = spObject;
            }
            else
            {
                //m_properties.Hide();
                //m_properties.SelectedObject = null;
            }
        }

        /// <summary>
        /// Determines if the object has properties that can be
        /// displayed in the property grid.
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        private bool HasProperties(ISharePointObject spObject)
        {
            return spObject != null;
        }
    }
}
