// SharePointContentType.cs: John F. Holliday [john@johnholliday.net]
#region Copyright � 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright � 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  3/17/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using ECM401.Utilities;

namespace ECM401.ContentTypes
{
    /// <summary>
    /// Use this attribute to markup any class as a SharePoint content type.  
    /// Use the FieldRef attribute within the target class to declare
    /// the associated field references.
    /// </summary>
    /// <remarks>
    /// This attribute class supports automatic wiring of event receivers,
    /// loading of document templates and XML documents from embedded resources,
    /// and two-way data binding for fields.
    /// <para>To handle events, derive the target class from SPItemEventReceiver
    /// and override the desired method.  This attribute will reflect over the
    /// target class to determine which event receivers to bind.</para>
    /// </remarks>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class SharePointContentType : Attribute, ISharePointObject
    {
        #region Fields
        SPContentType m_ct = null;
        #endregion
        #region Helper Methods

        protected Attribute FindAttribute(Type attributeType)
        {
            object[] attributes = GetType().GetCustomAttributes(attributeType, true);
            if (attributes.Length > 0)
                return attributes[0] as Attribute;
            return null;
        }

        #endregion
        #region Constructors
        /// <summary>
        /// Allows the attribute to double as a wrapper for a real content type.
        /// </summary>
        /// <param name="ct"></param>
        public SharePointContentType(SPContentType ct)
        {
            m_ct = ct;
        }
        /// <summary>
        /// Default constructor for use as an attribute.
        /// </summary>
        public SharePointContentType()
        {
        }
        #endregion
        #region Core Properties

        /// <summary>
        /// Calculates the identifier automatically based on attributes or type.
        /// </summary>
        public virtual string Id
        {
            get
            {
                // try for the Guid attribute
                GuidAttribute guidAttribute = FindAttribute(typeof(GuidAttribute)) as GuidAttribute;
                if (guidAttribute != null) return guidAttribute.Value;
                // use the type name
                return GetType().FullName;
            }
        }

        private string m_name;
        /// <summary>
        /// The content type name.
        /// </summary>
        public string Name
        {
            get
            {
                if (m_ct != null)
                    return m_ct.Name;
                if (!string.IsNullOrEmpty(m_name))
                    return m_name;
                NameAttribute attribute = FindAttribute(typeof(NameAttribute)) as NameAttribute;
                if (attribute != null)
                    return attribute.Name;
                return GetType().Name;
            }
            set { m_name = value; }
        }

        /// <summary>
        /// The content type title.
        /// </summary>
        public string Title
        {
            get { return m_ct != null ? m_ct.Name : string.Empty; }
        }

        private bool m_hidden;
        /// <summary>
        /// Whether or not the content type is hidden from the user interface.
        /// </summary>
        public bool Hidden
        {
            get { return m_ct != null ? m_ct.Hidden : m_hidden; }
            set { m_hidden = value; }
        }


        private bool m_sealed;
        /// <summary>
        /// Whether or not the content type is sealed to prevent modifications.
        /// </summary>
        public bool Sealed
        {
            get { return m_ct != null ? m_ct.Sealed : m_sealed; }
            set { m_sealed = value; }
        }

        private string m_group;
        /// <summary>
        /// The group category with which the content type is associated.
        /// </summary>
        public string Group
        {
            get { return m_ct != null ? m_ct.Group : m_group; }
            set { m_group = value; }
        }

        private string m_description;
        /// <summary>
        /// The content type description.
        /// </summary>
        public string Description
        {
            get
            {
                if (m_ct != null)
                    return m_ct.Description;
                DescriptionAttribute attribute = FindAttribute(typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null)
                    return attribute.Description;
                if (!string.IsNullOrEmpty(m_description))
                    return m_description;
                return string.Empty;
            }
            set { m_description = value; }
        }

        /// <summary>
        /// Extracts the base type from the raw CAML schema.
        /// </summary>
        /// <param name="schemaXml"></param>
        /// <returns></returns>
        private string ParseBaseType(string schemaXml)
        {
            return "";
        }

        private string m_baseType = "Item";
        /// <summary>
        /// Specifies the content type on which this one is based.
        /// </summary>
        public string BaseType
        {
            get { return m_ct != null ? ParseBaseType(m_ct.SchemaXml) : m_baseType; }
            set { m_baseType = value; }
        }

        /// <summary>
        /// Retrieves the schema for this object.
        /// </summary>
        public string SchemaXml
        {
            get { return m_ct != null ? m_ct.SchemaXml : string.Empty; }
        }

        private string m_docTemplate = string.Empty;
        /// <summary>
        /// The url of the document template to be associated with the content type.
        /// </summary>
        /// <remarks>
        /// You can supply the url of an existing document, or you can tell the attribute
        /// to load a document from an embedded resource.  To specify an embedded resource,
        /// prefix the resource path with the string "res://", as in the following example:
        /// <example>res://projectfolder.subfolder.filename</example>  In this case, the
        /// attribute will search the target assembly for the specified embedded resource 
        /// file and add it to the content type at runtime.
        /// </remarks>
        public string DocumentTemplate
        {
            get { return m_ct != null ? m_ct.DocumentTemplate : m_docTemplate; }
            set { m_docTemplate = value; }
        }

        private string m_xmlDocuments = string.Empty;
        /// <summary>
        /// A semi-colon delimited list of xml document specifications.
        /// Each specification is of the following form:
        ///     res://embedded.resource.path[namespace]
        /// Where:
        ///     "embedded.resource.path" is the path to a document in the same assembly, without the assembly name, and
        ///     "namespace" is the namespace to use when storing and accessing the document within the content type
        ///         if no namespace is given, then the resource path is used as the namespace
        /// For example:
        ///     "res://projectfolder.xmldoc1[schemas.johnholliday.net];res://anotherfolder.subfolder.xmldoc2[schemas.microsoft.com]"
        /// </summary>
        public string XmlDocuments
        {
            get { return m_xmlDocuments; }
            set { m_xmlDocuments = value; }
        }

        /// <summary>
        /// Retrieves the publisher name.
        /// </summary>
        public virtual string Publisher
        {
            get
            {
                PublisherAttribute attribute = FindAttribute(typeof(PublisherAttribute)) as PublisherAttribute;
                if (attribute != null) return attribute.Name;
                return string.Empty;
            }
        }

        /// <summary>
        /// Retrieves the fully qualified assembly name for this component.
        /// </summary>
        public virtual string AssemblyName
        {
            get
            {
                return GetType().Assembly.GetName().FullName;
            }
        }

        /// <summary>
        /// Retrieves the fully qualified class name for this component.
        /// </summary>
        public virtual string ClassName
        {
            get
            {
                return GetType().FullName;
            }
        }

        #endregion
        #region Static Methods

        /// <summary>
        /// Creates a new content type from information stored in the 
        /// attributes associated with the specified holder class.
        /// </summary>
        /// <param name="web">the SPWeb in which to create the content type</param>
        /// <param name="ctHolder">the class used to declare the content type</param>
        /// <returns>a new SPContentType object</returns>
        public static SPContentType Create(SPWeb web, Type ctHolder)
        {
            SPContentType ct = null;
            CTHelper info = new CTHelper(ctHolder);

            try
            {
                // determine the base content type
                SPContentType baseType = (info.BaseType == null || info.BaseType.Length == 0) ?
                    web.AvailableContentTypes[SPContentTypeId.Empty] :
                    web.AvailableContentTypes[info.BaseType];
                // in case they supplied an invalid base type...
                if (baseType == null)
                    baseType = web.AvailableContentTypes[SPContentTypeId.Empty];
                // check if the CT already exists.
                try
                {
                    ct = web.ContentTypes[info.Name];
                }
                catch
                {
                }
                // Create a new CT.
                if (ct == null)
                    ct = info.Create(web.ContentTypes, baseType);
                else try
                    {
                        web.ContentTypes.Delete(ct.Id);
                        ct = info.Create(web.ContentTypes, baseType);
                    }
                    catch
                    {
                        // Instances of the content type exist...
                        info.AddEventReceivers(ct);
                        return ct;
                    }

                // If we have a CT, either an existing one or a new one,
                // add the fields that have been declared in the specified class.
                // This allows us to easily extend an existing content type with new fields.
                // Note: This does not alter existing event receivers and does not change
                // the document template associated with existing content types.
                if (ct != null)
                {
                    info.AddReflectedFields(ct);
                    info.AddDocumentTemplate(ct);
                    info.AddXmlDocuments(ct);
                    info.AddEventReceivers(ct);
                }
            }
            catch
            {
            }
            return ct;
        }

        /// <summary>
        /// Adds or creates a text field reference.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static SPFieldLink AddOrCreateFieldReference(SPContentType ct, string fieldName)
        {
            return AddOrCreateFieldReference(ct, fieldName, SPFieldType.Text, false, false, true, true, true);
        }

        /// <summary>
        /// Adds a field of a given type.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="fieldName"></param>
        /// <param name="fieldType"></param>
        /// <returns></returns>
        public static SPFieldLink AddOrCreateFieldReference(SPContentType ct, string fieldName, SPFieldType fieldType)
        {
            return AddOrCreateFieldReference(ct, fieldName, fieldType, false, false, true, true, true);
        }

        /// <summary>
        /// Adds a field of a given type with additional parameters.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="fieldName"></param>
        /// <param name="fieldType"></param>
        /// <param name="required"></param>
        /// <param name="hidden"></param>
        /// <param name="showInDisplayForm"></param>
        /// <param name="showInEditForm"></param>
        /// <param name="showInNewForm"></param>
        /// <returns></returns>
        public static SPFieldLink AddOrCreateFieldReference(SPContentType ct,
            string fieldName, SPFieldType fieldType, bool required, bool hidden,
            bool showInDisplayForm, bool showInEditForm, bool showInNewForm)
        {
            try
            {
                SPFieldLink result = ct.FieldLinks[fieldName];
                if (result != null)
                    return result;
            }
            catch { }

            SPFieldCollection fields = ct.ParentList == null ? ct.ParentWeb.Fields : ct.ParentList.Fields;
            SPField field = null;
            try
            {
                // search for the field by name
                field = fields[fieldName];
            }
            catch
            {
                // field did not exists - so create it
                string internalFieldName = fields.Add(fieldName, fieldType, required);
                field = fields[fieldName];
                field.ShowInDisplayForm = showInDisplayForm;
                field.ShowInEditForm = showInEditForm;
                field.ShowInNewForm = showInNewForm;
                field.Update();
            }

            // Add a field reference to the content type
            SPFieldLink fieldRef = new SPFieldLink(field);
            ct.FieldLinks.Add(fieldRef);
            ct.Update();

            // Ensure that the field is on the default list view if this is a list content type.
            if ((ct.ParentList != null) && ((ct.ParentList.DefaultView.ViewFields.Exists(fieldName) == false)))
            {
                SPView listView = ct.ParentList.DefaultView;
                listView.ViewFields.Add(fieldName);
                listView.Update();
            }

            return fieldRef;
        }

        /// <summary>
        /// Attempts to remove the content type from the specified web.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="ctHolder"></param>
        /// <returns></returns>
        public static bool Delete(SPWeb web, Type ctHolder)
        {
            SPContentType ct = null;
            try
            {
                CTHelper info = new CTHelper(ctHolder);
                ct = web.AvailableContentTypes[info.Name];
                if (ct != null)
                {
                    web.ContentTypes.Delete(ct.Id);
                    ct = null;
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Returns a list of all content types that have been defined
        /// in the local SharePoint farm.
        /// </summary>
        /// <returns></returns>
        static List<SPContentType> m_allContentTypes = null;
        public static List<SPContentType> GetAllContentTypes() { return GetAllContentTypes(false); }
        public static List<SPContentType> GetAllContentTypes(bool reload)
        {
            if (reload)
                m_allContentTypes = null;

            if (m_allContentTypes == null)
            {
                m_allContentTypes = new List<SPContentType>();

                // Create a dictionary to hold the actual instances.
                Dictionary<string, SPContentType> types = new Dictionary<string, SPContentType>();

                // Loop over all servers in the farm.
                foreach (SPServer server in SPFarm.Local.Servers)
                {
                    // loop over all services running on the server.
                    foreach (SPServiceInstance service in server.ServiceInstances)
                    {
                        // check for the SPWeb service
                        if (service.Service is SPWebService)
                        {
                            SPWebService spws = (SPWebService)service.Service;
                            // loop over the IIS web applications controlled by this service.
                            foreach (SPWebApplication webapp in spws.WebApplications)
                            {
                                // loop over all site collections in the web application.
                                foreach (SPSite siteCollection in webapp.Sites)
                                {
                                    // loop over all webs in the site collection.
                                    foreach (SPWeb web in siteCollection.AllWebs)
                                    {
                                        // loop over all available content types
                                        foreach (SPContentType ct in web.AvailableContentTypes)
                                        {
                                            if (!types.ContainsKey(ct.Name))
                                                types[ct.Name] = ct;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // return a list of just the values
                foreach (SPContentType type in types.Values)
                    m_allContentTypes.Add(type);
            }
            return m_allContentTypes;
        }

        #endregion
        #region Nested Classes
        /// <summary>
        /// Helper class for extracting content type information from a given type.
        /// </summary>
        private class CTHelper
        {
            Type m_ctHolder = null;
            public string BaseType = null;
            public string Name = string.Empty;
            public string Description = string.Empty;
            public string Group = string.Empty;
            public string DocumentTemplateUrl = string.Empty;
            public string[] XmlDocuments = null;
            public bool Sealed = false;
            public bool Hidden = false;

            /// <summary>
            /// Performs the extraction based on custom attributes.
            /// </summary>
            /// <param name="ctHolder"></param>
            public CTHelper(Type ctHolder)
            {
                m_ctHolder = ctHolder;
                object[] attributes = ctHolder.GetCustomAttributes(typeof(SharePointContentType), true);
                if (attributes.Length > 0)
                {
                    SharePointContentType ct = attributes[0] as SharePointContentType;
                    if (ct != null)
                    {
                        this.Name = ct.Name;
                        this.Description = ct.Description;
                        this.BaseType = ct.BaseType;
                        this.Sealed = ct.Sealed;
                        this.Group = ct.Group;
                        this.Hidden = ct.Hidden;
                        this.DocumentTemplateUrl = ct.DocumentTemplate.Trim();
                        this.XmlDocuments = ct.XmlDocuments.Split(";".ToCharArray());
                    }
                }
            }

            /// <summary>
            /// Creates a content type in the target collection.
            /// </summary>
            /// <param name="collection"></param>
            /// <param name="baseType"></param>
            /// <returns></returns>
            public SPContentType Create(SPContentTypeCollection collection, SPContentType baseType)
            {
                SPContentType ct = null;

                // Create the new content type.
                ct = new SPContentType(baseType, collection, this.Name);
                ct.Description = this.Description;
                ct.Group = this.Group;
                ct.Hidden = this.Hidden;
                ct.Sealed = this.Sealed;

                // Add it to the collection.
                collection.Add(ct);

                return ct;
            }

            /// <summary>
            /// This method sets up the event receivers in the content type object.
            /// </summary>
            /// <param name="ct"></param>
            public void AddEventReceivers(SPContentType ct)
            {
                // Add the event receivers as specified by the holder class.
                if (m_ctHolder.IsSubclassOf(typeof(SPItemEventReceiver)))
                {
                    // Remove all event receiver definitions.
                    for (int i = 0; i < ct.EventReceivers.Count; i++)
                        ct.EventReceivers[i].Delete();
                    // Add the ones that have been implemented by the holder type.
                    foreach (SPEventReceiverType receiverType in Enum.GetValues(typeof(SPEventReceiverType)))
                    {
                        // Check that the method is actually overridden in a derived class.
                        MethodInfo method = m_ctHolder.GetMethod(receiverType.ToString());
                        if (method != null && method.DeclaringType != typeof(SPItemEventReceiver))
                            ct.EventReceivers.Add(receiverType, m_ctHolder.Assembly.FullName, m_ctHolder.FullName);
                    }
                    ct.Update();
                }
            }

            /// <summary>
            /// This method sets up the document template, if specified, for the content type.
            /// </summary>
            /// <param name="ct"></param>
            public void AddDocumentTemplate(SPContentType ct)
            {
                if (!String.IsNullOrEmpty(this.DocumentTemplateUrl))
                {
                    if (DocumentTemplateUrl.StartsWith("res://"))
                    {
                        // get the resource path
                        string resourcePath = DocumentTemplateUrl.Substring(6).Replace("/", ".").Replace("\\", ".");
                        // get the document template filename
                        string docTemplateFileName = EmbeddedResource.GetFileName(m_ctHolder.Assembly, resourcePath);
                        if (!string.IsNullOrEmpty(docTemplateFileName))
                        {
                            // get the folder to upload the template into
                            SPFolder ctFolder = ct.ResourceFolder;

                            // check if the file already exists in the folder
                            foreach (SPFile file in ctFolder.Files)
                            {
                                if (file.Name == docTemplateFileName)
                                {
                                    ctFolder.Files.Delete(docTemplateFileName);
                                    break;
                                }
                            }

                            // load the bytes into the folder as a new file
                            SPFile docTemplate = ctFolder.Files.Add(docTemplateFileName,
                                EmbeddedResource.LoadBytes(m_ctHolder.Assembly, resourcePath));

                            // if successfully loaded, add the url to the content type
                            if (docTemplate != null)
                            {
                                ct.DocumentTemplate = docTemplateFileName;
                                ct.Update();
                            }
                        }
                    }
                    else
                    {
                        ct.DocumentTemplate = this.DocumentTemplateUrl;
                        ct.Update();
                    }
                }
            }

            /// <summary>
            /// Uses reflection to locate FieldRefAttributes attached to the holder object.
            /// </summary>
            /// <param name="ct"></param>
            public void AddReflectedFields(SPContentType ct)
            {
                bool needToUpdate = false;
                foreach (PropertyInfo info in m_ctHolder.GetProperties())
                {
                    object[] attributes = info.GetCustomAttributes(typeof(FieldRef), true);
                    foreach (FieldRef fieldRef in attributes)
                    {
                        fieldRef.AddToContentType(ct, info);
                        needToUpdate = true;
                    }
                }
                if (needToUpdate)
                {
                    try { ct.Update(false); }
                    catch { }
                }
            }

            /// <summary>
            /// Uses reflection to locate XML documents in the resource pool.
            /// </summary>
            /// <param name="ct"></param>
            public void AddXmlDocuments(SPContentType ct)
            {
                foreach (string xmlDocumentSpec in XmlDocuments)
                {
                    // extract or compute the namespace and the resource path
                    Regex pattern = new Regex(@"(?<protocol>res)://(?<path>[^/\r\n\[\]]+)(?<namespacespec>\[(?<namespace>[^\r\n\]""]*)\])?", RegexOptions.IgnoreCase);
                    Match match = pattern.Match(xmlDocumentSpec);
                    if (match.Success)
                    {
                        string ns = match.Groups["namespace"].Value;
                        string path = match.Groups["path"].Value;
                        SharePointContentType.AddXmlDocumentString(ct, ns,
                            EmbeddedResource.LoadString(m_ctHolder.Assembly, path));
                    }
                }
                ct.Update();
            }
        }
        #endregion
        #region XML Document Methods
        /// <summary>
        /// Adds an XML document to the content type using a specified namespace key.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="xmlns"></param>
        /// <param name="xml"></param>
        public static void AddXmlDocumentString(SPContentType ct, string xmlns, string xml)
        {
            if (ct != null)
            {
                try
                {
                    XmlTextReader reader = new XmlTextReader(new StringReader(xml));
                    XmlNamespaceManager nsMgr = new XmlNamespaceManager(reader.NameTable);
                    nsMgr.AddNamespace(string.Empty, xmlns);
                    XmlDocument doc = new XmlDocument();
                    doc.Load(reader);
                    ct.XmlDocuments.Add(doc);
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// Retrieves an XML document associated with a given namespace.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="xmlns"></param>
        /// <returns></returns>
        public static string GetXmlDocumentString(SPContentType ct, string xmlns)
        {
            if (ct != null)
            {
                SPXmlDocumentCollection xmlDocuments = ct.XmlDocuments;
                return xmlDocuments[xmlns];
            }
            return string.Empty;
        }

        /// <summary>
        /// Diagnostic routine to check the XML documents.
        /// </summary>
        /// <param name="ct"></param>
        public static void DumpXmlDocuments(SPContentType ct)
        {
            int index = 0;
            Trace.WriteLine(string.Format("Dumping XML documents for content type: {0}", ct.Name));
            Trace.WriteLine(string.Format("Count = {0}", ct.XmlDocuments.Count));
            foreach (string doc in ct.XmlDocuments)
                Trace.WriteLine(string.Format("[ {0} ] = {1}", index++, doc));
        }
        #endregion
        #region ISharePointObject Members

        string ISharePointObject.Id
        {
            get { return this.Id; }
        }

        string ISharePointObject.Name
        {
            get { return this.Name; }
        }

        string ISharePointObject.Title
        {
            get { return this.Title; }
        }

        string ISharePointObject.Description
        {
            get { return this.Description; }
        }

        string ISharePointObject.SchemaXml
        {
            get { return this.SchemaXml; }
        }

        string ISharePointObject.Publisher
        {
            get { return this.Publisher; }
        }

        string ISharePointObject.AssemblyName
        {
            get { return this.AssemblyName; }
        }

        string ISharePointObject.ClassName
        {
            get { return this.ClassName; }
        }

        #endregion
    }

}
