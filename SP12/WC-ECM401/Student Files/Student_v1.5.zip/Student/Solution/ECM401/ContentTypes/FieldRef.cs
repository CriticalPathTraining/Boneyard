// FieldRef.cs - John F. Holliday [john@johnholliday.net]
#region Copyright � 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright � 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  3/17/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Microsoft.SharePoint;

namespace ECM401.ContentTypes
{
    /// <summary>
    /// Use this attribute class to markup public properties
    /// that you want to map to SharePoint fields.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class FieldRef : Attribute
    {
        #region Properties
        private string m_fieldName = String.Empty;

        public string FieldName
        {
            get { return m_fieldName; }
            set { m_fieldName = value; }
        }

        public FieldRef(string fieldName)
        {
            m_fieldName = fieldName;
        }

        private string m_displayName = string.Empty;

        public string DisplayName
        {
            get { return string.IsNullOrEmpty(m_displayName) ? m_fieldName : m_displayName; }
            set { m_displayName = value; }
        }

        private int m_displaySize=30;

        public int DisplaySize
        {
            get { return m_displaySize; }
            set { m_displaySize = value; }
        }

        private string m_description = string.Empty;

        public string Description
        {
            get { return m_description; }
            set { m_description = value; }
        }

        private bool m_required = false;

        public bool Required
        {
            get { return m_required; }
            set { m_required = value; }
        }

        private string m_group = string.Empty;

        public string Group
        {
            get { return m_group; }
            set { m_group = value; }
        }

        private bool m_hidden = false;

        public bool Hidden
        {
            get { return m_hidden; }
            set { m_hidden = value; }
        }

        private bool m_indexed = false;

        public bool Indexed
        {
            get { return m_indexed; }
            set { m_indexed = value; }
        }

        private bool m_readOnly = false;

        public bool ReadOnly
        {
            get { return m_readOnly; }
            set { m_readOnly = value; }
        }

        private bool m_showInDisplayForm = true;

        public bool ShowInDisplayForm
        {
            get { return m_showInDisplayForm; }
            set { m_showInDisplayForm = value; }
        }
        private bool m_showInEditForm = true;

        public bool ShowInEditForm
        {
            get { return m_showInEditForm; }
            set { m_showInEditForm = value; }
        }

        private bool m_showInListSettings = true;

        public bool ShowInListSettings
        {
            get { return m_showInListSettings; }
            set { m_showInListSettings = value; }
        }
        private bool m_showInNewForm = true;

        public bool ShowInNewForm
        {
            get { return m_showInNewForm; }
            set { m_showInNewForm = value; }
        }
        private bool m_showInVersionHistory = true;

        public bool ShowInVersionHistory
        {
            get { return m_showInVersionHistory; }
            set { m_showInVersionHistory = value; }
        }
        private bool m_showInViewForms = true;

        public bool ShowInViewForms
        {
            get { return m_showInViewForms; }
            set { m_showInViewForms = value; }
        }

        #endregion

        /// <summary>
        /// Calculates the SPFieldType based on the reflected property info.
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        /// <param name="propInfo">describes the property to which this attribute is attached</param>
        /// <returns>an SPFieldType that corresponds to the underlying property type</returns>
        private SPFieldType GetFieldType(PropertyInfo propInfo)
        {
            if (propInfo.PropertyType.IsEnum)
                return SPFieldType.Choice;
            switch (propInfo.PropertyType.Name.ToLower())
            {
                case "int": return SPFieldType.Integer;
                case "decimal": return SPFieldType.Currency;
                case "double": return SPFieldType.Number;
                case "float": return SPFieldType.Number;
                case "datetime": return SPFieldType.DateTime;
                case "guid": return SPFieldType.Guid;
                case "bool": return SPFieldType.Boolean;
            }
            // check the size to determine which type of text field it is
            if (this.DisplaySize > 255)
                return SPFieldType.Note;
            return SPFieldType.Text;
        }


        /// <summary>
        /// Adds the field reference to a content type.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="propInfo"></param>
        public void AddToContentType(SPContentType ct, PropertyInfo propInfo)
        {
            try
            {
                // Locate the field in the web associated with the type.
                SPWeb web = ct.ParentWeb;
                SPField field = null;

                try
                {
                    // Perform a special check for changes to the
                    // display name of the Title field.
                    if (this.FieldName == "Title")
                    {
                        SPFieldLink fieldLink = ct.FieldLinks["Title"];
                        fieldLink.DisplayName = this.DisplayName;
                        ct.Update();
                        return;
                    }

                    // check if it's in the available fields
                    field = web.AvailableFields[this.DisplayName];
                    if (field != null)
                    {
                        // now check if it's in the actual web
                        // if so, then delete it
                        field = web.Fields[this.DisplayName];
                        if (field != null && field.CanBeDeleted)
                        {
                            web.Fields.Delete(this.DisplayName);
                            field = null;
                        }
                    }
                }
                catch { }

                // Create a new field if none exists.
                if (field == null)
                {
                    try
                    {
                        SPFieldType fieldType = GetFieldType(propInfo);
                        string fieldName = web.Fields.Add(this.DisplayName, fieldType, this.Required);
                        field = web.Fields[this.DisplayName];
                        if (!string.IsNullOrEmpty(this.Description))
                            field.Description = this.Description;
                        if (!string.IsNullOrEmpty(this.Group))
                            field.Group = this.Group;
                        field.Hidden = this.Hidden;
                        field.Indexed = this.Indexed;
                        field.ReadOnlyField = this.ReadOnly;
                        field.ShowInDisplayForm = this.ShowInDisplayForm;
                        field.ShowInEditForm = this.ShowInEditForm;
                        field.ShowInListSettings = this.ShowInListSettings;
                        field.ShowInNewForm = this.ShowInNewForm;
                        field.ShowInVersionHistory = this.ShowInVersionHistory;
                        field.ShowInViewForms = this.ShowInViewForms;
                        field.DisplaySize = this.DisplaySize.ToString();

                        // Add choices for an enum type
                        if (fieldType == SPFieldType.Choice && propInfo.PropertyType.IsEnum)
                        {
                            SPFieldChoice choiceField = field as SPFieldChoice;
                            foreach (string s in Enum.GetNames(propInfo.PropertyType))
                                choiceField.Choices.Add(s);
                            choiceField.Update();
                        }
                    }
                    catch { }
                }

                if (field != null)
                {
                    try
                    {
                        // avoid adding duplicate field links
                        bool found = false;
                        foreach (SPFieldLink fieldLink in ct.FieldLinks)
                            if (fieldLink.Name.Equals(field.Title))
                            {
                                found = true;
                                break;
                            }
                        if (!found)
                            ct.FieldLinks.Add(new SPFieldLink(field));
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }
    }
}
