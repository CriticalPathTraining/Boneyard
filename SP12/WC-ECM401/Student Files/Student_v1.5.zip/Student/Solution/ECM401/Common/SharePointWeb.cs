﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Microsoft.Office.RecordsManagement.RecordsRepository;
using Microsoft.SharePoint;

namespace ECM401
{
    /// <summary>
    /// Custom extensions for the SPWeb object.
    /// </summary>
    public static class SharePointWeb
    {
    }
}
