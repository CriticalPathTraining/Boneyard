// EmbeddedResource.cs: John F. Holliday [john@johnholliday.net]
#region Copyright � 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright � 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  3/17/2008: Initial release
#endregion
using System;
using System.IO;
using System.Drawing;
using System.Reflection;

namespace ECM401.Utilities
{
    public class EmbeddedResource
    {
        /// <summary>
        /// Adjusts a resource path for compliance with the other routines.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string FixResourcePath(string path)
        {
            if (path.StartsWith("res://"))
                path = path.Replace("res://", "");
            return path.Replace("/", ".");
        }

        /// <summary>
        /// Retrieves the filename portion of a specified resource.
        /// </summary>
        /// <param name="asm"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string GetFileName(Assembly asm, string path)
        {
            path = FixResourcePath(path);
            ManifestResourceInfo info = asm.GetManifestResourceInfo(asm.GetName().Name + "." + path);
            if (info == null) return string.Empty;  // resource not found
            if (!string.IsNullOrEmpty(info.FileName))
                return info.FileName;               // recognized filename
            // impossible to distinguish multi-segment filenames from path segments
            // best we can do is assume only one segment, as in "filename.ext" and not "filename.segment.ext".
            string extension = Path.GetExtension(path);
            string filename = Path.GetFileNameWithoutExtension(path);
            int pos = filename.LastIndexOf('.');
            string basename = pos >= 0 ? filename.Substring(pos+1) : filename;
            return basename + extension;
        }

        public static string GetFileName(string path)
        {
            return GetFileName(Assembly.GetCallingAssembly(), path);
        }

        /// <summary>
        /// Loads a byte array from a resource path in a given assembly.
        /// </summary>
        /// <param name="asm"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static byte[] LoadBytes(Assembly asm, string path)
        {
            Stream stream = null;
            path = FixResourcePath(path);
            try
            {
                string name = asm.GetName().Name + "." + path;
                stream = asm.GetManifestResourceStream(name);
                if (stream != null)
                {
                    int chunk, read = 0;
                    byte[] buffer = new byte[32768];
                    while ((chunk = stream.Read(buffer, read, buffer.Length - read)) > 0)
                    {
                        read += chunk;
                        if (read == buffer.Length)
                        {
                            int nextByte = stream.ReadByte();
                            if (nextByte == -1)
                                return buffer;
                            byte[] newBuffer = new byte[buffer.Length * 2];
                            Array.Copy(buffer, newBuffer, buffer.Length);
                            newBuffer[read] = (byte)nextByte;
                            buffer = newBuffer;
                            read++;
                        }
                    }
                    byte[] result = new byte[read];
                    Array.Copy(buffer, result, read);
                    return result;
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }
            return null;
        }

        public static byte[] LoadBytes(string path)
        {
            return LoadBytes(Assembly.GetCallingAssembly(), path);
        }

        /// <summary>
        /// Loads a string from a given assembly.
        /// </summary>
        /// <param name="asm"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string LoadString(Assembly asm, string path)
        {
            string strContent = "";
            Stream strm = null;
            StreamReader reader = null;
            path = FixResourcePath(path);
            try
            {
                //get resource:
                string strName = asm.GetName().Name + "." + path;
                strm = asm.GetManifestResourceStream(strName);
                if (strm == null)
                    strContent = null;
                else
                {
                    //read contents of embedded file:
                    reader = new StreamReader(strm);

                    if (reader == null)
                        strContent = null;
                    else
                        strContent = reader.ReadToEnd();
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                if (strm != null)
                    strm.Close();
                if (reader != null)
                    reader.Close();
            }

            return strContent;
        }

        /// <summary>
        /// Loads an image resource from a given assembly.
        /// </summary>
        /// <param name="asm"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static Image LoadImage(Assembly asm, string path)
        {
            Stream stream = null;
            Image image = null;
            path = FixResourcePath(path);
            try
            {
                stream = asm.GetManifestResourceStream(asm.GetName().Name + "." + path);
                if (stream != null)
                    image = Image.FromStream(stream);
            }
            catch
            {
                throw;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }
            return image;
        }

        /// <summary>
        /// Loads a resource string from the executing assembly.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string LoadString(string path)
        {
            return LoadString(Assembly.GetCallingAssembly(), path);
        }

        /// <summary>
        /// Loads an image resource from the executing assembly.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static Image LoadImage(string path)
        {
            return LoadImage(Assembly.GetCallingAssembly(), path);
        }

        /// <summary>
        /// Loads a resource stream.
        /// </summary>
        /// <param name="asm"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static Stream LoadStream(Assembly asm, string path)
        {
            string target = asm.GetName().Name + "." + FixResourcePath(path);
            return asm.GetManifestResourceStream(target);
        }

        public static Stream LoadStream(string path)
        {
            return LoadStream(Assembly.GetCallingAssembly(), path);
        }
    }
}

