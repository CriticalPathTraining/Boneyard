﻿// SharePointList.cs: John F. Holliday [john@johnholliday.net]
#region Copyright © 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright © 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  3/17/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401
{
    public class SharePointList
    {
        /// <summary>
        /// Creates a list of the specified type.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="type"></param>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        public static SPList Create(SPWeb web, SPListTemplateType type, string title, string description)
        {
            Guid listid = Guid.Empty;
            SPList list = null;
            try { list = web.Lists[title]; }
            catch { }
            if (list == null)
            {
                listid = web.Lists.Add(title, description, type);
                list = web.Lists[listid];
            }
            return list;
        }

        /// <summary>
        /// Creates a list and then associates it with a given set of content types.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="type"></param>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <param name="contentTypes"></param>
        /// <returns></returns>
        public static SPList Create(SPWeb web, SPListTemplateType type, string title, string description, params SPContentType[] contentTypes)
        {
            SPList list = Create(web, type, title, description);
            if (list != null)
            {
                if (contentTypes.Length > 0)
                {
                    list.ContentTypesEnabled = true;
                    foreach (SPContentType ct in contentTypes)
                    {
                        try
                        {
                            list.ContentTypes.Add(ct);
                        }
                        catch { }
                    }
                    list.Update();
                }
            }
            return list;
        }

        /// <summary>
        /// Removes the specified list (if found) from the web.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="title"></param>
        /// <returns></returns>
        public static bool Delete(SPWeb web, string title)
        {
            try
            {
                SPList list = web.Lists[title];
                if (list != null)
                {
                    list.Delete();
                    return true;
                }
            }
            catch
            {
            }
            return false;
        }

        /// <summary>
        /// Searches for a given list in a specified website.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="title"></param>
        /// <returns></returns>
        public static SPList Find(SPWeb web, string title)
        {
            SPList list = null;
            try
            {
                list = web.Lists[title];
            }
            catch
            {
            }
            return list;
        }

        /// <summary>
        /// Creates a folder in the list having the specified name.
        /// Returns the existing folder if already there.
        /// </summary>
        /// <param name="list"></param>
        /// <param name="folderName"></param>
        /// <returns></returns>
        public static SPFolder CreateFolder(SPList list, string folderName)
        {
            try
            {
                // search for an existing folder...
                foreach (SPFolder folder in list.RootFolder.SubFolders)
                    if (folder.Name.Equals(folderName))
                        return folder;

                // not found, so create a new one
                return list.RootFolder.SubFolders.Add(folderName);
            }
            catch (Exception x)
            {
                string message = string.Format(
                    "Exception creating folder '{0}': {1}", 
                    folderName, x.Message);
                EventLog.WriteEntry(message, "SharePointList");
            }
            return null;
        }

        /// <summary>
        /// Creates a column in a list.
        /// </summary>
        /// <param name="list"></param>
        /// <param name="fieldName"></param>
        /// <param name="fieldType"></param>
        /// <param name="required"></param>
        /// <returns></returns>
        public static SPField CreateColumn(SPList list, string fieldName, SPFieldType fieldType, bool required)
        {
            SPField field = null;
            SPWeb web = list.ParentWeb;
            try
            {
                field = web.AvailableFields[fieldName];
            }
            catch { }
            if (field != null)
            {
                foreach (SPField f in list.Fields)
                    if (f.Id == field.Id)
                        return f;
            }
            try
            {
                string fName = web.Fields.Add(fieldName, fieldType, required);
                field = web.Fields[fieldName];
                list.Fields.Add(field);
            }
            catch (Exception x)
            {
                Trace.WriteLine(string.Format("Failed to create field '{0}' - {1}", fieldName, x.ToString()),"SharePointList");
            }
            return field;
        }
    }
}
