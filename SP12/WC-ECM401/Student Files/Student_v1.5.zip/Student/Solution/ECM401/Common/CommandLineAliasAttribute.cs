using System;

namespace ECM401.CommandLine
{
	/// <summary>
	/// This class implements an alias attribute to work in conjunction
	/// with the <see cref="CommandLineSwitchAttribute">CommandLineSwitchAttribute</see>
	/// attribute.  If the CommandLineSwitchAttribute exists, then this attribute
	/// defines an alias for it.
	/// </summary>
	[AttributeUsage( AttributeTargets.Property )]
	public class CommandLineAliasAttribute : System.Attribute
	{
		#region Private Variables
		protected string[] m_Aliases;
		#endregion

		#region Public Properties
		public string[] Aliases
		{
			get { return m_Aliases; }
		}
		#endregion

		#region Constructors

		public CommandLineAliasAttribute( string alias ) {
			m_Aliases = new string[] { alias };
		}

		public CommandLineAliasAttribute(string[] aliases) {
			m_Aliases = aliases;
		}
		#endregion
	}

}
