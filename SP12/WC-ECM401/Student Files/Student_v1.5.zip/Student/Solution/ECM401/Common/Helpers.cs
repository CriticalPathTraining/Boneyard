﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Reflection;
using System.Xml;

namespace ECM401.Utilities
{
    public static class Helpers
    {
        /// <summary>
        /// Searches for a given attribute on a specified type.
        /// </summary>
        /// <typeparam name="TAttribute"></typeparam>
        /// <param name="holder"></param>
        /// <param name="inherit"></param>
        /// <returns></returns>
        public static TAttribute FindAttribute<TAttribute>(Type holder, bool inherit) where TAttribute:Attribute
        {
            object[] attributes = holder.GetCustomAttributes(typeof(TAttribute), inherit);
            if (attributes.Length > 0)
                return (TAttribute)attributes[0];
            return null;
        }

        /// <summary>
        /// Encodes a string for XML rendering.
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string XmlEncode(string str)
        {
            XmlElement e = new XmlDocument().CreateElement("E");
            e.InnerText = str;
            return e.InnerXml;
        }

        /// <summary>
        /// Copies one stream to another.
        /// </summary>
        /// <param name="sourceStream"></param>
        /// <param name="targetStream"></param>
        /// <param name="resetTarget">whether to reset the position of the target stream</param>
        public static void CopyStream(Stream sourceStream, Stream targetStream, bool resetTarget)
        {
            int Length = 256;
            byte[] buffer = new byte[Length];
            sourceStream.Position = 0;
            int bytesRead = sourceStream.Read(buffer, 0, Length);
            while (bytesRead > 0)
            {
                targetStream.Write(buffer, 0, bytesRead);
                bytesRead = sourceStream.Read(buffer, 0, Length);
            }
            if (resetTarget)
                targetStream.Position = 0;
        }

        /// <summary>
        /// Provides default reset behavior for stream to stream copy.
        /// </summary>
        /// <param name="sourceStream"></param>
        /// <param name="targetStream"></param>
        public static void CopyStream(Stream sourceStream, Stream targetStream)
        {
            CopyStream(sourceStream, targetStream, true);
        }
    }
}
