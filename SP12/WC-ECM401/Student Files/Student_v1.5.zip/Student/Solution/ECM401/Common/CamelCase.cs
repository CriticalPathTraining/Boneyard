using System;
using System.Collections.Generic;
using System.Text;

namespace ECM401
{
    /// <summary>
    /// Utility class for converting strings to Camel case.
    /// </summary>
    public class CamelCase
    {
        private string m_str = string.Empty;
        public CamelCase(string val) {
            m_str = (val.Length <= 2) ? val.ToLower() : val.Substring(0, 1).ToLower() + val.Substring(1);
        }
        public override string ToString() {
            return m_str;
        }
        public static explicit operator CamelCase(string s) {
            return new CamelCase(s);
        }
    }
}
