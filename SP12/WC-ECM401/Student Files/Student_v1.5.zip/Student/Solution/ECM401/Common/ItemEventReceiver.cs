﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using ECM401.Utilities;

namespace ECM401
{
    /// <summary>
    /// Base class for declaring item event receivers.
    /// </summary>
    /// <remarks>
    /// This class provides a default implementation of SPItemEventReceiver
    /// that uses reflection to determine which event receiver methods have been
    /// implemented by the derived class and automatically determines the assembly
    /// and class name to use when registering the event receiver in SharePoint.  
    /// The class also exposes static methods for registering and unregistering
    /// the receiver methods.
    /// </remarks>
    public class ItemEventReceiver : SPItemEventReceiver
    {
        /// <summary>
        /// Helper class that describes an event receiver method.
        /// </summary>
        class ReceiverInfo
        {
            public string ReceiverName { get; set; }
            public string AssemblyName { get; set; }
            public string ClassName { get; set; }
            public SPEventReceiverType ReceiverType { get; set; }

            /// <summary>
            /// Searches a type for item event receiver methods and returns
            /// a list of descriptors.
            /// </summary>
            /// <param name="receiverClass"></param>
            /// <returns></returns>
            public static List<ReceiverInfo> ExtractFrom(Type receiverClass)
            {
                // Create the result list.
                List<ReceiverInfo> receivers = new List<ReceiverInfo>();

                // Create an instance of the ItemEventReceiver in case the derived
                // class overrides the default values.
                ItemEventReceiver receiver = Activator.CreateInstance(receiverClass) as ItemEventReceiver;

                // Get the methods defined by the receiver class.
                MethodInfo[] methods = receiverClass.GetMethods(BindingFlags.Instance |
                    BindingFlags.NonPublic | BindingFlags.Public |
                    BindingFlags.DeclaredOnly);

                // Create event receiver definitions for all implemented methods.
                foreach (MethodInfo method in methods)
                {
                    // Get the base method to avoid false positives from SPItemEventReceiver.
                    MethodInfo baseDef = method.GetBaseDefinition();
                    if (baseDef != method)
                    {
                        foreach (string receiverName in Enum.GetNames(typeof(SPEventReceiverType)))
                            if (method.Name.Equals(receiverName))
                            {
                                ReceiverInfo info = new ReceiverInfo();
                                info.ReceiverName = receiver.Name;
                                info.AssemblyName = receiver.AssemblyName;
                                info.ClassName = receiver.ClassName;
                                info.ReceiverType = (SPEventReceiverType)
                                    Enum.Parse(typeof(SPEventReceiverType), receiverName);
                                receivers.Add(info);
                                break;
                            }
                    }
                }
                return receivers;
            }
        }

        /// <summary>
        /// Registers the event receiver for a content type.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="receiverClass"></param>
        public static void Create(SPContentType ct, Type receiverClass)
        {
            if (ct.ParentList != null)
            {
                // If the content type is already associated with a list, then
                // attach the receiver methods directly to the list.
                Create(ct.ParentList, receiverClass);
                return;
            }
            foreach (ReceiverInfo info in ReceiverInfo.ExtractFrom(receiverClass))
            {
                try
                {
                    SPEventReceiverDefinition receiverDefinition = ct.EventReceivers.Add();
                    receiverDefinition.Name = info.ReceiverName;
                    receiverDefinition.Assembly = info.AssemblyName;
                    receiverDefinition.Class = info.ClassName;
                    receiverDefinition.Type = info.ReceiverType;
                    receiverDefinition.Update();
                }
                catch (ArgumentException)
                {
                    // already existed
                }
                catch (Exception x)
                {
                    Trace.WriteLine(string.Format(
                        "Failed to create event receiver of type '{0}' for content type '{1}' - {2}", 
                        receiverClass.FullName, ct.Name, x.Message));
                    throw x;
                }
            }
        }

        /// <summary>
        /// Removes the event receiver registration for a content type.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="receiverClass"></param>
        public static void Remove(SPContentType ct, Type receiverClass)
        {
            if (ct.ParentList != null)
            {
                Remove(ct.ParentList, receiverClass);
                return;
            }
            foreach (ReceiverInfo info in ReceiverInfo.ExtractFrom(receiverClass))
            {
                SPEventReceiverDefinitionCollection ctReceivers = ct.EventReceivers;
                for (int i = 0; i < ctReceivers.Count; i++)
                {
                    SPEventReceiverDefinition receiver = ctReceivers[i];
                    if (receiver.Name == info.ReceiverName && receiver.Type == info.ReceiverType)
                        receiver.Delete();
                }
            }
        }

        /// <summary>
        /// Registers the event receiver for a list.
        /// </summary>
        /// <param name="list"></param>
        /// <param name="receiverClass"></param>
        public static void Create(SPList list, Type receiverClass)
        {
            foreach (ReceiverInfo info in ReceiverInfo.ExtractFrom(receiverClass))
            {
                try
                {
                    SPEventReceiverDefinition receiverDefinition = list.EventReceivers.Add();
                    receiverDefinition.Name = info.ReceiverName;
                    receiverDefinition.Assembly = info.AssemblyName;
                    receiverDefinition.Class = info.ClassName;
                    receiverDefinition.Type = info.ReceiverType;
                    receiverDefinition.Update();
                }
                catch (ArgumentException)
                {
                    // already existed
                }
                catch (Exception x)
                {
                    Trace.WriteLine(string.Format(
                        "Failed to create event receiver of type '{0}' for list '{1}' - {2}",
                        receiverClass.FullName, list.Title, x.Message));
                    throw x;
                }
            }
        }

        /// <summary>
        /// Removes the event receiver registration for a list.
        /// </summary>
        /// <param name="list"></param>
        /// <param name="receiverClass"></param>
        public static void Remove(SPList list, Type receiverClass)
        {
            foreach (ReceiverInfo info in ReceiverInfo.ExtractFrom(receiverClass))
            {
                SPEventReceiverDefinition receiverDefinition = null;
                SPEventReceiverDefinitionCollection receivers = list.EventReceivers;
                bool fFound = false;

                for (int i = 0; i < receivers.Count; ++i)
                {
                    receiverDefinition = receivers[i];
                    if (receiverDefinition.Name == info.ReceiverName && 
                        receiverDefinition.Type == info.ReceiverType)
                    {
                        fFound = true;
                        break;
                    }
                }

                if (fFound)
                    receiverDefinition.Delete();
            }
        }

        #region Virtual Overrides
        protected virtual string Name
        {
            get
            {
                NameAttribute nameAttribute = Helpers.FindAttribute<NameAttribute>(GetType(), false);
                if (nameAttribute != null) return nameAttribute.Name;
                return GetType().Name;
            }
        }

        protected virtual string AssemblyName
        {
            get
            {
                Assembly asm = GetType().Assembly;
                return asm.FullName;
            }
        }

        protected virtual string ClassName
        {
            get
            {
                return GetType().FullName;
            }
        }
        #endregion

    }
}
