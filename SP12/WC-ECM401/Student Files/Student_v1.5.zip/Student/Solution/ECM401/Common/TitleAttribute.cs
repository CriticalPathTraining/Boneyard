﻿#region Copyright © 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright © 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  9/1/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace ECM401
{
    public class TitleAttribute : Attribute
    {
        public string Title { get; set; }

        public TitleAttribute(string title)
        {
            this.Title = title;
        }
    }
}
