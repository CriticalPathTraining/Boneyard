﻿#region Copyright © 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright © 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  9/1/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Configuration.Install;
using System.Reflection;
using System.Text;

namespace ECM401
{
    public class SharePointObject : Installer, ISharePointObject
    {
        #region Helper Methods

        protected Attribute FindAttribute(Type attributeType)
        {
            object[] attributes = GetType().GetCustomAttributes(attributeType, true);
            if (attributes.Length > 0)
                return attributes[0] as Attribute;
            return null;
        }

        protected void Log(string format, params object[] args)
        {
            Console.WriteLine(format, args);
            Trace.WriteLine(string.Format(format, args), "ECM401");
        }

        #endregion

        #region Public Virtual Properties

        /// <summary>
        /// Calculates the identifier automatically based on attributes or type.
        /// </summary>
        public virtual string Id
        {
            get
            {
                // try for the Guid attribute
                GuidAttribute guidAttribute = FindAttribute(typeof(GuidAttribute)) as GuidAttribute;
                if (guidAttribute != null) return guidAttribute.Value;
                // use the type name
                return GetType().FullName;
            }
        }

        /// <summary>
        /// Calculates the component name.
        /// </summary>
        private string m_name = string.Empty;
        public virtual string Name
        {
            get
            {
                if (!string.IsNullOrEmpty(m_name)) return m_name;
                NameAttribute attribute = FindAttribute(typeof(NameAttribute)) as NameAttribute;
                if (attribute != null) return attribute.Name;
                return GetType().Name;
            }
            set
            {
                m_name = value;
            }
        }

        /// <summary>
        /// Calculates the component description based on attributes or type.
        /// </summary>
        private string m_description = string.Empty;
        public virtual string Description
        {
            get
            {
                if (!string.IsNullOrEmpty(m_description)) return m_description;
                DescriptionAttribute attribute = FindAttribute(typeof(DescriptionAttribute)) as DescriptionAttribute;
                if (attribute != null) return attribute.Description;
                return GetType().FullName;
            }
            set
            {
                m_description = value;
            }
        }

        /// <summary>
        /// Retrieves the title.
        /// </summary>
        private string m_title = string.Empty;
        public virtual string Title
        {
            get
            {
                if (!string.IsNullOrEmpty(m_title)) return m_title;
                TitleAttribute attribute = FindAttribute(typeof(TitleAttribute)) as TitleAttribute;
                if (attribute != null) return attribute.Title;
                return GetType().Name;
            }
            set
            {
                m_title = value;
            }
        }

        /// <summary>
        /// Retrieves the publisher name.
        /// </summary>
        private string m_publisher = string.Empty;
        public virtual string Publisher
        {
            get
            {
                if (!string.IsNullOrEmpty(m_publisher)) return m_publisher;
                PublisherAttribute attribute = FindAttribute(typeof(PublisherAttribute)) as PublisherAttribute;
                if (attribute != null) return attribute.Name;
                return string.Empty;
            }
            set
            {
                m_publisher = value;
            }
        }

        /// <summary>
        /// Retrieves the fully qualified assembly name for this component.
        /// </summary>
        public virtual string AssemblyName
        {
            get
            {
                return GetType().Assembly.GetName().FullName;
            }
        }

        /// <summary>
        /// Retrieves the fully qualified class name for this component.
        /// </summary>
        public virtual string ClassName
        {
            get
            {
                return GetType().FullName;
            }
        }

        /// <summary>
        /// Returns the schema for this component.
        /// </summary>
        public virtual string SchemaXml
        {
            get
            {
                string manifest = string.Empty;
                return manifest;
            }
        }

        #endregion

        #region ISharePointObject Members

        /// <summary>
        /// Use reflection to extract the SharePoint Component Id.
        /// </summary>
        string ISharePointObject.Id
        {
            get { return this.Id; }
        }

        /// <summary>
        /// Use reflection to extract the SharePoint component name.
        /// Returns the type name if not found.
        /// </summary>
        string ISharePointObject.Name
        {
            get { return this.Name; }
        }

        /// <summary>
        /// Use reflection to extract the component title.
        /// Returns the name of the type if not found.
        /// </summary>
        string ISharePointObject.Title
        {
            get { return this.Title; }
        }

        /// <summary>
        /// Use reflection to extract the component description.
        /// Returns the full name of the type if not found.
        /// </summary>
        string ISharePointObject.Description
        {
            get { return this.Description; }
        }

        /// <summary>
        /// Retrieves the CAML definition or manifest for the component.
        /// </summary>
        string ISharePointObject.SchemaXml
        {
            get { return this.SchemaXml; }
        }

        /// <summary>
        /// User reflection to extract the component publisher.
        /// </summary>
        string ISharePointObject.Publisher
        {
            get { return this.Publisher; }
        }

        /// <summary>
        /// Returns the assembly name for the component.
        /// </summary>
        string ISharePointObject.AssemblyName
        {
            get { return this.AssemblyName; }
        }

        /// <summary>
        /// Returns the class name for the component.
        /// </summary>
        string ISharePointObject.ClassName
        {
            get { return this.ClassName; }
        }        
        #endregion
    }
}
