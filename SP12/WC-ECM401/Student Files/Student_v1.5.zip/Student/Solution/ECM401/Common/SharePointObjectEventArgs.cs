﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECM401
{
    public class SharePointObjectEventArgs : EventArgs
    {
        public ISharePointObject SharePointObject { get; set; }
        public SharePointObjectEventArgs(ISharePointObject spObject)
        {
            this.SharePointObject = spObject;
        }
    }
}
