﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECM401.InformationPolicy
{
    /// <summary>
    /// Describes an information policy.
    /// </summary>
    interface ISharePointPolicy
    {
        /// <summary>
        /// The policy identifier.
        /// </summary>
        Guid PolicyId { get; set; }
        /// <summary>
        /// The name of the policy.
        /// </summary>
        string PolicyName { get; set; }
        /// <summary>
        /// A brief description of the policy.
        /// </summary>
        string PolicyDescription { get; set; }
        /// <summary>
        /// The policy statement presented to end users.
        /// </summary>
        string PolicyStatement { get; set; }
        /// <summary>
        /// The XML manifest that describes the policy.
        /// </summary>
        string PolicyManifest { get; }
    }
}
