﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint;

namespace ECM401.InformationPolicy
{
    /// <summary>
    /// Base class for declaring information policy features.
    /// </summary>
    /// <remarks>
    /// This class provides a default implementation of the IPolicyFeature
    /// interface, allowing derived classes to implement only the methods
    /// they require.
    /// </remarks>
    public abstract class SharePointPolicyFeature : SharePointObject,
        ISharePointPolicyFeature, IPolicyFeature
    {
        #region SharePointObject Overrides

        /// <summary>
        /// Returns the schema xml that describes the policy.
        /// </summary>
        public override string SchemaXml
        {
            get
            {
                StringBuilder sb = new StringBuilder(
                    "<PolicyFeature xmlns='urn:schemas-microsoft-com:office:server:policy' ");
                sb.AppendFormat("id = '{0}'>", this.Id);
                sb.AppendFormat("<Name>{0}</Name>", this.Name);
                sb.AppendFormat("<Description>{0}</Description>", this.Description);
                sb.AppendFormat("<Publisher>{0}</Publisher>", this.Publisher);
                sb.AppendFormat("<ConfigPage>{0}</ConfigPage>", this.ConfigPage);
                sb.AppendFormat("<ConfigPageInstructions>{0}</ConfigPageInstructions>", 
                    this.ConfigPageInstructions);
                sb.AppendFormat("<AssemblyName>{0}</AssemblyName>", this.AssemblyName);
                sb.AppendFormat("<ClassName>{0}</ClassName>", this.ClassName);
                sb.Append("</PolicyFeature>");
                return sb.ToString();
            }
        }
        #endregion

        #region Virtual Properties
        public virtual string ConfigPage { get; set; }
        public virtual string ConfigPageInstructions { get; set; }
        #endregion

        #region Virtual Overrides
        /* Virtual methods that can be overridden by derived classes. */
        public virtual void OnCustomDataChange(PolicyItem policyItem, SPContentType ct) { }
        public virtual void OnGlobalCustomDataChange(PolicyFeature feature) { }
        public virtual bool ProcessListItem(SPSite site, PolicyItem policyItem, SPListItem listItem) { return false; }
        public virtual bool ProcessListItemOnRemove(SPSite site, SPListItem listItem) { return false; }
        public virtual void Register(SPContentType ct) { }
        public virtual void UnRegister(SPContentType ct) { }
        #endregion

        #region IPolicyFeature Members

        void IPolicyFeature.OnCustomDataChange(PolicyItem policyItem, SPContentType ct)
        {
            this.OnCustomDataChange(policyItem, ct);
        }

        void IPolicyFeature.OnGlobalCustomDataChange(PolicyFeature feature)
        {
            this.OnGlobalCustomDataChange(feature);
        }

        bool IPolicyFeature.ProcessListItem(SPSite site, PolicyItem policyItem, SPListItem listItem)
        {
            return this.ProcessListItem(site, policyItem, listItem);
        }

        bool IPolicyFeature.ProcessListItemOnRemove(SPSite site, SPListItem listItem)
        {
            return this.ProcessListItemOnRemove(site, listItem);
        }

        void IPolicyFeature.Register(SPContentType ct)
        {
            this.Register(ct);
        }

        void IPolicyFeature.UnRegister(SPContentType ct)
        {
            this.UnRegister(ct);
        }

        #endregion

        #region ISharePointPolicyFeature Members

        string ISharePointPolicyFeature.Id
        {
            get
            {
                return this.Id;
            }
        }

        string ISharePointPolicyFeature.Name
        {
            get
            {
                return this.Name;
            }
            set
            {
                this.Name = value;
            }
        }

        string ISharePointPolicyFeature.Description
        {
            get
            {
                return this.Description;
            }
            set
            {
                this.Description = value;
            }
        }

        string ISharePointPolicyFeature.ConfigPage
        {
            get
            {
                return this.ConfigPage;
            }
            set
            {
                this.ConfigPage = value;
            }
        }

        string ISharePointPolicyFeature.ConfigPageInstructions
        {
            get
            {
                return this.ConfigPageInstructions;
            }
            set
            {
                this.ConfigPageInstructions = value;
            }
        }

        string ISharePointPolicyFeature.Manifest
        {
            get
            {
                return this.SchemaXml;
            }
        }

        #endregion

        #region Static Methods

        /// <summary>
        /// Adds a policy feature to the global catalog.
        /// </summary>
        /// <param name="policyFeatureType"></param>
        /// <returns></returns>
        public static bool Install(Type policyFeatureType)
        {
            ISharePointPolicyFeature policyFeature =
                Activator.CreateInstance(policyFeatureType) as ISharePointPolicyFeature;
            if (policyFeature != null)
                try
                {
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        PolicyFeatureCollection.Add(policyFeature.Manifest);
                    });
                    return true;
                }
                catch (Exception x)
                {
                    Trace.WriteLine("Failed to install policy feature '"
                        + policyFeature.Name + "' - " + x.Message);
                }
            return false;
        }

        /// <summary>
        /// Removes a policy feature from the global catalog.
        /// </summary>
        /// <param name="policyFeatureType"></param>
        /// <returns></returns>
        public static bool Uninstall(Type policyFeatureType)
        {
            ISharePointPolicyFeature policyFeature =
                Activator.CreateInstance(policyFeatureType) as ISharePointPolicyFeature;
            if (policyFeature != null)
                try
                {
                    PolicyFeatureCollection.Delete(policyFeature.Id);
                    return true;
                }
                catch (Exception x)
                {
                    Trace.WriteLine("Failed to remove policy feature '"
                        + policyFeature.Name + "' - " + x.Message);
                }
            return false;

        }

        #endregion
    }
}
