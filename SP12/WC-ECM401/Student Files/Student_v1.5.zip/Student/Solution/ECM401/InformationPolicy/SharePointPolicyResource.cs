﻿#region Copyright © 2008 John F. Holliday
/* This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not
 *      claim that you wrote the original software.  If you use this software in a
 *      product, an acknowledgement in the product documentation is requested, as
 *      shown here:
 * 
 *      Portions copyright © 2008 John Holliday (http://www.johnholliday.net/).
 * 
 * 2. No substantial portion of this source code may be redistributed without
 *      the express written permission of the copyright holder, where
 *      "substantial" is defined as enough code to be recognizably from this code.
 */
#endregion
#region History
// History:
//  9/1/2008: Initial release
#endregion
using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Configuration.Install;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.Office.RecordsManagement.PolicyFeatures;

namespace ECM401.InformationPolicy
{
    /// <summary>
    /// Base class for policy resource implementations.
    /// </summary>
    public abstract class SharePointPolicyResource : SharePointObject, ISharePointPolicyResource
    {
        /// <summary>
        /// Installs the policy resource into the local farm.
        /// </summary>
        /// <param name="stateSaver"></param>
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);
            string manifest = this.SchemaXml;
            Console.WriteLine("Installing policy resource: {0}", this.Name);
            try
            {
                Console.WriteLine("Attempting to delete using id: {0}", this.Id);
                Microsoft.Office.RecordsManagement.InformationPolicy.PolicyResourceCollection.Delete(this.Id);
            }
            catch (Exception x1)
            {
                Console.WriteLine("Delete failed: {0}", x1.Message);
            }
            try
            {
                Console.WriteLine("Validating manifest:\n{0}", manifest);
                Microsoft.Office.RecordsManagement.InformationPolicy.PolicyResource.ValidateManifest(manifest);
                Microsoft.Office.RecordsManagement.InformationPolicy.PolicyResourceCollection.Add(manifest);
            }
            catch (Exception x2)
            {
                Console.WriteLine("Error in manifest: {0}", x2.Message);
            }
        }

        /// <summary>
        /// Removes the policy resource from the local farm.
        /// </summary>
        /// <param name="savedState"></param>
        public override void Uninstall(System.Collections.IDictionary savedState)
        {
            base.Uninstall(savedState);
            Console.WriteLine("Uninstalling policy resource with id: {0}", this.Id);
            Microsoft.Office.RecordsManagement.InformationPolicy.PolicyResourceCollection.Delete(this.Id);
        }

        /// <summary>
        /// Override this property to specify the correct ID of the policy feature this resource belongs to.
        /// </summary>
        protected virtual string FeatureId
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Override this property to specify the policy resource type.
        /// </summary>
        protected virtual string ResourceType
        {
            get { return this.Name; }
        }

        /// <summary>
        /// Override to construct the required manifest for this component type.
        /// </summary>
        public override string SchemaXml
        {
            get
            {
                StringBuilder sb = new StringBuilder(
                    "<PolicyResource xmlns='urn:schemas-microsoft-com:office:server:policy' ");
                sb.AppendFormat("id = '{0}' ", this.Id);
                sb.AppendFormat("featureId = '{0}' ", this.FeatureId);
                sb.AppendFormat("type = '{0}'>", this.ResourceType);
                sb.AppendFormat("<Name>{0}</Name>", this.Name);
                sb.AppendFormat("<Description>{0}</Description>", this.Description);
                sb.AppendFormat("<Publisher>{0}</Publisher>", this.Publisher);
                sb.AppendFormat("<AssemblyName>{0}</AssemblyName>", this.AssemblyName);
                sb.AppendFormat("<ClassName>{0}</ClassName>", this.ClassName);
                sb.Append("</PolicyResource>");
                return sb.ToString();
            }
        }

        #region ISharePointPolicyResource Members

        string ISharePointPolicyResource.FeatureId
        {
            get { return this.FeatureId; }
        }

        string ISharePointPolicyResource.Publisher
        {
            get { return this.Publisher; }
        }

        #endregion
    }
}
