﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ECM401.InformationPolicy
{
    /// <summary>
    /// Describes an information policy feature.
    /// </summary>
    interface ISharePointPolicyFeature
    {
        /// <summary>
        /// The unique policy feature identifier.
        /// </summary>
        string Id { get; }
        /// <summary>
        /// The name of the feature.
        /// </summary>
        string Name { get; set; }
        /// <summary>
        /// A brief description of what the feature does.
        /// </summary>
        string Description { get; set; }
        /// <summary>
        /// The name of the user control that provides a user interface
        /// for configuring the policy feature.
        /// </summary>
        string ConfigPage { get; set; }
        /// <summary>
        /// Additional instructions that are added to the configuration
        /// user interface for the policy feature.
        /// </summary>
        string ConfigPageInstructions { get; set; }
        /// <summary>
        /// Retrieves the XML manifest for the feature.
        /// </summary>
        string Manifest { get; }
    }
}
