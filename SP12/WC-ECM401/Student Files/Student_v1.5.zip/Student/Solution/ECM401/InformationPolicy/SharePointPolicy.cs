﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.ComponentModel;
using System.Configuration.Install;
using System.Runtime.InteropServices;
using System.IO;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint;
using ECM401.Utilities;

namespace ECM401.InformationPolicy
{
    /// <summary>
    /// Base class for declaring information policies.
    /// </summary>
    public abstract class SharePointPolicy : SharePointObject, ISharePointPolicy
    {
        #region ISharePointPolicy Members

        Guid ISharePointPolicy.PolicyId
        {
            get
            {
                return this.PolicyId;
            }
            set
            {
                this.PolicyId = value;
            }
        }

        string ISharePointPolicy.PolicyName
        {
            get
            {
                return this.PolicyName;
            }
            set
            {
                this.PolicyName = value;
            }
        }

        string ISharePointPolicy.PolicyDescription
        {
            get
            {
                return this.PolicyDescription;
            }
            set
            {
                this.PolicyDescription = value;
            }
        }

        string ISharePointPolicy.PolicyStatement
        {
            get
            {
                return this.PolicyStatement;
            }
            set
            {
                this.PolicyStatement = value;
            }
        }

        string ISharePointPolicy.PolicyManifest
        {
            get
            {
                return this.SchemaXml;
            }
        }

        #endregion

        #region Protected Virtual Properties
        private Guid m_id = Guid.Empty;
        protected virtual Guid PolicyId
        {
            get
            {
                if (m_id != Guid.Empty) return m_id;
                GuidAttribute guidAttribute = Helpers.FindAttribute<GuidAttribute>(GetType(), false);
                if (guidAttribute != null) return new Guid(guidAttribute.Value);
                m_id = Guid.NewGuid();
                return m_id;
            }
            set { m_id = value; }
        }

        private bool m_local = false;
        protected virtual bool IsLocal
        {
            get { return m_local; }
            set { m_local = value; }
        }

        protected virtual string PolicyName
        {
            get { return this.Name; }
            set { this.Name = value; }
        }

        protected virtual string PolicyDescription
        {
            get { return this.Description; }
            set { this.Description = value; }
        }

        private string m_policyStatement = string.Empty;
        protected virtual string PolicyStatement
        {
            get { return m_policyStatement; }
            set { m_policyStatement = value; }
        }
        #endregion

        #region Component Overrides
        /// <summary>
        /// Installs the policy into the local farm.
        /// </summary>
        /// <param name="stateSaver"></param>
        public override void Install(System.Collections.IDictionary stateSaver)
        {
            base.Install(stateSaver);
            Trace.WriteLine(string.Format("Installing information policy: {0}", this.PolicyName));
            try
            {
                if (Context.Parameters.ContainsKey("url"))
                {
                    using (SPSite site = new SPSite(Context.Parameters["url"]))
                    {
                        try
                        {
                            PolicyCollection.Add(site, this.SchemaXml);
                        }
                        catch
                        {
                            // Policy already exists in the collection.
                            Trace.WriteLine(string.Format("Policy '{0}' already exists - attempting delete", this.PolicyName));
                            PolicyCollection.Delete(site, this.Id);
                            PolicyCollection.Add(site, this.SchemaXml);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Cannot install information policy '{0}' - no site url provided.", this.PolicyName);
                }
            }
            catch (Exception x)
            {
                Console.WriteLine("Failed to install information policy '{0}' - {1}", this.PolicyName, x.ToString());
            }
        }

        /// <summary>
        /// Removes the policy from the local farm.
        /// </summary>
        /// <param name="savedState"></param>
        public override void Uninstall(System.Collections.IDictionary savedState)
        {
            base.Uninstall(savedState);
            Trace.WriteLine(string.Format("Removing information policy: {0}", this.PolicyName));
            try
            {
                if (Context.Parameters.ContainsKey("url"))
                {
                    using (SPSite site = new SPSite(Context.Parameters["url"]))
                        PolicyCollection.Delete(site, this.Id);
                }
                else
                {
                    Console.WriteLine("Cannot unintall information policy '{0}' - no site url provided.", this.PolicyName);
                }
            }
            catch (Exception x)
            {
                Console.WriteLine("Failed to remove information policy '{0}' - {1}", this.PolicyName, x.ToString());
            }
        }
        #endregion

        #region SharePointObject Overrides

        /// <summary>
        /// Returns the schema xml that describes the policy.
        /// </summary>
        public override string SchemaXml
        {
            get
            {
                StringBuilder sb = new StringBuilder(
                    "<Policy xmlns='urn:schemas-microsoft-com:office:server:policy' ");
                sb.AppendFormat("id = '{0}' ", this.Id);
                sb.AppendFormat("Local = '{0}'>", this.IsLocal ? "TRUE" : "FALSE");
                sb.AppendFormat(@"<Name>{0}</Name>", this.PolicyName);
                sb.AppendFormat(@"<Description>{0}</Description>", this.PolicyDescription);
                sb.AppendFormat(@"<Statement>{0}</Statement>", this.PolicyStatement);
                sb.Append("</Policy>");
                return sb.ToString();
            }
        }
        #endregion

        #region Static Methods

        /// <summary>
        /// Creates a global policy.
        /// </summary>
        /// <param name="site"></param>
        /// <param name="policyType"></param>
        /// <returns></returns>
        public static Policy Create(SPSite site, Type policyType)
        {
            ISharePointPolicy policyInstance = Activator.CreateInstance(policyType) as ISharePointPolicy;
            if (policyInstance != null)
            {
                try
                {
                    PolicyCollection.Add(site, policyInstance.PolicyManifest);
                }
                catch
                {
                    PolicyCollection.Delete(site, policyInstance.PolicyId.ToString());
                    PolicyCollection.Add(site, policyInstance.PolicyManifest);
                }
            }
            return FindPolicy(site,policyType);
        }

        /// <summary>
        /// Associates a policy with a content type.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="policyType"></param>
        /// <returns></returns>
        public static Policy Create(SPContentType ct, Type policyType)
        {
            Policy policy = null;
            try
            {
                policy = FindPolicy(ct.ParentWeb.Site, policyType);
                if (policy == null)
                    policy = Create(ct.ParentWeb.Site,policyType);
                if (policy != null && !policy.IsLocal)
                    Policy.CreatePolicy(ct, policy);
            }
            catch (Exception x)
            {
                Trace.WriteLine(string.Format(
                    "Failed to create policy of type '{0}' for content type '{1}' - {2}", 
                    policyType.Name, ct.Name, x.Message));
            }
            return policy;
        }

        /// <summary>
        /// Locates a policy in a site collection.
        /// </summary>
        /// <param name="site"></param>
        /// <param name="policyType"></param>
        /// <returns></returns>
        public static Policy FindPolicy(SPSite site, Type policyType)
        {
            ISharePointPolicy policyInstance = Activator.CreateInstance(policyType) as ISharePointPolicy;
            if (policyInstance != null)
            {
                PolicyCatalog catalog = new PolicyCatalog(site);
                foreach (Policy policy in catalog.PolicyList)
                    if (policy.Id.Equals(policyInstance.PolicyId.ToString()))
                        return policy;
            }
            return null;
        }

        #endregion
    }
}
