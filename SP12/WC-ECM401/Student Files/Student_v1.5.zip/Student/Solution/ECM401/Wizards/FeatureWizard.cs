﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TemplateWizard;
using System.Windows.Forms;
using EnvDTE;
using Microsoft.SharePoint;

namespace ECM401
{
    public class FeatureWizard : IWizard
    {
        const string RootFolderName = "12";
        const string DefaultFeatureFolderName = "SimpleFeature"; 
        
        private string feature_name = string.Empty;
        private string feature_prefix = "Custom";
        private string feature_folder = string.Empty;
        private string feature_title = "SharePoint Feature";
        private string feature_description = string.Empty;
        private bool feature_hidden = false;
        private SPFeatureScope feature_scope = SPFeatureScope.Web;
        private FeatureDetailsForm m_inputForm;

        /// <summary>
        /// Recursively searches for an item having the default feature folder name
        /// and changes it to the value in feature_name.
        /// </summary>
        bool AdjustFeatureFolderName(ProjectItem item)
        {
            if (item.Name.Equals(DefaultFeatureFolderName))
            {
                item.Name = feature_folder;
                return true;
            }
            else
            {
                foreach (ProjectItem subItem in item.ProjectItems)
                    if (AdjustFeatureFolderName(subItem))
                        return true;
            }
            return false;
        }

        #region IWizard Members

        /// <summary>
        /// Called before opening any item that has the OpenInEditor attribute.
        /// </summary>
        /// <param name="projectItem"></param>
        void IWizard.BeforeOpeningFile(ProjectItem projectItem)
        {
        }

        /// <summary>
        /// Called after a new project is generated.
        /// </summary>
        /// <param name="project"></param>
        void IWizard.ProjectFinishedGenerating(Project project)
        {
            // Search for the "12" folder.
            foreach (ProjectItem item in project.ProjectItems)
            {
                switch (item.Kind)
                {
                    case EnvDTE.Constants.vsProjectItemKindPhysicalFolder:
                        if (item.Name.Equals(RootFolderName))
                            AdjustFeatureFolderName(item);
                        break;
                }
            }
            // Adjust the project name
            project.Name = feature_folder;
        }

        /// <summary>
        /// Called for item templates, not for project templates.
        /// </summary>
        /// <param name="projectItem"></param>
        void IWizard.ProjectItemFinishedGenerating(ProjectItem projectItem)
        {
        }

        /// <summary>
        /// Called after the project is created.
        /// </summary>
        void IWizard.RunFinished()
        {
        }

        /// <summary>
        /// Called when the wizard is started.
        /// </summary>
        /// <param name="automationObject">The root DTE object - used for customization.</param>
        /// <param name="replacementsDictionary">A collection of all pre-defined parameters in the template.</param>
        /// <param name="runKind">A WizardRunKind parameter that contains information about what kind of template is being used.</param>
        /// <param name="customParams">An object array that contains a set of parameters passed to the wizard by Visual Studio.</param>
        void IWizard.RunStarted(object automationObject, Dictionary<string, string> replacementsDictionary, WizardRunKind runKind, object[] customParams)
        {
            try
            {
                // Retrieve some parameters for use later.
                feature_name = replacementsDictionary["$safeprojectname$"];
                feature_title = replacementsDictionary["$projectname$"];

                // Display a form to the user to collect data needed to configure the project.
                m_inputForm = new FeatureDetailsForm();
                m_inputForm.Hidden = feature_hidden;
                m_inputForm.FeatureName = feature_name;
                m_inputForm.FeatureTitle = feature_title;
                m_inputForm.FeaturePrefix = feature_prefix;
                m_inputForm.FeatureDescription = feature_description;
                m_inputForm.FeatureScope = feature_scope;
                m_inputForm.ShowDialog();

                // Retrieve the edited parameters from the input form.
                feature_name = m_inputForm.FeatureName.Replace(" ","");
                feature_title = m_inputForm.FeatureTitle;
                feature_prefix = m_inputForm.FeaturePrefix.Replace(" ","_");
                feature_folder = string.IsNullOrEmpty(feature_prefix) ? feature_name : feature_prefix + "." + feature_name;
                feature_description = m_inputForm.FeatureDescription;
                feature_scope = m_inputForm.FeatureScope;
                feature_hidden = m_inputForm.Hidden;

                // Add custom parameters that can be referenced from the template.
                replacementsDictionary.Add("$feature_name$", feature_name);
                replacementsDictionary.Add("$feature_title$", feature_title);
                replacementsDictionary.Add("$feature_prefix$", feature_prefix);
                replacementsDictionary.Add("$feature_folder$", feature_folder);
                replacementsDictionary.Add("$feature_description$", feature_description);
                replacementsDictionary.Add("$feature_scope$", feature_scope.ToString());
                replacementsDictionary.Add("$feature_hidden$", feature_hidden ? "TRUE" : "FALSE");

            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString());
            }
        }

        /// <summary>
        /// Only called for item templates.
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        bool IWizard.ShouldAddProjectItem(string filePath)
        {
            return true;
        }

        #endregion
    }
}
