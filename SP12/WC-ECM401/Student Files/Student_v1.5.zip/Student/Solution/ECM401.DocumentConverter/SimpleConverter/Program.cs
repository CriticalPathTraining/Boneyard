using System;
using System.IO;
using System.ComponentModel;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;

namespace ECM401.DocumentConversion
{
    public class SimpleConverter
    {
        enum ArgType { _in, _out, _config, _log, _unknown };

        static void Main(string[] args)
        {
            ArgType m_argType = ArgType._unknown;
            string[] arg = new string[(int)ArgType._unknown];

            foreach (string s in args) {
                if (s[0] == '-' || s[0] == '/')
                    m_argType = (ArgType)Enum.Parse(typeof(ArgType),s.Replace(s[0].ToString(), "_"));
                else {
                    arg[(int)m_argType] = s;
                    m_argType = ArgType._unknown;
                }
            }
            SimpleConverter.ConvertToHTML(arg[0],arg[1],arg[2],arg[3]);
        }

        /// <summary>
        /// Performs the conversion to HTML
        /// </summary>
        /// <param name="inFile">the input file containing comma-delimited strings</param>
        /// <param name="outFile">the HTML output file</param>
        /// <param name="configFile">optional configuration settings file</param>
        /// <param name="logFile">optional log file</param>
        static void ConvertToHTML(string inFile, string outFile, string configFile, string logFile)
        {
            using (StreamReader reader = new StreamReader(inFile)) {
                using (HtmlTextWriter writer = new HtmlTextWriter(new StreamWriter(outFile))) {
                    writer.RenderBeginTag(HtmlTextWriterTag.Html);
                    WriteStyles(reader, writer);
                    WriteBody(reader, writer);
                    writer.RenderEndTag();
                    writer.Close();
                }
            }
        }

        static void WriteStyles(StreamReader reader, HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Head);
            writer.RenderBeginTag(HtmlTextWriterTag.Style);
            writer.WriteLine("TABLE { border-style:solid; border-color:green; }");
            writer.WriteLine("TH { font-weight:bold; font-size:10pt; }");
            writer.WriteLine("TD { font-size:8pt; color:blue; }");
            writer.RenderEndTag();
            writer.RenderEndTag();
        }

        static void WriteBody(StreamReader reader, HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Body);
            writer.RenderBeginTag(HtmlTextWriterTag.Table);
            int i, rows = 0, cols = 0;
            while (!reader.EndOfStream) {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr);
                HtmlTextWriterTag colTag = HtmlTextWriterTag.Td;
                string[] tokens = reader.ReadLine().Split(",".ToCharArray());
                if (rows++ == 0) {
                    cols = tokens.Length;
                    colTag = HtmlTextWriterTag.Th;
                }
                for (i = 0; i < cols; i++) {
                    writer.RenderBeginTag(colTag);
                    if (i < tokens.Length) {
                        writer.Write(tokens[i]);
                    }
                    writer.RenderEndTag();
                }
                writer.RenderEndTag();
            }
            writer.RenderEndTag();
            writer.RenderEndTag();
        }

        static void DoConversion(SPWeb web, System.Guid converterId)
        {
            SPDocumentLibrary docLib = web.Lists["Pages"] as SPDocumentLibrary;
            foreach (SPListItem item in docLib.Items) {
                SPFile fileToConvert = item.File;
                if (!fileToConvert.IsConvertedFile) {
                    if (PublishingWeb.IsPublishingWeb(web)) {
                        PublishingWeb publishingWeb = PublishingWeb.GetPublishingWeb(web);
                        PublishingPageCollection pages = publishingWeb.GetPublishingPages();
                        PublishingPage page = pages.Add(item.Title, fileToConvert, converterId, PageConversionPriority.Immediately);
                    } else {
                        Guid workItemId=Guid.Empty;
                        fileToConvert.Convert(converterId,item.Title,null,null,null,0,null,false,false,out workItemId);
                    }
                }
            }
        }
    }
}
