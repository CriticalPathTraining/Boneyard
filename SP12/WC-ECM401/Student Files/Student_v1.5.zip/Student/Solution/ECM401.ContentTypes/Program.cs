using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.ContentTypeBrowser
{
    class Program
    {
        #region Data Members
        private bool m_recursive=false;

        public bool Recursive
        {
            get { return m_recursive; }
            set { m_recursive = value; }
        }
        private string m_url="http://litwareinc.com";

        public string Url
        {
            get { return m_url; }
            set { m_url = value; }
        }
        private string m_targetType="Item";

        public string TargetType
        {
            get { return m_targetType; }
            set { m_targetType = value; }
        }
        #endregion

        static void Main(string[] args)
        {
            bool isType = false;
            bool recursive = true;
            string baseType = null;
            string url = "http://litwareinc.com/sites/documents";

            foreach (string option in args)
            {
                switch (option.ToLower())
                {
                    case "-type": isType = true; break;
                    case "-recursive": recursive = true; break;
                    default:
                        if (isType)
                        {
                            baseType = option.Replace("\"", "");
                            isType = false;
                        }
                        else
                        {
                            url = option.Replace("\"", "");
                        }
                        break;
                }
            }

            new Program(url, baseType, recursive).Run();

            Console.WriteLine("Press any key...");
            Console.ReadKey();
        }

        /// <summary>
        /// Program constructor
        /// </summary>
        public Program(string url, string baseType, bool recursive)
        {
            this.Url = url;
            this.TargetType = baseType;
            this.Recursive = recursive;
        }

        /// <summary>
        /// Executes the program.
        /// </summary>
        public void Run()
        {
            // Open the site.
            using (SPSite site = new SPSite(this.Url))
            {
                // Get the root web.
                using (SPWeb web = site.OpenWeb())
                {
                    // Prevent endless recursion.
                    if (this.TargetType == null)
                        this.Recursive = false;

                    // Get the available content types.
                    foreach (SPContentType contentType in web.AvailableContentTypes)
                    {
                        if (this.TargetType == null)
                            DisplayContentType(0,contentType);
                        else if (contentType.Name.Equals(this.TargetType))
                            DisplayContentType(0,contentType);
                    }
                }
            }
        }

        /// <summary>
        /// Writes content type information to the console.
        /// </summary>
        /// <param name="indentLevel"></param>
        /// <param name="contentType"></param>
        public void DisplayContentType(int indentLevel, SPContentType contentType)
        {
            for (int i = 0; i < indentLevel; i++)
                Console.Write("   ");
            Console.WriteLine("{0}",contentType.Name);
            //Console.WriteLine(contentType.SchemaXml);
            if (this.Recursive)
            {
                foreach (SPContentType subType in contentType.ParentWeb.AvailableContentTypes)
                    if (DerivesFrom(contentType, subType))
                        DisplayContentType(indentLevel + 1, subType);
            }
        }

        /// <summary>
        /// Returns true if the child is derived from the parent.
        /// </summary>
        /// <param name="parentType"></param>
        /// <param name="testType"></param>
        /// <returns></returns>
        private bool DerivesFrom(SPContentType parentType, SPContentType testType)
        {
            while (testType.Name != "System")
            {
                testType = testType.Parent;
                if (testType.Name.Equals(parentType.Name))
                    return true;
            }
            return false;
        }
    }
}
