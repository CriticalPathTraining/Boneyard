﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Xml;
using ECM401.InformationPolicy;
using Microsoft.SharePoint;
using ECM401.ContentTypes;
using Microsoft.Office.RecordsManagement.InformationPolicy;

namespace ECM401.PrinterControlPolicy
{
    [Name("Document Print Controller")]
    [Description("Maintains a list of 'trusted' printers so that administrators "
        + "can control where documents are printed.")]
    [Publisher("John F. Holliday")]
    public class PrinterPolicyFeature : SharePointPolicyFeature
    {
        public const string TrustedPrintersFieldName = "TrustedPrinters";
        public const string PrintControlPolicyNamespace = "urn:ecm401:policy.printcontrol";

        public PrinterPolicyFeature()
        {
            this.ConfigPage = "ECM401.PrinterControlPolicyFeature/PrinterPolicySettings.ascx";
            this.ConfigPageInstructions = @"Add the names of trusted printers "
                + "here, separated by semicolons.  This will prevent users from printing "
                + "documents to which this policy is applied on unsecure printers. "
                + "NOTE: In order for this to work, you must also deploy the "
                + "PrintController add-on for Microsoft Office to all client machines.";
        }

        /// <summary>
        /// Helper method for logging trace messages.
        /// </summary>
        /// <param name="message"></param>
        public static void Log(string message)
        {
            Trace.WriteLine(message, "ECM401.PrinterPolicyFeature");
        }

        /// <summary>
        /// This class implements the event receivers for the policy feature.
        /// </summary>
        public class PrinterPolicyEventReceiver : ItemEventReceiver
        {
            /// <summary>
            /// Handles the item added event to set the list of trusted printers.
            /// </summary>
            /// <param name="properties"></param>
            public override void ItemAdded(SPItemEventProperties properties)
            {
                base.ItemAdded(properties);
                Log("PrinterPolicyFeature.ItemAdded - " + properties.ListTitle);
                AddPrintersToListItem(properties.ListItem);
            }

            /// <summary>
            /// Handles the item updated event to set the list of trusted printers.
            /// </summary>
            /// <param name="properties"></param>
            public override void ItemUpdated(SPItemEventProperties properties)
            {
                base.ItemUpdated(properties);
                Log("PrinterPolicyFeature.ItemUpdated - " + properties.ListTitle);
                AddPrintersToListItem(properties.ListItem);
            }

            /// <summary>
            /// Gets the list of trusted printers from the content type associated
            /// with the item and places it into the appropriate field.
            /// </summary>
            /// <param name="item"></param>
            private void AddPrintersToListItem(SPListItem item)
            {
                if (item == null || item.ContentType == null)
                    return;
                Log("AddPrintersToListItem '" + item.Title + "'");
                string xml = item.ContentType.XmlDocuments[PrinterPolicyFeature.PrintControlPolicyNamespace];
                if (string.IsNullOrEmpty(xml))
                {
                    Log("-- content type payload is empty");
                }
                else
                {
                    Log("-- loading content type payload");
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(xml);
                    XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
                    nsmgr.AddNamespace("p", PrinterPolicyFeature.PrintControlPolicyNamespace);
                    XmlNode node = xmlDoc.SelectSingleNode("p:data/p:printers", nsmgr);
                    Log("-- '" + node.InnerText + "'");
                    SPField field = item.Fields[PrinterPolicyFeature.TrustedPrintersFieldName];

                    try
                    {
                        item[field.Id] = node.InnerText;
                        item.SystemUpdate();
                        Log("-- UPDATED!");
                    }
                    catch (SPException x)
                    {
                        Log(string.Format("-- FAILED to update item - {0}", x.Message));
                    }
                }
            }
        }

        #region SharePointPolicyFeature Overrides

        /// <summary>
        /// This method is called when the feature is registered for a content type.
        /// Adds a "TrustedPrinters" field to the content type.
        /// </summary>
        /// <param name="ct"></param>
        public override void Register(SPContentType ct)
        {
            base.Register(ct);
            Log("Registering print control for content type: " + ct.Name);

            // Setup the item event receiver for the content type.
            ItemEventReceiver.Create(ct, typeof(PrinterPolicyEventReceiver));

            // Add the "TrustedPrinters" field to the content type.
            SPFieldLink fieldRef = SharePointContentType.AddOrCreateFieldReference(ct, 
                PrinterPolicyFeature.TrustedPrintersFieldName, SPFieldType.Text, false, 
                true, true,true,true);
        }

        /// <summary>
        /// This method is called when the policy feature is removed.
        /// Uninstalls the event receiver from the content type.
        /// </summary>
        /// <param name="ct"></param>
        public override void UnRegister(SPContentType ct)
        {
            base.UnRegister(ct);
            Log("Unregistering PrintControl for content type: " + ct.Name);
            ItemEventReceiver.Remove(ct, typeof(PrinterPolicyEventReceiver));
        }

        /// <summary>
        /// This method is called by the policy framework for list items that were
        /// created before the policy was applied to the list.
        /// </summary>
        /// <param name="site"></param>
        /// <param name="policyItem"></param>
        /// <param name="listItem"></param>
        /// <returns></returns>
        public override bool ProcessListItem(SPSite site, Microsoft.Office.RecordsManagement.InformationPolicy.PolicyItem policyItem, SPListItem listItem)
        {
            Log("Processing list item: " + listItem.Title);
            bool result = base.ProcessListItem(site, policyItem, listItem);

            // Add the policy item custom data to the TrustedPrinters field.
            try
            {
                // Get the policy data from the item payload.
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(policyItem.CustomData);

                XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
                nsmgr.AddNamespace("p", PrinterPolicyFeature.PrintControlPolicyNamespace);
                XmlNode node = xmlDoc.SelectSingleNode("p:data/p:printers", nsmgr);

                // Store the list of trusted printers into the list item.
                listItem[PrinterPolicyFeature.TrustedPrintersFieldName] = node.InnerText;
                listItem.Update();
            }
            catch (Exception x)
            {
                Log("ProcessListItem failed for item: " + listItem.Title + " - " + x.ToString());
            }
            return result;
        }

        /// <summary>
        /// This method is called when the custom data for a policy item changes.
        /// </summary>
        /// <param name="policyItem"></param>
        /// <param name="ct"></param>
        public override void OnCustomDataChange(PolicyItem policyItem, SPContentType ct)
        {
            base.OnCustomDataChange(policyItem, ct);
            Log("OnCustomDataChange for policy item: " + policyItem.Name
                + " and content type " + ct.Name + " where policy item custom data = "
                + policyItem.CustomData);

            try
            {
                // Get the custom data from the policy item.
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(policyItem.CustomData);
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
                nsmgr.AddNamespace("p", PrinterPolicyFeature.PrintControlPolicyNamespace);

                // Add the custom data to the content type payload.
                ct.XmlDocuments.Delete(PrinterPolicyFeature.PrintControlPolicyNamespace);
                ct.XmlDocuments.Add(xmlDoc);
                ct.Update();
            }
            catch (Exception x)
            {
                Log("OnCustomDataChange failed for item: " + policyItem.Name + " - " + x.ToString());
            }
        }

        #endregion
    }
}
