﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Xml;
using System.IO;
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint;

namespace ECM401.PrinterControlPolicy
{
    /// <summary>
    /// This class implements a custom Information Policy settings control
    /// that enables an administrator to enter the list of trusted printers.
    /// </summary>
    public class PrinterPolicySettings : CustomSettingsControl
    {
        // holds the custom data associated with the control
        string m_customData = string.Empty;

        // automatically bound to the TextBox control in the template
        protected TextBox TextBoxPrinters;

        /// <summary>
        /// This accessor is called to get or set the custom data
        /// associated with the control.
        /// </summary>
        public override string CustomData
        {
            get
            {
                XmlDocument xmlDoc = new XmlDocument();
                string ns = PrinterPolicyFeature.PrintControlPolicyNamespace;
                new XmlNamespaceManager(xmlDoc.NameTable).AddNamespace("p", ns);
                XmlElement rootNode = xmlDoc.CreateElement("p", "data", ns);
                xmlDoc.AppendChild(rootNode);
                XmlElement printersNode = xmlDoc.CreateElement("p", "printers", ns);
                rootNode.AppendChild(printersNode);
                printersNode.InnerText = TextBoxPrinters.Text;
                m_customData = xmlDoc.InnerXml;
                return m_customData;
            }
            set
            {
                m_customData = value;
            }
        }

        /// <summary>
        /// Not used - must be implemented because base class is abstract.
        /// </summary>
        public override void RaisePostDataChangedEvent(){}

        /// <summary>
        /// Not used - must be implemented because base class is abstract.
        /// </summary>
        public override SPList List { get; set; }

        /// <summary>
        /// Not used - must be implemented because base class is abstract.
        /// </summary>
        public override SPContentType ContentType { get; set; }

        /// <summary>
        /// This method updates the custom data associated with the control.
        /// </summary>
        /// <param name="postDataKey"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public override bool LoadPostData(string postDataKey, System.Collections.Specialized.NameValueCollection values)
        {
            string oldData = this.CustomData;
            string newData = values[postDataKey];
            if (oldData != newData)
            {
                this.CustomData = newData;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Loads the custom data string into the textbox whenever the control is loaded.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (!(base.IsPostBack || string.IsNullOrEmpty(m_customData)))
            {
                try
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(m_customData);
                    XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
                    nsmgr.AddNamespace("p", PrinterPolicyFeature.PrintControlPolicyNamespace);
                    XmlNode node = xmlDoc.SelectSingleNode("p:data/p:printers", nsmgr);
                    TextBoxPrinters.Text = node.InnerText;
                }
                catch (Exception x)
                {
                    System.Diagnostics.Trace.WriteLine("Failed to load printer settings - " + x.Message, GetType().Name);
                }
            }
        }
    }
}
