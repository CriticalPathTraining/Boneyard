﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.SharePoint;
using ECM401.InformationPolicy;
using Microsoft.Office.RecordsManagement.InformationPolicy;

namespace ECM401.PrinterControlPolicy
{
    /// <summary>
    /// Handles events during feature installation and activation.
    /// </summary>
    public class FeatureReceiver : SPFeatureReceiver
    {
        /// <summary>
        /// Override to install the printer control policy feature.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            using (SPSite site = properties.Feature.Parent as SPSite)
                if (!SharePointPolicyFeature.Install(typeof(PrinterPolicyFeature)))
                    Trace.WriteLine("Printer Policy Feature installation failed.");
        }

        /// <summary>
        /// Override to remove the printer control policy feature.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            using (SPSite site = properties.Feature.Parent as SPSite)
                if (!SharePointPolicyFeature.Uninstall(typeof(PrinterPolicyFeature)))
                    Trace.WriteLine("Printer Policy Feature removal failed.");
        }

        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    }
}
