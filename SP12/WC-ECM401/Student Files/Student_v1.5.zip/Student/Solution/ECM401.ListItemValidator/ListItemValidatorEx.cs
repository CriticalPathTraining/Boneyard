using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    /// <summary>
    /// Extends the generated class to include static factory methods and to fire events
    /// when validation fails for a given list item.
    /// </summary>
    public partial class ListItemValidator
    {
        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; }
        public event ValidationHandler ValidationFailed;
        public delegate void ValidationHandler(SPListItem item, string message);

        static void Log(string message)
        {
            Trace.WriteLine(message, "ListItemValidator");
        }

        #region Deserialization Methods

        public static ListItemValidator FromXml(string xmlString)
        {
            XmlSerializer ser = new XmlSerializer(typeof(ListItemValidator), "");
            ListItemValidator validator = null;
            try
            {
                validator = ser.Deserialize(new StringReader(xmlString)) as ListItemValidator;
            }
            catch (System.Exception x)
            {
                Log(string.Format("Exception occurred during deserialization - {0}", x.ToString()));
            }
            return validator;
        }

        public static ListItemValidator FromFile(string filename)
        {
            XmlSerializer ser = new XmlSerializer(typeof(ListItemValidator), "");
            ListItemValidator validator = null;
            try
            {
                validator = ser.Deserialize(new FileStream(filename, FileMode.Open)) as ListItemValidator;
            }
            catch (System.Exception x)
            {
                Log(string.Format("Exception occurred during deserialization - {0}", x.ToString()));
            }
            return validator;
        }
        #endregion

        #region Validation Methods

        /// <summary>
        /// Helper to fire validation events.
        /// </summary>
        protected void OnValidationFailed(SPListItem item, string message)
        {
            this.IsValid = false;
            this.ErrorMessage = message;
            Log(string.Format("Validation failed for item '{0}' - '{1}'", item.Title, message));
            if (ValidationFailed != null)
                ValidationFailed(item, message);
        }

        /// <summary>
        /// Helper to set flags for later interrogation by caller.
        /// </summary>
        /// <param name="properties"></param>
        /// <param name="message"></param>
        protected void OnValidationFailed(SPItemEventDataCollection properties, string message)
        {
            this.IsValid = false;
            this.ErrorMessage = message;
            Log(string.Format("Validation failed for item properties - '{0}'", message));
            if (ValidationFailed != null)
                ValidationFailed(null, message);
        }

        /// <summary>
        /// Evaluates the validation rules in sequence to determine which rules match this list item.
        /// Matching rules are then fired, raising the ValidationFailed event on failure.
        /// </summary>
        /// <param name="item">the list item to be validated</param>
        /// <returns>true if the validation succeeded</returns>
        public bool Validate(SPListItem item)
        {
            try
            {
                this.IsValid = true;
                this.ErrorMessage = string.Empty;
                Log(String.Format("Validating Item", item.Title));

                foreach (Rule rule in this.Rule)
                {
                    Log("Validating Rule = " + rule.Name);
                    if (rule.Match.Eval(item))
                    {
                        Log("Matched Rule = " + rule.Name);
                        if (!rule.Try.Eval(item))
                        {
                            Log("rule.Try.Eval(item) - failed - Firing Event...");
                            OnValidationFailed(item, rule.Catch.Throw);
                            return false;
                        }
                        else
                        {
                            Log("rule.Try.Eval(item)-Succeeded");
                        }
                    }
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Validates all items in a collection.
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public bool Validate(SPListItemCollection items)
        {
            foreach (SPListItem item in items)
                if (!Validate(item))
                    return false;
            return true;
        }

        /// <summary>
        /// Validates a set of item data elements.
        /// </summary>
        /// <param name="properties"></param>
        /// <returns></returns>
        public bool Validate(SPItemEventDataCollection properties)
        {
            try
            {
                this.IsValid = true;
                this.ErrorMessage = string.Empty;

                Log("Validating Properties " + properties.ToString());
                foreach (Rule rule in this.Rule)
                {
                    Log("Validating Rule = " + rule.Name);
                    if (rule.Match.Eval(properties))
                    {
                        Log("Matched Rule = " + rule.Name);
                        if (!rule.Try.Eval(properties))
                        {
                            Log("rule.Try.Eval(properties) failed - Firing Event...");
                            OnValidationFailed(properties, rule.Catch.Throw);
                            return false;
                        }
                        else
                        {
                            Log("rule.Try.Eval(properties)-Succeeded");
                        }
                    }
                }
            }
            catch
            {
                Log("rule.Try.Eval(properties) failed - Firing Event...");
                return false;
            }
            return true;
        }

        #endregion

    }
}
