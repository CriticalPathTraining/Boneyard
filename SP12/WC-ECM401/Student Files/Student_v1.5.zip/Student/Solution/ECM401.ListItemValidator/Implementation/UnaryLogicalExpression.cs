﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    public partial class UnaryLogicalExpression
    {
        public bool Eval(SPListItem item, ItemChoiceType1 op)
        {
            switch (op)
            {
                case ItemChoiceType1.Not:
                    return !Expression.Evaluate(item, op, this.Item);
            }
            return false;
        }

        public bool Eval(SPItemEventDataCollection properties, ItemChoiceType1 op)
        {
            switch (op)
            {
                case ItemChoiceType1.Not:
                    return !Expression.Evaluate(properties, op, this.Item);
            }
            return false;
        }
    }
}
