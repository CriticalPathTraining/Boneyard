﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    public partial class FieldRangeExpression
    {
        /// <summary>
        /// Determines if a field value is within a given range.
        /// </summary>
        /// <param name="item"></param>
        /// <param name="op"></param>
        /// <returns></returns>
        public bool Eval(SPListItem item, ItemChoiceType1 op)
        {
            object fieldValue = Expression.GetFieldValue(item, this.Field);
            if (fieldValue == null) return false;
            return 
                this.From.Eval(ItemChoiceType1.Geq, fieldValue) && 
                this.To.Eval(ItemChoiceType1.Leq, fieldValue);
        }

        public bool Eval(SPItemEventDataCollection properties, ItemChoiceType1 op)
        {
            object fieldValue = Expression.GetFieldValue(properties, this.Field);
            if (fieldValue == null) return false;
            return
                this.From.Eval(ItemChoiceType1.Geq, fieldValue) &&
                this.To.Eval(ItemChoiceType1.Leq, fieldValue);
        }
    }
}
