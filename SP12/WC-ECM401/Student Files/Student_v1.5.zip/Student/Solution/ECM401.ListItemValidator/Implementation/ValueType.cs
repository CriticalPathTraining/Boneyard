﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    /// <summary>
    /// Handles low-level value comparisons.
    /// </summary>
    public partial class ValueType
    {
        public static void Log(string message, params object[] args)
        {
            string result = string.Format(message, args);
            Trace.WriteLine(result, "ValueType");
        }

        public bool Eval(ItemChoiceType1 op, object fieldValue)
        {
            Log("Eval op={0}, fieldValue={1}", op.ToString(), fieldValue.ToString());
            FieldDataType dataType = this.TypeSpecified ? this.Type : FieldDataType.String;
            switch (dataType)
            {
                case FieldDataType.Date:
                    {
                        DateTime dateTest = DateTime.Parse(this.Value);
                        DateTime dateValue = DateTime.Parse(fieldValue.ToString());
                        switch (op)
                        {
                            case ItemChoiceType1.Eq:
                                return dateValue.Equals(dateTest);
                            case ItemChoiceType1.Geq:
                                return dateValue.CompareTo(dateTest) >= 0;
                            case ItemChoiceType1.Gtr:
                                return dateValue.CompareTo(dateTest) > 0;
                            case ItemChoiceType1.Leq:
                                return dateValue.CompareTo(dateTest) <= 0;
                            case ItemChoiceType1.Less:
                                return dateValue.CompareTo(dateTest) < 0;
                            case ItemChoiceType1.Neq:
                                return !dateValue.Equals(dateTest);
                            case ItemChoiceType1.Any:
                                return true;
                        } break;
                    }
                case FieldDataType.Boolean:
                    {
                        break;
                    }
                case FieldDataType.Decimal:
                    {
                        decimal decTest = decimal.Parse(this.Value);
                        decimal decValue = decimal.Parse(fieldValue.ToString());
                        switch (op)
                        {
                            case ItemChoiceType1.Eq:
                                return decValue.Equals(decTest);
                            case ItemChoiceType1.Geq:
                                return decValue.CompareTo(decTest) >= 0;
                            case ItemChoiceType1.Gtr:
                                return decValue.CompareTo(decTest) > 0;
                            case ItemChoiceType1.Leq:
                                return decValue.CompareTo(decTest) <= 0;
                            case ItemChoiceType1.Less:
                                return decValue.CompareTo(decTest) < 0;
                            case ItemChoiceType1.Neq:
                                return !decValue.Equals(decTest);
                        }
                        break;
                    }
                case FieldDataType.Double:
                    {
                        double doubleTest = double.Parse(this.Value);
                        double doubleValue = double.Parse(fieldValue.ToString());
                        switch (op)
                        {
                            case ItemChoiceType1.Eq:
                                return doubleValue.Equals(doubleTest);
                            case ItemChoiceType1.Geq:
                                return doubleValue.CompareTo(doubleTest) >= 0;
                            case ItemChoiceType1.Gtr:
                                return doubleValue.CompareTo(doubleTest) > 0;
                            case ItemChoiceType1.Leq:
                                return doubleValue.CompareTo(doubleTest) <= 0;
                            case ItemChoiceType1.Less:
                                return doubleValue.CompareTo(doubleTest) < 0;
                            case ItemChoiceType1.Neq:
                                return !doubleValue.Equals(doubleTest);
                        }
                        break;
                    }
                case FieldDataType.Number:
                    {
                        int intTest = int.Parse(this.Value);
                        int intValue = int.Parse(fieldValue.ToString());
                        switch (op)
                        {
                            case ItemChoiceType1.Eq:
                                return intValue.Equals(intTest);
                            case ItemChoiceType1.Geq:
                                return intValue.CompareTo(intTest) >= 0;
                            case ItemChoiceType1.Gtr:
                                return intValue.CompareTo(intTest) > 0;
                            case ItemChoiceType1.Leq:
                                return intValue.CompareTo(intTest) <= 0;
                            case ItemChoiceType1.Less:
                                return intValue.CompareTo(intTest) < 0;
                            case ItemChoiceType1.Neq:
                                return !intValue.Equals(intTest);
                        }
                        break;
                    }
                case FieldDataType.String:
                    {
                        string stringTest = this.Value;
                        string stringValue = fieldValue.ToString();
                        switch (op)
                        {
                            case ItemChoiceType1.Eq:
                                return stringValue.Equals(stringTest);
                            case ItemChoiceType1.Geq:
                                return stringValue.CompareTo(stringTest) >= 0;
                            case ItemChoiceType1.Gtr:
                                return stringValue.CompareTo(stringTest) > 0;
                            case ItemChoiceType1.Leq:
                                return stringValue.CompareTo(stringTest) <= 0;
                            case ItemChoiceType1.Less:
                                return stringValue.CompareTo(stringTest) < 0;
                            case ItemChoiceType1.Neq:
                                return !stringValue.Equals(stringTest);
                        }
                        break;
                    }
            }
            return false;
        }
    }
}
