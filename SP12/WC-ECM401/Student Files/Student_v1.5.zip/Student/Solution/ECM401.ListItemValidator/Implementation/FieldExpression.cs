﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    /// <summary>
    /// Applies an operator to a given field value to determine a match.
    /// </summary>
    public partial class FieldExpression
    {
        public bool Eval(SPListItem item, ItemChoiceType1 op)
        {
            Trace.WriteLine(string.Format("Eval op='{0}'",op.ToString()));
            object fieldValue = Expression.GetFieldValue(item, this.Field);
            if (fieldValue == null)
                return false;
            return this.Value.Eval(op, fieldValue);
        }

        public bool Eval(SPItemEventDataCollection properties, ItemChoiceType1 op)
        {
            object fieldValue = Expression.GetFieldValue(properties, this.Field);
            if (fieldValue == null)
                return false;
            return this.Value.Eval(op, fieldValue);
        }
    }
}
