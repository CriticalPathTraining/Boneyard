using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    /// <summary>
    /// Extends the generated Expression class to evaluate a given list item.  Used both to
    /// match list items to rules and to determine whether a given list item is valid.
    /// </summary>
    public partial class Expression
    {
        public static void Log(string message,params object[] args)
        {
            string result = string.Format(message,args);
            Trace.WriteLine(result, "Expression");
        }

        /// <summary>
        /// Determines if the values of the specified list item fields matches this expression.
        /// </summary>
        /// <param name="item">the list item to test</param>
        /// <returns>true if the item matches the rule, otherwise false</returns>
        public bool Eval(SPListItem item)
        {
            try
            {
                ItemChoiceType1 op = this.ItemElementName;
                if (Item is FieldExpression)
                {
                    Log("Evaluating field expression: op='{0}'", op.ToString());
                    return ((FieldExpression)Item).Eval(item, op);
                }
                else if (Item is FieldRangeExpression)
                {
                    Log("Evaluating field range expression: op='{0}'", op.ToString());
                    return ((FieldRangeExpression)Item).Eval(item, op);
                }
                else if (Item is LogicalExpression)
                {
                    Log("Evaluating logical expression: op='{0}'", op.ToString());
                    return ((LogicalExpression)Item).Eval(item, op);
                }
                else if (Item is UnaryLogicalExpression)
                {
                    Log("Evaluating unary logical expression: op='{0}'", op.ToString());
                    return ((UnaryLogicalExpression)Item).Eval(item, op);
                }
                else if (ItemElementName == ItemChoiceType1.Any)
                {
                    Log("Evaluating to true");
                    return true;
                }
            }
            catch (System.Exception x)
            {
                Log("Evaluation failed - {0}", x.Message);
            }
            return false;
        }

        /// <summary>
        /// Processes a collection of item data properties.
        /// </summary>
        /// <param name="properties"></param>
        /// <returns></returns>
        public bool Eval(SPItemEventDataCollection properties)
        {
            try
            {
                ItemChoiceType1 op = this.ItemElementName;
                if (Item is FieldExpression)
                    return ((FieldExpression)Item).Eval(properties, op);
                else if (Item is FieldRangeExpression)
                    return ((FieldRangeExpression)Item).Eval(properties, op);
                else if (Item is LogicalExpression)
                    return ((LogicalExpression)Item).Eval(properties, op);
                else if (Item is UnaryLogicalExpression)
                    return ((UnaryLogicalExpression)Item).Eval(properties, op);
                else if (ItemElementName == ItemChoiceType1.Any)
                    return true;
            }
            catch
            {
            }
            return false;
        }


        /// <summary>
        /// Safely retrieves the value of a given field.
        /// </summary>
        /// <param name="item"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static object GetFieldValue(SPListItem item, string fieldName)
        {
            object result = null;
            try
            {
                result = item[fieldName];
            }
            catch (System.Exception x)
            {
            }
            return result;
        }

        /// <summary>
        /// Safely retrieves the value of a given field in a property collection.
        /// </summary>
        /// <param name="properties"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static object GetFieldValue(SPItemEventDataCollection properties, string fieldName)
        {
            object result = null;
            try
            {
                Log("GetFieldValue('{0}')", fieldName);
                result = properties[fieldName];
                Log("field '{0}' result = '{1}'", fieldName, result);
            }
            catch (System.Exception x)
            {
                Log("Exception in GetFieldValue '{0}' - {1}", fieldName, x.ToString());
            }
            return result;
        }

        /// <summary>
        /// Applies an operation to a list item for different kinds of expressions.
        /// </summary>
        public static bool Evaluate(SPListItem item, ItemChoiceType1 op, object expression)
        {
            if (expression is FieldExpression)
                return ((FieldExpression)expression).Eval(item, op);
            else if (expression is FieldRangeExpression)
                return ((FieldRangeExpression)expression).Eval(item, op);
            else if (expression is LogicalExpression)
                return ((LogicalExpression)expression).Eval(item, op);
            else if (expression is UnaryLogicalExpression)
                return ((UnaryLogicalExpression)expression).Eval(item, op);
            return false;
        }


        /// <summary>
        /// Applies an operation to a property set for different kinds of expressions.
        /// </summary>
        public static bool Evaluate(SPItemEventDataCollection properties, ItemChoiceType1 op, object expression)
        {
            if (expression is FieldExpression)
                return ((FieldExpression)expression).Eval(properties, op);
            else if (expression is FieldRangeExpression)
                return ((FieldRangeExpression)expression).Eval(properties, op);
            else if (expression is LogicalExpression)
                return ((LogicalExpression)expression).Eval(properties, op);
            else if (expression is UnaryLogicalExpression)
                return ((UnaryLogicalExpression)expression).Eval(properties, op);
            return false;
        }
    }

}
