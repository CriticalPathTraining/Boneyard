﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace ECM401.Validation
{
    public partial class LogicalExpression
    {
        public bool Eval(SPListItem item, ItemChoiceType1 op)
        {
            switch (op)
            {
                case ItemChoiceType1.And:
                    return Expression.Evaluate(item, op, Items[0]) && 
                        Expression.Evaluate(item, op, Items[1]);
                case ItemChoiceType1.Or:
                    return Expression.Evaluate(item, op, Items[0]) || 
                        Expression.Evaluate(item, op, Items[1]);
            }
            return false;
        }

        public bool Eval(SPItemEventDataCollection properties, ItemChoiceType1 op)
        {
            switch (op)
            {
                case ItemChoiceType1.And:
                    return Expression.Evaluate(properties, op, Items[0]) &&
                        Expression.Evaluate(properties, op, Items[1]);
                case ItemChoiceType1.Or:
                    return Expression.Evaluate(properties, op, Items[0]) ||
                        Expression.Evaluate(properties, op, Items[1]);
            }
            return false;
        }
    }
}
