﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ECM401.ContentTypeBrowser
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles changes in the selected content type.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void contentTypeTree1_SelectionChanged(object sender, SharePointObjectEventArgs e)
        {
            m_properties.SetObject(e.SharePointObject);
            m_detail.SetObject(e.SharePointObject);
        }

        /// <summary>
        /// Closes the application.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Called to refresh the content type tree.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            contentTypeTree1.RefreshTypes();
        }
    }
}
