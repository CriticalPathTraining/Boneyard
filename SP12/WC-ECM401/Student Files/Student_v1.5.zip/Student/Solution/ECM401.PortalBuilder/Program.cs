﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.DirectoryServices;
using System.Security;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Navigation;

namespace ECM401.PortalBuilder
{
    /// <summary>
    /// This program creates a portal for the ECM401 training class.
    /// </summary>
    /// <remarks>
    /// The following components are created:
    ///     1) An IIS web application named "ECM" on port 401 so that the top-level url is "http://localhost:401".
    ///     2) A separate web for each day of the course, namely:
    ///         a) http://localhost:401/DocMan    (day 1 - document management)
    ///         b) http://localhost:401/RecMan    (day 2 - records management)
    ///         c) http://localhost:401/BPM       (day 3 - electronic forms and workflow)
    ///         d) http://localhost:401/WCM       (day 4 - web content management)
    /// </remarks>
    class Program
    {
        const int ecmPort = 401;
        const string ecmAppName = "ECM401";
        const string ecmHostHeader = "ECM401";
        const string ecmDatabaseName = "WSS_Content_ECM401";
        const string ecmAppDescription = "Enterprise Content Management Portal";
        const string ecmAppTemplate = "SPSPORTAL#0";
        const string appPoolName = "ECM401";
        const string adminEmail = "admin@litwareinc.com";
        const string adminLogin = "Administrator";
        const string adminPassword = "pass@word1";
        const string adminDisplayName = "ECM Administrator";

        static void Main(string[] args)
        {
            try
            {
                // Get the local SPFarm object.
                SPFarm farm = SPFarm.Local;

                // Check if the application already exists.
                string appUrl = string.Format("http://localhost:{0}", ecmPort);
                SPWebApplication app = SPWebApplication.Lookup(new Uri(appUrl));

                // Delete it if found
                if (app != null)
                    app.Delete();

                // Use the SPWebApplicationBuilder to create the web application.
                SPWebApplicationBuilder builder = new SPWebApplicationBuilder(farm);
                builder.Port = ecmPort;
                //builder.HostHeader = ecmHostHeader;
                builder.CreateNewDatabase = true;
                builder.UseNTLMExclusively = true;
                builder.AllowAnonymousAccess = false;
                builder.UseSecureSocketsLayer = false;
                builder.ApplicationPoolId = appPoolName;
                builder.IdentityType = IdentityType.SpecificUser;
                builder.ApplicationPoolUsername = adminLogin;
                builder.ApplicationPoolPassword = new SecureString();
                foreach (Char c in adminPassword.ToCharArray())
                    builder.ApplicationPoolPassword.AppendChar(c);

                // Create a new web application attached to a new application pool.
                Console.WriteLine("Creating web application: {0}", appUrl);
                app = builder.Create();
                app.Name = ecmAppName;
                app.Update();
                Console.WriteLine("Provisioning content database: {0}", builder.DatabaseName);
                app.Provision();

                // Add the new web application to central admin.
                Console.WriteLine("Adding application to central administration");
                SPWebService.AdministrationService.WebApplications.Add(app);

                // Recycle the app pool.
                using (DirectoryEntry appPool = new DirectoryEntry(string.Format("IIS://localhost/w3svc/apppools/{0}", appPoolName)))
                {
                    Console.WriteLine("Recycling app pool: {0}", appPoolName);
                    appPool.Invoke("Recycle");
                }

                // Create the site collections.
                Console.WriteLine("Creating site collection...");
                SPSite siteCollection = app.Sites.Add("/", ecmAppName, ecmAppDescription, 1033, ecmAppTemplate, adminLogin, adminDisplayName, adminEmail);
                PortalInit(siteCollection.RootWeb);
            }
            catch (Exception x)
            {
                Console.WriteLine("An exception occurred during processing:");
                Console.WriteLine(x.ToString());
            }
            Console.Write("Press any key...");
            Console.ReadKey();
        }

        /// <summary>
        /// Initializes the portal.
        /// </summary>
        /// <param name="web"></param>
        static void PortalInit(SPWeb web)
        {
            // Add the subwebs.
            DocManInit(CreateSubWeb(web, "docman", "", "Day 1 - Document Management", "ECM410 Course Materials for document management.", "STS#0"));
            RecManInit(CreateSubWeb(web, "recman", "", "Day 2 - Records Management", "ECM401 Course Materials for records management.", "STS#0"));
            BPMInit(CreateSubWeb(web, "bpm", "", "Day 3 - Electronic Forms and Workflow", "ECM401 Course Materials for business process management.", "STS#0"));
            WCMInit(CreateSubWeb(web, "wcm", "", "Day 4 - Web Content Management", "ECM401 Course Materials for web content management.", "STS#0"));
        }

        /// <summary>
        /// Creates a subweb having the specified properties.
        /// </summary>
        static SPWeb CreateSubWeb(SPWeb web, string url, string navTitle, string title, string description, string template)
        {
            Console.WriteLine("Creating subweb '{0}' beneath web '{1}'", navTitle, web.Title);
            SPWeb subweb = web.Webs.Add(url, title, description, 1033, template, false, false);
            // add navigation links
            if (!string.IsNullOrEmpty(navTitle))
            {
                // add top navigation link
                web.Navigation.TopNavigationBar.AddAsLast(new SPNavigationNode(navTitle, subweb.ServerRelativeUrl));
                // add quick launch link
                foreach (SPNavigationNode node in web.Navigation.QuickLaunch)
                    if (node.Title.Equals("Sites"))
                        node.Children.AddAsLast(new SPNavigationNode(navTitle, subweb.ServerRelativeUrl));
            }
            return subweb;
        }

        /// <summary>
        /// Initializes the document management web.
        /// </summary>
        /// <param name="web"></param>
        static void DocManInit(SPWeb web)
        {
            Console.WriteLine("Initializing document management web...");
            CreateSubWeb(web, "Part1", "Document Libraries", "Part 1 - Document Libraries", "Exercises for creating and managing document libraries.", "STS#1");
            CreateSubWeb(web, "Part2", "Content Types", "Part 2 - Content Types", "Exercises for creating and working with content types.", "STS#1");
            CreateSubWeb(web, "Part3", "Auditing", "Part 3 - Tracking, Auditing and Secrity", "Exercises for monitoring changes to documents and list items.", "STS#1");
            CreateSubWeb(web, "Part4", "IRM", "Part 4 - Information Rights Management", "Exercises for setting up and working with Rights Management Services and Information Rights Management.", "STS#1");
        }

        /// <summary>
        /// Initializes the records management web.
        /// </summary>
        /// <param name="web"></param>
        static void RecManInit(SPWeb web)
        {
            Console.WriteLine("Initializing records management web...");
            CreateSubWeb(web, "Part1", "Records Repositories", "Part 1 - Records Repositories", "Exercises for creating and working with records repositories.", "STS#1");
            CreateSubWeb(web, "Part2", "Information Policy", "Part 2 - Information Management Policy", "Exercises for creating information policies, policy features and resources.", "STS#1");
            CreateSubWeb(web, "Part3", "Routing and Holds", "Part 3 - Routing and Holds", "Exercises for creating and working with holds.", "STS#1");
            CreateSubWeb(web, "RecordCenter", "Record Center", "ECM401 Record Center", "A sample record repository site.", "OFFILE#1");
        }

        static void BPMInit(SPWeb web)
        {
            Console.WriteLine("Initializing business process management web...");
            CreateSubWeb(web, "Part1", "InfoPath", "Part 1 - Gathering Data with InfoPath", "Exercises for working with InfoPath to create form data.", "STS#1");
            CreateSubWeb(web, "Part2", "Form Services", "Part 2 - Working with Form Data", "Exercises for working with form data.", "STS#1");
            CreateSubWeb(web, "Part3", "Workflow", "Part 3 - Building Custom Workflows", "Exercises for creating workflows using SPD and Visual Studio.", "STS#1");
        }

        static void WCMInit(SPWeb web)
        {
            Console.WriteLine("Initializing web content management web...");
            CreateSubWeb(web, "Part1", "MOSS Publishing", "Part 1 - Publishing in MOSS", "Exercises for understanding the MOSS publishing framework.", "STS#1");
            CreateSubWeb(web, "Part2", "Custom Publishing", "Part 2 - Customizing the Framework", "Exercises for building custom publishing solutions.", "STS#1");
            CreateSubWeb(web, "Part3", "Publishing Workflow", "Part 3 - Publishing and Workflow", "Exercises for extending the OOB publishing workflows.", "STS#1");
            CreateSubWeb(web, "Publishing", "Sample Portal", "ECM401 Publishing", "A sample publishing portal.", "BLANKINTERNETCONTAINER#2");
        }
    }
}
