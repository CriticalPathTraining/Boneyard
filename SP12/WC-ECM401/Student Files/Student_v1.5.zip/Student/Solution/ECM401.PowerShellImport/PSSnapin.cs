using System;
using System.Collections.Generic;
using System.Text;
using System.Management.Automation;
using System.ComponentModel;

namespace SPPowerShell
{
    /// <summary>
    /// This is a PowerShell 'snapin' class, which acts as a deployment package for
    /// the collection of cmdlets and PScmdlets used to administer SharePoint.
    /// </summary>
    [RunInstaller(true)]
    public class SPPowerShell_SnapIn : PSSnapIn
    {
        public override string Name
        {
            get { return "SPPowerShell"; }
        }
        public override string Vendor
        {
            get { return "John F. Holliday"; }
        }
        public override string VendorResource
        {
            get { return "SPPowerShell,Vendor"; }
        }
        public override string Description
        {
            get { return "A set of PowerShell commands for SharePoint."; }
        }
        public override string DescriptionResource
        {
            get { return "SPPowerShell,A set of PowerShell commands for SharePoint"; }
        }
    }
}
