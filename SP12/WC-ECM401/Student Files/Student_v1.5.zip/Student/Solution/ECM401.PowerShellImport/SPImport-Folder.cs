using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Management.Automation;
using System.Collections;
using Microsoft.SharePoint;
using System.Runtime.InteropServices;

namespace SPPowerShell
{
    /// <summary>
    /// This cmdlet provides a more powerful and comprehensive way to move documents into a SharePoint
    /// site collection by letting the user add metadata and permissions to each document as it is
    /// being transferred.  The source documents are first arranged in physical folders on the file system,
    /// and a manifest file is optionally added to the folder to specify the metadata and other rules
    /// that should apply to the documents in that folder.  Rules in the manifest control whether nested
    /// folders inherit or override the settings in the parent folder.
    /// </summary>
    /// <remarks>
    /// SYNOPSIS
    /// Imports documents from file system folders into SharePoint site(s).
    /// 
    /// SYNTAX
    /// SPImport-Folder [-source] string [-url] string
    /// </remarks>
    [Cmdlet("SPImport", "Folder", SupportsShouldProcess = true)]
    public class SPImport_Folder : Cmdlet
    {
        #region Parameters

        /// <summary>
        /// This parameter accepts a wildcard file mask that will be expanded
        /// to a list of folders to be imported to the SharePoint site.
        /// </summary>
        [Parameter(Position = 0,
            Mandatory = true,
            ValueFromPipeline = true,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Enter the fully qualified path to the folder you wish to import.  You can enter a standard wildcard mask.")]
        [ValidateNotNullOrEmpty]
        [Alias("Folder", "Path", "SourceFolder")]
        public string Source { get; set; }

        /// <summary>
        /// This parameter specifies the url of the SharePoint site to which the
        /// documents will be imported.  If no manifest is found or no document library is specified
        /// in the manifest, then the files are imported to a new library called "Imported Documents".
        /// If the specified site does not exist, an InvalidArgument exception is thrown.
        /// </summary>
        [Parameter(Position = 1,
            Mandatory = true,
            ValueFromPipeline = true,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Enter the url of the target SharePoint site.")]
        [Alias("Site", "Url")]
        public string SiteUrl { get; set; }

        /// <summary>
        /// This parameter controls whether existing files with the same name are overwritten.
        /// </summary>
        [Parameter(
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Specify whether to overwrite files that already exist in the target library or folder.  Default=false.")]
        public SwitchParameter Overwrite { get; set; }

        /// <summary>
        /// This parameter controls whether subfolders are processed.
        /// </summary>
        [Parameter(
            ValueFromPipelineByPropertyName=true,
            HelpMessage = "Specify whether to process subfolders of the source folder.")]
        public SwitchParameter Recursive { get; set; }

        #endregion

        /// <summary>
        /// This is the standard entry point for PowerShell commands.  It is called after the command line
        /// arguments have been parsed and set into the corresponding properties of the cmdlet class.
        /// </summary>
        protected override void ProcessRecord()
        {
            try
            {
                // Reduce the source path to a DirectoryInfo object.
                if (!this.Source.EndsWith("\\"))
                    this.Source += "\\";
                string folderName = Path.GetDirectoryName(Source);
                if (string.IsNullOrEmpty(folderName))
                    folderName = Environment.CurrentDirectory;
                DirectoryInfo folder = new DirectoryInfo(Path.GetFullPath(folderName));

                // Locate the target SharePoint site collection.
                using (SPSite site = new SPSite(SiteUrl))
                using (SPWeb web = site.OpenWeb())
                {
                    // Process the files in the folder and its subfolders.
                    Utilities.TransferFolderUsingManifest(web, folder, Overwrite, Recursive);
                }
            }
            catch (Exception x)
            {
                Console.WriteLine("Unable to process files: ");
                Console.WriteLine(x.Message);
            }
        }

    }
}
