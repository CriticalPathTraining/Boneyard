using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Management.Automation;
using System.Collections;
using Microsoft.SharePoint;
using System.Runtime.InteropServices;

namespace SPPowerShell
{
    /// <summary>
    /// It is a common requirement to move documents from the file system into a SharePoint site.  This PowerShell cmdlet 
    /// enables an administrator to easily upload documents to a SharePoint site or document library.  Source files can
    /// be specified using a standard file mask, along with the target document library name.  If no document library name
    /// is provided, then the files are added directly to the target site.
    /// </summary>
    [Cmdlet("SPImport","Document",SupportsShouldProcess=true)]
    public class SPImport_Document : Cmdlet
    {
        #region Parameters

        /// <summary>
        /// This parameter accepts a wildcard file mask that will be expanded
        /// to a list of files to be uploaded to the document library.  
        /// </summary>
        [Parameter(Position = 0,
            Mandatory = true,
            ValueFromPipeline = true,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Enter the fully qualified path to the file(s) you wish to upload.  You can enter a standard wildcard mask.")]
        [ValidateNotNullOrEmpty]
        [Alias("Files")]
        public string FileMask { get; set; }

        /// <summary>
        /// This parameter specifies the url of the SharePoint site to which the
        /// document will be uploaded.  If no document library is specified, then the
        /// file is uploaded directly to the site.  If the site does not exist, an
        /// exception is thrown.
        /// </summary>
        [Parameter(Position = 1,
            Mandatory = true,
            ValueFromPipeline = true,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Enter the url of the target SharePoint site.")]
        [Alias("Url","Site")]
        public string SiteUrl { get; set; }

        /// <summary>
        /// This parameter specifies the name of the target folder or document library within the
        /// specified site.  If the destination folder or document library does not already
        /// exist, then it is created automatically if the 'AutoCreate' parameter is set to true.  
        /// </summary>
        [Parameter(Position = 2,
            Mandatory = false,
            ValueFromPipeline = true,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Enter the name of the folder or document library to which the file(s) will be added.  To specify a root folder within the site, precede the name with a forward slash '/'.")]
        [Alias("List","Library")]
        public string Destination { get; set; }

        /// <summary>
        /// This parameter specifies whether to create the target folder or document library if it
        /// does not already exist within the specified site.
        /// </summary>
        [Parameter(
            ValueFromPipeline=true,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Specify whether to create the target library or folder if it does not already exist.  Default=false.")]
        public SwitchParameter AutoCreate { get; set; }

        /// <summary>
        /// This parameter controls whether existing files with the same name are overwritten.
        /// </summary>
        [Parameter(
            ValueFromPipelineByPropertyName=true,
            HelpMessage="Specify whether to overwrite files that already exist in the target library or folder.  Default=false.")]
        public SwitchParameter Overwrite { get; set; }

        #endregion

        /// <summary>
        /// This is the standard entry point for PowerShell commands.  It is called after the command line
        /// arguments have been parsed and set into the corresponding properties of the cmdlet class.
        /// </summary>
        protected override void ProcessRecord()
        {
            try
            {
                // Expand the file mask into a list of FileInfo objects.
                FileInfo[] files = Utilities.ExpandWildcards(FileMask);
                if (files.Length == 0)
                    throw new Exception("No files specified.");

                // Locate the target SharePoint site collection.
                using (SPSite site = new SPSite(SiteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        // Check the destination to determine what to do.
                        if (string.IsNullOrEmpty(Destination))
                        {
                            // No destination provided, so copy the files into the site itself.
                            Utilities.TransferFiles(web, files, null,Overwrite);
                        }
                        else
                        {
                            // Find or create the target folder and transfer the files.
                            SPFolder targetFolder = Utilities.FindFolder(web, Destination, AutoCreate);
                            Utilities.TransferFiles(web, files, targetFolder,Overwrite);
                        }
                    }
                }
            }
            catch (Exception x)
            {
                Console.WriteLine("Unable to process files: ");
                Console.WriteLine(x.Message);
            }
        }

    }
}
