﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;

namespace SPPowerShell
{
    /// <summary>
    /// Extends the generated ImportManifest class to support file transfer
    /// operations into SharePoint sites.
    /// </summary>
    public partial class ImportManifest
    {
        /// <summary>
        /// Loads a manifest from a specified file.
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static ImportManifest Load(string fileName)
        {
            ImportManifest manifest = null;
            const string ns = "http://schemas.johnholliday.net/sharepoint/importmanifest.xsd";
            XmlSerializer ser = new XmlSerializer(typeof(ImportManifest), ns);
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                manifest = ser.Deserialize(fs) as ImportManifest;
            }
            return manifest;
        }

        /// <summary>
        /// Processes all files in the specified folder according to the rules
        /// specified in this manifest.
        /// </summary>
        /// <param name="web"></param>
        /// <param name="folder"></param>
        public void ImportFiles(SPWeb web, DirectoryInfo folder, bool overwrite)
        {
            // The manifest contains one or more <Library> nodes that target a specific
            // library.  This means that the same files may be imported more than once.
            foreach (LibrarySpecification library in this.Library)
                library.ImportFiles(web, folder, overwrite);
        }
    }

}
