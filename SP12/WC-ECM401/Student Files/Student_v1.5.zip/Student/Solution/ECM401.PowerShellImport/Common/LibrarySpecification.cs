﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;

namespace SPPowerShell
{
    /// <summary>
    /// Extends the generated LibrarySpecification class to support importing of files
    /// into SharePoint.
    /// </summary>
    public partial class LibrarySpecification
    {
        public void ImportFiles(SPWeb web, DirectoryInfo folder, bool overwrite)
        {
            int nCopied = 0;
            int nSkipped = 0;

            // determine the target web.
            SPWeb targetWeb = this.RootWeb ? web.Site.RootWeb : web;

            // find or create the target folder within SharePoint
            SPFolder targetFolder = Utilities.FindFolder(targetWeb, this.Path, this.AutoCreate);

            if (targetFolder == null)
            {
                Console.WriteLine("Cannot find target folder at '{0}'", this.Path);
                return;
            }

            if (targetFolder != null)
            {
                Console.WriteLine("Importing files from '{0}' => '{1}'", folder.FullName, targetFolder.Url);

                // get the list of files matching the file mask(s)
                Dictionary<string, FileInfo> files = new Dictionary<string, FileInfo>();
                string maskSpec = string.IsNullOrEmpty(this.FileMask) ? "*.*" : this.FileMask;
                string[] masks = maskSpec.Split(';');
                foreach (string mask in masks)
                {
                    FileInfo[] matchingFiles = folder.GetFiles(mask);

                    // add them to the list to be processed
                    foreach (FileInfo match in matchingFiles)
                        files.Add(match.Name, match);
                }

                // remove the list of excluded files
                if (!string.IsNullOrEmpty(this.Exclude))
                {
                    string[] excludePaths = this.Exclude.Split(';');
                    foreach (string exclusion in excludePaths)
                    {
                        FileInfo[] excludedFiles = folder.GetFiles(exclusion);
                        foreach (FileInfo exclude in excludedFiles)
                            if (files.ContainsKey(exclude.Name))
                                files.Remove(exclude.Name);
                    }
                }

                // process each file...
                foreach (FileInfo file in files.Values)
                {
                    bool okToCopy = true;
                    if (file.Name.Equals("_manifest.xml"))
                        continue;

                    // check if the file already exists in the target folder
                    SPFile targetFile = Utilities.FindFile(file, targetFolder);
                    if (targetFile != null)
                    {
                        if (overwrite)
                            targetFile.Delete();
                        else
                            okToCopy = false;
                    }

                    if (!okToCopy)
                        nSkipped++;

                    if (okToCopy)
                    {
                        try
                        {
                            // if there are any <Column> nodes, map them to columns
                            // in the target document library so that SharePoint will promote
                            // any matching properties in the document.
                            foreach (ColumnSpecification colSpec in this.Columns)
                                colSpec.MapToLibrary(targetFolder);

                            // Get the file bits and add them to the target folder.
                            using (FileStream fs = file.Open(FileMode.Open))
                                targetFolder.Files.Add(file.Name, fs);
                        }
                        catch (Exception x)
                        {
                            Console.WriteLine("Failed to transfer file: '{0}' to '{1}", file.Name, targetFolder.Name);
                            Console.WriteLine("Exception occurred: {0}", x.ToString());
                        }
                        nCopied++;
                    }
                }

                if (nCopied > 0)
                    Console.WriteLine("{0} files transferred.", nCopied);
                else
                    Console.WriteLine("No files transffered.");

                if (nSkipped > 0)
                    Console.WriteLine("{0} files skipped.", nSkipped);
            }
        }
    }
}
