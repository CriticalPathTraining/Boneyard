﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;

namespace SPPowerShell
{
    /// <summary>
    /// Utility methods shared by all cmdlets.
    /// </summary>
    static class Utilities
    {
        /// <summary>
        /// This method reduces a wildcard mask to an array of FileInfo objects.
        /// </summary>
        internal static FileInfo[] ExpandWildcards(string mask)
        {
            string folderName = Path.GetDirectoryName(mask);
            if (null == folderName || folderName.Length == 0)
            {
                folderName = Environment.CurrentDirectory;
            }
            DirectoryInfo folder = new DirectoryInfo(Path.GetFullPath(folderName));
            return folder.GetFiles(Path.GetFileName(mask));
        }

        /// <summary>
        /// Searches for a subfolder 
        /// </summary>
        /// <param name="folder">the parent folder</param>
        /// <param name="name">the name of the subfolder</param>
        /// <param name="autoCreate">whether to autocreate folders that do not exist</param>
        /// <returns>the specified folder</returns>
        internal static SPFolder FindOrCreateSubfolder(SPFolder folder, string name, bool autoCreate)
        {
            // Check if the folder already exists.
            foreach (SPFolder subFolder in folder.SubFolders)
                if (subFolder.Name.Equals(name))
                    return subFolder;

            // The specified subfolder does not exist - check for autocreate.
            if (autoCreate)
                return folder.SubFolders.Add(name);

            // Folder does not exist and auto-create is not enabled.
            throw new Exception(string.Format("Folder '{0}' does not exist.  Use 'autocreate' flag to create new folder.", name));
        }


        /// <summary>
        /// Determines if a given file already exists in a specified folder.
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="folder"></param>
        /// <returns>the matching SPFile object</returns>
        internal static SPFile FindFile(FileInfo fileInfo, SPFolder folder)
        {
            foreach (SPFile file in folder.Files)
                if (file.Name.Equals(fileInfo.Name))
                    return file;
            return null;
        }


        /// <summary>
        /// This method searches for a named folder within a SharePoint web site.  If the
        /// folder does not exist, then the AutoCreate parameter controls whether the folder
        /// is created automatically.  If the path includes multiple segments, then each
        /// segment is created with the specified name.
        /// </summary>
        /// <remarks>
        /// If the path starts with a forward slash '/', then interpret the string as the fully
        /// qualified path of a folder within the site, otherwise treat the first segment as the
        /// name of a document library and the remainder as the path of a folder within the library.
        /// </remarks>
        /// <param name="web">the SharePoint site to be searched</param>
        /// <param name="path">the path to the folder to be found or created</param>
        /// <returns>the resulting folder or null if it does not exist or could not be created</returns>
        internal static SPFolder FindFolder(SPWeb web, string path, bool autoCreate)
        {
            SPFolder targetFolder = web.RootFolder;
            string[] names = path.Split("/\\".ToCharArray());
            if (path.StartsWith("/"))
            {
                // find or create the specified subfolder
                foreach (string name in names)
                    if (!string.IsNullOrEmpty(name))
                        targetFolder = Utilities.FindOrCreateSubfolder(targetFolder, name, autoCreate);
            }
            else
            {
                // check if the first name matches a list in the site
                SPList targetList = null;
                try { targetList = web.Lists[names[0]]; }
                catch { }

                // no match, so check for autocreate
                if (targetList == null)
                {
                    if (autoCreate)
                    {
                        // create a new document library in the site
                        Guid guid = web.Lists.Add(names[0], "Created from PowerShell", SPListTemplateType.DocumentLibrary);
                        targetList = web.Lists[guid];
                    }
                }

                // check again if the list exists
                if (targetList == null)
                    throw new Exception(string.Format("Document library '{0}' not found.", path));

                // the default target is the root folder of the list
                targetFolder = targetList.RootFolder;

                // process the remaining names as folder name.
                for (int index = 1; index < names.Length; index++)
                    targetFolder = Utilities.FindOrCreateSubfolder(targetFolder, names[index], autoCreate);
            }
            return targetFolder;
        }

        /// <summary>
        /// This method transfers a collection of files into a folder within a SharePoint site.
        /// If the folder is null, then the files are copied directly into the site.
        /// </summary>
        /// <param name="web">the SharePoint site that will receive the files</param>
        /// <param name="files">the collection of files to be copied</param>
        /// <param name="targetFolder">the target folder within the site that will receive the files</param>
        /// <param name="overwrite">whether to overwrite existing files</param>
        internal static void TransferFiles(SPWeb web, FileInfo[] files, SPFolder targetFolder, bool overwrite)
        {
            int nCopied = 0;
            int nSkipped = 0;

            if (targetFolder == null)
                targetFolder = web.RootFolder;

            Console.WriteLine("Transferring files to folder '{0}' in site '{1}'", targetFolder.Name, web.Title);
            foreach (FileInfo fileInfo in files)
            {
                bool okToCopy = true;

                // Check if the file already exists in the target folder.
                SPFile targetFile = Utilities.FindFile(fileInfo, targetFolder);
                if (targetFile != null)
                {
                    if (overwrite)
                        targetFile.Delete();
                    else
                        okToCopy = false;
                }

                // Get the file bits and add them to the target folder.
                if (okToCopy)
                {
                    nCopied++;
                    using (FileStream fs = fileInfo.Open(FileMode.Open))
                        targetFolder.Files.Add(fileInfo.Name, fs);
                }
                else
                {
                    nSkipped++;
                }
            }

            if (nCopied > 0)
                Console.WriteLine("{0} files transferred.", nCopied);
            else
                Console.WriteLine("No files transferred.");

            if (nSkipped > 0)
                Console.WriteLine("{0} files skipped.", nSkipped);
        }

        /// <summary>
        /// This method transfers all files in a given folder 
        /// using an optional manifest file located within the folder itself.  
        /// The manifest file name must be "_manifest.xml".  This file is
        /// deserialized into an ImportManifest object, which is then 
        /// used to perform the actual transfer.
        /// </summary>
        /// <param name="web">the target website into 
        /// which files will be transferred</param>
        /// <param name="folder">the source folder from 
        /// which files will be transferred</param>
        /// <param name="overwrite">whether to overwrite 
        /// existing files in the target library</param>
        /// <param name="recursive">whether to process subfolders</param>
        internal static void TransferFolderUsingManifest(SPWeb web, 
            DirectoryInfo folder, bool overwrite, bool recursive)
        {
            // create a default manifest
            ImportManifest manifest = new ImportManifest();
            FileInfo[] files = folder.GetFiles("_manifest.xml", 
                SearchOption.TopDirectoryOnly);

            // search for the manifest file
            if (files.Length > 0)
                try
                {
                    manifest = ImportManifest.Load(files[0].FullName);
                }
                catch (Exception x)
                {
                    throw new Exception(
                        string.Format("Failed to load manifest file: {0}", 
                        files[0].FullName), x);
                }

            // process the manifest
            if (manifest != null)
                try
                {
                    manifest.ImportFiles(web, folder, overwrite);
                }
                catch (Exception x2)
                {
                    throw new Exception(
                        string.Format("Failed to import files in folder: {0}", 
                        folder.FullName), x2);
                }

            // process the subfolders
            if (recursive)
            {
                foreach (DirectoryInfo subfolder in folder.GetDirectories())
                    TransferFolderUsingManifest(web, subfolder, overwrite, recursive);
            }
        }
    }
}
