﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;

namespace SPPowerShell
{
    /// <summary>
    /// Describes an individual column specification.
    /// </summary>
    public partial class ColumnSpecification
    {
        /// <summary>
        /// This method ensures that a column exists in the containing library of the
        /// specified folder that matches a property by name in the document.
        /// </summary>
        /// <param name="targetFolder"></param>
        public void MapToLibrary(SPFolder targetFolder)
        {
            SPList parentList = null;
            Guid parentListId = targetFolder.ContainingDocumentLibrary;

            if (parentListId == Guid.Empty)
                parentListId = targetFolder.ParentListId;

            if (parentListId != Guid.Empty)
                parentList = targetFolder.ParentWeb.Lists[parentListId];

            if (parentList != null)
            {
                SPField matchingField = null;
                SPFieldType fieldType = GetFieldType(this.Type);
                string fieldName = string.IsNullOrEmpty(this.DisplayName) ? this.DocProperty : this.DisplayName;

                try
                {
                    matchingField = parentList.Fields.GetField(fieldName);
                }
                catch { }
                if (matchingField == null)
                    try
                    {
                        matchingField = parentList.Fields.GetFieldByInternalName(fieldName);
                    }
                    catch { }
                if (matchingField == null)
                {
                    // field was not found, so add a new column to the list
                    parentList.Fields.Add(fieldName, fieldType, this.RequiredSpecified ? this.Required : false);
                    parentList.Update();
                }
            }
        }

        /// <summary>
        /// Determines the target field type based on a string.
        /// </summary>
        /// <param name="fieldType"></param>
        /// <returns></returns>
        SPFieldType GetFieldType(string fieldType)
        {
            SPFieldType type = SPFieldType.Text;
            try
            {
                type = (SPFieldType)Enum.Parse(typeof(SPField), fieldType);
            }
            catch
            {
            }
            return type;
        }
    }
}
