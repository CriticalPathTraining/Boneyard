﻿using System;
using System.IO;
using System.Data;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Xml;
using System.Xml.Xsl;
using System.Windows.Forms;
using DocumentFormat.OpenXml.Packaging;
using ECM401.CommandLine;
using ECM401.Utilities;

namespace LabGen
{
    class Program
    {
        const string DebugOutputPath = @"c:\LabGen.xml";

        [CommandLineOperand(Name="LabFile",Description="The fully qualified path to the XML lab file.")]
        public string FileName { get; set; }

        [CommandLineSwitch("NoLogo","Suppress the program logo.")]
        public bool NoLogo { get; set; }

        [CommandLineSwitch("Help","Display instructions for using the program.")]
        public bool ShowHelp { get; set; }

        [CommandLineSwitch("ImagePath", "Specify the path from which to retrieve images.")]
        public string ImagePath { get; set; }

        [CommandLineSwitch("SnippetPath", "Specify the path from which to retrieve code snippets.")]
        public string SnippetPath { get; set; }

        [CommandLineSwitch("LabPath", "Specify the path that contains the lab.")]
        public string LabPath { get; set; }

        [CommandLineSwitch("Debug","Turns on debug mode.")]
        public bool Debug { get; set; }

        [CommandLineSwitch("ShowOutput","Specify whether to open the generated document.")]
        public bool ShowOutput { get; set; }

        /// <summary>
        /// Displays the program logo.
        /// </summary>
        /// <param name="parser"></param>
        /// <returns></returns>
        private void DisplayLogo(CommandLineParser parser)
        {
            Console.WriteLine("\nXML Lab Generator");
            Console.WriteLine("Copyright (c) John F. Holliday 2008.  All rights reserved.\n");
        }

        /// <summary>
        /// Displays usage information.
        /// </summary>
        /// <param name="parser"></param>
        /// <returns></returns>
        private void DisplayUsage(CommandLineParser parser)
        {
            Console.WriteLine("\nUsage:\n");
            Console.WriteLine("\tLabGen.exe [<options>] <filename>");
            Console.WriteLine("\nOptions:\n");
            foreach (string s in parser.Usage)
                Console.WriteLine("\t{0}", s);
        }

        static void Main(string[] args)
        {
            new Program().Run(Environment.CommandLine);
        }

        private int Run(string commandLine)
        {
            // Initialize the command line parser, passing in a reference to this
            // class so that we can look for any attributes that implement
            // command line switches.
            CommandLineParser parser = new CommandLineParser(commandLine, this);

            // Parse the command line.
            parser.Parse();

            // Display the program logo.
            if (!NoLogo) {
                DisplayLogo(parser);
            }

            // Check that the user provided a file path.
            if (string.IsNullOrEmpty(FileName))
            {
                ShowHelp = true;
                Console.WriteLine("No lab definition file specified.");
            }

            // If help was requested, then display program usage.
            if (ShowHelp)
            {
                DisplayUsage(parser);
            }
            else
            {
                FileInfo fileInfo = new FileInfo(FileName);
                string currentDirectory = fileInfo.DirectoryName;

                if (string.IsNullOrEmpty(SnippetPath))
                    SnippetManager.SetSnippetRoot(Path.Combine(currentDirectory,"Snippets"));
                else
                    SnippetManager.SetSnippetRoot(SnippetPath);

                if (string.IsNullOrEmpty(ImagePath))
                    ImageManager.SetImageRoot(Path.Combine(currentDirectory,"Images"));
                else
                    ImageManager.SetImageRoot(ImagePath);

                if (string.IsNullOrEmpty(LabPath))
                {
                    //LabManager.SetLabDirectory(Path.Combine(currentDirectory, "../../Source") + "/" + Path.GetFileNameWithoutExtension(FileName));
                    LabManager.SetLabDirectory(Path.GetFileNameWithoutExtension(FileName));
                }
                else
                    LabManager.SetLabDirectory(LabPath);

                ProcessFile(fileInfo.FullName);
            }
            return 0;
        }

        /// <summary>
        /// Creates and initializes an XmlDocument for a given package part.
        /// </summary>
        /// <param name="part"></param>
        /// <param name="nsManager"></param>
        /// <returns></returns>
        private XmlDocument OpenXmlDocumentPart(OpenXmlPart part, XmlNamespaceManager nsManager)
        {
            XmlDocument xd = new XmlDocument();
            using (Stream stream = part.GetStream())
            {
                // Load the document from the stream.
                xd.Load(stream);

                // setup the Word namespace for navigating the XML
                string wordNamespace = xd.DocumentElement.NamespaceURI;
                nsManager.AddNamespace("w", wordNamespace);
            }
            return xd;
        }

        /// <summary>
        /// Performs a transformation on a document part using XSLT.
        /// </summary>
        /// <param name="part"></param>
        private void TransformDocumentPart(Stream inputStream, string stylesheetResourcePath, OpenXmlPart part)
        {
            try
            {
                // Create an object to perform the transform.
                XslCompiledTransform xslt = new XslCompiledTransform();
                XmlReader xslReader = new XmlTextReader(new StringReader(EmbeddedResource.LoadString(stylesheetResourcePath)));

                // Enable document() function and scripts.
                xslt.Load(xslReader, new XsltSettings(true, true), null);

                // Open an XMLReader on the input stream.
                XmlReader xmlReader = new XmlTextReader(inputStream);

                // Setup a string to receive the transformed results.
                StringBuilder sb = new StringBuilder();
                XmlWriter xmlWriter = new XmlTextWriter(new StringWriter(sb));

                // Perform the transform into the string.
                xslt.Transform(xmlReader, xmlWriter);

                if (this.Debug)
                {
                    using (StreamWriter writer = new StreamWriter(DebugOutputPath))
                        writer.Write(sb.ToString());
                }

                // Open the part as an XmlDocument to setup the name table.
                XmlNamespaceManager nsManager = new XmlNamespaceManager(new NameTable());
                XmlDocument xmlPart = OpenXmlDocumentPart(part, nsManager);

                // Load the result string into the document.
                xmlPart.LoadXml(sb.ToString());

                // Perform the transform into the document part.
                using (Stream resultStream = part.GetStream(FileMode.Create, FileAccess.Write))
                {
                    xmlPart.Save(resultStream);
                    resultStream.Close();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }

        /// <summary>
        /// Process the lab definition file to generate a word document.
        /// </summary>
        /// <param name="fileName"></param>
        public void ProcessFile(string fileName)
        {
            Trace.WriteLine(string.Format("Processing lab definition file: {0}", fileName));

            // Copy the document template into a new memory stream.
            MemoryStream resultStream = new MemoryStream();
            Helpers.CopyStream(EmbeddedResource.LoadStream("LabTemplate.docx"), resultStream);

            // Open the template as a word processing document.
            WordprocessingDocument doc = WordprocessingDocument.Open(resultStream, true);

            // Calculate the target filename.
            string targetFileName = Path.GetFileNameWithoutExtension(fileName);
            string targetFolder = Path.GetDirectoryName(fileName);
            targetFileName = Path.Combine(targetFolder, targetFileName + ".docx");

            // Open the lab definition file.
            using (FileStream inputStream = new FileStream(fileName,FileMode.Open))
            using (FileStream outputStream = new FileStream(targetFileName, FileMode.Create))
            {
                // transform the main part of the docment
                TransformDocumentPart(inputStream, "Stylesheets.LabToWord.xslt", doc.MainDocumentPart);
                // load any images that were referenced
                ImageManager.LoadImages(doc);
                doc.Close();
                // copy the document to the output file
                Helpers.CopyStream(resultStream, outputStream);
            }

            if (Debug)
            {
                Process.Start(DebugOutputPath);
            }
            else if (ShowOutput)
            {
                Process.Start(targetFileName);
            }
        }
    }
}
