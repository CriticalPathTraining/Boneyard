using System;
using System.Collections.Generic;
using System.Text;

namespace LabGen
{
    /// <summary>
    /// Utility class for converting strings to their plural form.
    /// </summary>
    public class Plural
    {
        private string m_str = string.Empty;
        public Plural(string s) {
            m_str = ConvertToPlural(s);
        }
        public override string ToString() {
            return m_str;
        }
        private string ConvertToPlural(string singular) {
            string result, lower = singular.ToLower();
            // rule out a few exceptions
            if (lower == "foot") result = "Feet";
            else if (lower == "goose") result = "Geese";
            else if (lower == "man") result = "Men";
            else if (lower == "woman") result = "Women";
            else if (lower == "criterion") result = "Criteria";
            // plural uses "ies" if word ends with "y" preceeded by a non-vowel
            else if ((lower.EndsWith("y") && ("aeiou".IndexOf(lower.Substring(lower.Length - 2, 1)) < 0))) {
                result = singular.Substring(0, singular.Length - 1) + "ies";
            }
            else {
                result = singular + "s";
            }
            // the result must preserve the original word's capitalization
            if (singular == lower) {
                return result.ToLower();	// it was all lowercase
            }
            else if (singular == singular.ToUpper()) {
                return result.ToUpper();	// it was all uppercase
            }
            else {
                return result;
            }
        }
        public static explicit operator Plural(string s) {
            return new Plural(s);
        }
    }
}
