using System;

namespace LabGen
{
	/// <summary>Implements a non-switch operand.</summary>
	[AttributeUsage( AttributeTargets.Property )]
	public class CommandLineOperandAttribute : System.Attribute
	{
		#region Private Variables
		private int m_index=0;
		private string m_name = "";
		private string m_description = "";
		#endregion

		#region Public Properties
		/// <summary>Accessor for retrieving the operand name for an associated
		/// property.</summary>
		public string Name 			{ get { return m_name; } set { m_name=value; }}

		/// <summary>Accessor for retrieving the description for an operand of
		/// an associated property.</summary>
		public string Description { get { return m_description; } set { m_description = value; } }

		/// <summary>
		/// Accessor for retrieving the position index for an operand.
		/// </summary>
		public int Index { get { return m_index; } set { m_index=value; }}

		#endregion

		#region Constructors
		public CommandLineOperandAttribute() {
		}
		/// <summary>Attribute constructor.</summary>
		public CommandLineOperandAttribute( string name,  string description, int index )
		{
			m_name = name;
			m_description = description;
			m_index = index;
		}
		#endregion
	}
}
