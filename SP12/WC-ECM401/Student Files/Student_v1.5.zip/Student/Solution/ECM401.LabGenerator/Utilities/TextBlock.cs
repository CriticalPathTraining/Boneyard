using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LabGen
{
    /// <summary>
    /// A formatting tool for converting long strings into an array of strings
    /// of a given maximum length.
    /// </summary>
    class TextBlock
    {
        const int defaultWidth = 80;
        string m_text = string.Empty;
        int m_maxWidth = defaultWidth;

        /// <summary>
        /// Constructor that uses the default width.
        /// </summary>
        /// <param name="text"></param>
        public TextBlock(string text) {
            m_text = text;
        }

        /// <summary>
        /// Constructor that sets a specified maximum width.
        /// </summary>
        /// <param name="text"></param>
        /// <param name="maxWidth"></param>
        public TextBlock(string text, int maxWidth) {
            m_text = text;
            m_maxWidth = maxWidth;
        }

        /// <summary>
        /// The maximum width of the text block.
        /// </summary>
        public int MaxWidth {
            get { return m_maxWidth; }
            set { m_maxWidth = value; }
        }

        /// <summary>
        /// The underlying text string.
        /// </summary>
        public string Text {
            get { return m_text; }
            set { m_text = value; }
        }

        /// <summary>
        /// Removes all new lines from a text string.
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string NoNewLines(string text) {
            return text.Replace("\r\n", " ").Replace("\n", " ");
        }

        /// <summary>
        /// Removes all white space from a text string.
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string NoWhiteSpace(string text) {
            string result = NoNewLines(text).Replace("\t", " ");
            while (result.IndexOf("  ") > 0) result = result.Replace("  ", " ");
            return result;
        }

        /// <summary>
        /// String array conversion operator.
        /// </summary>
        /// <param name="block"></param>
        /// <returns></returns>
        public static explicit operator string[](TextBlock block) {
            ArrayList strings = new ArrayList();
            string text = NoNewLines(block.Text);
            int width = block.MaxWidth;
            while (text.Length > width) {
                int pos = width;
                while ((pos > 0) && !(Char.IsWhiteSpace(text[pos]))) {
                    pos--;
                }
                strings.Add(text.Substring(0, pos).Trim());
                text = text.Substring(pos).TrimStart();
            }
            if (text.Length > 0) {
                strings.Add(text);
            }
            return (string[])strings.ToArray(typeof(string));
        }
    }
}
