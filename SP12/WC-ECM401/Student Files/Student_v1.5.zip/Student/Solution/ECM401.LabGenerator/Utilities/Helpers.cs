﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Data;
using System.Text;
using System.Xml;

namespace LabGen
{
    public static class Helpers
    {
        /// <summary>
        /// Encodes a string for XML rendering.
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string XmlEncode(string str)
        {
            XmlElement e = new XmlDocument().CreateElement("E");
            e.InnerText = str;
            return e.InnerXml;
        }

        /// <summary>
        /// Copies one stream to another.
        /// </summary>
        /// <param name="sourceStream"></param>
        /// <param name="targetStream"></param>
        /// <param name="resetTarget">whether to reset the position of the target stream</param>
        public static void CopyStream(Stream sourceStream, Stream targetStream, bool resetTarget)
        {
            int Length = 256;
            byte[] buffer = new byte[Length];
            sourceStream.Position = 0;
            int bytesRead = sourceStream.Read(buffer, 0, Length);
            while (bytesRead > 0)
            {
                targetStream.Write(buffer, 0, bytesRead);
                bytesRead = sourceStream.Read(buffer, 0, Length);
            }
            if (resetTarget)
                targetStream.Position = 0;
        }

        /// <summary>
        /// Provides default reset behavior for stream to stream copy.
        /// </summary>
        /// <param name="sourceStream"></param>
        /// <param name="targetStream"></param>
        public static void CopyStream(Stream sourceStream, Stream targetStream)
        {
            CopyStream(sourceStream, targetStream, true);
        }
    }
}
