﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LabGen
{
    public static class LabManager
    {
        static string m_labRoot = "";

        public static void SetLabDirectory(string path)
        {
            m_labRoot = path;
        }

        public static string GetLabDirectory()
        {
            return m_labRoot;
        }
    }
}
