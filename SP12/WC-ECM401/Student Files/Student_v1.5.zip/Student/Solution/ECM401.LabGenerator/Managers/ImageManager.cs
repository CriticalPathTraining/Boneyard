﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
using DocumentFormat.OpenXml.Packaging;
using ECM401.Utilities;

namespace LabGen
{
    /// <summary>
    /// This static class is called from the XSLT stylesheet to
    /// format and work with image files.
    /// </summary>
    public static class ImageManager
    {
        static string m_imageRoot = string.Empty;
        static Dictionary<string, ImageInfo> m_images = new Dictionary<string, ImageInfo>();

        public class ImageInfo
        {
            static int lastId = 1;
            public string Id { get; set; }
            public ImagePart Part { get; set; }
            public string ImagePath { get; set; }
            public string Dimensions { get; private set; }
            public ImagePartType Type { get; private set; }

            public ImageInfo(string path)
            {
                this.ImagePath = path;
                this.Id = string.Format("rImage{0}", lastId++);
                using (FileStream fs = new FileStream(path, FileMode.Open))
                {
                    Image image = Image.FromStream(fs);
                    this.Dimensions = string.Format("width:{0};height:{1};", image.Width, image.Height);
                    this.Type=image.RawFormat.Guid.Equals(ImageFormat.Jpeg.Guid) ? ImagePartType.Jpeg :
                        image.RawFormat.Guid.Equals(ImageFormat.Png.Guid) ? ImagePartType.Png:
                        image.RawFormat.Guid.Equals(ImageFormat.Tiff.Guid) ? ImagePartType.Tiff:
                        image.RawFormat.Guid.Equals(ImageFormat.Icon.Guid) ? ImagePartType.Icon:
                        image.RawFormat.Guid.Equals(ImageFormat.Bmp.Guid)?ImagePartType.Bmp:
                        image.RawFormat.Guid.Equals(ImageFormat.Emf.Guid)?ImagePartType.Emf:
                        image.RawFormat.Guid.Equals(ImageFormat.Gif.Guid)?ImagePartType.Gif:
                        image.RawFormat.Guid.Equals(ImageFormat.Wmf.Guid)?ImagePartType.Wmf:
                        image.RawFormat.Guid.Equals(ImageFormat.MemoryBmp.Guid)?ImagePartType.Bmp:
                        ImagePartType.Jpeg;
                }
            }

            /// <summary>
            /// Adds the image to the specified document.
            /// </summary>
            /// <param name="doc"></param>
            public void AddToDocument(MainDocumentPart mainPart)
            {
                ImagePart imagePart = mainPart.AddImagePart(this.Type, this.Id);
                using (FileStream fs = new FileStream(this.ImagePath, FileMode.Open))
                    imagePart.FeedData(fs);
            }
        }

        /// <summary>
        /// Sets the root path for images.
        /// </summary>
        /// <param name="imagePath"></param>
        public static void SetImageRoot(string imagePath)
        {
            m_imageRoot = imagePath;
        }

        /// <summary>
        /// Stores a reference to the word processing document currently being constructed.
        /// </summary>
        /// <param name="doc"></param>
        public static void LoadImages(WordprocessingDocument doc)
        {
            foreach (ImageInfo info in m_images.Values)
                info.AddToDocument(doc.MainDocumentPart);
        }

        /// <summary>
        /// Returns the fully-qualified path to the image file.
        /// </summary>
        /// <param name="imageFileName"></param>
        /// <returns></returns>
        public static string GetImagePath(string imageFileName)
        {
            return Path.Combine(m_imageRoot, imageFileName);
        }


        /// <summary>
        /// Retrieves the ImageInfo structure corresponding to
        /// a specified filename.
        /// </summary>
        /// <param name="imageFileName"></param>
        /// <returns></returns>
        static ImageInfo GetImageInfo(string imageFileName)
        {
            ImageInfo info = null;
            if (m_images.ContainsKey(imageFileName))
                info = m_images[imageFileName];
            else
            {
                info = new ImageInfo(GetImagePath(imageFileName));
                m_images[imageFileName] = info;
            }

            return info;
        }

        /// <summary>
        /// Returns a unique identifier for the specified image.  This identifier
        /// is used to create a matching element in the appropriate document part
        /// for the loaded image.
        /// </summary>
        /// <param name="imageFileName"></param>
        /// <returns></returns>
        public static string GetImageIdentifier(string imageFileName)
        {
            ImageInfo info = GetImageInfo(imageFileName);
            if (info != null) return info.Id;
            return string.Empty;
        }

        /// <summary>
        /// Returns a dimension string of the form "width:16.56cm;height:5.36cm;" for
        /// a given image.  Once the image is loaded, this method caches the bits in
        /// a static dictionary for use by other routines.
        /// </summary>
        /// <param name="imageFileName"></param>
        /// <returns></returns>
        public static string GetImageDimensionString(string imageFileName)
        {
            ImageInfo info = GetImageInfo(imageFileName);
            if (info != null) return info.Dimensions;
            return string.Empty;
        }
    }
}
