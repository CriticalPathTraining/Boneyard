﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using ECM401.Utilities;

namespace LabGen
{
    /// <summary>
    /// This static class is called from the XSLT stylesheet to format
    /// code blocks for insertion into the Word document.
    /// </summary>
    public static class CodeManager
    {
        /// <summary>
        /// Formats a block of code for insertion into a document.
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static string FormatCodeBlock(string code)
        {
            // format the code with hard returns
            string[] lines = Helpers.XmlEncode(code).Replace("\t","<w:tab/>").Replace("\r\n","\n").Split('\n');
            // construct the correct WordProcessingML for the code block
            StringBuilder sb = new StringBuilder();
            foreach (string line in lines)
                sb.AppendFormat("{0}<w:br/>",line);
            return sb.ToString();
        }
    }
}
