﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Windows.Forms;
using ECM401.Utilities;


namespace LabGen
{
    public static class SnippetManager
    {
        static string m_snippetRoot = "";
        static string m_snippetPath = "";

        public static void SetSnippetRoot(string path)
        {
            m_snippetRoot = path;
        }

        /// <summary>
        /// i.e. "VisualStudio/Code Snippets"
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string SetSnippetPath(string path)
        {
            m_snippetPath = path;
            return path;
        }

        public static string CodeSnippetPath
        {
            get { return Path.Combine(m_snippetRoot, "Visual C#/My Code Snippets/ECM401"); }
        }

        public static string XmlSnippetPath
        {
            get { return Path.Combine(m_snippetRoot, "XML/My Xml Snippets/ECM401"); }
        }

        private static string GetSnippetPath(string path, string name)
        {
            string snippetPath = Path.Combine(path, m_snippetPath);
            string result = snippetPath + "/" + name + ".snippet";
            return result;
        }

        public static string GetSnippetTitle(string path, string name)
        {
            string filePath = GetSnippetPath(path, name);
            XmlDocument doc = new XmlDocument();
            try
            {
                doc.Load(filePath);
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
                nsmgr.AddNamespace("snippet", "http://schemas.microsoft.com/VisualStudio/2005/CodeSnippet");
                XmlNode title = doc.SelectSingleNode("//snippet:Title", nsmgr);
                if (title != null)
                    return title.InnerText;
            }
            catch (FileNotFoundException x)
            {
                return x.Message;
            }
            return "snippet not found";
        }

        public static string GetSnippetBody(string path, string name)
        {
            string filePath = GetSnippetPath(path, name);
            XmlDocument doc = new XmlDocument();
            try
            {
                doc.Load(filePath);
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
                nsmgr.AddNamespace("snippet", "http://schemas.microsoft.com/VisualStudio/2005/CodeSnippet");
                XmlNode body = doc.SelectSingleNode("//snippet:Snippet", nsmgr);
                if (body != null)
                {
                    string result = body.InnerText;
                    // format the code with hard returns
                    string[] lines = result.Replace("\r\n", "\n").Split('\n');
                    // construct the correct WordProcessingML for this code block
                    StringBuilder sb = new StringBuilder();
                    foreach (string line in lines)
                        sb.AppendFormat("{0}<w:br/>", Helpers.XmlEncode(line));
                    return sb.ToString();
                }
            }
            catch (FileNotFoundException x)
            {
                return x.Message;
            }
            return "snippet not found";
        }

        public static string GetCodeSnippetTitle(string name)
        {
            return GetSnippetTitle(CodeSnippetPath, name);
        }

        public static string GetCodeSnippetBody(string name)
        {
            return GetSnippetBody(CodeSnippetPath, name);
        }

        public static string GetXmlSnippetTitle(string name)
        {
            return GetSnippetTitle(XmlSnippetPath, name);
        }

        public static string GetXmlSnippetBody(string name)
        {
            return GetSnippetBody(XmlSnippetPath, name);
        }
    }
}
