﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using ECM401.ContentTypes;

namespace ECM401.ValidatingProposal
{
    /// <summary>
    /// Handles events during feature installation and activation.
    /// </summary>
    public class FeatureReceiver : SPFeatureReceiver
    {
        /// <summary>
        /// Override to create the project proposal content type.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSite siteCollection = properties.Feature.Parent as SPSite;
            if (siteCollection != null)
            {
                // Create the Project Proposal content type
                SPContentType ctProposal = SharePointContentType.Create(siteCollection.RootWeb, typeof(ProjectProposal));
            }
        }

        /// <summary>
        /// Override to remove the project proposal content type.
        /// </summary>
        /// <param name="properties"></param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite siteCollection = properties.Feature.Parent as SPSite;
            if (siteCollection != null)
            {
                SharePointContentType.Delete(siteCollection.RootWeb, typeof(ProjectProposal));
            }
        }
        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    }
}
