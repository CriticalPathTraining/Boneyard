﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using ECM401.ContentTypes;
using ECM401.Validation;
using Microsoft.SharePoint;

namespace ECM401.ValidatingProposal
{
    [
        SharePointContentType(
           Name = "Validating Proposal",
           Description = "A Sales Proposal Content Type with Validation",
           BaseType = "Document",
           Group = "ECM401",
           Hidden = false,
           XmlDocuments = "res://ProposalRules.xml[http://tempuri.org/ListItemValidator.xsd]")
    ]
    public class ProjectProposal : SPItemEventReceiver
    {
        const string VALIDATION_NAMESPACE = "http://tempuri.org/ListItemValidator.xsd";

        public enum ProposalTypeEnum
        {
            FixedBid,
            TimeAndMaterials
        }

        void Log(string message)
        {
            Trace.WriteLine(message, "ProjectProposal");
        }

        #region Field References

        [FieldRef("ProposalType", DisplayName = "Proposal Type", Required = true)]
        public ProposalTypeEnum ProposalType { get; set; }

        [FieldRef("BidAmount", DisplayName = "Bid Amount")]
        public decimal BidAmount { get; set; }

        [FieldRef("EstHours", DisplayName = "Estimated Hours")]
        public int EstimatedHours { get; set; }

        #endregion

        #region Event Receiver Methods

        /// <summary>
        /// Prevent the creation of invalid proposals.
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
            Log("ItemAdding");
            ValidateFromResourceFile(ref properties, "ProposalRules.xml");
        }

        /// <summary>
        /// Prevent the updating of invalid proposals.
        /// </summary>
        /// <param name="properties"></param>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
            Log("ItemUpdating");
            ValidateFromResourceFile(ref properties, "ProposalRules.xml");
        }

        #endregion

        #region Validation Helpers

        void ValidateFromResourceFile(ref SPItemEventProperties properties, string rulesFile)
        {
            try
            {
                Assembly asm = Assembly.GetExecutingAssembly();
                string resourcePath = asm.GetName().Name + "." + rulesFile;

                Log("Resource path = " + resourcePath);
                Stream stream = asm.GetManifestResourceStream(resourcePath);

                if (stream == null)
                {
                    Log("Failed to load rules file: " + resourcePath);
                    return;
                }

                Log("Calling validator");
                StreamReader reader = new StreamReader(stream);
                ListItemValidator validator = ListItemValidator.FromXml(reader.ReadToEnd());
                bool isValid = validator.Validate(properties.AfterProperties);
                if (!isValid)
                {
                    properties.Cancel = true;
                    properties.ErrorMessage = validator.ErrorMessage;
                    Log(string.Format("Validation failed: {0}",validator.ErrorMessage));
                }
            }
            catch (System.Exception x)
            {
                Log(String.Format("Exception during validation: {0}", x.Message));
                EventLog.WriteEntry("Validating Proposal", "Exception during validation: " + x.ToString());
            }
        }

        /// <summary>
        /// Validates a set of list item properties.
        /// </summary>
        /// <param name="properties"></param>
        void ValidateFromXmlDocument(ref SPItemEventProperties properties, string nsRules)
        {
            try
            {
                Log("ValidateFromXmlDocument");
                // get the web associated with the object
                using (SPWeb web = properties.OpenWeb())
                {
                    // get the content type
                    string ctName = properties.AfterProperties["ContentType"].ToString();
                    Log("Retrieving content type: " + ctName);

                    SPContentType ctProposal = web.ContentTypes[ctName];
                    if (ctProposal == null)
                        Log("Failed to retrieve content type " + ctName);

                    if (ctProposal != null)
                    {
                        // Create a list item validator by loading the rules from the content type.
                        Log("Retrieving rules from namespace " + nsRules);
                        string rules = SharePointContentType.GetXmlDocumentString(ctProposal, nsRules);

                        if (string.IsNullOrEmpty(rules))
                        {
                            Log("No rules in content type payload for type: " + ctName);
                            return;
                        }
                        ListItemValidator validator = ListItemValidator.FromXml(rules);

                        bool isValid = (properties.ListItem == null) ?
                            validator.Validate(properties.AfterProperties)
                            : validator.Validate(properties.ListItem);

                        if (!isValid)
                        {
                            properties.Cancel = true;
                            properties.ErrorMessage = validator.ErrorMessage;
                            Log(string.Format("Validation failed - {0}", validator.ErrorMessage));
                        }
                    }
                }
            }
            catch (System.Exception x)
            {
                Log(string.Format("Exception during validation - {0}", x.ToString()));
                EventLog.WriteEntry("Validating Proposal", "Exception during validation: " + x.ToString());
            }
        }

        #endregion
    }
}
