﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.SharePoint.Workflow;

namespace InfoPathApprovalWorkflow
{
  public sealed partial class Workflow : SequentialWorkflowActivity
  {
    [Serializable]
    public enum TaskResult
    {
      None,
      Approved,
      Rejected
    }

    public Workflow()
    {
      InitializeComponent();
    }

    private AssocInitData m_initData;

    public AssocInitData InitData { get { return m_initData; } set { m_initData = value; } }

    private Guid m_approvalTaskId;
    public Guid ApprovalTaskId { get { return m_approvalTaskId; } set { m_approvalTaskId = value; } }

    private TaskResult m_approvalTaskResult;
    public TaskResult ApprovalTaskResult { get { return m_approvalTaskResult; } set { m_approvalTaskResult = value; } }

    private string m_approvalTaskComments;
    public string ApprovalTaskComments { get { return m_approvalTaskComments; } set { m_approvalTaskComments = value; } }
    public string ApprovalTaskResultString { get { return ApprovalTaskResult.ToString(); } }

    private void OnWorkflowActivated_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPActivationEventArgs args = e as SPActivationEventArgs;

      InitData = AssocInitData.Deserialize(args.properties.InitiationData);
      this.ApprovalTaskResult = TaskResult.None;
    }

    private void CreateApprovalTask_Invoking(object sender, EventArgs e)
    {
      ApprovalTaskId = Guid.NewGuid();

      CreateTask createApprovalTask = sender as CreateTask;

      createApprovalTask.TaskProperties = new SPWorkflowTaskProperties();
      createApprovalTask.TaskProperties.AssignedTo = InitData.Approvers[0].AccountId;
      createApprovalTask.TaskProperties.Title = "Approve document.";
      createApprovalTask.TaskProperties.Description = InitData.Instructions;
      createApprovalTask.TaskProperties.ExtendedProperties.Add(
        "Instructions", InitData.Instructions);
    }

    private void ApprovalTaskChanged_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPTaskServiceEventArgs args = e as SPTaskServiceEventArgs;

      this.ApprovalTaskComments = args.afterProperties.ExtendedProperties[
        new Guid("52578fc3-1f01-4f4d-b016-94ccbcf428cf")] as string;

      string result = args.afterProperties.ExtendedProperties["Result"] as string;
      this.ApprovalTaskResult = (TaskResult)Enum.Parse(typeof(TaskResult), result);
    }
  }
}
