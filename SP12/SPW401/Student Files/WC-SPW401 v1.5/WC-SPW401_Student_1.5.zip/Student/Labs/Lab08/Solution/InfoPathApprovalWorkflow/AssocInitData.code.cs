﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace InfoPathApprovalWorkflow
{
    public partial class AssocInitData
    {
        public static AssocInitData Deserialize(string value)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(AssocInitData));
            using (StringReader reader = new StringReader(value))
                return serializer.Deserialize(reader) as AssocInitData;
        }
    }
}
