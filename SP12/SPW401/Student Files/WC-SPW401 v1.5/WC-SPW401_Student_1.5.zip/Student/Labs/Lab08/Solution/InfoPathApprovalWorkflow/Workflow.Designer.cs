﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace InfoPathApprovalWorkflow
{
	partial class Workflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
            this.ApprovalTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
            this.LogTaskResults = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.CompleteApprovalTask = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
            this.WaitForApproval = new System.Workflow.Activities.WhileActivity();
            this.CreateApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
            this.WorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
            // 
            // ApprovalTaskChanged
            // 
            this.ApprovalTaskChanged.AfterProperties = null;
            this.ApprovalTaskChanged.BeforeProperties = null;
            correlationtoken1.Name = "ApprovalTaskToken";
            correlationtoken1.OwnerActivityName = "Workflow";
            this.ApprovalTaskChanged.CorrelationToken = correlationtoken1;
            this.ApprovalTaskChanged.Executor = null;
            this.ApprovalTaskChanged.Name = "ApprovalTaskChanged";
            activitybind1.Name = "Workflow";
            activitybind1.Path = "ApprovalTaskId";
            this.ApprovalTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.ApprovalTaskChanged_Invoked);
            this.ApprovalTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // LogTaskResults
            // 
            this.LogTaskResults.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.LogTaskResults.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            activitybind2.Name = "Workflow";
            activitybind2.Path = "ApprovalTaskComments";
            activitybind3.Name = "Workflow";
            activitybind3.Path = "ApprovalTaskResultString";
            this.LogTaskResults.Name = "LogTaskResults";
            this.LogTaskResults.OtherData = "";
            this.LogTaskResults.UserId = -1;
            this.LogTaskResults.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            this.LogTaskResults.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            // 
            // CompleteApprovalTask
            // 
            this.CompleteApprovalTask.CorrelationToken = correlationtoken1;
            this.CompleteApprovalTask.Name = "CompleteApprovalTask";
            activitybind4.Name = "Workflow";
            activitybind4.Path = "ApprovalTaskId";
            this.CompleteApprovalTask.TaskOutcome = null;
            this.CompleteApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            // 
            // WaitForApproval
            // 
            this.WaitForApproval.Activities.Add(this.ApprovalTaskChanged);
            ruleconditionreference1.ConditionName = "IsApprovalTaskComplete";
            this.WaitForApproval.Condition = ruleconditionreference1;
            this.WaitForApproval.Name = "WaitForApproval";
            // 
            // CreateApprovalTask
            // 
            this.CreateApprovalTask.CorrelationToken = correlationtoken1;
            this.CreateApprovalTask.ListItemId = -1;
            this.CreateApprovalTask.Name = "CreateApprovalTask";
            this.CreateApprovalTask.SpecialPermissions = null;
            activitybind5.Name = "Workflow";
            activitybind5.Path = "ApprovalTaskId";
            this.CreateApprovalTask.TaskProperties = null;
            this.CreateApprovalTask.MethodInvoking += new System.EventHandler(this.CreateApprovalTask_Invoking);
            this.CreateApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
            // 
            // WorkflowActivated
            // 
            correlationtoken2.Name = "WorkflowToken";
            correlationtoken2.OwnerActivityName = "Workflow";
            this.WorkflowActivated.CorrelationToken = correlationtoken2;
            this.WorkflowActivated.EventName = "OnWorkflowActivated";
            this.WorkflowActivated.Name = "WorkflowActivated";
            this.WorkflowActivated.WorkflowProperties = null;
            this.WorkflowActivated.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnWorkflowActivated_Invoked);
            // 
            // Workflow
            // 
            this.Activities.Add(this.WorkflowActivated);
            this.Activities.Add(this.CreateApprovalTask);
            this.Activities.Add(this.WaitForApproval);
            this.Activities.Add(this.CompleteApprovalTask);
            this.Activities.Add(this.LogTaskResults);
            this.Name = "Workflow";
            this.CanModifyActivities = false;

		}

		#endregion

        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged OnTaskChanged;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteTask;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated WorkflowActivated;
        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateApprovalTask;
        private WhileActivity WaitForApproval;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged ApprovalTaskChanged;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteApprovalTask;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogTaskResults;





    }
}
