﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DocumentArchiveWorkflowPart3.UI
{
    public abstract class AssociationForm : LayoutsPageBase
    {
        protected virtual void PopulateControls() { }
        protected abstract void BindAssociationData(string value);
        protected abstract string UpdateAssociationData();

        private enum AssociationType
        {
            List,
            ContentType,
            ListContentType
        }

        private AssociationType _associationType;
        private SPContentType _contentType;
        private SPList _list;
        private SPWorkflowAssociation _workflowAssociation;

        protected bool IsNewAssociation
        {
            get { return string.IsNullOrEmpty(Request.Params["GuidAssoc"]); }
        }

        protected string WorkflowAssociationName
        {
            get { return Request.Params["WorkflowName"]; }
        }

        protected override void OnLoad(EventArgs e)
        {
            // read the form level parameters
            string listId = Request.Params["List"];
            string ctypeId = Request.Params["ctype"];
            string guidAssocId = Request.Params["GuidAssoc"];

            // determine the type of association
            if (!string.IsNullOrEmpty(listId) && !string.IsNullOrEmpty(ctypeId))
                _associationType = AssociationType.ListContentType;
            else if (!string.IsNullOrEmpty(listId) && string.IsNullOrEmpty(ctypeId))
                _associationType = AssociationType.List;
            else if (string.IsNullOrEmpty(listId) && !string.IsNullOrEmpty(ctypeId))
                _associationType = AssociationType.ContentType;

            // validate the workflow association id
            Guid? workflowAssociationId = new Guid?();
            if (!string.IsNullOrEmpty(guidAssocId))
                workflowAssociationId = new Guid(guidAssocId);

            // lookup the list, content type, and existing workflow associations
            switch (_associationType)
            {
                case AssociationType.ContentType:
                    _contentType = Web.AvailableContentTypes[new SPContentTypeId(ctypeId)];
                    if (workflowAssociationId.HasValue)
                        _workflowAssociation =
                            _contentType.WorkflowAssociations[workflowAssociationId.Value];
                    break;
                case AssociationType.List:
                    _list = Web.Lists[new Guid(listId)];
                    if (workflowAssociationId.HasValue)
                        _workflowAssociation =
                            _list.WorkflowAssociations[workflowAssociationId.Value];
                    break;
                case AssociationType.ListContentType:
                    _list = Web.Lists[new Guid(listId)];
                    _contentType = _list.ContentTypes[new SPContentTypeId(ctypeId)];
                    if (workflowAssociationId.HasValue)
                        _workflowAssociation =
                            _contentType.WorkflowAssociations[workflowAssociationId.Value];
                    break;
            }

            // call the base implementation
            base.OnLoad(e);
        }

        protected override void OnPreRender(EventArgs e)
        {
            // register parameters in the hidden field
            ClientScript.RegisterHiddenField("WorkflowName",
                Request.Params["WorkflowName"]);
            ClientScript.RegisterHiddenField("WorkflowDefinition",
                Request.Params["WorkflowDefinition"]);
            ClientScript.RegisterHiddenField("AddToStatusMenu",
                Request.Params["AddToStatusMenu"]);
            ClientScript.RegisterHiddenField("AllowManual", Request.Params["AllowManual"]);
            ClientScript.RegisterHiddenField("RoleSelect", Request.Params["RoleSelect"]);
            ClientScript.RegisterHiddenField("GuidAssoc", Request.Params["GuidAssoc"]);
            ClientScript.RegisterHiddenField("SetDefault", Request.Params["SetDefault"]);
            ClientScript.RegisterHiddenField("HistoryList", Request.Params["HistoryList"]);
            ClientScript.RegisterHiddenField("TaskList", Request.Params["TaskList"]);
            ClientScript.RegisterHiddenField("UpdateLists", Request.Params["UpdateLists"]);
            ClientScript.RegisterHiddenField("AutoStartCreate",
                Request.Params["AutoStartCreate"]);
            ClientScript.RegisterHiddenField("AutoStartChange",
                Request.Params["AutoStartChange"]);

            // populate controls unrelated to the association data
            this.PopulateControls();

            // bind the association data (if any)
            if (_workflowAssociation != null)
                this.BindAssociationData(_workflowAssociation.AssociationData);

            // call the base implementation
            base.OnPreRender(e);
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            // redirect back to the workflow settings page
            SPUtility.Redirect(
                BuildRedirectString(_associationType, Request.Params["List"],
                    Request.Params["ctype"]),
                    SPRedirectFlags.RelativeToLayoutsPage, this.Context);
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            // get the association data
            string associationData = UpdateAssociationData();

            // check whether updates to content types cascade to their lists
            bool updateContentTypeLists = (Request.Params["UpdateLists"] == "TRUE");

            // create or update the workflow association
            if (_workflowAssociation != null)
                UpdateWorkflowAssociation(
                    Request.Params["TaskList"], Request.Params["HistoryList"], associationData, updateContentTypeLists);
            else
                CreateWorkflowAssociation(
                    Request.Params["TaskList"], Request.Params["HistoryList"], associationData, updateContentTypeLists);

            // redirect back to the workflow settings page
            SPUtility.Redirect(
                BuildRedirectString(
                    _associationType, Request.Params["List"], Request.Params["ctype"]),
                    SPRedirectFlags.RelativeToLayoutsPage, this.Context);

        }

        private void CreateWorkflowAssociation(string taskListName, string historyListName, string associationData, bool updateContentTypeLists)
        {
            // lookup the workflow template and the workflow name
            string workflowName = Request.Params["WorkflowName"];
            Guid workflowTemplateId = new Guid(Request.Params["WorkflowDefinition"]);
            SPWorkflowTemplate workflowTemplate = Web.WorkflowTemplates[workflowTemplateId];

            switch (_associationType)
            {
                case AssociationType.ContentType:
                    _workflowAssociation =
                        SPWorkflowAssociation.CreateSiteContentTypeAssociation(
                            workflowTemplate, workflowName, taskListName, historyListName);
                    PopulateWorkflowAssociation(taskListName, historyListName, associationData);
                    _contentType.AddWorkflowAssociation(_workflowAssociation);
                    if (updateContentTypeLists)
                        _contentType.UpdateWorkflowAssociationsOnChildren(true, true, true);
                    break;
                case AssociationType.List:
                    _workflowAssociation =
                        SPWorkflowAssociation.CreateListAssociation(
                            workflowTemplate, workflowName,
                            LookupOrCreateList(taskListName, SPListTemplateType.Tasks),
                            LookupOrCreateList(historyListName, SPListTemplateType.WorkflowHistory));
                    PopulateWorkflowAssociation(taskListName, historyListName, associationData);
                    _list.AddWorkflowAssociation(_workflowAssociation);
                    break;
                case AssociationType.ListContentType:
                    _workflowAssociation =
                        SPWorkflowAssociation.CreateListContentTypeAssociation(
                            workflowTemplate, workflowName,
                            LookupOrCreateList(taskListName, SPListTemplateType.Tasks),
                            LookupOrCreateList(historyListName, SPListTemplateType.WorkflowHistory));
                    PopulateWorkflowAssociation(taskListName, historyListName, associationData);
                    _contentType.AddWorkflowAssociation(_workflowAssociation);
                    break;
            }
        }

        private void UpdateWorkflowAssociation(string taskListName, string historyListName, string associationData, bool updateContentTypeLists)
        {
            PopulateWorkflowAssociation(taskListName, historyListName, associationData);

            switch (_associationType)
            {
                case AssociationType.ContentType:
                    _contentType.UpdateWorkflowAssociation(_workflowAssociation);
                    if (updateContentTypeLists)
                        _contentType.UpdateWorkflowAssociationsOnChildren(true, true, true);
                    break;
                case AssociationType.List:
                    _list.UpdateWorkflowAssociation(_workflowAssociation);
                    break;
                case AssociationType.ListContentType:
                    _contentType.UpdateWorkflowAssociation(_workflowAssociation);
                    break;
            }
        }


        private void PopulateWorkflowAssociation(string taskListName, string historyListName, string associationData)
        {
            // assign the form data to the new workflow association
            _workflowAssociation.Name = Request.Params["WorkflowName"];
            _workflowAssociation.AutoStartCreate =
                (Request.Params["AutoStartCreate"] == "ON");
            _workflowAssociation.AutoStartChange =
                (Request.Params["AutoStartChange"] == "ON");
            _workflowAssociation.AllowManual = (Request.Params["AllowManual"] == "ON");
            _workflowAssociation.AssociationData = associationData;

            // assign/update the tasks and history lists
            if (this._associationType != AssociationType.ContentType)
            {
                SPList taskList = LookupOrCreateList(
                    taskListName, SPListTemplateType.Tasks);
                SPList historyList = LookupOrCreateList(
                    historyListName, SPListTemplateType.WorkflowHistory);

                if (_workflowAssociation.TaskListId != taskList.ID)
                    _workflowAssociation.SetTaskList(taskList);

                if (_workflowAssociation.HistoryListId != historyList.ID)
                    _workflowAssociation.SetHistoryList(historyList);
            }
            else
            {
                if (_workflowAssociation.TaskListTitle != taskListName)
                    _workflowAssociation.TaskListTitle = taskListName;
                if (_workflowAssociation.HistoryListTitle != historyListName)
                    _workflowAssociation.HistoryListTitle = historyListName;
            }
        }

        private SPList LookupOrCreateList(string paramList, SPListTemplateType listType)
        {
            // lookup the history list
            if (paramList.StartsWith("z"))
            {
                Guid newListId =
                  Web.Lists.Add(paramList.Substring(1), "Workflow Tasks", listType);
                return Web.Lists[newListId];
            }
            else
            {
                // supports existing lists only, custom lists not shown for brevity
                return Web.Lists[new Guid(paramList)]; 
            }
        }

        private static string BuildRedirectString(AssociationType associationType, string paramList, string paramCtype)
        {
            switch (associationType)
            {
                case AssociationType.ContentType:
                    return "WrkSetng.aspx?ctype=" + paramCtype;
                case AssociationType.List:
                    return "WrkSetng.aspx?List=" + paramList;
                case AssociationType.ListContentType:
                    return "WrkSetng.aspx?List=" + paramList + "&ctype=" + paramCtype;
                default:
                    throw new InvalidOperationException();
            }
        }


    }
}
