﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Collections;

namespace DocumentArchiveWorkflowPart3.UI
{
  public class DocArchivePart3TaskForm : LayoutsPageBase
  {
    private SPWorkflow _workflow;
    private SPWorkflowTask _task;
    private SPList _taskList;
    private SPListItem _taskItem;

    protected Label lblListName;
    protected HyperLink lnkItem;
    protected DropDownList lstArchiveList;

    protected string TaskItemName
    {
      get { return _taskItem.DisplayName; }
    }

    protected override void OnLoad(EventArgs e)
    {
      // find the tasks list and task list item
      _taskList = Web.Lists[new Guid(Request.Params["List"])];
      _taskItem = _taskList.GetItemById(int.Parse(Request.Params["ID"]));

      // use the task list item to find the workflow object
      _workflow = new SPWorkflow(Web, new Guid(_taskItem["WorkflowInstanceID"] as string));

      // using the workflow object, lookup the task
      _task = _workflow.Tasks[0];

      // bind the task data
      if (!this.IsPostBack)
      {
        // filter the list of lists for all document libraries that aren't hidden
        IEnumerable<SPList> documentLibraries =
            Web.Lists.Cast<SPList>().Where(n => n is SPDocumentLibrary && !n.Hidden);

        // add each visible document library to the list
        foreach (SPList documentLibrary in documentLibraries)
          lstArchiveList.Items.Add(new ListItem(documentLibrary.Title, documentLibrary.ID.ToString()));

        // initialize the controls
        lnkItem.Text = _workflow.ParentItem.DisplayName;
        lnkItem.NavigateUrl = _workflow.ParentItem.Url;
        lblListName.Text = _workflow.ParentList.Title;

        // initialize the archive list selection
        Hashtable extendedProperties =
            SPWorkflowTask.GetExtendedPropertiesAsHashtable(_taskItem);
        lstArchiveList.SelectedValue = extendedProperties["ArchiveListId"] as string;
      }

      // call the base implementation
      base.OnLoad(e);
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
      // redirect to the page defnined in the source url parameter or the default page
      SPUtility.Redirect(_taskList.DefaultViewUrl, SPRedirectFlags.UseSource, this.Context);
    }

    protected void Reject_Click(object sender, EventArgs e)
    {
      // setup the task's new data
      Hashtable data = new Hashtable();
      data.Add("Result", TaskResults.Rejected);

      // submit the changes to the task            
      SPWorkflowTask.AlterTask(_taskItem, data, true);

      // redirect to the page defnined in the source url parameter or the default page
      SPUtility.Redirect(_taskList.DefaultViewUrl, SPRedirectFlags.UseSource, this.Context);
    }

    protected void Approve_Click(object sender, EventArgs e)
    {
      // setup the task's new data
      Hashtable data = new Hashtable();
      data.Add("Result", TaskResults.Approved);
      data.Add("ArchiveListId", lstArchiveList.SelectedValue);

      // submit the changes to the task            
      SPWorkflowTask.AlterTask(_taskItem, data, true);

      // redirect to the page defnined in the source url parameter or the default page
      SPUtility.Redirect(_taskList.DefaultViewUrl, SPRedirectFlags.UseSource, this.Context);
    }
  }
}
