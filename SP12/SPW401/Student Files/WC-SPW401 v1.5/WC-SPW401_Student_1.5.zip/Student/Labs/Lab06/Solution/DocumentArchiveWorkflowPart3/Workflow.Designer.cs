﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace DocumentArchiveWorkflowPart3
{
    partial class Workflow
    {
        #region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
            this.CanModifyActivities = true;
            System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference2 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference3 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
            this.CompleteApprovalTask = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
            this.moveOnApprovalTaskRejected = new System.Workflow.Activities.SetStateActivity();
            this.LogApprovalTaskRejected = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.MoveOnApprovalTaskApproved = new System.Workflow.Activities.SetStateActivity();
            this.LogApprovalTaskApproved = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.ApprovalTaskIncomplete = new System.Workflow.Activities.IfElseBranchActivity();
            this.ApprovalTaskComplete = new System.Workflow.Activities.IfElseBranchActivity();
            this.ifElseBranchActivity1 = new System.Workflow.Activities.IfElseBranchActivity();
            this.ApprovalTaskInProgress = new System.Workflow.Activities.IfElseBranchActivity();
            this.ApprovalTaskApproved = new System.Workflow.Activities.IfElseBranchActivity();
            this.CheckApprovalTaskFinalAction = new System.Workflow.Activities.IfElseActivity();
            this.CheckApprovalTaskResult = new System.Workflow.Activities.IfElseActivity();
            this.OnApprovalTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
            this.CreateApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
            this.MoveToCompleted = new System.Workflow.Activities.SetStateActivity();
            this.LogWorkflowStarted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.onWorkflowActivated1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
            this.WaitingForApprovalFinal = new System.Workflow.Activities.StateFinalizationActivity();
            this.WaitingForApprovalTaskChanged = new System.Workflow.Activities.EventDrivenActivity();
            this.WaitingForApprovalInit = new System.Workflow.Activities.StateInitializationActivity();
            this.WorkflowActivatedActivity = new System.Workflow.Activities.EventDrivenActivity();
            this.WaitingForApproval = new System.Workflow.Activities.StateActivity();
            this.Completed = new System.Workflow.Activities.StateActivity();
            this.Initial = new System.Workflow.Activities.StateActivity();
            // 
            // CompleteApprovalTask
            // 
            correlationtoken1.Name = "approvalToken";
            correlationtoken1.OwnerActivityName = "WaitingForApproval";
            this.CompleteApprovalTask.CorrelationToken = correlationtoken1;
            this.CompleteApprovalTask.Name = "CompleteApprovalTask";
            activitybind1.Name = "Workflow";
            activitybind1.Path = "ApprovalTaskId";
            this.CompleteApprovalTask.TaskOutcome = null;
            this.CompleteApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // moveOnApprovalTaskRejected
            // 
            this.moveOnApprovalTaskRejected.Name = "moveOnApprovalTaskRejected";
            this.moveOnApprovalTaskRejected.TargetStateName = "Completed";
            // 
            // LogApprovalTaskRejected
            // 
            this.LogApprovalTaskRejected.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.LogApprovalTaskRejected.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.LogApprovalTaskRejected.HistoryDescription = "Approval task rejected.";
            this.LogApprovalTaskRejected.HistoryOutcome = "";
            this.LogApprovalTaskRejected.Name = "LogApprovalTaskRejected";
            this.LogApprovalTaskRejected.OtherData = "";
            this.LogApprovalTaskRejected.UserId = -1;
            // 
            // MoveOnApprovalTaskApproved
            // 
            this.MoveOnApprovalTaskApproved.Name = "MoveOnApprovalTaskApproved";
            this.MoveOnApprovalTaskApproved.TargetStateName = "Completed";
            // 
            // LogApprovalTaskApproved
            // 
            this.LogApprovalTaskApproved.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.LogApprovalTaskApproved.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.LogApprovalTaskApproved.HistoryDescription = "";
            this.LogApprovalTaskApproved.HistoryOutcome = "";
            this.LogApprovalTaskApproved.Name = "LogApprovalTaskApproved";
            this.LogApprovalTaskApproved.OtherData = "";
            this.LogApprovalTaskApproved.UserId = -1;
            // 
            // ApprovalTaskIncomplete
            // 
            this.ApprovalTaskIncomplete.Name = "ApprovalTaskIncomplete";
            // 
            // ApprovalTaskComplete
            // 
            this.ApprovalTaskComplete.Activities.Add(this.CompleteApprovalTask);
            ruleconditionreference1.ConditionName = "IsApprovaltaskComplete";
            this.ApprovalTaskComplete.Condition = ruleconditionreference1;
            this.ApprovalTaskComplete.Name = "ApprovalTaskComplete";
            // 
            // ifElseBranchActivity1
            // 
            this.ifElseBranchActivity1.Name = "ifElseBranchActivity1";
            // 
            // ApprovalTaskInProgress
            // 
            this.ApprovalTaskInProgress.Activities.Add(this.LogApprovalTaskRejected);
            this.ApprovalTaskInProgress.Activities.Add(this.moveOnApprovalTaskRejected);
            ruleconditionreference2.ConditionName = "IsApprovalTaskRejected";
            this.ApprovalTaskInProgress.Condition = ruleconditionreference2;
            this.ApprovalTaskInProgress.Name = "ApprovalTaskInProgress";
            // 
            // ApprovalTaskApproved
            // 
            this.ApprovalTaskApproved.Activities.Add(this.LogApprovalTaskApproved);
            this.ApprovalTaskApproved.Activities.Add(this.MoveOnApprovalTaskApproved);
            ruleconditionreference3.ConditionName = "IsApprovalTaskApproved";
            this.ApprovalTaskApproved.Condition = ruleconditionreference3;
            this.ApprovalTaskApproved.Name = "ApprovalTaskApproved";
            // 
            // CheckApprovalTaskFinalAction
            // 
            this.CheckApprovalTaskFinalAction.Activities.Add(this.ApprovalTaskComplete);
            this.CheckApprovalTaskFinalAction.Activities.Add(this.ApprovalTaskIncomplete);
            this.CheckApprovalTaskFinalAction.Name = "CheckApprovalTaskFinalAction";
            // 
            // CheckApprovalTaskResult
            // 
            this.CheckApprovalTaskResult.Activities.Add(this.ApprovalTaskApproved);
            this.CheckApprovalTaskResult.Activities.Add(this.ApprovalTaskInProgress);
            this.CheckApprovalTaskResult.Activities.Add(this.ifElseBranchActivity1);
            this.CheckApprovalTaskResult.Name = "CheckApprovalTaskResult";
            // 
            // OnApprovalTaskChanged
            // 
            this.OnApprovalTaskChanged.AfterProperties = null;
            this.OnApprovalTaskChanged.BeforeProperties = null;
            this.OnApprovalTaskChanged.CorrelationToken = correlationtoken1;
            this.OnApprovalTaskChanged.Executor = null;
            this.OnApprovalTaskChanged.Name = "OnApprovalTaskChanged";
            activitybind2.Name = "Workflow";
            activitybind2.Path = "ApprovalTaskId";
            this.OnApprovalTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnApprovalTaskChanged_Invoked);
            this.OnApprovalTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            // 
            // CreateApprovalTask
            // 
            this.CreateApprovalTask.CorrelationToken = correlationtoken1;
            this.CreateApprovalTask.ListItemId = -1;
            this.CreateApprovalTask.Name = "CreateApprovalTask";
            this.CreateApprovalTask.SpecialPermissions = null;
            activitybind3.Name = "Workflow";
            activitybind3.Path = "ApprovalTaskId";
            this.CreateApprovalTask.TaskProperties = null;
            this.CreateApprovalTask.MethodInvoking += new System.EventHandler(this.CreateApprovalTask_Invoking);
            this.CreateApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            // 
            // MoveToCompleted
            // 
            this.MoveToCompleted.Name = "MoveToCompleted";
            this.MoveToCompleted.TargetStateName = "WaitingForApproval";
            // 
            // LogWorkflowStarted
            // 
            this.LogWorkflowStarted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.LogWorkflowStarted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.LogWorkflowStarted.HistoryDescription = "Workflow was started";
            activitybind4.Name = "Workflow";
            activitybind4.Path = "WorkflowProperties.Item.DisplayName";
            this.LogWorkflowStarted.Name = "LogWorkflowStarted";
            this.LogWorkflowStarted.OtherData = "";
            this.LogWorkflowStarted.UserId = -1;
            this.LogWorkflowStarted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            // 
            // onWorkflowActivated1
            // 
            correlationtoken2.Name = "WorkflowToken";
            correlationtoken2.OwnerActivityName = "Workflow";
            this.onWorkflowActivated1.CorrelationToken = correlationtoken2;
            this.onWorkflowActivated1.EventName = "OnWorkflowActivated";
            this.onWorkflowActivated1.Name = "onWorkflowActivated1";
            activitybind5.Name = "Workflow";
            activitybind5.Path = "WorkflowProperties";
            this.onWorkflowActivated1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnWorkflowActivated_Invoked);
            this.onWorkflowActivated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
            // 
            // WaitingForApprovalFinal
            // 
            this.WaitingForApprovalFinal.Activities.Add(this.CheckApprovalTaskFinalAction);
            this.WaitingForApprovalFinal.Name = "WaitingForApprovalFinal";
            // 
            // WaitingForApprovalTaskChanged
            // 
            this.WaitingForApprovalTaskChanged.Activities.Add(this.OnApprovalTaskChanged);
            this.WaitingForApprovalTaskChanged.Activities.Add(this.CheckApprovalTaskResult);
            this.WaitingForApprovalTaskChanged.Name = "WaitingForApprovalTaskChanged";
            // 
            // WaitingForApprovalInit
            // 
            this.WaitingForApprovalInit.Activities.Add(this.CreateApprovalTask);
            this.WaitingForApprovalInit.Name = "WaitingForApprovalInit";
            // 
            // WorkflowActivatedActivity
            // 
            this.WorkflowActivatedActivity.Activities.Add(this.onWorkflowActivated1);
            this.WorkflowActivatedActivity.Activities.Add(this.LogWorkflowStarted);
            this.WorkflowActivatedActivity.Activities.Add(this.MoveToCompleted);
            this.WorkflowActivatedActivity.Name = "WorkflowActivatedActivity";
            // 
            // WaitingForApproval
            // 
            this.WaitingForApproval.Activities.Add(this.WaitingForApprovalInit);
            this.WaitingForApproval.Activities.Add(this.WaitingForApprovalTaskChanged);
            this.WaitingForApproval.Activities.Add(this.WaitingForApprovalFinal);
            this.WaitingForApproval.Name = "WaitingForApproval";
            // 
            // Completed
            // 
            this.Completed.Name = "Completed";
            // 
            // Initial
            // 
            this.Initial.Activities.Add(this.WorkflowActivatedActivity);
            this.Initial.Name = "Initial";
            // 
            // Workflow
            // 
            this.Activities.Add(this.Initial);
            this.Activities.Add(this.Completed);
            this.Activities.Add(this.WaitingForApproval);
            this.CompletedStateName = "Completed";
            this.DynamicUpdateCondition = null;
            this.InitialStateName = "Initial";
            this.Name = "Workflow";
            this.CanModifyActivities = false;

        }

        #endregion

        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated OnWorkflowActivated;
        private StateActivity WaitingForApproval;
        private StateInitializationActivity WaitingForApprovalInit;
        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateApprovalTask;
        private StateActivity Completed;
        private EventDrivenActivity WorkflowActivatedActivity;
        private SetStateActivity MoveToCompleted;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogWorkflowStarted;
        private EventDrivenActivity WaitingForApprovalTaskChanged;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged OnApprovalTaskChanged;
        private IfElseBranchActivity ApprovalTaskInProgress;
        private IfElseBranchActivity ApprovalTaskApproved;
        private IfElseActivity CheckApprovalTaskResult;
        private SetStateActivity MoveOnApprovalTaskApproved;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogApprovalTaskApproved;
        private IfElseBranchActivity ApprovalTaskIncomplete;
        private IfElseBranchActivity ApprovalTaskComplete;
        private IfElseActivity CheckApprovalTaskFinalAction;
        private StateFinalizationActivity WaitingForApprovalFinal;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteApprovalTask;
        private IfElseBranchActivity ifElseBranchActivity1;
        private SetStateActivity moveOnApprovalTaskRejected;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogApprovalTaskRejected;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated1;
        private StateActivity Initial;















    }
}
