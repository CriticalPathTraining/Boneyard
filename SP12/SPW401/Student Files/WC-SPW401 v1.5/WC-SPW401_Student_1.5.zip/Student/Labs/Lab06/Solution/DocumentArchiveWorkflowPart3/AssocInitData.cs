﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace DocumentArchiveWorkflowPart3
{
    [Serializable]
    [XmlTypeAttribute(AnonymousType = true, Namespace = "urn:DocumentArchiveWorkflowPart3")]
    [XmlRootAttribute(Namespace = "urn:DocumentArchiveWorkflowPart3", IsNullable = false)]
    public class AssocInitData
    {
        public string ApproverUserName { get; set; }
        public string ArchiveListId { get; set; }

        public string Serialize()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(AssocInitData));
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, this);
                return writer.ToString();
            }
        }

        public static AssocInitData Deserialize(string value)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(AssocInitData));
            using (StringReader reader = new StringReader(value))
                return serializer.Deserialize(reader) as AssocInitData;
        }
    }
}
