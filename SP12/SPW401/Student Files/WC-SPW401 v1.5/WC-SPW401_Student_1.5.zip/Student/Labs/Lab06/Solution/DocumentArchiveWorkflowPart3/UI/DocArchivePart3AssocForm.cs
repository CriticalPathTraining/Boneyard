﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;

namespace DocumentArchiveWorkflowPart3.UI
{
  public class DocArchivePart3AssocForm : AssociationForm
  {
    protected PeopleEditor ppkApprover;
    protected DropDownList lstArchiveList;

    protected override void PopulateControls()
    {
      // filter the list of lists for all document libraries that aren't hidden
      IEnumerable<SPList> documentLibraries =
          Web.Lists.Cast<SPList>().Where(n => n is SPDocumentLibrary && !n.Hidden);

      // add each visible document library to the list
      foreach (SPList documentLibrary in documentLibraries)
        lstArchiveList.Items.Add(
            new ListItem(documentLibrary.Title, documentLibrary.ID.ToString()));
    }

    protected override void BindAssociationData(string value)
    {
      // deserialize the association data
      AssocInitData assocInitData = AssocInitData.Deserialize(value);
      
      // bind the controls to the association data
      ppkApprover.CommaSeparatedAccounts = assocInitData.ApproverUserName;
      lstArchiveList.SelectedValue = assocInitData.ArchiveListId.ToString();
    }

    protected override string UpdateAssociationData()
    {
      // populate the association data using the UI
      AssocInitData assocInitData = new AssocInitData();
      assocInitData.ApproverUserName = (ppkApprover.Entities[0] as PickerEntity).Key;
      assocInitData.ArchiveListId = lstArchiveList.SelectedValue;

      // serialize the return the association data
      return assocInitData.Serialize();
    }
  }
}
