﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace DocumentArchiveWorkflowPart4.UI
{
	public abstract class DocArchivePart4InitForm : LayoutsPageBase
	{
    private SPWorkflowAssociation _workflowAssociation;
    private SPList _list;
    private SPListItem _listItem;

    protected PeopleEditor ppkApprover;
    protected DropDownList lstArchiveList;

    protected string WorkflowName
    {
      get { return _workflowAssociation.Name; }
    }

    protected string ItemName
    {
      get { return _listItem.DisplayName; }
    }

    protected override void OnLoad(EventArgs e)
    {

      // read the form level parameters
      string listId = Request.Params["List"];
      string listItemId = Request.Params["ID"];
      string ctypeId = Request.Params["ctype"];
      string templateId = Request.Params["TemplateId"];

      // find the list and list item
      _list = Web.Lists[new Guid(listId)];
      _listItem = _list.GetItemById(int.Parse(listItemId));

      // check for the workflow association in the list
      _workflowAssociation = _list.WorkflowAssociations[new Guid(templateId)];

      // if the association wasn't found, check the content type
      if (_workflowAssociation == null)
      {
        SPContentType _contentType =
            _list.ContentTypes[new SPContentTypeId(ctypeId)];
        _workflowAssociation =
            _contentType.WorkflowAssociations[new Guid(templateId)];
      }

      // make sure the workflow association could be found
      if (_workflowAssociation == null)
        throw new SPException("The requested workflow could not be found.");

      // populate the UI
      if (!this.IsPostBack)
      {
        // filter the list of lists for all document libraries that aren't hidden
        IEnumerable<SPList> documentLibraries =
            Web.Lists.Cast<SPList>().Where(n => n is SPDocumentLibrary && !n.Hidden);

        // add each visible document library to the list
        foreach (SPList documentLibrary in documentLibraries)
          lstArchiveList.Items.Add(new ListItem(documentLibrary.Title, documentLibrary.ID.ToString()));

        // populate the form using the association data
        AssocInitData assocInitData = AssocInitData.Deserialize(_workflowAssociation.AssociationData);
        ppkApprover.CommaSeparatedAccounts = assocInitData.ApproverUserName;
        lstArchiveList.SelectedValue = assocInitData.ArchiveListId.ToString();
      }

      // call the base implementation
      base.OnLoad(e);
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
      // redirect to the page in the source url parameter or the default page
      SPUtility.Redirect(_list.DefaultViewUrl,
          SPRedirectFlags.UseSource, this.Context);
    }

    protected void Start_Click(object sender, EventArgs e)
    {
      // populate the association data using the UI
      AssocInitData assocInitData = new AssocInitData();
      assocInitData.ApproverUserName = (ppkApprover.Entities[0] as PickerEntity).Key;
      assocInitData.ArchiveListId = lstArchiveList.SelectedValue;

      // get the initiation data
      string initiationData = assocInitData.Serialize();

      // start the new workflow instance
      Web.Site.WorkflowManager.StartWorkflow(_listItem,
          _workflowAssociation, initiationData);

      // redirect to the list default view
      SPUtility.Redirect(_list.DefaultViewUrl,
          SPRedirectFlags.UseSource, this.Context);
    } 

  }
}
