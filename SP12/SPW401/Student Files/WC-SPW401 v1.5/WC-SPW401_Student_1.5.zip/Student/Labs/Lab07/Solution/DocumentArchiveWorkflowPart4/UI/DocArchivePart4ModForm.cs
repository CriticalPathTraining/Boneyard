﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;

namespace DocumentArchiveWorkflowPart4.UI
{
	public abstract class DocArchivePart4ModForm : LayoutsPageBase
	{
    private SPList _list;
    private SPListItem _listItem;
    private SPWorkflow _workflow;
    private SPWorkflowModification _modification;

    protected PeopleEditor pplApprover;
    protected PeopleEditor pplManager;

    protected override void OnLoad(EventArgs e)
    {
      // read the form level parameters
      string listId = Request.Params["List"];
      string listItemId = Request.Params["ID"];
      string workflowId = Request.Params["WorkflowInstanceID"];
      string modificationId = Request.Params["ModificationID"];

      // find the list and workflow modification objects
      _list = Web.Lists[new Guid(listId)];
      _listItem = _list.GetItemById(Convert.ToInt32(listItemId));
      _workflow = _listItem.Workflows[new Guid(workflowId)];
      _modification = _workflow.Modifications[new Guid(modificationId)];
    
      // populate the UI
      if (!this.IsPostBack)
      {
        // deserialize the association data
        ModificationData modData = ModificationData.Deserialize(_modification.ContextData);

        // bind the controls to the association data
        pplApprover.CommaSeparatedAccounts = modData.ApproverUserName;
      }

      // call the base implementation
      base.OnLoad(e);
    }

    protected void Cancel_Click(object sender, EventArgs e)
    {
      // redirect to the page in the source url parameter or the default page
      SPUtility.Redirect(_list.DefaultViewUrl,
          SPRedirectFlags.UseSource, this.Context);
    }

    protected void Submit_Click(object sender, EventArgs e)
    {
      // populate the modification data using the UI
      ModificationData modData = new ModificationData();
      modData.ApproverUserName = (pplApprover.Entities[0] as PickerEntity).Key;

      // serialize the modification data
      string modificationData = modData.Serialize();

      // apply the modification to the workflow
      Web.Site.WorkflowManager.ModifyWorkflow(_workflow,
                                              _modification,
                                              modificationData);
      
      // redirect to the page defnined in the source url parameter or the default page
      SPUtility.Redirect(_list.DefaultViewUrl,
          SPRedirectFlags.UseSource, this.Context);
    } 
  }
}
