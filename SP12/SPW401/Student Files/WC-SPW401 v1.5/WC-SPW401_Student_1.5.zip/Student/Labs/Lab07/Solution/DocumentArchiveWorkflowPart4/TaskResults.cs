﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DocumentArchiveWorkflowPart4
{
    public enum TaskResults
    {
        None,
        Approved,
        Rejected
    }
}
