﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.SharePoint;

namespace DocumentArchiveWorkflowPart4
{
  public sealed partial class Workflow : StateMachineWorkflowActivity
  {
    public Workflow()
    {
      InitializeComponent();
    }

    public SPWorkflowActivationProperties WorkflowProperties { get; set; }
    public Guid ApprovalTaskId { get; set; }
    public TaskResults ApprovalTaskResult { get; set; }

    private AssocInitData AssocInitData { get; set; }

    private void CreateApprovalTask_Invoking(object sender, EventArgs e)
    {
      ApprovalTaskId = Guid.NewGuid();

      SPWorkflowTaskProperties taskProperties = new SPWorkflowTaskProperties();
      //taskProperties.AssignedTo = "WIN2K3STD\\Administrator";
      taskProperties.AssignedTo = AssocInitData.ApproverUserName;
      taskProperties.Title = "Archival Approval";
      taskProperties.Description = "This document was flagged to be archived.  Please approve or reject this action.";
      taskProperties.ExtendedProperties.Add("ArchiveListId", this.AssocInitData.ArchiveListId);

      CreateTask createApprovalTask = sender as CreateTask;
      createApprovalTask.TaskProperties = taskProperties;
    }

    private void OnApprovalTaskChanged_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPTaskServiceEventArgs args = e as SPTaskServiceEventArgs;

      //Guid statusFieldId = new Guid("{c15b34c3-ce7d-490a-b133-3f4de8801b76}");
      //string result = args.afterProperties.ExtendedProperties[statusFieldId] as string;
      //if (result == "Completed")
      //    this.ApprovalTaskResult = TaskResults.Approved;

      string result = args.afterProperties.ExtendedProperties["Result"] as string;
      this.ApprovalTaskResult = (TaskResults)Enum.Parse(typeof(TaskResults), result);
    }

    private void OnWorkflowActivated_Invoked(object sender, ExternalDataEventArgs e)
    {
      // deserialize init data, if none use defaults
      this.AssocInitData = AssocInitData.Deserialize(
          WorkflowProperties.InitiationData);
    }

    private void EnableModification_Invoking(object sender, EventArgs e)
    {
      // populate the modification data object
      ModificationData modData = new ModificationData();
      modData.ApproverUserName = AssocInitData.ApproverUserName;

      // serialize and assign the context data to the modification
      EnableWorkflowModification activity = sender as EnableWorkflowModification;
      activity.ContextData = modData.Serialize();
    }

    private void OnWorkflowModified_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPModificationEventArgs args = e as SPModificationEventArgs;

      // deserialize the modification data and apply the changes
      ModificationData modData = ModificationData.Deserialize(args.data);
      AssocInitData.ApproverUserName = modData.ApproverUserName;
    }

    private void ArchiveDocument_ExecuteCode(object sender, EventArgs e)
    {
        // find the target archive list
        Guid archiveListId = new Guid(AssocInitData.ArchiveListId);
        SPList targetList = this.WorkflowProperties.Web.Lists[archiveListId];

        // copy the document to the archive folder
        this.WorkflowProperties.Item.CopyTo(
            targetList.ParentWeb.Url + "/" + targetList.RootFolder.Url + "/" + this.WorkflowProperties.Item.File.Name);
    }
  }
}
