﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Design;
using System.ComponentModel;
using System.Runtime.Serialization;
using System.ComponentModel.Design;

namespace SqlDatabaseActivities
{
    public class SqlConnectionToolboxItem : ActivityToolboxItem
    {
        public SqlConnectionToolboxItem(Type type)
            : base(type)
        {
        }

        private SqlConnectionToolboxItem(SerializationInfo info, StreamingContext context)
        {
            this.Deserialize(info, context);
        }

        protected override IComponent[] CreateComponentsCore(IDesignerHost designerHost)
        {
            SqlConnectionActivity activity = new SqlConnectionActivity();
            activity.Activities.Add(new SqlScalarQueryActivity());
            return new IComponent[] { activity };
        }
    }
}
