﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Data.SqlClient;

namespace SqlDatabaseActivities
{
    [Designer(typeof(SqlScalarQueryActivityDesigner))]
    [ActivityValidator(typeof(SqlScalarQueryActivityValidator))]
    public partial class SqlScalarQueryActivity : Activity
    {
        public SqlScalarQueryActivity()
        {
            InitializeComponent();
        }

        public static DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(System.String), typeof(SqlScalarQueryActivity));

        [Category("Parameters")]
        public string Query
        {
            get { return base.GetValue(QueryProperty) as string; }
            set { base.SetValue(QueryProperty, value); }
        }

        public static DependencyProperty ParametersProperty =
           DependencyProperty.Register("Parameters", typeof(SqlParameter[]), typeof(SqlScalarQueryActivity));

        [Category("Parameters")]
        public SqlParameter[] Parameters
        {
            get { return base.GetValue(ParametersProperty) as SqlParameter[]; }
            set { base.SetValue(ParametersProperty, value); }
        }

        public static DependencyProperty ResultProperty =
           DependencyProperty.Register("Result", typeof(System.Object), typeof(SqlScalarQueryActivity));

        [Category("Parameters")]
        public object Result
        {
            get { return base.GetValue(ResultProperty); }
            set { base.SetValue(ResultProperty, value); }
        }

        public static DependencyProperty InvokingEvent =
            DependencyProperty.Register("Invoking", typeof(EventHandler), typeof(SqlScalarQueryActivity));

        [Category("Handlers")]
        public event EventHandler Invoking
        {
            add { base.AddHandler(InvokingEvent, value); }
            remove { base.RemoveHandler(InvokingEvent, value); }
        }

        public static DependencyProperty InvokedEvent =
            DependencyProperty.Register("Invoked", typeof(EventHandler), typeof(SqlScalarQueryActivity));

        [Category("Handlers")]
        public event EventHandler Invoked
        {
            add { base.AddHandler(InvokedEvent, value); }
            remove { base.RemoveHandler(InvokedEvent, value); }
        }

        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            // raise the invoking event
            this.RaiseEvent(InvokingEvent, this, EventArgs.Empty);

            // find the parent SqlConnectionActivity
            SqlConnectionActivity connectionActivity = FindParentConnection(this);
            if (connectionActivity == null)
                throw new InvalidOperationException("No parent connection was found.");

            // store the connection for later
            SqlConnection connection = connectionActivity.Connection;

            //// find the parent SqlConnection activity
            //using (SqlConnection connection = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Litware;Integrated Security=True"))
            //{
            //    connection.Open();
            // create the sql command
            SqlCommand command = new SqlCommand(this.Query, connection);
            if (this.Parameters != null)
                foreach (SqlParameter parameter in this.Parameters)
                    command.Parameters.Add((parameter as ICloneable).Clone() as SqlParameter);
            this.Result = command.ExecuteScalar();
            //}

            // raise the Invoked event
            this.RaiseEvent(InvokedEvent, this, EventArgs.Empty);

            // return the closed activity status
            return ActivityExecutionStatus.Closed;
        }

        private SqlConnectionActivity FindParentConnection(Activity current)
        {
            while (current.Parent != null)
            {
                if (current.Parent is SqlConnectionActivity)
                    return current.Parent as SqlConnectionActivity;
                current = current.Parent;
            }
            return null;
        }
    }
}
