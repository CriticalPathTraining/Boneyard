﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Data.SqlClient;

namespace SqlDatabaseActivities
{
	public partial class SqlGetValueActivity: SequenceActivity
	{
		public SqlGetValueActivity()
		{
			InitializeComponent();
		}

    public static DependencyProperty ConnectionStringProperty =
    DependencyProperty.Register("ConnectionString",
      typeof(System.String), typeof(SqlDatabaseActivities.SqlGetValueActivity));

    [Category("Parameters")]
    public String ConnectionString
    {
      get { return ((string)(base.GetValue(ConnectionStringProperty))); }
      set { base.SetValue(ConnectionStringProperty, value); }
    }

    public static DependencyProperty ResultFieldProperty =
        DependencyProperty.Register("ResultField",
          typeof(System.String), typeof(SqlDatabaseActivities.SqlGetValueActivity));

    [Category("Parameters")]
    public String ResultField
    {
      get { return ((string)(base.GetValue(ResultFieldProperty))); }
      set { base.SetValue(ResultFieldProperty, value); }
    }

    public static DependencyProperty TableProperty =
        DependencyProperty.Register("Table",
          typeof(System.String), typeof(SqlDatabaseActivities.SqlGetValueActivity));

    [Category("Parameters")]
    public String Table
    {
      get { return ((string)(base.GetValue(TableProperty))); }
      set { base.SetValue(TableProperty, value); }
    }

    public static DependencyProperty QueryFieldProperty =
        DependencyProperty.Register("QueryField",
          typeof(System.String), typeof(SqlDatabaseActivities.SqlGetValueActivity));

    [Category("Parameters")]
    public String QueryField
    {
      get { return ((string)(base.GetValue(QueryFieldProperty))); }
      set { base.SetValue(QueryFieldProperty, value); }
    }

    public static DependencyProperty QueryValueProperty =
        DependencyProperty.Register("QueryValue",
          typeof(System.String), typeof(SqlDatabaseActivities.SqlGetValueActivity));

    [Category("Parameters")]
    public String QueryValue
    {
      get { return ((string)(base.GetValue(QueryValueProperty))); }
      set { base.SetValue(QueryValueProperty, value); }
    }

    public static DependencyProperty ResultProperty =
        DependencyProperty.Register("Result",
          typeof(System.String), typeof(SqlDatabaseActivities.SqlGetValueActivity));

    [Category("Parameters")]
    public String Result
    {
      get { return ((string)(base.GetValue(ResultProperty))); }
      set { base.SetValue(ResultProperty, value); }
    }

    private void LookupValue_Invoking(object sender, EventArgs e)
    {
      SqlScalarQueryActivity activity = sender as SqlScalarQueryActivity;

      activity.Query = string.Format(
          activity.Query, this.ResultField, this.Table, this.QueryField);
      activity.Parameters = new SqlParameter[]
      {
          new SqlParameter("@queryValue", this.QueryValue)
      };
    }

	}
}
