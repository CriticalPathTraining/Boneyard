﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Data.SqlClient;

namespace SqlDatabaseActivities
{
    [ActivityValidator(typeof(SqlConnectionActivityValidator))]
    [Designer(typeof(SqlConnectionActivityDesigner))]
    [ToolboxItem(typeof(SqlConnectionToolboxItem))]
    public partial class SqlConnectionActivity : SequenceActivity,
        IActivityEventListener<ActivityExecutionStatusChangedEventArgs>
    {
        public SqlConnectionActivity()
        {
            InitializeComponent();
        }

        public static DependencyProperty ConnectionStringProperty =
            DependencyProperty.Register("ConnectionString", typeof(System.String), typeof(SqlConnectionActivity));

        [Category("Parameters")]
        public string ConnectionString
        {
            get { return base.GetValue(ConnectionStringProperty) as string; }
            set { base.SetValue(ConnectionStringProperty, value); }
        }

        [Browsable(false)]
        public SqlConnection Connection { get; private set; }

        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            // check if there's any activities to execute
            if (base.EnabledActivities.Count == 0)
                return ActivityExecutionStatus.Closed;

            // open the database connection
            if (this.Connection == null)
            {
                this.Connection = new SqlConnection(this.ConnectionString);
                this.Connection.Open();
            }

            // start the first child activity and register for it's state change event
            Activity firstEnabledActivity = base.EnabledActivities[0];
            firstEnabledActivity.RegisterForStatusChange(Activity.ClosedEvent, this);
            executionContext.ExecuteActivity(firstEnabledActivity);

            // tell the runtime this activity is still executing
            return ActivityExecutionStatus.Executing;
        }

        protected override void OnClosed(IServiceProvider provider)
        {
            // close the database connection
            if (this.Connection != null)
            {
                if (this.Connection.State != System.Data.ConnectionState.Closed)
                    this.Connection.Close();
                this.Connection = null;
            }

            // call the base implementation
            base.OnClosed(provider);
        }

        #region IActivityEventListener<ActivityExecutionStatusChangedEventArgs> Members
        public void OnEvent(object sender, ActivityExecutionStatusChangedEventArgs e)
        {
            // validate the sender
            ActivityExecutionContext executionContext = sender as ActivityExecutionContext;
            if (executionContext == null)
                throw new ArgumentException("sender");

            // unregister the handler for status events
            e.Activity.UnregisterForStatusChange(Activity.ClosedEvent, this);

            // if the activity is cancelling or faulting, cleanup
            if ((this.ExecutionStatus == ActivityExecutionStatus.Canceling) || (this.ExecutionStatus == ActivityExecutionStatus.Faulting))
            {
                executionContext.CloseActivity();
            }
            // if the activity is executing, schedule the next child
            else if (this.ExecutionStatus == ActivityExecutionStatus.Executing)
            {
                // find the next activity in the sequence
                Activity nextActivity = FindNextChild();
                if (nextActivity != null)
                {
                    // register and start the next activity
                    nextActivity.RegisterForStatusChange(Activity.ClosedEvent, this);
                    executionContext.ExecuteActivity(nextActivity);
                }
                else
                {
                    // close this activity
                    executionContext.CloseActivity();
                }
            }
        }

        private Activity FindNextChild()
        {
            // check if any activities are in the list
            if (base.EnabledActivities.Count == 0)
                return null;

            // find the last activity in the list that is closed
            Activity lastClosedActivity = base.EnabledActivities.LastOrDefault(
                n => n.ExecutionStatus == ActivityExecutionStatus.Closed);

            // if this is the last closed activity, return false
            int indexOfLastClosedActivity = base.EnabledActivities.IndexOf(lastClosedActivity);
            if (indexOfLastClosedActivity == base.EnabledActivities.Count - 1)
                return null;

            // return try to indicate a task was found
            return base.EnabledActivities[indexOfLastClosedActivity + 1];
        }
        #endregion
    }
}
