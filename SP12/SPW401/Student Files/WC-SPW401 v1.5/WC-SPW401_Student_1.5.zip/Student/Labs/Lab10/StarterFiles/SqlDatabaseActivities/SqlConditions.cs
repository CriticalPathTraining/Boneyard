﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using Microsoft.SharePoint.WorkflowActions;

namespace SqlDatabaseActivities
{
	class SqlConditions
	{
public static bool ItemExists(WorkflowContext context, string listId, int itemId, string table, string queryField, object queryValue, string connectionString)
{
// create the SqlConnection object
using (SqlConnection connection = new SqlConnection(connectionString))
{
    connection.Open();

// build the query using the parameters
string query = 
    string.Format("SELECT TOP 1 COUNT(*) FROM {0} WHERE {1} = @queryValue", 
        table, queryField);

// create the SqlCommand and the parameters
SqlCommand command = new SqlCommand(query, connection);
command.Parameters.Add(new SqlParameter("@queryValue", queryValue));

// execute the query and return true if an item was found
return ((int)command.ExecuteScalar() == 1);
            }
        }
	}
}
