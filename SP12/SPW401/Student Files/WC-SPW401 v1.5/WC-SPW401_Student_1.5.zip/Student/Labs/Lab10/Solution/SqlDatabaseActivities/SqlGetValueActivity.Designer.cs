﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SqlDatabaseActivities
{
	public partial class SqlGetValueActivity
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
      this.CanModifyActivities = true;
      System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
      this.LookupValue = new SqlDatabaseActivities.SqlScalarQueryActivity();
      this.SqlConnection = new SqlDatabaseActivities.SqlConnectionActivity();
      // 
      // LookupValue
      // 
      this.LookupValue.Name = "LookupValue";
      this.LookupValue.Parameters = null;
      this.LookupValue.Query = "SELECT {0} FROM {1} WHERE {2} = @queryValue";
      activitybind1.Name = "SqlGetValueActivity";
      activitybind1.Path = "Result";
      this.LookupValue.Invoking += new System.EventHandler(this.LookupValue_Invoking);
      this.LookupValue.SetBinding(SqlDatabaseActivities.SqlScalarQueryActivity.ResultProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
      // 
      // SqlConnection
      // 
      this.SqlConnection.Activities.Add(this.LookupValue);
      activitybind2.Name = "SqlGetValueActivity";
      activitybind2.Path = "ConnectionString";
      this.SqlConnection.Name = "SqlConnection";
      this.SqlConnection.SetBinding(SqlDatabaseActivities.SqlConnectionActivity.ConnectionStringProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
      // 
      // SqlGetValueActivity
      // 
      this.Activities.Add(this.SqlConnection);
      this.Name = "SqlGetValueActivity";
      this.CanModifyActivities = false;

		}

		#endregion

        private SqlScalarQueryActivity LookupValue;
        private SqlConnectionActivity SqlConnection;


  }
}
