﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel;

namespace SqlDatabaseActivities
{
    public class SqlScalarQueryActivityValidator : ActivityValidator
    {
        public override ValidationErrorCollection Validate(ValidationManager manager, object obj)
        {

            SqlScalarQueryActivity activity = obj as SqlScalarQueryActivity;

            // build the errors collection using the base validation method
            ValidationErrorCollection errors = base.Validate(manager, obj);

            // only perform validation if in design or runtime mode
            if (activity.Parent != null)
            {
                // validate that a query was defined
                if (string.IsNullOrEmpty(activity.Query))
                    errors.Add(ValidationError.GetNotSetValidationError("Query"));

                // validate the activity has an ancestor that is a SqlConnectionActivity
                if (!HasSqlConnectionParent(activity))
                    errors.Add(new ValidationError("SqlScalarQueryActivities must be palaced in a SqlConnectionActivity", 100, false));
            }

            // return the errors
            return errors;
        }

        private bool HasSqlConnectionParent(Activity current)
        {
            while (current.Parent != null)
            {
                if (current.Parent is SqlConnectionActivity)
                    return true;
                current = current.Parent;
            }
            return false;
        }

    }
}
