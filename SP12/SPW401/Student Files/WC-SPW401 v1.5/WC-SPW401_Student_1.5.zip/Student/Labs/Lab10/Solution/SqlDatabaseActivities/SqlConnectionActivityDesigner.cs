﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Activities;
using System.ComponentModel.Design;
using System.Collections.ObjectModel;

namespace SqlDatabaseActivities
{
    [ActivityDesignerTheme(typeof(SqlConnectionActivityDesignerTheme))]
    public class SqlConnectionActivityDesigner : SequentialActivityDesigner
    {
        /// <summary>
        /// Only allow the insert if no activities derive from IEventActivity.
        /// </summary>
        public override bool CanInsertActivities(HitTestInfo insertLocation, ReadOnlyCollection<Activity> activitiesToInsert)
        {
            // check if any activities are of type IEventActivity            
            return !activitiesToInsert.Any(n => n is IEventActivity);
        }

        protected override ActivityDesignerVerbCollection Verbs
        {
            get
            {
                // load the verbs from the base class
                ActivityDesignerVerbCollection verbs = new ActivityDesignerVerbCollection();
                verbs.AddRange(base.Verbs);

                // add the new verb
                verbs.Add(
                    new ActivityDesignerVerb(this, DesignerVerbGroup.Actions, "Add Scalar Query",
                        new EventHandler(AddScalarQuery_Click)));

                // return the list of verbs
                return verbs;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void AddScalarQuery_Click(object sender, EventArgs e)
        {
            CompositeActivity activity = base.Activity as CompositeActivity;

            // create the list of new activites
            List<Activity> activities = new List<Activity>();
            activities.Add(new SqlScalarQueryActivity());

            // determine where to add the activities
            ConnectorHitTestInfo location =
                new ConnectorHitTestInfo(this,
                    HitTestLocations.Designer, activity.Activities.Count);

            // add the activities to the designer 
            base.InsertActivities(location, activities.AsReadOnly());
        }
    }
}
