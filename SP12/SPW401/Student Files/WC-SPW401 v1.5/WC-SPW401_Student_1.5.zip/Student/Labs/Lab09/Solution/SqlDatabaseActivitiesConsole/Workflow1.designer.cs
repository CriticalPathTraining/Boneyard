﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SqlDatabaseActivitiesConsole
{
	partial class Workflow1
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
      this.CanModifyActivities = true;
      this.LookupComments = new SqlDatabaseActivities.SqlScalarQueryActivity();
      this.SqlConnection = new SqlDatabaseActivities.SqlConnectionActivity();
      // 
      // LookupComments
      // 
      this.LookupComments.Name = "LookupComments";
      this.LookupComments.Parameters = null;
      this.LookupComments.Query = "SELECT Comments FROM UserProfiles WHERE Email = @email";
      this.LookupComments.Result = null;
      this.LookupComments.Invoking += new System.EventHandler(this.LookupComments_Invoking);
      this.LookupComments.Invoked += new System.EventHandler(this.LookupComments_Invoked);
      // 
      // SqlConnection
      // 
      this.SqlConnection.Activities.Add(this.LookupComments);
      this.SqlConnection.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Labs\\Files\\Litware.mdf;Integrated Se" +
          "curity=True;Connect Timeout=30;User Instance=True";
      this.SqlConnection.Name = "SqlConnection";
      // 
      // Workflow1
      // 
      this.Activities.Add(this.SqlConnection);
      this.Name = "Workflow1";
      this.CanModifyActivities = false;

		}

		#endregion

        private SqlDatabaseActivities.SqlConnectionActivity SqlConnection;
        private SqlDatabaseActivities.SqlScalarQueryActivity LookupComments;






  }
}
