﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel;
using System.Workflow.Activities;

namespace SqlDatabaseActivities
{
	public class SqlConnectionActivityValidator : CompositeActivityValidator
  {
    public override ValidationErrorCollection Validate(ValidationManager manager, object obj)
    {
      SqlConnectionActivity activity = obj as SqlConnectionActivity;

      // build the errors collection using the base validation method
      ValidationErrorCollection errors = base.Validate(manager, obj);

      // only perform validation if in design or runtime mode
      if (activity.Parent != null)
      {
        // validate that a connection string was defined
        if (string.IsNullOrEmpty(activity.ConnectionString))
          errors.Add(ValidationError.GetNotSetValidationError("ConnectionString"));

        // validate the activity has has no child IEventActivity activities
        if (HasChildIEventActivity(activity))
          errors.Add(new ValidationError(
              "SqlConnectionActivities cannot contain IEventActivity activities. ",
              100, false));
      }

      // return the errors
      return errors;
    }

    private bool HasChildIEventActivity(CompositeActivity activity)
    {
      // loop through each child activity that is enabled
      foreach (Activity childActivity in activity.EnabledActivities)
      {
        // if the child activity is an IEventActivity, log an error
        if (childActivity is IEventActivity)
          return true;

        // if the child activity is a composite activity, check its children
        CompositeActivity compositeActivity = childActivity as CompositeActivity;
        if (compositeActivity != null)
          if (HasChildIEventActivity(compositeActivity))
            return true;
      }

      // no child activities are IEventActivity
      return false;


    }



	}
}
