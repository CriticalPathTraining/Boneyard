﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel;

namespace SqlDatabaseActivities
{
	public class SqlScalarQueryActivityDesigner : ActivityDesigner
	{
    public override bool CanBeParentedTo(CompositeActivityDesigner parentActivityDesigner)
    {
      // if the parent activity is a SqlConnectionActivity
      if (parentActivityDesigner.Activity is SqlConnectionActivity)
        return true;

      // if not, check if a parent is a SqlConnectionActivity
      return HasSqlConnectionParent(parentActivityDesigner.Activity);
    }
    
    private bool HasSqlConnectionParent(Activity current)
    {
      while (current.Parent != null)
      {
        if (current.Parent is SqlConnectionActivity)
          return true;
        current = current.Parent;
      }
      return false;
    }

	}
}
