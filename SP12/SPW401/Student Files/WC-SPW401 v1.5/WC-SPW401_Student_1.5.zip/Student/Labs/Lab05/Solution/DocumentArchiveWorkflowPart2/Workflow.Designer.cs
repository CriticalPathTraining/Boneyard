﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace DocumentArchiveWorkflowPart2
{
    partial class Workflow
    {
        #region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference2 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference3 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
          this.CompleteApprovalTask = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
          this.MoveOnApprovalTaskRejected = new System.Workflow.Activities.SetStateActivity();
          this.LogApprovalTaskRejected = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.MoveOnApprovalTaskApproved = new System.Workflow.Activities.SetStateActivity();
          this.LocApprovalTaskApproved = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.ApprovaltaskIncomplete = new System.Workflow.Activities.IfElseBranchActivity();
          this.ApprovalTaskComplete = new System.Workflow.Activities.IfElseBranchActivity();
          this.ApprovalTaskInProgress = new System.Workflow.Activities.IfElseBranchActivity();
          this.ApprovalTaskRejected = new System.Workflow.Activities.IfElseBranchActivity();
          this.ApprovalTaskApproved = new System.Workflow.Activities.IfElseBranchActivity();
          this.CheckApprovaltaskFinalaction = new System.Workflow.Activities.IfElseActivity();
          this.CheckApprovaltaskResult = new System.Workflow.Activities.IfElseActivity();
          this.OnApprovalTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
          this.CreateApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
          this.MoveToWaitingForApproval = new System.Workflow.Activities.SetStateActivity();
          this.LogWorkflowStarted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.onWorkflowActivated1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
          this.WaitingForApprovalFinal = new System.Workflow.Activities.StateFinalizationActivity();
          this.WaitingForApprovalTaskChanged = new System.Workflow.Activities.EventDrivenActivity();
          this.WaitingForApprovalInit = new System.Workflow.Activities.StateInitializationActivity();
          this.WorkflowActivatedActivity = new System.Workflow.Activities.EventDrivenActivity();
          this.WaitingForApproval = new System.Workflow.Activities.StateActivity();
          this.Completed = new System.Workflow.Activities.StateActivity();
          this.Initial = new System.Workflow.Activities.StateActivity();
          // 
          // CompleteApprovalTask
          // 
          correlationtoken1.Name = "ApprovalToken";
          correlationtoken1.OwnerActivityName = "WaitingForApproval";
          this.CompleteApprovalTask.CorrelationToken = correlationtoken1;
          this.CompleteApprovalTask.Name = "CompleteApprovalTask";
          activitybind1.Name = "Workflow";
          activitybind1.Path = "ApprovalTaskId";
          this.CompleteApprovalTask.TaskOutcome = null;
          this.CompleteApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
          // 
          // MoveOnApprovalTaskRejected
          // 
          this.MoveOnApprovalTaskRejected.Name = "MoveOnApprovalTaskRejected";
          this.MoveOnApprovalTaskRejected.TargetStateName = "Completed";
          // 
          // LogApprovalTaskRejected
          // 
          this.LogApprovalTaskRejected.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.LogApprovalTaskRejected.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.LogApprovalTaskRejected.HistoryDescription = "Approval task rejected.";
          this.LogApprovalTaskRejected.HistoryOutcome = "";
          this.LogApprovalTaskRejected.Name = "LogApprovalTaskRejected";
          this.LogApprovalTaskRejected.OtherData = "";
          this.LogApprovalTaskRejected.UserId = -1;
          // 
          // MoveOnApprovalTaskApproved
          // 
          this.MoveOnApprovalTaskApproved.Name = "MoveOnApprovalTaskApproved";
          this.MoveOnApprovalTaskApproved.TargetStateName = "Completed";
          // 
          // LocApprovalTaskApproved
          // 
          this.LocApprovalTaskApproved.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.LocApprovalTaskApproved.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.LocApprovalTaskApproved.HistoryDescription = "Approval task approved.";
          this.LocApprovalTaskApproved.HistoryOutcome = "";
          this.LocApprovalTaskApproved.Name = "LocApprovalTaskApproved";
          this.LocApprovalTaskApproved.OtherData = "";
          this.LocApprovalTaskApproved.UserId = -1;
          // 
          // ApprovaltaskIncomplete
          // 
          this.ApprovaltaskIncomplete.Name = "ApprovaltaskIncomplete";
          // 
          // ApprovalTaskComplete
          // 
          this.ApprovalTaskComplete.Activities.Add(this.CompleteApprovalTask);
          ruleconditionreference1.ConditionName = "IsApprovalTaskComplete";
          this.ApprovalTaskComplete.Condition = ruleconditionreference1;
          this.ApprovalTaskComplete.Name = "ApprovalTaskComplete";
          // 
          // ApprovalTaskInProgress
          // 
          this.ApprovalTaskInProgress.Name = "ApprovalTaskInProgress";
          // 
          // ApprovalTaskRejected
          // 
          this.ApprovalTaskRejected.Activities.Add(this.LogApprovalTaskRejected);
          this.ApprovalTaskRejected.Activities.Add(this.MoveOnApprovalTaskRejected);
          ruleconditionreference2.ConditionName = "IsApprovalTaskRejected";
          this.ApprovalTaskRejected.Condition = ruleconditionreference2;
          this.ApprovalTaskRejected.Name = "ApprovalTaskRejected";
          // 
          // ApprovalTaskApproved
          // 
          this.ApprovalTaskApproved.Activities.Add(this.LocApprovalTaskApproved);
          this.ApprovalTaskApproved.Activities.Add(this.MoveOnApprovalTaskApproved);
          ruleconditionreference3.ConditionName = "IsApprovalTaskApproved";
          this.ApprovalTaskApproved.Condition = ruleconditionreference3;
          this.ApprovalTaskApproved.Name = "ApprovalTaskApproved";
          // 
          // CheckApprovaltaskFinalaction
          // 
          this.CheckApprovaltaskFinalaction.Activities.Add(this.ApprovalTaskComplete);
          this.CheckApprovaltaskFinalaction.Activities.Add(this.ApprovaltaskIncomplete);
          this.CheckApprovaltaskFinalaction.Name = "CheckApprovaltaskFinalaction";
          // 
          // CheckApprovaltaskResult
          // 
          this.CheckApprovaltaskResult.Activities.Add(this.ApprovalTaskApproved);
          this.CheckApprovaltaskResult.Activities.Add(this.ApprovalTaskRejected);
          this.CheckApprovaltaskResult.Activities.Add(this.ApprovalTaskInProgress);
          this.CheckApprovaltaskResult.Name = "CheckApprovaltaskResult";
          // 
          // OnApprovalTaskChanged
          // 
          this.OnApprovalTaskChanged.AfterProperties = null;
          this.OnApprovalTaskChanged.BeforeProperties = null;
          this.OnApprovalTaskChanged.CorrelationToken = correlationtoken1;
          this.OnApprovalTaskChanged.Executor = null;
          this.OnApprovalTaskChanged.Name = "OnApprovalTaskChanged";
          activitybind2.Name = "Workflow";
          activitybind2.Path = "ApprovalTaskId";
          this.OnApprovalTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnApprovalTaskChanged_Invoked);
          this.OnApprovalTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
          // 
          // CreateApprovalTask
          // 
          this.CreateApprovalTask.CorrelationToken = correlationtoken1;
          this.CreateApprovalTask.ListItemId = -1;
          this.CreateApprovalTask.Name = "CreateApprovalTask";
          this.CreateApprovalTask.SpecialPermissions = null;
          activitybind3.Name = "Workflow";
          activitybind3.Path = "ApprovalTaskId";
          this.CreateApprovalTask.TaskProperties = null;
          this.CreateApprovalTask.MethodInvoking += new System.EventHandler(this.CreateApprovalTask_Invoking);
          this.CreateApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
          // 
          // MoveToWaitingForApproval
          // 
          this.MoveToWaitingForApproval.Name = "MoveToWaitingForApproval";
          this.MoveToWaitingForApproval.TargetStateName = "WaitingForApproval";
          // 
          // LogWorkflowStarted
          // 
          this.LogWorkflowStarted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.LogWorkflowStarted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.LogWorkflowStarted.HistoryDescription = "Workflow was started";
          activitybind4.Name = "Workflow";
          activitybind4.Path = "WorkflowProperties.Item.DisplayName";
          this.LogWorkflowStarted.Name = "LogWorkflowStarted";
          this.LogWorkflowStarted.OtherData = "";
          this.LogWorkflowStarted.UserId = -1;
          this.LogWorkflowStarted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
          // 
          // onWorkflowActivated1
          // 
          correlationtoken2.Name = "WorkflowToken";
          correlationtoken2.OwnerActivityName = "Workflow";
          this.onWorkflowActivated1.CorrelationToken = correlationtoken2;
          this.onWorkflowActivated1.EventName = "OnWorkflowActivated";
          this.onWorkflowActivated1.Name = "onWorkflowActivated1";
          activitybind5.Name = "Workflow";
          activitybind5.Path = "WorkflowProperties";
          this.onWorkflowActivated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
          // 
          // WaitingForApprovalFinal
          // 
          this.WaitingForApprovalFinal.Activities.Add(this.CheckApprovaltaskFinalaction);
          this.WaitingForApprovalFinal.Name = "WaitingForApprovalFinal";
          // 
          // WaitingForApprovalTaskChanged
          // 
          this.WaitingForApprovalTaskChanged.Activities.Add(this.OnApprovalTaskChanged);
          this.WaitingForApprovalTaskChanged.Activities.Add(this.CheckApprovaltaskResult);
          this.WaitingForApprovalTaskChanged.Name = "WaitingForApprovalTaskChanged";
          // 
          // WaitingForApprovalInit
          // 
          this.WaitingForApprovalInit.Activities.Add(this.CreateApprovalTask);
          this.WaitingForApprovalInit.Name = "WaitingForApprovalInit";
          // 
          // WorkflowActivatedActivity
          // 
          this.WorkflowActivatedActivity.Activities.Add(this.onWorkflowActivated1);
          this.WorkflowActivatedActivity.Activities.Add(this.LogWorkflowStarted);
          this.WorkflowActivatedActivity.Activities.Add(this.MoveToWaitingForApproval);
          this.WorkflowActivatedActivity.Name = "WorkflowActivatedActivity";
          // 
          // WaitingForApproval
          // 
          this.WaitingForApproval.Activities.Add(this.WaitingForApprovalInit);
          this.WaitingForApproval.Activities.Add(this.WaitingForApprovalTaskChanged);
          this.WaitingForApproval.Activities.Add(this.WaitingForApprovalFinal);
          this.WaitingForApproval.Name = "WaitingForApproval";
          // 
          // Completed
          // 
          this.Completed.Name = "Completed";
          // 
          // Initial
          // 
          this.Initial.Activities.Add(this.WorkflowActivatedActivity);
          this.Initial.Name = "Initial";
          // 
          // Workflow
          // 
          this.Activities.Add(this.Initial);
          this.Activities.Add(this.Completed);
          this.Activities.Add(this.WaitingForApproval);
          this.CompletedStateName = "Completed";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "Initial";
          this.Name = "Workflow";
          this.CanModifyActivities = false;

        }

        #endregion

        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated OnWorkflowActivated;
        private StateActivity Completed;
        private EventDrivenActivity WorkflowActivatedActivity;
        private SetStateActivity MoveToWaitingForApproval;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogWorkflowStarted;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated1;
        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateApprovalTask;
        private StateInitializationActivity WaitingForApprovalInit;
        private StateActivity WaitingForApproval;
        private EventDrivenActivity WaitingForApprovalTaskChanged;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged OnApprovalTaskChanged;
        private IfElseBranchActivity ApprovalTaskInProgress;
        private IfElseBranchActivity ApprovalTaskApproved;
        private IfElseActivity CheckApprovaltaskResult;
        private SetStateActivity MoveOnApprovalTaskApproved;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LocApprovalTaskApproved;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteApprovalTask;
        private IfElseBranchActivity ApprovaltaskIncomplete;
        private IfElseBranchActivity ApprovalTaskComplete;
        private IfElseActivity CheckApprovaltaskFinalaction;
        private StateFinalizationActivity WaitingForApprovalFinal;
        private IfElseBranchActivity ApprovalTaskRejected;
        private SetStateActivity MoveOnApprovalTaskRejected;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogApprovalTaskRejected;
        private StateActivity Initial;















    }
}
