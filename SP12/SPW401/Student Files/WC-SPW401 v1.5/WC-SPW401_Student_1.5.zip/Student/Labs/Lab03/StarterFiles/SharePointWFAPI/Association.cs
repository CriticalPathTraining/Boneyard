﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using System.Collections;

namespace SharePointWFAPI
{
    public partial class Association : UserControl
    {
        #region Initialization Methods
        /// <summary>
        /// Initializes the UI by calling InitializeComponent
        /// </summary>
        public Association()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Initializes the UI based on the provided SPWeb object
        /// </summary>
        /// <param name="web"></param>
        public void Initialize(SPWeb web)
        {
        }
        #endregion

        #region UI Event Handlers
        /// <summary>
        /// Handle the event caused by selection of a new list.  
        /// Update the list of workflow associations and add a New Item... list option.
        /// </summary>
        private void SelectedListChanged(object sender, EventArgs e)
        {
            SPList list = lstWebLists.SelectedItem as SPList;
            PopulateComboBox(list.WorkflowAssociations, lstAssociations);
            lstAssociations.Items.Add("New Item...");

            if (lstAssociations.Items.Count == 1)
                grpAssociation.Enabled = false;
        }

        /// <summary>
        /// Handle the event caused by selection of a different workflow association.  
        /// Checks if a new association is being added and updates the UI appropriately.
        /// </summary>
        private void SelectedAssociationChanged(object sender, EventArgs e)
        {
            SPWorkflowAssociation association = lstAssociations.SelectedItem as SPWorkflowAssociation;

            m_current = lstAssociations.SelectedItem as SPWorkflowAssociation;
            if (m_current != null)
                DisplayAssociation(m_current);
            else
                DisplayNewAssociation();
        }

        /// <summary>
        /// When the update button is clicked either create or update a
        /// workflow association.  Once the update is complete, refresh the 
        /// UI by selecting the new workflow association.
        /// </summary>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // either create or update the workflow
            if (m_current == null)
                m_current = CreateWorkflowAssociation();
            else
                UpdateWorkflowAssociation(m_current);

            // store the current association as the update will change m_current
            SPWorkflowAssociation current = m_current;
            SelectedListChanged(lstWebLists, EventArgs.Empty);
            lstAssociations.SelectedItem = current;
        }

        /// <summary>
        /// When the delete button is clicked, delete the current associatoin 
        /// and update the UI by simulating the selection of a list.
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (m_current != null)
            {
                DeleteWorkflowAssociation(m_current);
                SelectedListChanged(lstWebLists, EventArgs.Empty);
            }
        }
        #endregion

        #region SharePoint API Access Methods
        /// <summary>
        /// Displays the details of an existing SPWorkflowAssociation in the user interface.
        /// </summary>
        private void DisplayAssociation(SPWorkflowAssociation association)
        {
        }

        /// <summary>
        /// Displays the details of an new SPWorkflowAssociation in the user interface.
        /// </summary>
        private void DisplayNewAssociation()
        {
        }

        /// <summary>
        /// Creates or finds the task and history lists.  Once those are found
        /// a new WorkflowAssociation is created and added to the list.
        /// </summary>
        private SPWorkflowAssociation CreateWorkflowAssociation()
        {
          return null;
        }

        /// <summary>
        /// Creates or finds the task and history lists.  Once those are found
        /// a new WorkflowAssociation is updated.
        /// </summary>
        private void UpdateWorkflowAssociation(SPWorkflowAssociation association)
        {
        }

        /// <summary>
        /// Removes the workflow association from the list.
        /// </summary>
        private void DeleteWorkflowAssociation(SPWorkflowAssociation association)
        {
        }

        /// <summary>
        /// Creates a tasks or history list using the name and type provided.
        /// </summary>
        private SPList CreateList(string name, SPListTemplateType type)
        {
            // create the list
            Guid listId = m_web.Lists.Add(name, string.Empty, type);

            // commit the changes
            m_web.Update();

            return m_web.Lists[listId];
        }
        #endregion

        #region Private UI Helper Methods
        /// <summary>
        /// Populates a combo box using a data source.  Selects the first item if one is available.
        /// </summary>
        private void PopulateComboBox(IEnumerable dataSource, ComboBox control)
        {
            control.Items.Clear();
            if (dataSource != null)
                foreach (object item in dataSource)
                    control.Items.Add(item);
            if (control.Items.Count != 0)
                control.SelectedIndex = 0;
        }

        /// <summary>
        /// Populates a combo box using a filtered data source.  
        /// A query is done on the typed data source using the provided predicate function.
        /// Selects the first item if one is available.
        /// </summary>
        private void PopulateComboBox<T>(IEnumerable<T> dataSource, ComboBox control, Func<T, bool> predicate)
        {
            control.Items.Clear();
            if (dataSource != null)
                foreach (T item in dataSource.Where(predicate))
                    control.Items.Add(item);
            if (control.Items.Count != 0)
                control.SelectedIndex = 0;
        }
        #endregion
    }
}
