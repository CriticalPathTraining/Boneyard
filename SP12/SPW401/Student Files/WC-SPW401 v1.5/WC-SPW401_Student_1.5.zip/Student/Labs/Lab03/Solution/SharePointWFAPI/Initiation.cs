﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using System.Collections;
using Microsoft.SharePoint.Workflow;
using System.Globalization;

namespace SharePointWFAPI
{
  public partial class Initiation : UserControl
  {
    private SPWeb m_web;

    #region Initialization Methods
    /// <summary>
    /// Initializes the UI by calling InitializeComponent
    /// </summary>
    public Initiation()
    {
      InitializeComponent();
    }

    /// <summary>
    /// Initializes the UI based on the provided SPWeb object
    /// </summary>
    /// <param name="web"></param>
    public void Initialize(SPWeb web)
    {
      m_web = web;

      PopulateComboBox(m_web.Lists, lstWebLists);
    }
    #endregion

    #region UI Event Handlers
    /// <summary>
    /// Handle the event caused by selection of a new list.  
    /// Populate the combo box based on the selected list's list items and workflow associations.
    /// </summary>
    private void SelectedListChanged(object sender, EventArgs e)
    {
      PopulateListDetails(lstWebLists.SelectedItem as SPList);

      if ((lstListItems.Items.Count == 0) || (lstAssociations.Items.Count == 0))
        grpAssociation.Enabled = false;
    }

    /// <summary>
    /// Handle the event caused by selection of a new list item.  If a list item 
    /// and association are selected, check if there are already any running 
    /// instances of the workflow and disable the UI if any exist.
    /// </summary>
    private void SelectedListItemChanged(object sender, EventArgs e)
    {
      SPListItem listItem = lstListItems.SelectedItem as SPListItem;
      SPWorkflowAssociation association = lstAssociations.SelectedItem as SPWorkflowAssociation;

      grpAssociation.Enabled = false;
      if ((listItem != null) && (association != null))
        if (!ContainsRunningWorkflow(listItem, association))
          grpAssociation.Enabled = true;
    }

    /// <summary>
    /// Handle the button click by starting the new workflow.
    /// </summary>
    private void btnStart_Click(object sender, EventArgs e)
    {
      // start the workflow instance
      StartWorkflow();

      // update the UI
      SelectedListChanged(lstWebLists, EventArgs.Empty);
    }
    #endregion

    #region SharePoint API Access Methods
    /// <summary>
    /// Populates the combo boxes using the Items and WorkflowAssociations
    /// collections of the currently selected lists.
    /// </summary>
    public void PopulateListDetails(SPList list)
    {
      // populate the combo box containing the list items
      // and workflow associations for the list
      PopulateComboBox(list.Items, lstListItems);
      PopulateComboBox(list.WorkflowAssociations, lstAssociations);
    }

    /// <summary>
    /// Uses the provided list item and workflow association to determine if an instance
    /// of the workflow is already running on the list item.
    /// </summary>
    public bool ContainsRunningWorkflow(SPListItem listItem, SPWorkflowAssociation association)
    {
      IEnumerable<SPWorkflow> workflows = listItem.Workflows.Cast<SPWorkflow>();

      // find the first item in the list that matches the condition
      // FirstOrDefault returns null if no item is found
      SPWorkflow workflow = workflows.FirstOrDefault(
          n => n.AssociationId == association.Id &&
          n.InternalState == SPWorkflowState.Running);

      // return true if a workflow was found
      return (workflow != null);
    }

    /// <summary>
    /// Start a workflow using the API.  Since this application isn't a sharepoint site, so 
    /// the starting of the workflow will initially fail.  SharePoint will automatically retry
    /// so just wait for the workflow's status to change from Starting to In Progress.  It could
    /// take up to 5 minutes.
    /// </summary>
    public void StartWorkflow()
    {
      SPListItem listItem = lstListItems.SelectedItem as SPListItem;
      SPWorkflowAssociation association =
          lstAssociations.SelectedItem as SPWorkflowAssociation;

      // start the workflow
      m_web.Site.WorkflowManager.StartWorkflow(
          listItem, association, txtInitiationData.Text, true);

      // update the UI to indicate the workflow has started
      MessageBox.Show(this, "Workflow started");
      txtInitiationData.Text = string.Empty;
    }
    #endregion

    #region Private UI Helper Methods
    /// <summary>
    /// Populates a combo box using a data source.  Selects the first item if one is available.
    /// </summary>
    private void PopulateComboBox(IEnumerable dataSource, ComboBox control)
    {
      control.Items.Clear();
      if (dataSource != null)
        foreach (object item in dataSource)
          control.Items.Add(item);
      if (control.Items.Count != 0)
        control.SelectedIndex = 0;
    }
    #endregion
  }
}
