﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;

namespace SharePointWFAPI
{
  public partial class MainForm : Form
  {
    private SPSite m_site;
    private SPWeb m_web;

    public MainForm()
    {
      InitializeComponent();
    }

    private void MainForm_Load(object sender, EventArgs e)
    {
      m_site = new SPSite("http://litwareinc.com/sites/Demo");
      m_web = m_site.RootWeb;

      ctlAssociation.Initialize(m_web);
      ctlInitiation.Initialize(m_web);
      ctlWorkflow.Initialize(m_web);
    }

    private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
    {
      m_web.Dispose();
      m_site.Dispose();
    }
  }
}
