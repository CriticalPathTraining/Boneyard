﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using System.Collections;

namespace SharePointWFAPI
{
  public partial class Workflow : UserControl
  {
    private SPWeb m_web;

    #region Initialization Methods
    /// <summary>
    /// Initializes the UI by calling InitializeComponent
    /// </summary>
    public Workflow()
    {
      InitializeComponent();
    }

    /// <summary>
    /// Initializes the UI based on the provided SPWeb object
    /// </summary>
    /// <param name="web"></param>
    public void Initialize(SPWeb web)
    {
      m_web = web;

      PopulateComboBox(m_web.Lists, lstWebLists);
    }
    #endregion

    #region UI Event Handlers
    /// <summary>
    /// Handle the event caused by selection of a new list.  
    /// Populate the combo box based on the selected list's list items and workflow associations.
    /// </summary>
    private void SelectedListChanged(object sender, EventArgs e)
    {
      SPList list = lstWebLists.SelectedItem as SPList;
      PopulateListItems(list);
    }

    /// <summary>
    /// Handles the event caused by selection of a new list item.  Populates the
    /// list of workflows based on the selected list item.
    /// </summary>
    private void SelectedListItemChanged(object sender, EventArgs e)
    {
      SPListItem listItem = lstListItems.SelectedItem as SPListItem;
      PopulateWorkflows(listItem);
    }

    /// <summary>
    /// Handles the event caused by selection of a new workflow.  Populates the
    /// UI based on the selected workflow.
    /// </summary>
    private void SelectedWorkflowChanged(object sender, EventArgs e)
    {
      SPWorkflow workflow = lstAssociations.SelectedItem as SPWorkflow;
      DisplayWorkflow(workflow);
    }

    /// <summary>
    /// Handles the link click event of the association data link bydisplaying 
    /// the association data in a message box.
    /// </summary>
    private void listAssociationData_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
      SPWorkflow workflow = lstAssociations.SelectedItem as SPWorkflow;
      MessageBox.Show(this, LookupAssociationData(workflow));
    }

    /// <summary>
    /// Allows the display value in the list box to be set manually instead of the
    /// automatic calling of the object's ToString method.
    /// </summary>
    private void lstAssociations_Format(object sender, ListControlConvertEventArgs e)
    {
      e.Value = (e.ListItem as SPWorkflow).ParentAssociation.Name;
    }

    /// <summary>
    /// Allows the display value in the list box to be set manually instead of the
    /// automatic calling of the object's ToString method.
    /// </summary>
    private void lstModifications_Format(object sender, ListControlConvertEventArgs e)
    {
      SPWorkflow workflow = lstAssociations.SelectedItem as SPWorkflow;
      SPWorkflowModification modification = e.ListItem as SPWorkflowModification;

      e.Value = LookupModificationName(workflow, modification);
    }

    /// <summary>
    /// Handles the double click event by displaying the modification's context data
    /// in a message box.
    /// </summary>
    private void lstModifications_MouseDoubleClick(object sender, MouseEventArgs e)
    {
      SPWorkflowModification modification = lstModifications.SelectedItem as SPWorkflowModification;
      MessageBox.Show(this, LookupModificationContextData(modification));
    }
    #endregion

    #region SharePoint API Access Methods
    /// <summary>
    /// Populates the combo box containing the list items for the
    /// currently selected list.
    /// </summary>
    public void PopulateListItems(SPList list)
    {
      PopulateComboBox(list.Items, lstListItems);
    }

    /// <summary>
    /// Populates the combo box containing the workflows for the
    /// currently selected list item.
    /// </summary>
    public void PopulateWorkflows(SPListItem listItem)
    {
      PopulateComboBox(listItem.Workflows, lstAssociations);
    }

    /// <summary>
    /// Populates the UI that displays the details of the currently
    /// selected workflow.
    /// </summary>
    public void DisplayWorkflow(SPWorkflow workflow)
    {
      // setup the workflow state UI
      txtInitiator.Text = workflow.AuthorUser.Name;
      txtStarted.Text = workflow.Created.ToString();
      txtWorkflowState.Text = workflow.InternalState.ToString();

      // populate the list of modifications
      PopulateListBox(workflow.Modifications, lstModifications);

      // populate the list of tasks
      SPWorkflowTaskCollection tasks =
          m_web.Site.WorkflowManager.GetItemTasks(
              workflow.ParentItem, workflow.TaskFilter);
      PopulateListBox(tasks, lstTasks);

    }

    /// <summary>
    /// Uses the workflow and modification objects to lookup
    /// the name using the workflow template's metadata collection.
    /// </summary>
    public string LookupModificationName(SPWorkflow workflow, SPWorkflowModification modification)
    {
      string metadataName = string.Format("Modification_{0}_Name", modification.Id);
      return workflow.ParentAssociation.BaseTemplate[metadataName] as string;
    }

    /// <summary>
    /// Uses the modification object to return the modification's context data.
    /// </summary>
    public string LookupModificationContextData(SPWorkflowModification modification)
    {
      return modification.ContextData;
    }

    /// <summary>
    /// Uses the workflow to lookup the association data stored in the workflow association.
    /// </summary>
    public string LookupAssociationData(SPWorkflow workflow)
    {
      return workflow.ParentAssociation.AssociationData;
    }
    #endregion

    #region Private UI Helper Methods
    /// <summary>
    /// Populates a combo box using a data source.  Selects the first item if one is available.
    /// </summary>
    private void PopulateComboBox(IEnumerable dataSource, ComboBox control)
    {
      control.Items.Clear();
      if (dataSource != null)
        foreach (object item in dataSource)
          control.Items.Add(item);
      if (control.Items.Count != 0)
        control.SelectedIndex = 0;
    }

    /// <summary>
    /// Populates a list box using a data source.  Selects the first item if one is available.
    /// </summary>
    private void PopulateListBox(IEnumerable dataSource, ListBox control)
    {
      control.Items.Clear();
      if (dataSource != null)
        foreach (object item in dataSource)
          control.Items.Add(item);
      if (control.Items.Count != 0)
        control.SelectedIndex = 0;
    }

    #endregion
  }
}
