﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace DocumentArchiveWorkflowPart1
{
    partial class Workflow
    {
        #region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
          this.MoveToCompletedState = new System.Workflow.Activities.SetStateActivity();
          this.LogWorkflowStarted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.OnWorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
          this.WorkflowActivatedActivity = new System.Workflow.Activities.EventDrivenActivity();
          this.WorkflowCompletedState = new System.Workflow.Activities.StateActivity();
          this.WorkflowInitialState = new System.Workflow.Activities.StateActivity();
          // 
          // MoveToCompletedState
          // 
          this.MoveToCompletedState.Name = "MoveToCompletedState";
          this.MoveToCompletedState.TargetStateName = "WorkflowCompletedState";
          // 
          // LogWorkflowStarted
          // 
          this.LogWorkflowStarted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.LogWorkflowStarted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.LogWorkflowStarted.HistoryDescription = "Workflow has started.";
          activitybind1.Name = "Workflow";
          activitybind1.Path = "WorkflowProperties.Item.DisplayName";
          this.LogWorkflowStarted.Name = "LogWorkflowStarted";
          this.LogWorkflowStarted.OtherData = "";
          this.LogWorkflowStarted.UserId = -1;
          this.LogWorkflowStarted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
          // 
          // OnWorkflowActivated
          // 
          correlationtoken1.Name = "WorkflowToken";
          correlationtoken1.OwnerActivityName = "Workflow";
          this.OnWorkflowActivated.CorrelationToken = correlationtoken1;
          this.OnWorkflowActivated.EventName = "OnWorkflowActivated";
          this.OnWorkflowActivated.Name = "OnWorkflowActivated";
          activitybind2.Name = "Workflow";
          activitybind2.Path = "WorkflowProperties";
          this.OnWorkflowActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
          // 
          // WorkflowActivatedActivity
          // 
          this.WorkflowActivatedActivity.Activities.Add(this.OnWorkflowActivated);
          this.WorkflowActivatedActivity.Activities.Add(this.LogWorkflowStarted);
          this.WorkflowActivatedActivity.Activities.Add(this.MoveToCompletedState);
          this.WorkflowActivatedActivity.Name = "WorkflowActivatedActivity";
          // 
          // WorkflowCompletedState
          // 
          this.WorkflowCompletedState.Name = "WorkflowCompletedState";
          // 
          // WorkflowInitialState
          // 
          this.WorkflowInitialState.Activities.Add(this.WorkflowActivatedActivity);
          this.WorkflowInitialState.Name = "WorkflowInitialState";
          // 
          // Workflow
          // 
          this.Activities.Add(this.WorkflowInitialState);
          this.Activities.Add(this.WorkflowCompletedState);
          this.CompletedStateName = "WorkflowCompletedState";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "WorkflowInitialState";
          this.Name = "Workflow";
          this.CanModifyActivities = false;

        }

        #endregion

        private StateActivity WorkflowCompletedState;
        private SetStateActivity MoveToCompletedState;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogWorkflowStarted;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated OnWorkflowActivated;
        private EventDrivenActivity WorkflowActivatedActivity;
        private StateActivity WorkflowInitialState;




    }
}
