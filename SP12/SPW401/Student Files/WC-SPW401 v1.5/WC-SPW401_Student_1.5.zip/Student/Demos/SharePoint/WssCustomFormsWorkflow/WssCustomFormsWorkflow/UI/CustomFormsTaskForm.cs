﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Collections;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Utilities;

namespace WssCustomFormsWorkflow.UI
{
  public class CustomFormsTaskForm : LayoutsPageBase
  {
    private SPWorkflow _workflow;
    private SPList _taskList;
    private SPListItem _taskItem;
    private SPWorkflowTask _task;
    private SPList _list;

    protected Label lblCustomData;
    protected TextBox txtComments;

    protected string TaskItemName
    {
      get { return _taskItem.DisplayName; }
    }

    /// <summary>
    /// Read the parameters from the request and the UI.  Load the task's extended
    /// properties and load the form.
    /// </summary>
    protected override void OnLoad(EventArgs e)
    {
      _taskList = Web.Lists[new Guid(Request.Params["List"])];
      _taskItem = _taskList.GetItemById(int.Parse(Request.Params["ID"]));
      _workflow = new SPWorkflow(Web, new Guid(_taskItem["WorkflowInstanceID"] as string));
      _task = _workflow.Tasks[0];
      _list = Web.Lists[_workflow.ListId];

      if (!IsPostBack)
      {
        Hashtable extendedProperties = SPWorkflowTask.GetExtendedPropertiesAsHashtable(_taskItem);
        lblCustomData.Text = extendedProperties["CustomData"] as string;
      }

      base.OnLoad(e);
    }

    /// <summary>
    /// Set the task's properties and update the task.  Afterward redirect to the list's default view.
    /// </summary>
    protected void Approve_Click(object sender, EventArgs e)
    {
      // build properties to send to workflow
      Hashtable data = new Hashtable();
      data.Add("Result", "Approved");
      data.Add("Comments", txtComments.Text);

      // update the task and redirect to list's default view
      SPWorkflowTask.AlterTask(_taskItem, data, true);
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }

    /// <summary>
    /// Set the task's properties and update the task.  Afterward redirect to the list's default view.
    /// </summary>
    protected void Reject_Click(object sender, EventArgs e)
    {
      Hashtable data = new Hashtable();
      data.Add("Result", "Rejected");
      data.Add("Comments", txtComments.Text);
      SPWorkflowTask.AlterTask(_taskItem, data, true);
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }

    /// <summary>
    /// Redirect to the list's default view.
    /// </summary>
    protected void Cancel_Click(object sender, EventArgs e)
    {
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }
  }
}
