﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

using Microsoft.SharePoint.WorkflowActions;
using Microsoft.SharePoint.Workflow;

namespace WssCustomFormsWorkflow
{
  public sealed partial class Workflow : StateMachineWorkflowActivity
  {
    public Workflow()
    {
      InitializeComponent();
    }

    public Guid TaskId { get; set; }
    public string TaskResult { get; set; }
    public string TaskComments { get; set; }
    public string CustomData { get; set; }

    private void onWorkflowActivated_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPActivationEventArgs args = e as SPActivationEventArgs;

      InitiationData instData = InitiationData.Deserialize(args.properties.InitiationData);
      this.CustomData = instData.CustomData;
    }

    #region Task Methods
    /// <summary>
    /// Defines the properties of the task to create.
    /// </summary>
    private void CreateSimpleTask_Invoking(object sender, EventArgs e)
    {
      this.TaskId = Guid.NewGuid();

      CreateTask activity = sender as CreateTask;
      activity.TaskProperties = new SPWorkflowTaskProperties();
      activity.TaskProperties.AssignedTo = "Administrator";
      activity.TaskProperties.Title = "Simple Task";
      activity.TaskProperties.Description = "Complete this simple task.";
      activity.TaskProperties.ExtendedProperties.Add("CustomData", this.CustomData);
    }

    /// <summary>
    /// When the task changes, check the result and comments.
    /// </summary>
    private void TaskChanged_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPTaskServiceEventArgs args = e as SPTaskServiceEventArgs;

      // access a named extended property
      this.TaskResult = args.afterProperties.ExtendedProperties["Result"] as string;

      // access a list item field by id
      Guid commentsId = new Guid("{52578FC3-1F01-4f4d-B016-94CCBCF428CF}");
      this.TaskComments = args.afterProperties.ExtendedProperties[commentsId] as string;      
    }
    #endregion    

    #region Workflow Modification Methods
    /// <summary>
    /// Populates the ModificationData object to be associated with the workflow modification.
    /// </summary>
    private void EnableModification_Invoking(object sender, EventArgs e)
    {
      ModificationData modData = new ModificationData();
      modData.CustomData = this.CustomData;

      EnableWorkflowModification enableModification = sender as EnableWorkflowModification;
      enableModification.ContextData = modData.Serialize();
    }

    /// <summary>
    /// Updates the custom data using the modification information.
    /// </summary>
    private void OnWorkflowModified_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPModificationEventArgs args = e as SPModificationEventArgs;

      ModificationData modData = WssCustomFormsWorkflow.ModificationData.Deserialize(args.data);
      this.CustomData = modData.CustomData;
    }
    #endregion
  }
}
