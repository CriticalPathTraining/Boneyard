﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.SharePoint.Workflow;

namespace CombinedProcess
{
    public sealed partial class ChildWorkflow : SequentialWorkflowActivity
    {
        public ChildWorkflow()
        {
            InitializeComponent();
        }

        private void codeActivity1_ExecuteCode(object sender, EventArgs e)
        {
            onWorkflowActivated1.WorkflowProperties.Item[SPBuiltInFieldId.TaskStatus] = "Completed";
            onWorkflowActivated1.WorkflowProperties.Item.Update();
        }

        private void createTask1_MethodInvoking(object sender, EventArgs e)
        {
            CreateTask activity = sender as CreateTask;

            activity.TaskId = Guid.NewGuid();
            activity.TaskProperties = new SPWorkflowTaskProperties();
            activity.TaskProperties.Title = "Parent Task";
            activity.TaskProperties.AssignedTo = "Administrator";

        }
    }

}
