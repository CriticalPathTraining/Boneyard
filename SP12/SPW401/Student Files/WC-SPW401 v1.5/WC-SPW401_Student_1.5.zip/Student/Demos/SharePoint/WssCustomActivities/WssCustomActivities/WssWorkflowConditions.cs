﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WorkflowActions;

namespace WssCustomActivities
{
  public class WssWorkflowConditions
  {
    /// <summary>
    /// Check if the supplied valid is even
    /// </summary>
    public static bool IsEven(WorkflowContext context, string listId, int itemId, double data)
    {
      return ((int)data % 2) == 0;
    }

    /// <summary>
    /// Check if the supplied valid is odd
    /// </summary>
    public static bool IsNotEven(WorkflowContext context, string listId, int itemId, double data)
    {
      return ((int)data % 2) != 0;
    }
  }
}
