﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.SharePoint.Workflow;

namespace CombinedProcess
{
    public sealed partial class ParentWorkflow : StateMachineWorkflowActivity
    {
        public ParentWorkflow()
        {
            InitializeComponent();
        }

        public Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties WorkflowProperties = new Microsoft.SharePoint.Workflow.SPWorkflowActivationProperties();

        private void CreateProcessingTask(object sender, EventArgs e)
        {
            CreateTask activity = sender as CreateTask;

            activity.TaskId = Guid.NewGuid();
            activity.TaskProperties = new SPWorkflowTaskProperties();
            activity.TaskProperties.Title = "Child Task";
            activity.TaskProperties.AssignedTo = "Administrator";
        }



        public static DependencyProperty NewItemIdProperty = DependencyProperty.Register("NewItemId", typeof(System.Guid), typeof(CombinedProcess.ParentWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public Guid NewItemId
        {
            get
            {
                return ((System.Guid)(base.GetValue(CombinedProcess.ParentWorkflow.NewItemIdProperty)));
            }
            set
            {
                base.SetValue(CombinedProcess.ParentWorkflow.NewItemIdProperty, value);
            }
        }

        public static DependencyProperty TargetListIdProperty = DependencyProperty.Register("TargetListId", typeof(System.Guid), typeof(CombinedProcess.ParentWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public Guid TargetListId
        {
            get
            {
                return ((System.Guid)(base.GetValue(CombinedProcess.ParentWorkflow.TargetListIdProperty)));
            }
            set
            {
                base.SetValue(CombinedProcess.ParentWorkflow.TargetListIdProperty, value);
            }
        }

        public static DependencyProperty NewItemPropertiesProperty = DependencyProperty.Register("NewItemProperties", typeof(System.Collections.Hashtable), typeof(CombinedProcess.ParentWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public Hashtable NewItemProperties
        {
            get
            {
                return ((System.Collections.Hashtable)(base.GetValue(CombinedProcess.ParentWorkflow.NewItemPropertiesProperty)));
            }
            set
            {
                base.SetValue(CombinedProcess.ParentWorkflow.NewItemPropertiesProperty, value);
            }
        }

        public static DependencyProperty ItemSenderProperty = DependencyProperty.Register("ItemSender", typeof(System.Object), typeof(CombinedProcess.ParentWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public Object ItemSender
        {
            get
            {
                return ((object)(base.GetValue(CombinedProcess.ParentWorkflow.ItemSenderProperty)));
            }
            set
            {
                base.SetValue(CombinedProcess.ParentWorkflow.ItemSenderProperty, value);
            }
        }

        public static DependencyProperty ItemEProperty = DependencyProperty.Register("ItemE", typeof(Microsoft.SharePoint.Workflow.SPListItemServiceEventArgs), typeof(CombinedProcess.ParentWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public SPListItemServiceEventArgs ItemE
        {
            get
            {
                return ((Microsoft.SharePoint.Workflow.SPListItemServiceEventArgs)(base.GetValue(CombinedProcess.ParentWorkflow.ItemEProperty)));
            }
            set
            {
                base.SetValue(CombinedProcess.ParentWorkflow.ItemEProperty, value);
            }
        }

        public static DependencyProperty OutputIdProperty = DependencyProperty.Register("OutputId", typeof(System.Int32), typeof(CombinedProcess.ParentWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public Int32 OutputId
        {
            get
            {
                return ((int)(base.GetValue(CombinedProcess.ParentWorkflow.OutputIdProperty)));
            }
            set
            {
                base.SetValue(CombinedProcess.ParentWorkflow.OutputIdProperty, value);
            }
        }

        private void CreateProcessingItem_Invoking(object sender, EventArgs e)
        {
            NewItemId = Guid.NewGuid();
            TargetListId = onWorkflowActivated.WorkflowProperties.Web.Lists["Automated Tasks"].ID;

            NewItemProperties = new Hashtable();
            NewItemProperties.Add("Title", "Test Task");
        }

        private void handleExternalEventActivity_Invoked(object sender, ExternalDataEventArgs e)
        {

        }
    }
}
