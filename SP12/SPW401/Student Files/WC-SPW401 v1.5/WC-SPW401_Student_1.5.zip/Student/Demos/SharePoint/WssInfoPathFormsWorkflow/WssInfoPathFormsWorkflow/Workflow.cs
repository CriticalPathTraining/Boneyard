﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Xml.Serialization;
using System.IO;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;

namespace WssInfoPathFormsWorkflow
{
	public sealed partial class Workflow: StateMachineWorkflowActivity
	{
		public Workflow()
		{
			InitializeComponent();
		}

    public myFields InitData { get; set; }
    public string TaskResult { get; set; }

    private void OnWorkflowActivated_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPActivationEventArgs args = e as SPActivationEventArgs;

      XmlSerializer serializer = new XmlSerializer(typeof(myFields));
      using (TextReader reader = new StringReader(args.properties.InitiationData))
        this.InitData = serializer.Deserialize(reader) as myFields;
    }

    public Guid TaskId = default(System.Guid);

    private void OnTaskChanged_Invoked(object sender, ExternalDataEventArgs e)
    {
      SPTaskServiceEventArgs args = e as SPTaskServiceEventArgs;
      this.TaskResult = args.afterProperties.ExtendedProperties["Result"] as string;
      this.InitData.Instructions = args.afterProperties.ExtendedProperties["Instructions"] as string;
    }

    private void CreateTask_MethodInvoking(object sender, EventArgs e)
    {
      this.TaskId = Guid.NewGuid();
      
      CreateTask activity = sender as CreateTask;
      activity.TaskProperties = new SPWorkflowTaskProperties();
      activity.TaskProperties.Title = "Complete this task";
      activity.TaskProperties.AssignedTo = this.InitData.Approvers[0].AccountId;
      activity.TaskProperties.ExtendedProperties.Add("Instructions", this.InitData.Instructions);
    }
	}

}
