﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Design;
using System.ComponentModel;
using System.ComponentModel.Design;

namespace WssCustomActivities
{
  public class ConsoleContainerActivityToolboxItem : ActivityToolboxItem
  {
    /// <summary>
    /// When a new console container activity is created, add a write console activity in it.
    /// </summary>
    protected override IComponent[] CreateComponentsCore(IDesignerHost host)
    {
      ConsoleContainerActivity container = new ConsoleContainerActivity();
      container.Activities.Add(new WriteConsoleActivity());

      return new IComponent[] { container };
    }
  }
}
