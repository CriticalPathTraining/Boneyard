﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using System.Collections;

namespace SharePointWFAPI
{
    public partial class Workflow : UserControl
    {
        private SPWeb m_web;

        public Workflow()
        {
            InitializeComponent();
        }

        public void Initialize(SPWeb web)
        {
            m_web = web;

            PopulateComboBox(m_web.Lists, lstWebLists);
        }

        private void SelectedListChanged(object sender, EventArgs e)
        {
            SPList list = lstWebLists.SelectedItem as SPList;
            PopulateComboBox(list.Items, lstListItems);

//            if (lstListItems.Items.Count == 0)
//                grpAssociation.Enabled = false;
        }

        private void PopulateComboBox(IEnumerable dataSource, ComboBox control)
        {
            control.Items.Clear();
            if (dataSource != null)
                foreach (object item in dataSource)
                    control.Items.Add(item);
            if (control.Items.Count != 0)
                control.SelectedIndex = 0;
        }

        private void PopulateListBox(IEnumerable dataSource, ListBox control)
        {
            control.Items.Clear();
            if (dataSource != null)
                foreach (object item in dataSource)
                    control.Items.Add(item);
            if (control.Items.Count != 0)
                control.SelectedIndex = 0;
        }

        private void SelectedListItemChanged(object sender, EventArgs e)
        {
            SPListItem listItem = lstListItems.SelectedItem as SPListItem;
            PopulateComboBox(listItem.Workflows, lstAssociations);            
        } 

        private void SelectedWorkflowChanged(object sender, EventArgs e)
        {
            SPWorkflow workflow = lstAssociations.SelectedItem as SPWorkflow;            
            txtWorkflowState.Text = workflow.InternalState.ToString();

            txtInitiator.Text = workflow.AuthorUser.Name;
            txtStarted.Text = workflow.Created.ToString();
            txtWorkflowState.Text = workflow.InternalState.ToString();

            //lstModifications             
            PopulateListBox(workflow.Modifications, lstModifications);   
            PopulateListBox(m_web.Site.WorkflowManager.GetItemTasks(workflow.ParentItem, workflow.TaskFilter), lstTasks);

            SPQuery query = new SPQuery();
            query.Query =
                "<Where>" +
                  "<Eq>" +
                    "<FieldRef Name=\"WorkflowInstance\" />" +
                    "<Value Type=\"Text\">" +
                      workflow.InstanceId.ToString() +
                    "</Value> " +
                  "</Eq>" +
                "</Where>";
            SPListItemCollection history = 
                workflow.HistoryList.GetItems(query);

//            PopulateListBox(m_web.Site.WorkflowManager.GetItem(workflow.ParentItem, workflow.HistoryList), lstHistory);
        }

        private void lstAssociations_Format(object sender, ListControlConvertEventArgs e)
        {
            e.Value = (e.ListItem as SPWorkflow).ParentAssociation.Name;
        }

        private void lstModifications_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            MessageBox.Show(this, (lstModifications.SelectedItem as SPWorkflowModification).ContextData);
        }

        private void lstModifications_Format(object sender, ListControlConvertEventArgs e)
        {
            SPWorkflow workflow = lstAssociations.SelectedItem as SPWorkflow;
            SPWorkflowModification modification = e.ListItem as SPWorkflowModification;

            e.Value = workflow.ParentAssociation.BaseTemplate["Modification_" + modification.Id.ToString() + "_Name"];
        }

        private void listAssociationData_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
SPWorkflow workflow = lstAssociations.SelectedItem as SPWorkflow;
SPWorkflowTemplate template = workflow.ParentAssociation.BaseTemplate;
foreach (SPWorkflowModification modification in workflow.Modifications)
    Console.WriteLine(template["Modification_" + modification.Id.ToString() + "_Name"]);
                     

            MessageBox.Show(this, workflow.ParentAssociation.AssociationData);
        }
    }
}
