﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;

namespace WssCustomActivities
{
  [ActivityDesignerTheme(typeof(ConsoleContainerActivityTheme))]
  public class ConsoleContainerActivityDesigner : SequentialActivityDesigner
  {
    public override bool CanInsertActivities(HitTestInfo insertLocation, System.Collections.ObjectModel.ReadOnlyCollection<System.Workflow.ComponentModel.Activity> activitiesToInsert)
    {
      foreach (Activity activity in activitiesToInsert)
        if (!(activity is WriteConsoleActivity))
          return false;
      return true;
    }

    protected override ActivityDesignerVerbCollection Verbs
    {
      get
      {
        // create the list containing the verbs
        ActivityDesignerVerbCollection verbs = new ActivityDesignerVerbCollection();
        verbs.AddRange(base.Verbs);

        // add the new verb
        verbs.Add(
            new ActivityDesignerVerb(this, DesignerVerbGroup.Actions,
                "Add WriteConsole Activity", new EventHandler(AddWriteConsole_Click)));

        // return the list of verbs
        return verbs;
      }
    }

    private void AddWriteConsole_Click(object sender, EventArgs e)
    {
      CompositeActivity activity = base.Activity as CompositeActivity;

      // create the list of new activites
      List<Activity> activities = new List<Activity>();
      activities.Add(new WriteConsoleActivity());

      // determine where to add the activities
      ConnectorHitTestInfo location =
          new ConnectorHitTestInfo(this,
              HitTestLocations.Designer, activity.Activities.Count);

      // add the activities to the designer 
      this.InsertActivities(location, activities.AsReadOnly());
    }
  }
}
