﻿namespace SharePointWFAPI
{
    partial class Workflow
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblListItems;
            System.Windows.Forms.Label lblLists;
            System.Windows.Forms.Label lblWorkflowState;
            System.Windows.Forms.Label lblInitiator;
            System.Windows.Forms.Label lblStarted;
            this.lstListItems = new System.Windows.Forms.ComboBox();
            this.lstAssociations = new System.Windows.Forms.ComboBox();
            this.grpWorkflow = new System.Windows.Forms.GroupBox();
            this.listAssociationData = new System.Windows.Forms.LinkLabel();
            this.lstTasks = new System.Windows.Forms.ListBox();
            this.lstModifications = new System.Windows.Forms.ListBox();
            this.txtStarted = new System.Windows.Forms.Label();
            this.txtInitiator = new System.Windows.Forms.Label();
            this.txtWorkflowState = new System.Windows.Forms.Label();
            this.lstWebLists = new System.Windows.Forms.ComboBox();
            lblListItems = new System.Windows.Forms.Label();
            lblLists = new System.Windows.Forms.Label();
            lblWorkflowState = new System.Windows.Forms.Label();
            lblInitiator = new System.Windows.Forms.Label();
            lblStarted = new System.Windows.Forms.Label();
            this.grpWorkflow.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblListItems
            // 
            lblListItems.AutoSize = true;
            lblListItems.Location = new System.Drawing.Point(3, 34);
            lblListItems.Name = "lblListItems";
            lblListItems.Size = new System.Drawing.Size(51, 13);
            lblListItems.TabIndex = 24;
            lblListItems.Text = "List Items";
            // 
            // lblLists
            // 
            lblLists.AutoSize = true;
            lblLists.Location = new System.Drawing.Point(3, 7);
            lblLists.Name = "lblLists";
            lblLists.Size = new System.Drawing.Size(28, 13);
            lblLists.TabIndex = 20;
            lblLists.Text = "Lists";
            // 
            // lstListItems
            // 
            this.lstListItems.DisplayMember = "Name";
            this.lstListItems.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstListItems.FormattingEnabled = true;
            this.lstListItems.Location = new System.Drawing.Point(60, 31);
            this.lstListItems.Name = "lstListItems";
            this.lstListItems.Size = new System.Drawing.Size(214, 21);
            this.lstListItems.TabIndex = 23;
            this.lstListItems.SelectedIndexChanged += new System.EventHandler(this.SelectedListItemChanged);
            // 
            // lstAssociations
            // 
            this.lstAssociations.DisplayMember = "Author";
            this.lstAssociations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstAssociations.FormattingEnabled = true;
            this.lstAssociations.Location = new System.Drawing.Point(75, 62);
            this.lstAssociations.Name = "lstAssociations";
            this.lstAssociations.Size = new System.Drawing.Size(195, 21);
            this.lstAssociations.TabIndex = 21;
            this.lstAssociations.SelectedIndexChanged += new System.EventHandler(this.SelectedWorkflowChanged);
            this.lstAssociations.Format += new System.Windows.Forms.ListControlConvertEventHandler(this.lstAssociations_Format);
            // 
            // grpWorkflow
            // 
            this.grpWorkflow.Controls.Add(lblStarted);
            this.grpWorkflow.Controls.Add(lblInitiator);
            this.grpWorkflow.Controls.Add(lblWorkflowState);
            this.grpWorkflow.Controls.Add(this.listAssociationData);
            this.grpWorkflow.Controls.Add(this.lstTasks);
            this.grpWorkflow.Controls.Add(this.lstModifications);
            this.grpWorkflow.Controls.Add(this.txtStarted);
            this.grpWorkflow.Controls.Add(this.txtInitiator);
            this.grpWorkflow.Controls.Add(this.txtWorkflowState);
            this.grpWorkflow.Location = new System.Drawing.Point(3, 67);
            this.grpWorkflow.Name = "grpWorkflow";
            this.grpWorkflow.Size = new System.Drawing.Size(273, 243);
            this.grpWorkflow.TabIndex = 22;
            this.grpWorkflow.TabStop = false;
            this.grpWorkflow.Text = "Workflow";
            // 
            // listAssociationData
            // 
            this.listAssociationData.AutoSize = true;
            this.listAssociationData.Location = new System.Drawing.Point(3, 222);
            this.listAssociationData.Name = "listAssociationData";
            this.listAssociationData.Size = new System.Drawing.Size(87, 13);
            this.listAssociationData.TabIndex = 7;
            this.listAssociationData.TabStop = true;
            this.listAssociationData.Text = "Association Data";
            this.listAssociationData.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.listAssociationData_LinkClicked);
            // 
            // lstTasks
            // 
            this.lstTasks.DisplayMember = "Name";
            this.lstTasks.FormattingEnabled = true;
            this.lstTasks.Location = new System.Drawing.Point(6, 137);
            this.lstTasks.Name = "lstTasks";
            this.lstTasks.Size = new System.Drawing.Size(260, 82);
            this.lstTasks.TabIndex = 6;
            // 
            // lstModifications
            // 
            this.lstModifications.DisplayMember = "Id";
            this.lstModifications.FormattingEnabled = true;
            this.lstModifications.Location = new System.Drawing.Point(6, 75);
            this.lstModifications.Name = "lstModifications";
            this.lstModifications.Size = new System.Drawing.Size(260, 56);
            this.lstModifications.TabIndex = 5;
            this.lstModifications.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lstModifications_MouseDoubleClick);
            this.lstModifications.Format += new System.Windows.Forms.ListControlConvertEventHandler(this.lstModifications_Format);
            // 
            // txtStarted
            // 
            this.txtStarted.AutoSize = true;
            this.txtStarted.Location = new System.Drawing.Point(95, 46);
            this.txtStarted.Name = "txtStarted";
            this.txtStarted.Size = new System.Drawing.Size(41, 13);
            this.txtStarted.TabIndex = 3;
            this.txtStarted.Text = "Started";
            // 
            // txtInitiator
            // 
            this.txtInitiator.AutoSize = true;
            this.txtInitiator.Location = new System.Drawing.Point(95, 33);
            this.txtInitiator.Name = "txtInitiator";
            this.txtInitiator.Size = new System.Drawing.Size(41, 13);
            this.txtInitiator.TabIndex = 2;
            this.txtInitiator.Text = "Initiator";
            // 
            // txtWorkflowState
            // 
            this.txtWorkflowState.AutoSize = true;
            this.txtWorkflowState.Location = new System.Drawing.Point(95, 59);
            this.txtWorkflowState.Name = "txtWorkflowState";
            this.txtWorkflowState.Size = new System.Drawing.Size(80, 13);
            this.txtWorkflowState.TabIndex = 1;
            this.txtWorkflowState.Text = "Workflow State";
            // 
            // lstWebLists
            // 
            this.lstWebLists.DisplayMember = "Title";
            this.lstWebLists.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstWebLists.FormattingEnabled = true;
            this.lstWebLists.Location = new System.Drawing.Point(60, 4);
            this.lstWebLists.Name = "lstWebLists";
            this.lstWebLists.Size = new System.Drawing.Size(214, 21);
            this.lstWebLists.TabIndex = 19;
            this.lstWebLists.ValueMember = "ID";
            this.lstWebLists.SelectedIndexChanged += new System.EventHandler(this.SelectedListChanged);
            // 
            // lblWorkflowState
            // 
            lblWorkflowState.AutoSize = true;
            lblWorkflowState.Location = new System.Drawing.Point(6, 59);
            lblWorkflowState.Name = "lblWorkflowState";
            lblWorkflowState.Size = new System.Drawing.Size(83, 13);
            lblWorkflowState.TabIndex = 8;
            lblWorkflowState.Text = "Workflow State:";
            // 
            // lblInitiator
            // 
            lblInitiator.AutoSize = true;
            lblInitiator.Location = new System.Drawing.Point(6, 33);
            lblInitiator.Name = "lblInitiator";
            lblInitiator.Size = new System.Drawing.Size(47, 13);
            lblInitiator.TabIndex = 9;
            lblInitiator.Text = "Initiator :";
            // 
            // lblStarted
            // 
            lblStarted.AutoSize = true;
            lblStarted.Location = new System.Drawing.Point(6, 46);
            lblStarted.Name = "lblStarted";
            lblStarted.Size = new System.Drawing.Size(47, 13);
            lblStarted.TabIndex = 10;
            lblStarted.Text = "Started :";
            // 
            // Workflow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(lblListItems);
            this.Controls.Add(this.lstListItems);
            this.Controls.Add(this.lstAssociations);
            this.Controls.Add(this.grpWorkflow);
            this.Controls.Add(lblLists);
            this.Controls.Add(this.lstWebLists);
            this.Name = "Workflow";
            this.Size = new System.Drawing.Size(282, 312);
            this.grpWorkflow.ResumeLayout(false);
            this.grpWorkflow.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox lstListItems;
        private System.Windows.Forms.ComboBox lstAssociations;
        private System.Windows.Forms.GroupBox grpWorkflow;
        private System.Windows.Forms.ComboBox lstWebLists;
        private System.Windows.Forms.Label txtWorkflowState;
        private System.Windows.Forms.Label txtStarted;
        private System.Windows.Forms.Label txtInitiator;
        private System.Windows.Forms.ListBox lstModifications;
        private System.Windows.Forms.ListBox lstTasks;
        private System.Windows.Forms.LinkLabel listAssociationData;
    }
}
