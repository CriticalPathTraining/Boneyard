﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace WssCustomFormsWorkflow
{
    partial class Workflow : System.Workflow.Activities.StateMachineWorkflowActivity
    {
		#region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference2 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference3 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.Runtime.CorrelationToken correlationtoken3 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
          this.deleteTask1 = new Microsoft.SharePoint.WorkflowActions.DeleteTask();
          this.completeTask1 = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
          this.moveOnRejected = new System.Workflow.Activities.SetStateActivity();
          this.logRejected = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.moveOnApproved = new System.Workflow.Activities.SetStateActivity();
          this.logApproved = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.ifNotCompleted = new System.Workflow.Activities.IfElseBranchActivity();
          this.ifCompleted = new System.Workflow.Activities.IfElseBranchActivity();
          this.ifTaskNotComplete = new System.Workflow.Activities.IfElseBranchActivity();
          this.ifTaskRejected = new System.Workflow.Activities.IfElseBranchActivity();
          this.ifTaskApproved = new System.Workflow.Activities.IfElseBranchActivity();
          this.moveToWaiting = new System.Workflow.Activities.SetStateActivity();
          this.EnableModification = new Microsoft.SharePoint.WorkflowActions.EnableWorkflowModification();
          this.onWorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
          this.ifElseFinal = new System.Workflow.Activities.IfElseActivity();
          this.isTaskCompleted = new System.Workflow.Activities.IfElseActivity();
          this.onTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
          this.CreateSimpleTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
          this.MoveBackToWaiting = new System.Workflow.Activities.SetStateActivity();
          this.onWorkflowModified1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowModified();
          this.WorkflowActivated = new System.Workflow.Activities.EventDrivenActivity();
          this.WaitingFinal = new System.Workflow.Activities.StateFinalizationActivity();
          this.TaskChanged = new System.Workflow.Activities.EventDrivenActivity();
          this.WaitingInit = new System.Workflow.Activities.StateInitializationActivity();
          this.WorkflowModified = new System.Workflow.Activities.EventDrivenActivity();
          this.InitialState = new System.Workflow.Activities.StateActivity();
          this.WaitingState = new System.Workflow.Activities.StateActivity();
          this.CompletedState = new System.Workflow.Activities.StateActivity();
          // 
          // deleteTask1
          // 
          correlationtoken1.Name = "taskToken";
          correlationtoken1.OwnerActivityName = "WaitingState";
          this.deleteTask1.CorrelationToken = correlationtoken1;
          this.deleteTask1.Name = "deleteTask1";
          activitybind1.Name = "Workflow";
          activitybind1.Path = "TaskId";
          this.deleteTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.DeleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
          // 
          // completeTask1
          // 
          this.completeTask1.CorrelationToken = correlationtoken1;
          this.completeTask1.Name = "completeTask1";
          activitybind2.Name = "Workflow";
          activitybind2.Path = "TaskId";
          this.completeTask1.TaskOutcome = null;
          this.completeTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
          // 
          // moveOnRejected
          // 
          this.moveOnRejected.Name = "moveOnRejected";
          this.moveOnRejected.TargetStateName = "CompletedState";
          // 
          // logRejected
          // 
          this.logRejected.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.logRejected.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          activitybind3.Name = "Workflow";
          activitybind3.Path = "TaskComments";
          this.logRejected.HistoryOutcome = "Rejected";
          this.logRejected.Name = "logRejected";
          this.logRejected.OtherData = "";
          this.logRejected.UserId = -1;
          this.logRejected.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
          // 
          // moveOnApproved
          // 
          this.moveOnApproved.Name = "moveOnApproved";
          this.moveOnApproved.TargetStateName = "CompletedState";
          // 
          // logApproved
          // 
          this.logApproved.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.logApproved.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          activitybind4.Name = "Workflow";
          activitybind4.Path = "TaskComments";
          this.logApproved.HistoryOutcome = "Approved";
          this.logApproved.Name = "logApproved";
          this.logApproved.OtherData = "";
          this.logApproved.UserId = -1;
          this.logApproved.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
          // 
          // ifNotCompleted
          // 
          this.ifNotCompleted.Activities.Add(this.deleteTask1);
          this.ifNotCompleted.Name = "ifNotCompleted";
          // 
          // ifCompleted
          // 
          this.ifCompleted.Activities.Add(this.completeTask1);
          ruleconditionreference1.ConditionName = "TaskCompleted";
          this.ifCompleted.Condition = ruleconditionreference1;
          this.ifCompleted.Name = "ifCompleted";
          // 
          // ifTaskNotComplete
          // 
          this.ifTaskNotComplete.Name = "ifTaskNotComplete";
          // 
          // ifTaskRejected
          // 
          this.ifTaskRejected.Activities.Add(this.logRejected);
          this.ifTaskRejected.Activities.Add(this.moveOnRejected);
          ruleconditionreference2.ConditionName = "TaskRejected";
          this.ifTaskRejected.Condition = ruleconditionreference2;
          this.ifTaskRejected.Name = "ifTaskRejected";
          // 
          // ifTaskApproved
          // 
          this.ifTaskApproved.Activities.Add(this.logApproved);
          this.ifTaskApproved.Activities.Add(this.moveOnApproved);
          ruleconditionreference3.ConditionName = "TaskApproved";
          this.ifTaskApproved.Condition = ruleconditionreference3;
          this.ifTaskApproved.Name = "ifTaskApproved";
          // 
          // moveToWaiting
          // 
          this.moveToWaiting.Name = "moveToWaiting";
          this.moveToWaiting.TargetStateName = "WaitingState";
          // 
          // EnableModification
          // 
          this.EnableModification.ContextData = null;
          correlationtoken2.Name = "modificationToken";
          correlationtoken2.OwnerActivityName = "Workflow";
          this.EnableModification.CorrelationToken = correlationtoken2;
          this.EnableModification.ModificationId = new System.Guid("d2f44911-1a23-42ee-8414-2b668c2467ae");
          this.EnableModification.Name = "EnableModification";
          this.EnableModification.MethodInvoking += new System.EventHandler(this.EnableModification_Invoking);
          // 
          // onWorkflowActivated
          // 
          correlationtoken3.Name = "workflowToken";
          correlationtoken3.OwnerActivityName = "Workflow";
          this.onWorkflowActivated.CorrelationToken = correlationtoken3;
          this.onWorkflowActivated.EventName = "OnWorkflowActivated";
          this.onWorkflowActivated.Name = "onWorkflowActivated";
          this.onWorkflowActivated.WorkflowProperties = null;
          this.onWorkflowActivated.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onWorkflowActivated_Invoked);
          // 
          // ifElseFinal
          // 
          this.ifElseFinal.Activities.Add(this.ifCompleted);
          this.ifElseFinal.Activities.Add(this.ifNotCompleted);
          this.ifElseFinal.Name = "ifElseFinal";
          // 
          // isTaskCompleted
          // 
          this.isTaskCompleted.Activities.Add(this.ifTaskApproved);
          this.isTaskCompleted.Activities.Add(this.ifTaskRejected);
          this.isTaskCompleted.Activities.Add(this.ifTaskNotComplete);
          this.isTaskCompleted.Name = "isTaskCompleted";
          // 
          // onTaskChanged
          // 
          this.onTaskChanged.AfterProperties = null;
          this.onTaskChanged.BeforeProperties = null;
          this.onTaskChanged.CorrelationToken = correlationtoken1;
          this.onTaskChanged.Executor = null;
          this.onTaskChanged.Name = "onTaskChanged";
          activitybind5.Name = "Workflow";
          activitybind5.Path = "TaskId";
          this.onTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.TaskChanged_Invoked);
          this.onTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
          // 
          // CreateSimpleTask
          // 
          this.CreateSimpleTask.CorrelationToken = correlationtoken1;
          this.CreateSimpleTask.ListItemId = -1;
          this.CreateSimpleTask.Name = "CreateSimpleTask";
          this.CreateSimpleTask.SpecialPermissions = null;
          activitybind6.Name = "Workflow";
          activitybind6.Path = "TaskId";
          this.CreateSimpleTask.TaskProperties = null;
          this.CreateSimpleTask.MethodInvoking += new System.EventHandler(this.CreateSimpleTask_Invoking);
          this.CreateSimpleTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
          // 
          // MoveBackToWaiting
          // 
          this.MoveBackToWaiting.Name = "MoveBackToWaiting";
          this.MoveBackToWaiting.TargetStateName = "WaitingState";
          // 
          // onWorkflowModified1
          // 
          this.onWorkflowModified1.ContextData = null;
          this.onWorkflowModified1.CorrelationToken = correlationtoken2;
          this.onWorkflowModified1.ModificationId = new System.Guid("d2f44911-1a23-42ee-8414-2b668c2467ae");
          this.onWorkflowModified1.Name = "onWorkflowModified1";
          this.onWorkflowModified1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnWorkflowModified_Invoked);
          // 
          // WorkflowActivated
          // 
          this.WorkflowActivated.Activities.Add(this.onWorkflowActivated);
          this.WorkflowActivated.Activities.Add(this.EnableModification);
          this.WorkflowActivated.Activities.Add(this.moveToWaiting);
          this.WorkflowActivated.Name = "WorkflowActivated";
          // 
          // WaitingFinal
          // 
          this.WaitingFinal.Activities.Add(this.ifElseFinal);
          this.WaitingFinal.Name = "WaitingFinal";
          // 
          // TaskChanged
          // 
          this.TaskChanged.Activities.Add(this.onTaskChanged);
          this.TaskChanged.Activities.Add(this.isTaskCompleted);
          this.TaskChanged.Name = "TaskChanged";
          // 
          // WaitingInit
          // 
          this.WaitingInit.Activities.Add(this.CreateSimpleTask);
          this.WaitingInit.Name = "WaitingInit";
          // 
          // WorkflowModified
          // 
          this.WorkflowModified.Activities.Add(this.onWorkflowModified1);
          this.WorkflowModified.Activities.Add(this.MoveBackToWaiting);
          this.WorkflowModified.Name = "WorkflowModified";
          // 
          // InitialState
          // 
          this.InitialState.Activities.Add(this.WorkflowActivated);
          this.InitialState.Name = "InitialState";
          // 
          // WaitingState
          // 
          this.WaitingState.Activities.Add(this.WaitingInit);
          this.WaitingState.Activities.Add(this.TaskChanged);
          this.WaitingState.Activities.Add(this.WaitingFinal);
          this.WaitingState.Name = "WaitingState";
          // 
          // CompletedState
          // 
          this.CompletedState.Name = "CompletedState";
          // 
          // Workflow
          // 
          this.Activities.Add(this.CompletedState);
          this.Activities.Add(this.WaitingState);
          this.Activities.Add(this.InitialState);
          this.Activities.Add(this.WorkflowModified);
          this.CompletedStateName = "CompletedState";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "InitialState";
          this.Name = "Workflow";
          this.CanModifyActivities = false;

        }

        #endregion

        private Microsoft.SharePoint.WorkflowActions.OnWorkflowModified OnWorkflowModified;
        private StateInitializationActivity WaitingInit;
        private EventDrivenActivity WorkflowActivated;
        private StateActivity CompletedState;
        private StateActivity WaitingState;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated;
        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateSimpleTask;
        private SetStateActivity moveToWaiting;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged onTaskChanged;
        private EventDrivenActivity TaskChanged;
        private StateFinalizationActivity WaitingFinal;
        private SetStateActivity moveOnApproved;
        private IfElseBranchActivity ifTaskNotComplete;
        private IfElseBranchActivity ifTaskApproved;
        private IfElseActivity isTaskCompleted;
        private IfElseBranchActivity ifNotCompleted;
        private IfElseBranchActivity ifCompleted;
        private IfElseActivity ifElseFinal;
        private Microsoft.SharePoint.WorkflowActions.DeleteTask deleteTask1;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask completeTask1;
        private SetStateActivity moveOnRejected;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logRejected;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logApproved;
        private IfElseBranchActivity ifTaskRejected;
        private EventDrivenActivity WorkflowModified;
        private Microsoft.SharePoint.WorkflowActions.EnableWorkflowModification EnableModification;
        private SetStateActivity MoveBackToWaiting;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowModified onWorkflowModified1;
        private StateActivity InitialState;








    }
}
