﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel;

namespace WssCustomActivities
{
  internal class WriteConsoleActivityValidator : ActivityValidator
  {
    /// <summary>
    /// Validate the control does not lie within a transaction scope activity.
    /// </summary>
    public override ValidationErrorCollection Validate(ValidationManager manager, object obj)
    {
      // validate the validator is connected to the appropriate activity type
      WriteConsoleActivity activity = obj as WriteConsoleActivity;
      if (activity == null)
        throw new InvalidOperationException();

      // call the base validation method
      ValidationErrorCollection errors = new ValidationErrorCollection();
      errors.AddRange(base.Validate(manager, obj));

      // make sure the write console activity exists in a ConsoleContainerActivity
      Activity parent = activity.Parent;
      if ((parent != null) && !(parent is ConsoleContainerActivity))
        errors.Add(new ValidationError("The WriteConsoleActivity can only be contained in a ConsoleContainerActivity.", 100));

      // return the errors
      return errors;
    }
  }
}
