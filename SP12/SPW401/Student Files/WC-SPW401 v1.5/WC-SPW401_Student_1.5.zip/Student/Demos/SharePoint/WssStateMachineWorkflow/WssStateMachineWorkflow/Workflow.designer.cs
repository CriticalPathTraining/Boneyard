﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace WssStateMachineWorkflow
{
    partial class Workflow
    {
		#region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
          this.setCompleted = new System.Workflow.Activities.SetStateActivity();
          this.logStarted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.workflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
          this.onWorkflowActivated = new System.Workflow.Activities.EventDrivenActivity();
          this.Completed = new System.Workflow.Activities.StateActivity();
          this.Initial = new System.Workflow.Activities.StateActivity();
          // 
          // setCompleted
          // 
          this.setCompleted.Name = "setCompleted";
          this.setCompleted.TargetStateName = "Completed";
          // 
          // logStarted
          // 
          this.logStarted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.logStarted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.logStarted.HistoryDescription = "Hello World";
          this.logStarted.HistoryOutcome = "";
          this.logStarted.Name = "logStarted";
          this.logStarted.OtherData = "";
          this.logStarted.UserId = -1;
          // 
          // workflowActivated
          // 
          correlationtoken1.Name = "workflowToken";
          correlationtoken1.OwnerActivityName = "Workflow";
          this.workflowActivated.CorrelationToken = correlationtoken1;
          this.workflowActivated.EventName = "OnWorkflowActivated";
          this.workflowActivated.Name = "workflowActivated";
          this.workflowActivated.WorkflowProperties = null;
          // 
          // onWorkflowActivated
          // 
          this.onWorkflowActivated.Activities.Add(this.workflowActivated);
          this.onWorkflowActivated.Activities.Add(this.logStarted);
          this.onWorkflowActivated.Activities.Add(this.setCompleted);
          this.onWorkflowActivated.Name = "onWorkflowActivated";
          // 
          // Completed
          // 
          this.Completed.Name = "Completed";
          // 
          // Initial
          // 
          this.Initial.Activities.Add(this.onWorkflowActivated);
          this.Initial.Name = "Initial";
          // 
          // Workflow
          // 
          this.Activities.Add(this.Initial);
          this.Activities.Add(this.Completed);
          this.CompletedStateName = "Completed";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "Initial";
          this.Name = "Workflow";
          this.CanModifyActivities = false;

        }

        #endregion

        private SetStateActivity setCompleted;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logStarted;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated workflowActivated;
        private EventDrivenActivity onWorkflowActivated;
        private StateActivity Completed;
        private StateActivity Initial;

    }
}
