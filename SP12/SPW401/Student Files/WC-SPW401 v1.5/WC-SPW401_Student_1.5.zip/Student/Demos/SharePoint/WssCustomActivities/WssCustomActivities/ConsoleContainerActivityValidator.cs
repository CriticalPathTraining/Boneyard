﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel;

namespace WssCustomActivities
{
  internal class ConsoleContainerActivityValidator : CompositeActivityValidator
  {
    // 
    public override ValidationErrorCollection Validate(ValidationManager manager, object obj)
    {
      // validate the validator is connected to the appropriate activity type
      ConsoleContainerActivity activity = obj as ConsoleContainerActivity;
      if (activity == null)
        throw new InvalidOperationException();

      // verify all child activities 
      ValidationErrorCollection errors = new ValidationErrorCollection();
      foreach (Activity childActivity in activity.EnabledActivities)
        if (!(childActivity is WriteConsoleActivity))
          errors.Add(new ValidationError("The ConsoleContainerActivity may only contain WriteConsoleActivities.", 100));

      // call the base validation method
      errors.AddRange(base.Validate(manager, obj));

      // return the errors
      return errors;
    }

  }
}
