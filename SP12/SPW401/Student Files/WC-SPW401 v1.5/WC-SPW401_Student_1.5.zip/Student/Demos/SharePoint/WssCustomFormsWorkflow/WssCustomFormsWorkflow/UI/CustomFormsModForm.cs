﻿using System;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;

namespace WssCustomFormsWorkflow.UI
{
  public class CustomFormsModForm : LayoutsPageBase
  {
    private SPList _list;
    private SPListItem _listItem;
    private SPWorkflow _workflow;
    private SPWorkflowModification _modification;

    protected TextBox txtCustomData;

    /// <summary>
    /// Read the parameters from the request and the UI.  Then find the workflow modification in
    /// the list or the content type and use it to initialize the page.
    /// </summary>
    protected override void OnLoad(EventArgs e)
    {
      // read the form level parameters
      string listId = Request.Params["List"];
      string listItemId = Request.Params["ID"];
      string workflowId = Request.Params["WorkflowInstanceID"];
      string modificationId = Request.Params["ModificationID"];

      // find the list, list item, workflow, and modification
      _list = Web.Lists[new Guid(listId)];
      _listItem = _list.GetItemById(Convert.ToInt32(listItemId));
      _workflow = _listItem.Workflows[new Guid(workflowId)];
      _modification = _workflow.Modifications[new Guid(modificationId)];

      // populate the controls
      if (!IsPostBack)
      {
        // deserialize the association data
        ModificationData modData = ModificationData.Deserialize(_modification.ContextData);

        // bind the controls to the association data
        txtCustomData.Text = modData.CustomData;
      }

      // call the base implementation
      base.OnLoad(e);
    }

    /// <summary>
    /// Apply the modification and redirect to the list's default view.
    /// </summary>
    protected void Submit_Click(object sender, EventArgs e)
    {
      // populate the modification data using the UI
      ModificationData modData = new ModificationData();
      modData.CustomData = txtCustomData.Text;

      // modify the workflow
      Web.Site.WorkflowManager.ModifyWorkflow(
          _workflow, _modification, modData.Serialize());

      // redirect to the list's default view
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }

    /// <summary>
    /// Redirect to the list's default view.
    /// </summary>
    protected void Cancel_Click(object sender, EventArgs e)
    {
      // redirect to the list's default view
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }
  }
}
