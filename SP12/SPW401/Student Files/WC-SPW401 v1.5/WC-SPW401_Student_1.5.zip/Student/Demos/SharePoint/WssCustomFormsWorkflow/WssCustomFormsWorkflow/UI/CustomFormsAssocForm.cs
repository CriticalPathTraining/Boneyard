﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Utilities;

namespace WssCustomFormsWorkflow.UI
{
  public class CustomFormsAssocForm : LayoutsPageBase
  {
    private enum AssociationType
    {
      List,
      ContentType,
      ListContentType
    }

    // form-level variables
    private AssociationType _associationType;
    private SPContentType _contentType;
    private SPList _list;
    private SPWorkflowAssociation _workflowAssociation;
    private bool _updateContentTypeLists;

    // form controls
    protected TextBox txtCustomData;

    // UI level fields        
    protected bool IsNewAssociation
    {
      get { return string.IsNullOrEmpty(Request.Params["GuidAssoc"]); }
    }

    protected string WorkflowAssociationName
    {
      get { return Request.Params["WorkflowName"]; }
    }

    /// <summary>
    /// Lookup the request parameters and determine what type of object the 
    /// association is attached to.  If an existing workflow association exists
    /// lookup the object.
    /// </summary>
    protected override void OnLoad(EventArgs e)
    {
      // read the form level parameters
      string listId = Request.Params["List"];
      string ctypeId = Request.Params["ctype"];
      string guidAssocId = Request.Params["GuidAssoc"];

      // determine the type of association
      if (!string.IsNullOrEmpty(listId) && !string.IsNullOrEmpty(ctypeId))
        _associationType = AssociationType.ListContentType;
      else if (!string.IsNullOrEmpty(listId) && string.IsNullOrEmpty(ctypeId))
        _associationType = AssociationType.List;
      else if (string.IsNullOrEmpty(listId) && !string.IsNullOrEmpty(ctypeId))
        _associationType = AssociationType.ContentType;

      // validate the workflow association id
      Guid? workflowAssociationId = new Guid?();
      if (!string.IsNullOrEmpty(guidAssocId))
        workflowAssociationId = new Guid(guidAssocId);

      // lookup the list, content type, and existing workflow associations
      switch (_associationType)
      {
        case AssociationType.ContentType:
          _contentType = Web.AvailableContentTypes[new SPContentTypeId(ctypeId)];
          if (workflowAssociationId.HasValue)
            _workflowAssociation = _contentType.WorkflowAssociations[workflowAssociationId.Value];
          break;
        case AssociationType.List:
          _list = Web.Lists[new Guid(listId)];
          if (workflowAssociationId.HasValue)
            _workflowAssociation = _list.WorkflowAssociations[workflowAssociationId.Value];
          break;
        case AssociationType.ListContentType:
          _list = Web.Lists[new Guid(listId)];
          _contentType = _list.ContentTypes[new SPContentTypeId(ctypeId)];
          if (workflowAssociationId.HasValue)
            _workflowAssociation = _contentType.WorkflowAssociations[workflowAssociationId.Value];
          break;
      }

      // check whether updates to content types cascade to their lists
      _updateContentTypeLists = (Request.Params["UpdateLists"] == "TRUE");

      // call the base implementation
      base.OnLoad(e);
    }

    /// <summary>
    /// Write the form parameters back into the page and populate the initial control values.
    /// </summary>
    protected override void OnPreRender(EventArgs e)
    {
      // register parameters in the hidden field
      ClientScript.RegisterHiddenField("WorkflowName", Request.Params["WorkflowName"]);
      ClientScript.RegisterHiddenField("WorkflowDefinition", Request.Params["WorkflowDefinition"]);
      ClientScript.RegisterHiddenField("AddToStatusMenu", Request.Params["AddToStatusMenu"]);
      ClientScript.RegisterHiddenField("AllowManual", Request.Params["AllowManual"]);
      ClientScript.RegisterHiddenField("RoleSelect", Request.Params["RoleSelect"]);
      ClientScript.RegisterHiddenField("GuidAssoc", Request.Params["GuidAssoc"]);
      ClientScript.RegisterHiddenField("SetDefault", Request.Params["SetDefault"]);
      ClientScript.RegisterHiddenField("HistoryList", Request.Params["HistoryList"]);
      ClientScript.RegisterHiddenField("TaskList", Request.Params["TaskList"]);
      ClientScript.RegisterHiddenField("UpdateLists", Request.Params["UpdateLists"]);
      ClientScript.RegisterHiddenField("AutoStartCreate", Request.Params["AutoStartCreate"]);
      ClientScript.RegisterHiddenField("AutoStartChange", Request.Params["AutoStartChange"]);

      // bind the association data (if any)            
      if (_workflowAssociation != null)
      {
        // deserialize the association data
        AssociationData assocData = AssociationData.Deserialize(_workflowAssociation.AssociationData);

        // bind the controls to the association data
        txtCustomData.Text = assocData.DefaultCustomData;
      }

      // call the base implementation
      base.OnPreRender(e);
    }

    /// <summary>
    /// Handle a cancel button click by redirecting to the workflow settings page.
    /// </summary>
    protected void Cancel_Click(object sender, EventArgs e)
    {
      SPUtility.Redirect(
          BuildRedirectString(_associationType, Request.Params["List"], Request.Params["ctype"]),
          SPRedirectFlags.RelativeToLayoutsPage, this.Context);
    }

    /// <summary>
    /// Creates or updates the workflow association and navigates to the workflow settings page.
    /// </summary>
    protected void Submit_Click(object sender, EventArgs e)
    {
      // get the association data
      AssociationData associationData = new AssociationData();
      associationData.DefaultCustomData = txtCustomData.Text;
      string serializedData = associationData.Serialize();

      // create or find the lists
      SPList taskList = LookupOrCreateList(Request.Params["TaskList"], SPListTemplateType.Tasks);
      SPList historyList = LookupOrCreateList(Request.Params["HistoryList"], SPListTemplateType.WorkflowHistory);

      // create or update the workflow association
      if (_workflowAssociation != null)
        UpdateWorkflowAssociation(taskList, historyList, associationData.Serialize());
      else
        CreateWorkflowAssociation(taskList, historyList, associationData.Serialize());

      // redirect to the status page
      SPUtility.Redirect(
          BuildRedirectString(_associationType, Request.Params["List"], Request.Params["ctype"]),
          SPRedirectFlags.RelativeToLayoutsPage, this.Context);
    }

    #region Workflow Association Management Methods
    /// <summary>
    /// Updates a workflow association using the request parameters, the task list, history list, and association data.
    /// </summary>
    private void UpdateWorkflowAssociation(SPList taskList, SPList historyList, string associationData)
    {
      // populate the basic association information
      PopulateWorkflowAssociation(taskList, historyList, associationData);

      // update the association in the proper location
      switch (_associationType)
      {
        case AssociationType.ContentType:
          // commit the changes to the existing workflow association
          _contentType.UpdateWorkflowAssociation(_workflowAssociation);

          // update lists based on content types if flag set
          if (_updateContentTypeLists)
            _contentType.UpdateWorkflowAssociationsOnChildren(true, true, true);
          break;
        case AssociationType.List:
          // commit the changes to the existing workflow association
          _list.UpdateWorkflowAssociation(_workflowAssociation);
          break;
        case AssociationType.ListContentType:
          // commit the changes to the existing workflow association
          _contentType.UpdateWorkflowAssociation(_workflowAssociation);
          break;
      }
    }

    /// <summary>
    /// Creates a new workflow association using the request parameters, the task list, history list, and association data.
    /// </summary>
    private void CreateWorkflowAssociation(SPList taskList, SPList historyList, string associationData)
    {
      // lookup the workflow template and the workflow name
      string workflowName = Request.Params["WorkflowName"];
      Guid workflowTemplateId = new Guid(Request.Params["WorkflowDefinition"]);
      SPWorkflowTemplate workflowTemplate = Web.WorkflowTemplates[workflowTemplateId];

      switch (_associationType)
      {
        case AssociationType.ContentType:
          // create the new association based on the template, name, and lists
          _workflowAssociation = SPWorkflowAssociation.CreateSiteContentTypeAssociation(
              workflowTemplate, workflowName, taskList.Title, historyList.Title);

          // update the data in the new workflow association and add it to the container    
          PopulateWorkflowAssociation(taskList, historyList, associationData);
          _contentType.AddWorkflowAssociation(_workflowAssociation);

          // update lists based on content types if flag set
          if (_updateContentTypeLists)
            _contentType.UpdateWorkflowAssociationsOnChildren(true, true, true);
          break;
        case AssociationType.List:
          // create the new association based on the template, name, and lists
          _workflowAssociation = SPWorkflowAssociation.CreateListAssociation(
              workflowTemplate, workflowName, taskList, historyList);

          // update the data in the new workflow association and add it to the container    
          PopulateWorkflowAssociation(taskList, historyList, associationData);
          _list.AddWorkflowAssociation(_workflowAssociation);
          break;
        case AssociationType.ListContentType:
          // create the new association based on the template, name, and lists
          _workflowAssociation = SPWorkflowAssociation.CreateListContentTypeAssociation(
              workflowTemplate, workflowName, taskList, historyList);

          // update the data in the new workflow association and add it to the container    
          PopulateWorkflowAssociation(taskList, historyList, associationData);
          _contentType.AddWorkflowAssociation(_workflowAssociation);
          break;
      }
    }

    /// <summary>
    /// Populates the SPWorkflowAssociation object with the data from the request.
    /// </summary>
    private void PopulateWorkflowAssociation(SPList taskList, SPList historyList, string associationData)
    {
      // assign base workflow association information
      _workflowAssociation.Name = Request.Params["WorkflowName"];
      _workflowAssociation.AutoStartCreate = (Request.Params["AutoStartCreate"] == "ON");
      _workflowAssociation.AutoStartChange = (Request.Params["AutoStartChange"] == "ON");
      _workflowAssociation.AllowManual = (Request.Params["AllowManual"] == "ON");
      _workflowAssociation.AssociationData = associationData;

      // assign the chosed task list to the association
      if (_workflowAssociation.TaskListId != taskList.ID)
        _workflowAssociation.SetTaskList(taskList);

      // assign the chosed history list to the association
      if (_workflowAssociation.HistoryListId != historyList.ID)
        _workflowAssociation.SetHistoryList(historyList);
    }
    #endregion

    #region Private Helper Methods
    /// <summary>
    /// Looks at the history or task list name and determine if it represents a new 
    /// list by checking for a starting character of z.  If it's new it creates the
    /// list, if not, it finds the list.
    /// </summary>
    private SPList LookupOrCreateList(string paramList, SPListTemplateType listType)
    {
      // lookup the history list
      if (paramList.StartsWith("z"))
      {
        Guid newListId = Web.Lists.Add(paramList.Substring(1), "Workflow Tasks", listType);
        return Web.Lists[newListId];
      }
      else
      {
        if (_associationType == AssociationType.ContentType)
          return Web.Lists[paramList];
        else
          return Web.Lists[new Guid(paramList)];
      }
    }

    /// <summary>
    /// Uses the association type, list id and content type id to build a redirect string.
    /// </summary>
    private static string BuildRedirectString(AssociationType associationType, string paramList, string paramCtype)
    {
      switch (associationType)
      {
        case AssociationType.ContentType:
          return "WrkSetng.aspx?ctype=" + paramCtype;
        case AssociationType.List:
          return "WrkSetng.aspx?List=" + paramList;
        case AssociationType.ListContentType:
          return "WrkSetng.aspx?List=" + paramList + "&ctype=" + paramCtype;
        default:
          throw new InvalidOperationException();
      }
    }
    #endregion
  }
}
