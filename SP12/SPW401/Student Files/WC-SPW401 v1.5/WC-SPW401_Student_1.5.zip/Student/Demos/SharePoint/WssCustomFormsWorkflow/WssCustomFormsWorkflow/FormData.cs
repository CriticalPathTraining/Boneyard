﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace WssCustomFormsWorkflow
{
	public class AssociationData
	{
        public string DefaultCustomData { get; set; }

        public string Serialize()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(AssociationData));
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, this);
                return writer.ToString();
            }
        }

        public static AssociationData Deserialize(string value)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(AssociationData));
            using (StringReader reader = new StringReader(value))
                return serializer.Deserialize(reader) as AssociationData;
        }
    }

    public class InitiationData
    {
        public string CustomData { get; set; }

        public string Serialize()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(InitiationData));
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, this);
                return writer.ToString();
            }
        }

        public static InitiationData Deserialize(string value)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(InitiationData));
            using (StringReader reader = new StringReader(value))
                return serializer.Deserialize(reader) as InitiationData;
        }
    }

    public class ModificationData
    {
        public string CustomData { get; set; }

        public string Serialize()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ModificationData));
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, this);
                return writer.ToString();
            }
        }

        public static ModificationData Deserialize(string value)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ModificationData));
            using (StringReader reader = new StringReader(value))
                return serializer.Deserialize(reader) as ModificationData;
        }
    }
}
