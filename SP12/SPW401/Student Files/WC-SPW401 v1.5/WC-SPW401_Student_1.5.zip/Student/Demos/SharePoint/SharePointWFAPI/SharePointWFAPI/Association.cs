﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using System.Collections;

namespace SharePointWFAPI
{
  public partial class Association : UserControl
  {
    private SPWeb m_web;
    private SPWorkflowAssociation m_current;

    public Association()
    {
      InitializeComponent();
    }

    public void Initialize(SPWeb web)
    {
      m_web = web;

      PopulateComboBox(m_web.Lists, lstWebLists);

      PopulateComboBox(m_web.WorkflowTemplates, lstWorkflowTemplates);
      PopulateComboBox(m_web.Lists.Cast<SPList>(), lstTaskList, n => n.BaseTemplate == SPListTemplateType.Tasks);
      PopulateComboBox(m_web.Lists.Cast<SPList>(), lstHistoryList, n => n.BaseTemplate == SPListTemplateType.WorkflowHistory);
    }

    private void SelectedListChanged(object sender, EventArgs e)
    {
      SPList list = lstWebLists.SelectedItem as SPList;
      PopulateComboBox(list.WorkflowAssociations, lstAssociations);
      lstAssociations.Items.Add("New Item...");

      if (lstAssociations.Items.Count == 1)
        grpAssociation.Enabled = false;
    }

    private void PopulateComboBox(IEnumerable dataSource, ComboBox control)
    {
      control.Items.Clear();
      if (dataSource != null)
        foreach (object item in dataSource)
          control.Items.Add(item);
      if (control.Items.Count != 0)
        control.SelectedIndex = 0;
    }

    private void PopulateComboBox<T>(IEnumerable<T> dataSource, ComboBox control, Func<T, bool> predicate)
    {
      control.Items.Clear();
      if (dataSource != null)
        foreach (T item in dataSource.Where(predicate))
          control.Items.Add(item);
      if (control.Items.Count != 0)
        control.SelectedIndex = 0;
    }

    private void SelectedAssociationChanged(object sender, EventArgs e)
    {
      SPWorkflowAssociation association = lstAssociations.SelectedItem as SPWorkflowAssociation;

      m_current = lstAssociations.SelectedItem as SPWorkflowAssociation;
      if (m_current != null)
        DisplayAssociation(m_current);
      else
        DisplayNewAssociation();
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
      // either create or update the workflow
      if (m_current == null)
        m_current = CreateWorkflowAssociation();
      else
        UpdateWorkflowAssociation(m_current);

      // store the current association as the update will change m_current
      SPWorkflowAssociation current = m_current;
      SelectedListChanged(lstWebLists, EventArgs.Empty);
      lstAssociations.SelectedItem = current;
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
      if (m_current != null)
      {
        DeleteWorkflowAssociation(m_current);
        SelectedListChanged(lstWebLists, EventArgs.Empty);
      }
    }

    private void DisplayAssociation(SPWorkflowAssociation association)
    {
      grpAssociation.Enabled = true;

      txtName.Text = association.Name;
      lstWorkflowTemplates.SelectedItem = lstWorkflowTemplates.Items.Cast<SPWorkflowTemplate>().First(n => n.Id == association.BaseTemplate.Id);
      lstWorkflowTemplates.Enabled = false;
      lstTaskList.SelectedItem = lstTaskList.Items.Cast<SPList>().First(n => n.ID == association.TaskListId);
      lstHistoryList.SelectedItem = lstHistoryList.Items.Cast<SPList>().First(n => n.ID == association.HistoryListId);

      btnDelete.Enabled = true;
    }

    private void DisplayNewAssociation()
    {
      grpAssociation.Enabled = true;

      txtName.Text = string.Empty;
      lstWorkflowTemplates.SelectedIndex = 0;
      lstWorkflowTemplates.Enabled = true;
      lstTaskList.SelectedItem = 0;
      lstHistoryList.SelectedItem = 0;

      btnDelete.Enabled = false;
    }

    private SPWorkflowAssociation CreateWorkflowAssociation()
    {
      SPList list = lstWebLists.SelectedItem as SPList;
      SPWorkflowTemplate template = lstWorkflowTemplates.SelectedItem as SPWorkflowTemplate;

      // create the history list if it doesn't exist
      SPList historyList = (lstHistoryList.SelectedItem == null) ?
          CreateList(lstHistoryList.Text, SPListTemplateType.WorkflowHistory) :
          lstHistoryList.SelectedItem as SPList;

      // create the task list if it doesn't exist
      SPList taskList = (lstTaskList.SelectedItem == null) ?
          CreateList(lstTaskList.Text, SPListTemplateType.Tasks) :
          lstTaskList.SelectedItem as SPList;

      // create the association
      SPWorkflowAssociation result =
          SPWorkflowAssociation.CreateListAssociation(template, txtName.Text,
              taskList, historyList);
      result.AssociationData = template.AssociationData;

      // add the association to the list
      list.AddWorkflowAssociation(result);
      list.Update();

      return result;
    }

    private void UpdateWorkflowAssociation(SPWorkflowAssociation association)
    {
      // update the association name
      association.Name = txtName.Text;

      // create the history list if it doesn't exist
      SPList historyList = (lstHistoryList.SelectedItem == null) ?
          CreateList(lstHistoryList.Text, SPListTemplateType.WorkflowHistory) :
          lstHistoryList.SelectedItem as SPList;

      // update the history list if it's changed
      if (association.HistoryListId != historyList.ID)
        association.SetHistoryList(historyList);

      // create the task list if it doesn't exist
      SPList taskList = (lstTaskList.SelectedItem == null) ?
          CreateList(lstTaskList.Text, SPListTemplateType.Tasks) :
          lstTaskList.SelectedItem as SPList;

      // update the task list if it's changed
      if (association.TaskListId != taskList.ID)
        association.SetTaskList(taskList);

      // update the association
      association.ParentList.UpdateWorkflowAssociation(association);
    }

    private void DeleteWorkflowAssociation(SPWorkflowAssociation association)
    {
      association.ParentList.RemoveWorkflowAssociation(association);
      association.ParentList.Update();
    }

    private SPList CreateList(string name, SPListTemplateType type)
    {
      // create the list
      Guid listId = m_web.Lists.Add(name, string.Empty, type);

      // commit the changes
      m_web.Update();

      return m_web.Lists[listId];
    }



  }
}
