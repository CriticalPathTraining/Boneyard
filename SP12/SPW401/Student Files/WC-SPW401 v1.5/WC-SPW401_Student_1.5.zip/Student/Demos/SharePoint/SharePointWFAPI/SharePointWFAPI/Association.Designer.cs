﻿namespace SharePointWFAPI
{
    partial class Association
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblLists;
            System.Windows.Forms.Label lblHistoryList;
            System.Windows.Forms.Label lblTasksList;
            System.Windows.Forms.Label lblTemplateLis;
            System.Windows.Forms.Label lblName;
            System.Windows.Forms.Label lblInfo;
            this.lstWebLists = new System.Windows.Forms.ComboBox();
            this.lstWorkflowTemplates = new System.Windows.Forms.ComboBox();
            this.lstHistoryList = new System.Windows.Forms.ComboBox();
            this.lstTaskList = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lstAssociations = new System.Windows.Forms.ComboBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.grpAssociation = new System.Windows.Forms.GroupBox();
            lblLists = new System.Windows.Forms.Label();
            lblHistoryList = new System.Windows.Forms.Label();
            lblTasksList = new System.Windows.Forms.Label();
            lblTemplateLis = new System.Windows.Forms.Label();
            lblName = new System.Windows.Forms.Label();
            lblInfo = new System.Windows.Forms.Label();
            this.grpAssociation.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstWebLists
            // 
            this.lstWebLists.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstWebLists.DisplayMember = "Title";
            this.lstWebLists.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstWebLists.FormattingEnabled = true;
            this.lstWebLists.Location = new System.Drawing.Point(37, 4);
            this.lstWebLists.Name = "lstWebLists";
            this.lstWebLists.Size = new System.Drawing.Size(240, 21);
            this.lstWebLists.TabIndex = 4;
            this.lstWebLists.ValueMember = "ID";
            this.lstWebLists.SelectedIndexChanged += new System.EventHandler(this.SelectedListChanged);
            // 
            // lstWorkflowTemplates
            // 
            this.lstWorkflowTemplates.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstWorkflowTemplates.DisplayMember = "Name";
            this.lstWorkflowTemplates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstWorkflowTemplates.FormattingEnabled = true;
            this.lstWorkflowTemplates.Location = new System.Drawing.Point(70, 56);
            this.lstWorkflowTemplates.Name = "lstWorkflowTemplates";
            this.lstWorkflowTemplates.Size = new System.Drawing.Size(197, 21);
            this.lstWorkflowTemplates.TabIndex = 3;
            this.lstWorkflowTemplates.ValueMember = "Id";
            // 
            // lstHistoryList
            // 
            this.lstHistoryList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstHistoryList.FormattingEnabled = true;
            this.lstHistoryList.Location = new System.Drawing.Point(70, 152);
            this.lstHistoryList.Name = "lstHistoryList";
            this.lstHistoryList.Size = new System.Drawing.Size(197, 21);
            this.lstHistoryList.TabIndex = 7;
            // 
            // lstTaskList
            // 
            this.lstTaskList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstTaskList.FormattingEnabled = true;
            this.lstTaskList.Location = new System.Drawing.Point(70, 125);
            this.lstTaskList.Name = "lstTaskList";
            this.lstTaskList.Size = new System.Drawing.Size(197, 21);
            this.lstTaskList.TabIndex = 6;
            // 
            // txtName
            // 
            this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtName.Location = new System.Drawing.Point(70, 30);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(197, 20);
            this.txtName.TabIndex = 5;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.Location = new System.Drawing.Point(192, 237);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 8;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lstAssociations
            // 
            this.lstAssociations.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstAssociations.DisplayMember = "Name";
            this.lstAssociations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstAssociations.FormattingEnabled = true;
            this.lstAssociations.Location = new System.Drawing.Point(123, 38);
            this.lstAssociations.Name = "lstAssociations";
            this.lstAssociations.Size = new System.Drawing.Size(148, 21);
            this.lstAssociations.TabIndex = 9;
            this.lstAssociations.SelectedIndexChanged += new System.EventHandler(this.SelectedAssociationChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Location = new System.Drawing.Point(111, 237);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // grpAssociation
            // 
            this.grpAssociation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpAssociation.Controls.Add(lblInfo);
            this.grpAssociation.Controls.Add(lblHistoryList);
            this.grpAssociation.Controls.Add(this.txtName);
            this.grpAssociation.Controls.Add(lblTasksList);
            this.grpAssociation.Controls.Add(this.btnDelete);
            this.grpAssociation.Controls.Add(lblTemplateLis);
            this.grpAssociation.Controls.Add(lblName);
            this.grpAssociation.Controls.Add(this.lstHistoryList);
            this.grpAssociation.Controls.Add(this.lstWorkflowTemplates);
            this.grpAssociation.Controls.Add(this.btnUpdate);
            this.grpAssociation.Controls.Add(this.lstTaskList);
            this.grpAssociation.Location = new System.Drawing.Point(4, 43);
            this.grpAssociation.Name = "grpAssociation";
            this.grpAssociation.Size = new System.Drawing.Size(273, 266);
            this.grpAssociation.TabIndex = 11;
            this.grpAssociation.TabStop = false;
            this.grpAssociation.Text = "Workflow Association";
            // 
            // lblLists
            // 
            lblLists.AutoSize = true;
            lblLists.Location = new System.Drawing.Point(3, 7);
            lblLists.Name = "lblLists";
            lblLists.Size = new System.Drawing.Size(28, 13);
            lblLists.TabIndex = 12;
            lblLists.Text = "Lists";
            // 
            // lblHistoryList
            // 
            lblHistoryList.AutoSize = true;
            lblHistoryList.Location = new System.Drawing.Point(6, 155);
            lblHistoryList.Name = "lblHistoryList";
            lblHistoryList.Size = new System.Drawing.Size(58, 13);
            lblHistoryList.TabIndex = 16;
            lblHistoryList.Text = "History List";
            // 
            // lblTasksList
            // 
            lblTasksList.AutoSize = true;
            lblTasksList.Location = new System.Drawing.Point(6, 128);
            lblTasksList.Name = "lblTasksList";
            lblTasksList.Size = new System.Drawing.Size(55, 13);
            lblTasksList.TabIndex = 15;
            lblTasksList.Text = "Tasks List";
            // 
            // lblTemplateLis
            // 
            lblTemplateLis.AutoSize = true;
            lblTemplateLis.Location = new System.Drawing.Point(6, 59);
            lblTemplateLis.Name = "lblTemplateLis";
            lblTemplateLis.Size = new System.Drawing.Size(51, 13);
            lblTemplateLis.TabIndex = 14;
            lblTemplateLis.Text = "Template";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new System.Drawing.Point(6, 33);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(35, 13);
            lblName.TabIndex = 13;
            lblName.Text = "Name";
            // 
            // lblInfo
            // 
            lblInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            lblInfo.Location = new System.Drawing.Point(67, 93);
            lblInfo.Name = "lblInfo";
            lblInfo.Size = new System.Drawing.Size(200, 29);
            lblInfo.TabIndex = 17;
            lblInfo.Text = "Select an existing list or enter the name of a new one.";
            lblInfo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // Association
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lstAssociations);
            this.Controls.Add(lblLists);
            this.Controls.Add(this.grpAssociation);
            this.Controls.Add(this.lstWebLists);
            this.Name = "Association";
            this.Size = new System.Drawing.Size(282, 312);
            this.grpAssociation.ResumeLayout(false);
            this.grpAssociation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox lstWebLists;
        private System.Windows.Forms.ComboBox lstWorkflowTemplates;
        private System.Windows.Forms.ComboBox lstHistoryList;
        private System.Windows.Forms.ComboBox lstTaskList;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ComboBox lstAssociations;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.GroupBox grpAssociation;
    }
}
