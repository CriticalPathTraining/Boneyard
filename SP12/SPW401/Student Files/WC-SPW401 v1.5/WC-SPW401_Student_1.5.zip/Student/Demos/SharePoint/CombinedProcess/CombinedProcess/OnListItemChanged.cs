﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities;
using System.Workflow.ComponentModel;
using System.Collections;
using Microsoft.SharePoint.Workflow;
using System.ComponentModel;

namespace CombinedProcess
{
	public class OnListItemChanged : HandleExternalEventActivity
	{
        public static DependencyProperty ExecutorProperty =
            DependencyProperty.Register("Executor", typeof(string), typeof(OnListItemChanged));
        public static DependencyProperty AfterPropertiesProperty =
            DependencyProperty.Register("AfterProperties", typeof(Hashtable), typeof(OnListItemChanged));
        public static DependencyProperty BeforePropertiesProperty =
            DependencyProperty.Register("BeforeProperties", typeof(Hashtable), typeof(OnListItemChanged));

        public OnListItemChanged()
        {
            this.InterfaceType = typeof(IListItemService);
            this.EventName = "OnItemChanged";
        }

        public string Executor
        {
            get { return (string)base.GetValue(ExecutorProperty); }
            set { base.SetValue(ExecutorProperty, value); }
        }
        

        public Hashtable BeforeProperties
        {
            get { return (Hashtable)base.GetValue(BeforePropertiesProperty); }
            set { base.SetValue(BeforePropertiesProperty, value); }
        }
        
        public Hashtable AfterProperties
        {
            get { return (Hashtable)base.GetValue(AfterPropertiesProperty); }
            set { base.SetValue(AfterPropertiesProperty, value); }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public override Type InterfaceType
        {
            get { return base.InterfaceType; }
            set { base.InterfaceType = value; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public override string EventName
        {
            get { return base.EventName; }
            set { base.EventName = value; }
        }

        protected override void OnInvoked(EventArgs e)
        {
            SPListItemServiceEventArgs args = (SPListItemServiceEventArgs)e;            
            this.Executor = args.executor;
            this.BeforeProperties = args.beforeProperties;
            this.AfterProperties = args.afterProperties;         
        }       
	}
}
