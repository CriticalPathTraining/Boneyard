﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint.Workflow;

namespace CombinedProcess
{
    public partial class CreateListItemActivity : CallExternalMethodActivity
    {
        public static DependencyProperty ListIdProperty =
          DependencyProperty.Register("ListId", typeof(Guid), typeof(CreateListItemActivity));
        public static DependencyProperty ItemIdProperty =
            DependencyProperty.Register("ItemId", typeof(Guid), typeof(CreateListItemActivity));
        public static DependencyProperty ItemPropertiesProperty =
            DependencyProperty.Register("ItemProperties", typeof(Hashtable), typeof(CreateListItemActivity));

        public CreateListItemActivity()
        {
            this.InterfaceType = typeof(IListItemService);
            this.MethodName = "UpdateListItem";
        }        

        public Guid ListId
        {
            get { return (Guid)base.GetValue(ListIdProperty); }
            set { base.SetValue(ListIdProperty, value); }
        }

        public Guid ItemId
        {
            get { return (Guid)base.GetValue(ItemIdProperty); }
            set { base.SetValue(ItemIdProperty, value); }
        }

        public Hashtable ItemProperties
        {
            get { return (Hashtable)base.GetValue(ItemPropertiesProperty); }
            set { base.SetValue(ItemPropertiesProperty, value); }
        }

        public int ListItemId;

        [NonSerialized]
        private IListItemService _listItemService;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public override Type InterfaceType
        {
            get { return base.InterfaceType; }
            set { base.InterfaceType = value; }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        [Browsable(false)]
        public override string MethodName
        {
            get { return base.MethodName; }
            set { base.MethodName = value; }
        }

        protected override void OnActivityExecutionContextLoad(IServiceProvider provider)
        {
            _listItemService = provider.GetService(typeof(IListItemService)) as IListItemService;

            if (_listItemService == null) 
                throw new ArgumentException("Can't access IListItemService from provider");

        }

        protected override void OnMethodInvoking(EventArgs e)
        {
            // create the list item first
            this.ListItemId = _listItemService.CreateListItem(
                this.ItemId, this.ListId, -1, this.ItemProperties);

            base.ParameterBindings["id"].Value = this.ItemId ;
            base.ParameterBindings["itemId"].Value = this.ListItemId;
            base.ParameterBindings["listId"].Value = this.ListId;
            base.ParameterBindings["itemProperties"].Value = this.ItemProperties;

            base.OnMethodInvoking(e);
        }
    }
}
