﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace WssInfoPathFormsWorkflow
{
    partial class Workflow
    {
		#region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference2 = new System.Workflow.Activities.Rules.RuleConditionReference();
          System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
          System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
          this.MoveOnTaskRejected = new System.Workflow.Activities.SetStateActivity();
          this.LogRejected = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.MoveOnTaskApproved = new System.Workflow.Activities.SetStateActivity();
          this.LogApproval = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
          this.ifTaskRejected = new System.Workflow.Activities.IfElseBranchActivity();
          this.ifTaskApproved = new System.Workflow.Activities.IfElseBranchActivity();
          this.checkTaskResult = new System.Workflow.Activities.IfElseActivity();
          this.onTaskChanged1 = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
          this.completeTask1 = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
          this.createTask1 = new Microsoft.SharePoint.WorkflowActions.CreateTask();
          this.MoveToCompleted = new System.Workflow.Activities.SetStateActivity();
          this.onWorkflowActivated1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
          this.WaitForTaskChange = new System.Workflow.Activities.EventDrivenActivity();
          this.WaitOnTaskfinal = new System.Workflow.Activities.StateFinalizationActivity();
          this.WaitOnTaskInit = new System.Workflow.Activities.StateInitializationActivity();
          this.WorkflowActivated = new System.Workflow.Activities.EventDrivenActivity();
          this.WaitOnTask = new System.Workflow.Activities.StateActivity();
          this.CompletedState = new System.Workflow.Activities.StateActivity();
          this.InitialState = new System.Workflow.Activities.StateActivity();
          // 
          // MoveOnTaskRejected
          // 
          this.MoveOnTaskRejected.Name = "MoveOnTaskRejected";
          this.MoveOnTaskRejected.TargetStateName = "CompletedState";
          // 
          // LogRejected
          // 
          this.LogRejected.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.LogRejected.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.LogRejected.HistoryDescription = "Rejected";
          activitybind1.Name = "Workflow";
          activitybind1.Path = "InitData.Instructions";
          this.LogRejected.Name = "LogRejected";
          this.LogRejected.OtherData = "";
          this.LogRejected.UserId = -1;
          this.LogRejected.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
          // 
          // MoveOnTaskApproved
          // 
          this.MoveOnTaskApproved.Name = "MoveOnTaskApproved";
          this.MoveOnTaskApproved.TargetStateName = "CompletedState";
          // 
          // LogApproval
          // 
          this.LogApproval.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
          this.LogApproval.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
          this.LogApproval.HistoryDescription = "Approved";
          activitybind2.Name = "Workflow";
          activitybind2.Path = "InitData.Instructions";
          this.LogApproval.Name = "LogApproval";
          this.LogApproval.OtherData = "";
          this.LogApproval.UserId = -1;
          this.LogApproval.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
          // 
          // ifTaskRejected
          // 
          this.ifTaskRejected.Activities.Add(this.LogRejected);
          this.ifTaskRejected.Activities.Add(this.MoveOnTaskRejected);
          ruleconditionreference1.ConditionName = "IsTaskRejected";
          this.ifTaskRejected.Condition = ruleconditionreference1;
          this.ifTaskRejected.Name = "ifTaskRejected";
          // 
          // ifTaskApproved
          // 
          this.ifTaskApproved.Activities.Add(this.LogApproval);
          this.ifTaskApproved.Activities.Add(this.MoveOnTaskApproved);
          ruleconditionreference2.ConditionName = "IsTaskApproved";
          this.ifTaskApproved.Condition = ruleconditionreference2;
          this.ifTaskApproved.Name = "ifTaskApproved";
          // 
          // checkTaskResult
          // 
          this.checkTaskResult.Activities.Add(this.ifTaskApproved);
          this.checkTaskResult.Activities.Add(this.ifTaskRejected);
          this.checkTaskResult.Name = "checkTaskResult";
          // 
          // onTaskChanged1
          // 
          this.onTaskChanged1.AfterProperties = null;
          this.onTaskChanged1.BeforeProperties = null;
          correlationtoken1.Name = "taskToken";
          correlationtoken1.OwnerActivityName = "Workflow";
          this.onTaskChanged1.CorrelationToken = correlationtoken1;
          this.onTaskChanged1.Executor = null;
          this.onTaskChanged1.Name = "onTaskChanged1";
          activitybind3.Name = "Workflow";
          activitybind3.Path = "TaskId";
          this.onTaskChanged1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnTaskChanged_Invoked);
          this.onTaskChanged1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
          // 
          // completeTask1
          // 
          this.completeTask1.CorrelationToken = correlationtoken1;
          this.completeTask1.Name = "completeTask1";
          activitybind4.Name = "Workflow";
          activitybind4.Path = "TaskId";
          activitybind5.Name = "Workflow";
          activitybind5.Path = "TaskResult";
          this.completeTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
          this.completeTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
          // 
          // createTask1
          // 
          this.createTask1.CorrelationToken = correlationtoken1;
          this.createTask1.ListItemId = -1;
          this.createTask1.Name = "createTask1";
          this.createTask1.SpecialPermissions = null;
          activitybind6.Name = "Workflow";
          activitybind6.Path = "TaskId";
          this.createTask1.TaskProperties = null;
          this.createTask1.MethodInvoking += new System.EventHandler(this.CreateTask_MethodInvoking);
          this.createTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
          // 
          // MoveToCompleted
          // 
          this.MoveToCompleted.Name = "MoveToCompleted";
          this.MoveToCompleted.TargetStateName = "WaitOnTask";
          // 
          // onWorkflowActivated1
          // 
          correlationtoken2.Name = "workflowToken";
          correlationtoken2.OwnerActivityName = "Workflow";
          this.onWorkflowActivated1.CorrelationToken = correlationtoken2;
          this.onWorkflowActivated1.EventName = "OnWorkflowActivated";
          this.onWorkflowActivated1.Name = "onWorkflowActivated1";
          this.onWorkflowActivated1.WorkflowProperties = null;
          this.onWorkflowActivated1.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.OnWorkflowActivated_Invoked);
          // 
          // WaitForTaskChange
          // 
          this.WaitForTaskChange.Activities.Add(this.onTaskChanged1);
          this.WaitForTaskChange.Activities.Add(this.checkTaskResult);
          this.WaitForTaskChange.Name = "WaitForTaskChange";
          // 
          // WaitOnTaskfinal
          // 
          this.WaitOnTaskfinal.Activities.Add(this.completeTask1);
          this.WaitOnTaskfinal.Name = "WaitOnTaskfinal";
          // 
          // WaitOnTaskInit
          // 
          this.WaitOnTaskInit.Activities.Add(this.createTask1);
          this.WaitOnTaskInit.Name = "WaitOnTaskInit";
          // 
          // WorkflowActivated
          // 
          this.WorkflowActivated.Activities.Add(this.onWorkflowActivated1);
          this.WorkflowActivated.Activities.Add(this.MoveToCompleted);
          this.WorkflowActivated.Name = "WorkflowActivated";
          // 
          // WaitOnTask
          // 
          this.WaitOnTask.Activities.Add(this.WaitOnTaskInit);
          this.WaitOnTask.Activities.Add(this.WaitOnTaskfinal);
          this.WaitOnTask.Activities.Add(this.WaitForTaskChange);
          this.WaitOnTask.Name = "WaitOnTask";
          // 
          // CompletedState
          // 
          this.CompletedState.Name = "CompletedState";
          // 
          // InitialState
          // 
          this.InitialState.Activities.Add(this.WorkflowActivated);
          this.InitialState.Name = "InitialState";
          // 
          // Workflow
          // 
          this.Activities.Add(this.InitialState);
          this.Activities.Add(this.CompletedState);
          this.Activities.Add(this.WaitOnTask);
          this.CompletedStateName = "CompletedState";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "InitialState";
          this.Name = "Workflow";
          this.CanModifyActivities = false;

        }

        #endregion

        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated OnWorkflowActivated;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask CompleteTask;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged OnTaskChanged;
        private Microsoft.SharePoint.WorkflowActions.CreateTask CreateTask;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogApproval;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity LogRejected;
        private Microsoft.SharePoint.WorkflowActions.OnTaskChanged onTaskChanged1;
        private Microsoft.SharePoint.WorkflowActions.CompleteTask completeTask1;
        private Microsoft.SharePoint.WorkflowActions.CreateTask createTask1;
        private IfElseBranchActivity ifTaskRejected;
        private IfElseBranchActivity ifTaskApproved;
        private IfElseActivity checkTaskResult;
        private SetStateActivity MoveOnTaskRejected;
        private SetStateActivity MoveOnTaskApproved;
        private EventDrivenActivity WorkflowActivated;
        private StateActivity CompletedState;
        private SetStateActivity MoveToCompleted;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated1;
        private StateActivity WaitOnTask;
        private EventDrivenActivity WaitForTaskChange;
        private StateFinalizationActivity WaitOnTaskfinal;
        private StateInitializationActivity WaitOnTaskInit;
        private StateActivity InitialState;








    }
}
