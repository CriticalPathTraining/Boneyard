﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.SharePoint;
using System.Collections;
using Microsoft.SharePoint.Workflow;
using System.Globalization;

namespace SharePointWFAPI
{
    public partial class Initiation : UserControl
    {
        private SPWeb m_web;
        
        public Initiation()
        {
            InitializeComponent();
        }

        public void Initialize(SPWeb web)
        {
            m_web = web;

            PopulateComboBox(m_web.Lists, lstWebLists);            
        }

        private void SelectedListChanged(object sender, EventArgs e)
        {
            SPList list = lstWebLists.SelectedItem as SPList;
            PopulateComboBox(list.Items, lstListItems);
            PopulateComboBox(list.WorkflowAssociations, lstAssociations);

            if ((lstListItems.Items.Count == 0) || (lstAssociations.Items.Count == 0))
                grpAssociation.Enabled = false;
        }

        private void PopulateComboBox(IEnumerable dataSource, ComboBox control)
        {
            control.Items.Clear();
            if (dataSource != null)
                foreach (object item in dataSource)
                    control.Items.Add(item);
            if (control.Items.Count != 0)
                control.SelectedIndex = 0;
        }

        private void SelectedListItemChanged(object sender, EventArgs e)
        {           
            SPListItem listItem = lstListItems.SelectedItem as SPListItem;
            SPWorkflowAssociation association = lstAssociations.SelectedItem as SPWorkflowAssociation;            

            grpAssociation.Enabled = false;
            if ((listItem != null) && (association != null))
            {
                SPWorkflow workflow = listItem.Workflows.Cast<SPWorkflow>().FirstOrDefault(
                    n => n.AssociationId == association.Id && n.InternalState == SPWorkflowState.Running);

                if (workflow == null)
                    grpAssociation.Enabled = true;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            SPListItem listItem = lstListItems.SelectedItem as SPListItem;
            SPWorkflowAssociation association = lstAssociations.SelectedItem as SPWorkflowAssociation;

            m_web.Site.WorkflowManager.StartWorkflow(listItem, association, txtInitiationData.Text, true);
            
            MessageBox.Show(this, "Workflow started");
            txtInitiationData.Text = string.Empty;

            SelectedListChanged(lstWebLists, EventArgs.Empty);
        }
    }
}
