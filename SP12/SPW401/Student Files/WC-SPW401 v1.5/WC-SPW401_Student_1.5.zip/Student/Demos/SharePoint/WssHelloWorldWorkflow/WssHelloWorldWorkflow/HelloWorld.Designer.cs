﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace WssHelloWorldWorkflow
{
	partial class HelloWorld
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
            this.onWorkflowItemDeleted = new Microsoft.SharePoint.WorkflowActions.OnWorkflowItemDeleted();
            this.onWorkflowItemChanged = new Microsoft.SharePoint.WorkflowActions.OnWorkflowItemChanged();
            this.logEvent = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.onWorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
            // 
            // onWorkflowItemDeleted
            // 
            correlationtoken1.Name = "workflowToken";
            correlationtoken1.OwnerActivityName = "HelloWorld";
            this.onWorkflowItemDeleted.CorrelationToken = correlationtoken1;
            this.onWorkflowItemDeleted.Name = "onWorkflowItemDeleted";
            // 
            // onWorkflowItemChanged
            // 
            this.onWorkflowItemChanged.AfterProperties = null;
            this.onWorkflowItemChanged.BeforeProperties = null;
            this.onWorkflowItemChanged.CorrelationToken = correlationtoken1;
            this.onWorkflowItemChanged.Name = "onWorkflowItemChanged";
            // 
            // logEvent
            // 
            this.logEvent.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.logEvent.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.logEvent.HistoryDescription = "Hello World";
            this.logEvent.HistoryOutcome = "";
            this.logEvent.Name = "logEvent";
            this.logEvent.OtherData = "";
            this.logEvent.UserId = -1;
            // 
            // onWorkflowActivated
            // 
            this.onWorkflowActivated.CorrelationToken = correlationtoken1;
            this.onWorkflowActivated.EventName = "OnWorkflowActivated";
            this.onWorkflowActivated.Name = "onWorkflowActivated";
            this.onWorkflowActivated.WorkflowProperties = null;
            // 
            // HelloWorld
            // 
            this.Activities.Add(this.onWorkflowActivated);
            this.Activities.Add(this.logEvent);
            this.Activities.Add(this.onWorkflowItemChanged);
            this.Activities.Add(this.onWorkflowItemDeleted);
            this.Name = "HelloWorld";
            this.CanModifyActivities = false;

		}

		#endregion

        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowItemDeleted onWorkflowItemDeleted;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowItemChanged onWorkflowItemChanged;
        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logEvent;



    }
}
