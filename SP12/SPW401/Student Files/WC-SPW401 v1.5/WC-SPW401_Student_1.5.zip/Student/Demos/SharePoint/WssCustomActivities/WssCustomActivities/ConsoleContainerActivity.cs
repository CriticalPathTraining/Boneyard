﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Compiler;
using System.ComponentModel;
using System.Workflow.ComponentModel.Design;

namespace WssCustomActivities
{
  [ActivityValidator(typeof(ConsoleContainerActivityValidator))]
  [Designer(typeof(ConsoleContainerActivityDesigner))]
  [ToolboxItem(typeof(ConsoleContainerActivityToolboxItem))]
  public class ConsoleContainerActivity : SequenceActivity,
          IActivityEventListener<ActivityExecutionStatusChangedEventArgs>
  {
    protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
    {
      if (executionContext == null)
        throw new ArgumentNullException("executionContext");

      // check if there's any activities to execute
      if (base.EnabledActivities.Count == 0)
      {
        this.OnSequenceComplete(executionContext);
        return ActivityExecutionStatus.Closed;
      }

      // start the first child activity and register for it's state change event
      base.EnabledActivities[0].RegisterForStatusChange(Activity.ClosedEvent, this);
      executionContext.ExecuteActivity(base.EnabledActivities[0]);

      // tell the runtime this activity is still executing
      return ActivityExecutionStatus.Executing;
    }

    public void OnEvent(object sender, ActivityExecutionStatusChangedEventArgs e)
    {
      ActivityExecutionContext executionContext = sender as ActivityExecutionContext;

      // verify the type of activity received
      ConsoleContainerActivity activity = executionContext.Activity as ConsoleContainerActivity;
      if (activity == null)
        throw new ArgumentException("sender");

      // unregister the handler for status events
      e.Activity.UnregisterForStatusChange(Activity.ClosedEvent, this);

      // if the activity is cancelling or faulting, cleanup
      if ((activity.ExecutionStatus == ActivityExecutionStatus.Canceling) || (activity.ExecutionStatus == ActivityExecutionStatus.Faulting))
      {
        executionContext.CloseActivity();
      }
      // if the activity is executi, schedule the next child
      else if (activity.ExecutionStatus == ActivityExecutionStatus.Executing)
      {
        // if no more children exist
        if (!this.TryScheduleNextChild(executionContext))
        {
          //base.RemoveProperty(ActiveChildQualifiedNameProperty);
          executionContext.CloseActivity();
        }
      }
    }

    private bool TryScheduleNextChild(ActivityExecutionContext executionContext)
    {
      // check if any activities are in the list
      if (base.EnabledActivities.Count == 0)
        return false;

      // find the last activity in the list that is closed
      Activity lastClosedActivity = base.EnabledActivities.LastOrDefault(
          n => n.ExecutionStatus == ActivityExecutionStatus.Closed);

      // if this is the last closed activity, return false
      if (lastClosedActivity == base.EnabledActivities[base.EnabledActivities.Count - 1])
        return false;

      // startup the next activity
      Activity nextActivity = base.EnabledActivities[
          base.EnabledActivities.IndexOf(lastClosedActivity) + 1];
      nextActivity.RegisterForStatusChange(Activity.ClosedEvent, this);
      executionContext.ExecuteActivity(nextActivity);
      return true;
    }
  }
}
