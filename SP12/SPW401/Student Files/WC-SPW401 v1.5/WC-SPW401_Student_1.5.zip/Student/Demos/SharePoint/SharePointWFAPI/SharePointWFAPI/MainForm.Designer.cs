﻿namespace SharePointWFAPI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabAssociation = new System.Windows.Forms.TabPage();
            this.tabInitiation = new System.Windows.Forms.TabPage();
            this.ctlAssociation = new SharePointWFAPI.Association();
            this.ctlInitiation = new SharePointWFAPI.Initiation();
            this.tabWorkflow = new System.Windows.Forms.TabPage();
            this.ctlWorkflow = new SharePointWFAPI.Workflow();
            this.tabControl.SuspendLayout();
            this.tabAssociation.SuspendLayout();
            this.tabInitiation.SuspendLayout();
            this.tabWorkflow.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabAssociation);
            this.tabControl.Controls.Add(this.tabInitiation);
            this.tabControl.Controls.Add(this.tabWorkflow);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(292, 346);
            this.tabControl.TabIndex = 1;
            // 
            // tabAssociation
            // 
            this.tabAssociation.Controls.Add(this.ctlAssociation);
            this.tabAssociation.Location = new System.Drawing.Point(4, 22);
            this.tabAssociation.Name = "tabAssociation";
            this.tabAssociation.Padding = new System.Windows.Forms.Padding(3);
            this.tabAssociation.Size = new System.Drawing.Size(284, 320);
            this.tabAssociation.TabIndex = 0;
            this.tabAssociation.Text = "Association";
            this.tabAssociation.UseVisualStyleBackColor = true;
            // 
            // tabInitiation
            // 
            this.tabInitiation.Controls.Add(this.ctlInitiation);
            this.tabInitiation.Location = new System.Drawing.Point(4, 22);
            this.tabInitiation.Name = "tabInitiation";
            this.tabInitiation.Padding = new System.Windows.Forms.Padding(3);
            this.tabInitiation.Size = new System.Drawing.Size(284, 320);
            this.tabInitiation.TabIndex = 1;
            this.tabInitiation.Text = "Initiation";
            this.tabInitiation.UseVisualStyleBackColor = true;
            // 
            // ctlAssociation
            // 
            this.ctlAssociation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlAssociation.Location = new System.Drawing.Point(3, 3);
            this.ctlAssociation.Name = "ctlAssociation";
            this.ctlAssociation.Size = new System.Drawing.Size(278, 314);
            this.ctlAssociation.TabIndex = 1;
            // 
            // ctlInitiation
            // 
            this.ctlInitiation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlInitiation.Location = new System.Drawing.Point(3, 3);
            this.ctlInitiation.Name = "ctlInitiation";
            this.ctlInitiation.Size = new System.Drawing.Size(278, 314);
            this.ctlInitiation.TabIndex = 0;
            // 
            // tabWorkflow
            // 
            this.tabWorkflow.Controls.Add(this.ctlWorkflow);
            this.tabWorkflow.Location = new System.Drawing.Point(4, 22);
            this.tabWorkflow.Name = "tabWorkflow";
            this.tabWorkflow.Padding = new System.Windows.Forms.Padding(3);
            this.tabWorkflow.Size = new System.Drawing.Size(284, 320);
            this.tabWorkflow.TabIndex = 2;
            this.tabWorkflow.Text = "Workflow Instances";
            this.tabWorkflow.UseVisualStyleBackColor = true;
            // 
            // ctlWorkflow
            // 
            this.ctlWorkflow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctlWorkflow.Location = new System.Drawing.Point(3, 3);
            this.ctlWorkflow.Name = "ctlWorkflow";
            this.ctlWorkflow.Size = new System.Drawing.Size(278, 314);
            this.ctlWorkflow.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 346);
            this.Controls.Add(this.tabControl);
            this.Name = "MainForm";
            this.Text = "Workflow API Demo";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabControl.ResumeLayout(false);
            this.tabAssociation.ResumeLayout(false);
            this.tabInitiation.ResumeLayout(false);
            this.tabWorkflow.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabAssociation;
        private System.Windows.Forms.TabPage tabInitiation;
        private Association ctlAssociation;
        private Initiation ctlInitiation;
        private System.Windows.Forms.TabPage tabWorkflow;
        private Workflow ctlWorkflow;
    }
}

