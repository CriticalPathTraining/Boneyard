﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace WssCustomActivitiesConsole
{
	partial class Workflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
      this.CanModifyActivities = true;
      System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
      this.writeConsoleActivity1 = new WssCustomActivities.WriteConsoleActivity();
      this.consoleContainerActivity1 = new WssCustomActivities.ConsoleContainerActivity();
      // 
      // writeConsoleActivity1
      // 
      activitybind1.Name = "Workflow";
      activitybind1.Path = "Message";
      this.writeConsoleActivity1.Name = "writeConsoleActivity1";
      this.writeConsoleActivity1.Invoking += new System.EventHandler(this.Activity_Invoking);
      this.writeConsoleActivity1.SetBinding(WssCustomActivities.WriteConsoleActivity.MessageProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
      // 
      // consoleContainerActivity1
      // 
      this.consoleContainerActivity1.Activities.Add(this.writeConsoleActivity1);
      this.consoleContainerActivity1.Name = "consoleContainerActivity1";
      // 
      // Workflow
      // 
      this.Activities.Add(this.consoleContainerActivity1);
      this.Name = "Workflow";
      this.CanModifyActivities = false;

		}

		#endregion

        private WssCustomActivities.ConsoleContainerActivity consoleContainerActivity1;
        private WssCustomActivities.WriteConsoleActivity writeConsoleActivity1;


















  }
}
