﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Compiler;
using System.ComponentModel;

namespace WssCustomActivities
{
  [ActivityValidator(typeof(WriteConsoleActivityValidator))]
  [Designer(typeof(WriteConsoleActivityDesigner))]
  public class WriteConsoleActivity : Activity
  {
    public static DependencyProperty MessageProperty =
       DependencyProperty.RegisterAttached("Message", typeof(string), typeof(WriteConsoleActivity));

    public string Message
    {
      get { return base.GetValue(MessageProperty) as string; }
      set { base.SetValue(MessageProperty, value); }
    }

    public static DependencyProperty InvokingEvent =
        DependencyProperty.RegisterAttached("Invoking", typeof(EventHandler), typeof(WriteConsoleActivity));

    public event EventHandler Invoking
    {
      add { base.AddHandler(InvokingEvent, value); }
      remove { base.RemoveHandler(InvokingEvent, value); }
    }

    protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
    {
      // raise the bound event
      base.RaiseEvent(InvokingEvent, this, EventArgs.Empty);

      // write the value stored in the dependency property
      Console.WriteLine(this.Message);

      // tell the framework that this activity is done
      return ActivityExecutionStatus.Closed;
    }
  }
}
