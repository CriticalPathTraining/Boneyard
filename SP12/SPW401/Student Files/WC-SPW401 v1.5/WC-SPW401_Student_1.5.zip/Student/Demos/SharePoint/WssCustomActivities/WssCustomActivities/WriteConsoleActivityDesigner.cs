﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel;

namespace WssCustomActivities
{
  internal class WriteConsoleActivityDesigner : ActivityDesigner
  {
    /// <summary>
    /// Only allow a console container activity to be placed in a console container activity.
    /// </summary>
    /// <param name="parentActivityDesigner"></param>
    /// <returns></returns>
    public override bool CanBeParentedTo(CompositeActivityDesigner parentActivityDesigner)
    {
      return (parentActivityDesigner.Activity is ConsoleContainerActivity);
    }
  }
}
