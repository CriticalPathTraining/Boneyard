﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Diagnostics;

namespace WssCustomActivities
{
  public partial class WssLogErrorActivity : SequenceActivity
  {
    public WssLogErrorActivity()
    {
      InitializeComponent();
    }

    public static DependencyProperty MyErrorMessageProperty =
        DependencyProperty.Register("MyErrorMessage",
            typeof(System.String), typeof(WssCustomActivities.WssLogErrorActivity));

    [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
    [BrowsableAttribute(true)]
    [CategoryAttribute("Misc")]
    public String MyErrorMessage
    {
      get
      {
        return ((string)(base.GetValue(WssCustomActivities.WssLogErrorActivity.MyErrorMessageProperty)));
      }
      set
      {
        base.SetValue(WssCustomActivities.WssLogErrorActivity.MyErrorMessageProperty, value);
      }
    }
  }
}
