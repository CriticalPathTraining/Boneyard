﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;

namespace WssCustomFormsWorkflow.UI
{
  public class CustomFormsInitForm : LayoutsPageBase
  {
    private SPWorkflowAssociation _workflowAssociation;
    private SPList _list;
    private SPListItem _listItem;

    protected TextBox txtCustomData;

    protected string WorkflowName
    {
      get
      {
        return _workflowAssociation.Name;
      }
    }

    protected string ItemName
    {
      get
      {
        return _listItem.DisplayName;
      }
    }

    #region Page Event Handlers
    /// <summary>
    /// Read the parameters from the request and the UI.  Then find the workflow association in
    /// the list or the content type and use it to initialize the page.
    /// </summary>
    protected override void OnLoad(EventArgs e)
    {
      // read the form level parameters
      string listId = Request.Params["List"];
      string listItemId = Request.Params["ID"];
      string ctypeId = Request.Params["ctype"];
      string templateId = Request.Params["TemplateId"];

      // find the list and list item
      _list = Web.Lists[new Guid(listId)];
      _listItem = _list.GetItemById(int.Parse(listItemId));

      // check for the workflow association in the list
      _workflowAssociation = _list.WorkflowAssociations[new Guid(templateId)];

      // if the association wasn't found, check the content type
      if (_workflowAssociation == null)
      {
        SPContentType _contentType = _list.ContentTypes[new SPContentTypeId(ctypeId)];
        _workflowAssociation = _contentType.WorkflowAssociations[new Guid(templateId)];
      }

      // verify the workflow association could be found
      if (_workflowAssociation == null)
        throw new SPException("The requested workflow could not be found.");

      // bind the association data (if any)
      if (!IsPostBack && (_workflowAssociation != null))
      {
        // bind the controls to the association data
        AssociationData assocData = AssociationData.Deserialize(_workflowAssociation.AssociationData);
        txtCustomData.Text = assocData.DefaultCustomData;
      }

      // call the base implementation
      base.OnLoad(e);
    }
    #endregion

    #region Page Button Handlers
    /// <summary>
    /// Handle a cancel button click by redirecting list's default view.
    /// </summary>
    protected void Cancel_Click(object sender, EventArgs e)
    {
      // redirect to the list default view
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }

    /// <summary>
    /// Starts the workflow instance and navigates to the list's default view.
    /// </summary>
    protected void Start_Click(object sender, EventArgs e)
    {
      // serialize the initiation data
      InitiationData initiationData = new InitiationData();
      initiationData.CustomData = txtCustomData.Text;

      // start the new workflow instance
      Web.Site.WorkflowManager.StartWorkflow(_listItem, _workflowAssociation, initiationData.Serialize());

      // redirect to the list default view
      SPUtility.Redirect(_list.DefaultViewUrl, SPRedirectFlags.Default, this.Context);
    }
    #endregion
  }
}
