﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace WssCustomActivities
{
	public partial class WssLogErrorActivity
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            this.logToHistoryList = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            // 
            // logToHistoryList
            // 
            this.logToHistoryList.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.logToHistoryList.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            activitybind1.Name = "WssLogErrorActivity";
            activitybind1.Path = "MyErrorMessage";
            this.logToHistoryList.HistoryOutcome = "Critical Error";
            this.logToHistoryList.Name = "logToHistoryList";
            this.logToHistoryList.OtherData = "";
            this.logToHistoryList.UserId = -1;
            this.logToHistoryList.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // WssLogErrorActivity
            // 
            this.Activities.Add(this.logToHistoryList);
            this.Name = "WssLogErrorActivity";
            this.CanModifyActivities = false;

		}

		#endregion

        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logToHistoryList;




    }
}
