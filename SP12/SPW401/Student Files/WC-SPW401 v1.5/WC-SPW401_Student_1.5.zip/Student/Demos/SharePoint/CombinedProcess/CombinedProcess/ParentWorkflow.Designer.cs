﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace CombinedProcess
{
    partial class ParentWorkflow
    {
        #region Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
            this.CanModifyActivities = true;
            System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            this.setStateActivity1 = new System.Workflow.Activities.SetStateActivity();
            this.OnProcessingItemChanged = new CombinedProcess.OnListItemChanged();
            this.CreateProcessingItem = new CombinedProcess.CreateListItemActivity();
            this.setToProcessing = new System.Workflow.Activities.SetStateActivity();
            this.onWorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
            this.WaitForChildListItem = new System.Workflow.Activities.EventDrivenActivity();
            this.CreateChildListItem = new System.Workflow.Activities.StateInitializationActivity();
            this.workflowActivation = new System.Workflow.Activities.EventDrivenActivity();
            this.Processing = new System.Workflow.Activities.StateActivity();
            this.Finish = new System.Workflow.Activities.StateActivity();
            this.Start = new System.Workflow.Activities.StateActivity();
            // 
            // setStateActivity1
            // 
            this.setStateActivity1.Name = "setStateActivity1";
            this.setStateActivity1.TargetStateName = "Finish";
            // 
            // OnProcessingItemChanged
            // 
            this.OnProcessingItemChanged.AfterProperties = null;
            this.OnProcessingItemChanged.BeforeProperties = null;
            correlationtoken1.Name = "updateItemToken";
            correlationtoken1.OwnerActivityName = "Processing";
            this.OnProcessingItemChanged.CorrelationToken = correlationtoken1;
            this.OnProcessingItemChanged.Executor = null;
            this.OnProcessingItemChanged.Name = "OnProcessingItemChanged";
            // 
            // CreateProcessingItem
            // 
            this.CreateProcessingItem.CorrelationToken = correlationtoken1;
            activitybind1.Name = "ParentWorkflow";
            activitybind1.Path = "NewItemId";
            activitybind2.Name = "ParentWorkflow";
            activitybind2.Path = "NewItemProperties";
            activitybind3.Name = "ParentWorkflow";
            activitybind3.Path = "TargetListId";
            this.CreateProcessingItem.Name = "CreateProcessingItem";
            this.CreateProcessingItem.MethodInvoking += new System.EventHandler(this.CreateProcessingItem_Invoking);
            this.CreateProcessingItem.SetBinding(CombinedProcess.CreateListItemActivity.ItemIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            this.CreateProcessingItem.SetBinding(CombinedProcess.CreateListItemActivity.ItemPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            this.CreateProcessingItem.SetBinding(CombinedProcess.CreateListItemActivity.ListIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            // 
            // setToProcessing
            // 
            this.setToProcessing.Name = "setToProcessing";
            this.setToProcessing.TargetStateName = "Processing";
            // 
            // onWorkflowActivated
            // 
            correlationtoken2.Name = "workflowToken";
            correlationtoken2.OwnerActivityName = "ParentWorkflow";
            this.onWorkflowActivated.CorrelationToken = correlationtoken2;
            this.onWorkflowActivated.EventName = "OnWorkflowActivated";
            this.onWorkflowActivated.Name = "onWorkflowActivated";
            activitybind4.Name = "ParentWorkflow";
            activitybind4.Path = "WorkflowProperties";
            this.onWorkflowActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            // 
            // WaitForChildListItem
            // 
            this.WaitForChildListItem.Activities.Add(this.OnProcessingItemChanged);
            this.WaitForChildListItem.Activities.Add(this.setStateActivity1);
            this.WaitForChildListItem.Name = "WaitForChildListItem";
            // 
            // CreateChildListItem
            // 
            this.CreateChildListItem.Activities.Add(this.CreateProcessingItem);
            this.CreateChildListItem.Name = "CreateChildListItem";
            // 
            // workflowActivation
            // 
            this.workflowActivation.Activities.Add(this.onWorkflowActivated);
            this.workflowActivation.Activities.Add(this.setToProcessing);
            this.workflowActivation.Name = "workflowActivation";
            // 
            // Processing
            // 
            this.Processing.Activities.Add(this.CreateChildListItem);
            this.Processing.Activities.Add(this.WaitForChildListItem);
            this.Processing.Name = "Processing";
            // 
            // Finish
            // 
            this.Finish.Name = "Finish";
            // 
            // Start
            // 
            this.Start.Activities.Add(this.workflowActivation);
            this.Start.Name = "Start";
            // 
            // ParentWorkflow
            // 
            this.Activities.Add(this.Start);
            this.Activities.Add(this.Finish);
            this.Activities.Add(this.Processing);
            this.CompletedStateName = "Finish";
            this.DynamicUpdateCondition = null;
            this.InitialStateName = "Start";
            this.Name = "ParentWorkflow";
            this.CanModifyActivities = false;

        }

        #endregion

        private OnListItemChanged OnProcessingItemChanged;
        private CreateListItemActivity CreateProcessingItem;
        private SetStateActivity setStateActivity1;
        private SetStateActivity setToProcessing;
        private StateInitializationActivity CreateChildListItem;
        private EventDrivenActivity WaitForChildListItem;
        private StateActivity Finish;
        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated;
        private EventDrivenActivity workflowActivation;
        private StateActivity Processing;
        private StateActivity Start;






























































    }
}
