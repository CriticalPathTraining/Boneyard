﻿namespace SharePointWFAPI
{
    partial class Initiation
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblLists;
            System.Windows.Forms.Label lblListItems;
            this.lstWebLists = new System.Windows.Forms.ComboBox();
            this.lstAssociations = new System.Windows.Forms.ComboBox();
            this.grpAssociation = new System.Windows.Forms.GroupBox();
            this.txtInitiationData = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.lstListItems = new System.Windows.Forms.ComboBox();
            lblLists = new System.Windows.Forms.Label();
            lblListItems = new System.Windows.Forms.Label();
            this.grpAssociation.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLists
            // 
            lblLists.AutoSize = true;
            lblLists.Location = new System.Drawing.Point(3, 7);
            lblLists.Name = "lblLists";
            lblLists.Size = new System.Drawing.Size(28, 13);
            lblLists.TabIndex = 14;
            lblLists.Text = "Lists";
            // 
            // lblListItems
            // 
            lblListItems.AutoSize = true;
            lblListItems.Location = new System.Drawing.Point(3, 34);
            lblListItems.Name = "lblListItems";
            lblListItems.Size = new System.Drawing.Size(51, 13);
            lblListItems.TabIndex = 18;
            lblListItems.Text = "List Items";
            // 
            // lstWebLists
            // 
            this.lstWebLists.DisplayMember = "Title";
            this.lstWebLists.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstWebLists.FormattingEnabled = true;
            this.lstWebLists.Location = new System.Drawing.Point(60, 4);
            this.lstWebLists.Name = "lstWebLists";
            this.lstWebLists.Size = new System.Drawing.Size(214, 21);
            this.lstWebLists.TabIndex = 13;
            this.lstWebLists.ValueMember = "ID";
            this.lstWebLists.SelectedIndexChanged += new System.EventHandler(this.SelectedListChanged);
            // 
            // lstAssociations
            // 
            this.lstAssociations.DisplayMember = "Name";
            this.lstAssociations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstAssociations.FormattingEnabled = true;
            this.lstAssociations.Location = new System.Drawing.Point(122, 62);
            this.lstAssociations.Name = "lstAssociations";
            this.lstAssociations.Size = new System.Drawing.Size(148, 21);
            this.lstAssociations.TabIndex = 15;
            this.lstAssociations.SelectedIndexChanged += new System.EventHandler(this.SelectedListItemChanged);
            // 
            // grpAssociation
            // 
            this.grpAssociation.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpAssociation.Controls.Add(this.txtInitiationData);
            this.grpAssociation.Controls.Add(this.label1);
            this.grpAssociation.Controls.Add(this.btnStart);
            this.grpAssociation.Location = new System.Drawing.Point(3, 67);
            this.grpAssociation.Name = "grpAssociation";
            this.grpAssociation.Size = new System.Drawing.Size(273, 243);
            this.grpAssociation.TabIndex = 16;
            this.grpAssociation.TabStop = false;
            this.grpAssociation.Text = "Workflow Association";
            // 
            // txtInitiationData
            // 
            this.txtInitiationData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInitiationData.Location = new System.Drawing.Point(7, 37);
            this.txtInitiationData.Multiline = true;
            this.txtInitiationData.Name = "txtInitiationData";
            this.txtInitiationData.Size = new System.Drawing.Size(260, 171);
            this.txtInitiationData.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Initiation Data";
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.Location = new System.Drawing.Point(192, 214);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lstListItems
            // 
            this.lstListItems.DisplayMember = "Name";
            this.lstListItems.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.lstListItems.FormattingEnabled = true;
            this.lstListItems.Location = new System.Drawing.Point(60, 31);
            this.lstListItems.Name = "lstListItems";
            this.lstListItems.Size = new System.Drawing.Size(214, 21);
            this.lstListItems.TabIndex = 17;
            this.lstListItems.SelectedIndexChanged += new System.EventHandler(this.SelectedListItemChanged);
            // 
            // Initiation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(lblListItems);
            this.Controls.Add(this.lstListItems);
            this.Controls.Add(this.lstAssociations);
            this.Controls.Add(this.grpAssociation);
            this.Controls.Add(lblLists);
            this.Controls.Add(this.lstWebLists);
            this.Name = "Initiation";
            this.Size = new System.Drawing.Size(280, 313);
            this.grpAssociation.ResumeLayout(false);
            this.grpAssociation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox lstWebLists;
        private System.Windows.Forms.ComboBox lstAssociations;
        private System.Windows.Forms.GroupBox grpAssociation;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox lstListItems;
        private System.Windows.Forms.TextBox txtInitiationData;
        private System.Windows.Forms.Label label1;
    }
}
