﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel.Design;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace WssCustomActivities
{
  internal class ConsoleContainerActivityTheme : CompositeDesignerTheme
  {
    public ConsoleContainerActivityTheme(WorkflowTheme theme)
      : base(theme)
    {
      this.ShowDropShadow = true;
      this.BackColorStart = Color.Gray;
      this.BackColorEnd = Color.White;
    }
  }
}
