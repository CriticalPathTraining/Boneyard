﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace StateMachineWorkflow
{
    partial class Workflow
    {
        #region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding3 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding4 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          this.readLineSetState = new System.Workflow.Activities.SetStateActivity();
          this.writeData = new System.Workflow.Activities.CallExternalMethodActivity();
          this.endReadData = new System.Workflow.Activities.HandleExternalEventActivity();
          this.startReadData = new System.Workflow.Activities.CallExternalMethodActivity();
          this.shutdownSetState = new System.Workflow.Activities.SetStateActivity();
          this.writeCancelled = new System.Workflow.Activities.CallExternalMethodActivity();
          this.handleShutdown = new System.Workflow.Activities.HandleExternalEventActivity();
          this.waitForReadLine = new System.Workflow.Activities.EventDrivenActivity();
          this.stateInit = new System.Workflow.Activities.StateInitializationActivity();
          this.waitForShutdown = new System.Workflow.Activities.EventDrivenActivity();
          this.Completed = new System.Workflow.Activities.StateActivity();
          this.ReadData = new System.Workflow.Activities.StateActivity();
          // 
          // readLineSetState
          // 
          this.readLineSetState.Name = "readLineSetState";
          this.readLineSetState.TargetStateName = "Completed";
          // 
          // writeData
          // 
          this.writeData.InterfaceType = typeof(StateMachineWorkflow.IInputOutputService);
          this.writeData.MethodName = "WriteLine";
          this.writeData.Name = "writeData";
          activitybind1.Name = "Workflow";
          activitybind1.Path = "ReadLineResults.Result";
          workflowparameterbinding1.ParameterName = "message";
          workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
          this.writeData.ParameterBindings.Add(workflowparameterbinding1);
          // 
          // endReadData
          // 
          this.endReadData.EventName = "ReadLineCompleted";
          this.endReadData.InterfaceType = typeof(StateMachineWorkflow.IInputOutputService);
          this.endReadData.Name = "endReadData";
          activitybind2.Name = "Workflow";
          activitybind2.Path = "ReadLineResults";
          workflowparameterbinding2.ParameterName = "e";
          workflowparameterbinding2.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
          this.endReadData.ParameterBindings.Add(workflowparameterbinding2);
          // 
          // startReadData
          // 
          this.startReadData.InterfaceType = typeof(StateMachineWorkflow.IInputOutputService);
          this.startReadData.MethodName = "ReadLine";
          this.startReadData.Name = "startReadData";
          workflowparameterbinding3.ParameterName = "prompt";
          workflowparameterbinding3.Value = "Enter some data:";
          this.startReadData.ParameterBindings.Add(workflowparameterbinding3);
          // 
          // shutdownSetState
          // 
          this.shutdownSetState.Name = "shutdownSetState";
          this.shutdownSetState.TargetStateName = "Completed";
          // 
          // writeCancelled
          // 
          this.writeCancelled.InterfaceType = typeof(StateMachineWorkflow.IInputOutputService);
          this.writeCancelled.MethodName = "WriteLine";
          this.writeCancelled.Name = "writeCancelled";
          workflowparameterbinding4.ParameterName = "message";
          workflowparameterbinding4.Value = "The workflow was cancelled.";
          this.writeCancelled.ParameterBindings.Add(workflowparameterbinding4);
          // 
          // handleShutdown
          // 
          this.handleShutdown.EventName = "InputOutputShutdown";
          this.handleShutdown.InterfaceType = typeof(StateMachineWorkflow.IInputOutputService);
          this.handleShutdown.Name = "handleShutdown";
          // 
          // waitForReadLine
          // 
          this.waitForReadLine.Activities.Add(this.endReadData);
          this.waitForReadLine.Activities.Add(this.writeData);
          this.waitForReadLine.Activities.Add(this.readLineSetState);
          this.waitForReadLine.Name = "waitForReadLine";
          // 
          // stateInit
          // 
          this.stateInit.Activities.Add(this.startReadData);
          this.stateInit.Name = "stateInit";
          // 
          // waitForShutdown
          // 
          this.waitForShutdown.Activities.Add(this.handleShutdown);
          this.waitForShutdown.Activities.Add(this.writeCancelled);
          this.waitForShutdown.Activities.Add(this.shutdownSetState);
          this.waitForShutdown.Name = "waitForShutdown";
          // 
          // Completed
          // 
          this.Completed.Name = "Completed";
          // 
          // ReadData
          // 
          this.ReadData.Activities.Add(this.stateInit);
          this.ReadData.Activities.Add(this.waitForReadLine);
          this.ReadData.Name = "ReadData";
          // 
          // Workflow
          // 
          this.Activities.Add(this.ReadData);
          this.Activities.Add(this.Completed);
          this.Activities.Add(this.waitForShutdown);
          this.CompletedStateName = "Completed";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "ReadData";
          this.Name = "Workflow";
          this.CanModifyActivities = false;

        }

        #endregion

        private SetStateActivity readLineSetState;
        private CallExternalMethodActivity writeData;
        private SetStateActivity shutdownSetState;
        private CallExternalMethodActivity writeCancelled;
        private HandleExternalEventActivity handleShutdown;
        private EventDrivenActivity waitForShutdown;
        private HandleExternalEventActivity endReadData;
        private CallExternalMethodActivity startReadData;
        private EventDrivenActivity waitForReadLine;
        private StateInitializationActivity stateInit;
        private StateActivity Completed;
        private StateActivity ReadData;





























    }
}
