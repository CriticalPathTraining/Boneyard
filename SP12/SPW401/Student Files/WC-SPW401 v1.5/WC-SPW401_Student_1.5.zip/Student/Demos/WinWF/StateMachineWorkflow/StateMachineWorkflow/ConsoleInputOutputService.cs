﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.Threading;

namespace StateMachineWorkflow
{
  public class ConsoleInputOutputService : WorkflowRuntimeService, IInputOutputService
  {
    public Guid InstanceId { get; set; }

    protected override void OnStarted()
    {
      Console.CancelKeyPress += new ConsoleCancelEventHandler(Console_CancelKeyPress);
      base.OnStarted();
    }

    protected override void OnStopped()
    {
      Console.CancelKeyPress -= new ConsoleCancelEventHandler(Console_CancelKeyPress);
      base.OnStopped();
    }

    void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
    {
      if (InputOutputShutdown != null)
        InputOutputShutdown(null, new ExternalDataEventArgs(this.InstanceId));
      e.Cancel = true;
    }

    public event EventHandler<ReadLineEventArgs> ReadLineCompleted;
    public event EventHandler<ExternalDataEventArgs> InputOutputShutdown;

    public void WriteLine(string message)
    {
      Console.WriteLine(message);
    }

    public void ReadLine(string prompt)
    {
      Console.WriteLine(prompt);

      ThreadPool.QueueUserWorkItem(ReadLineWorker,
          new KeyValuePair<Guid, ConsoleInputOutputService>(WorkflowEnvironment.WorkflowInstanceId, this));
    }

    private static void ReadLineWorker(object state)
    {
      string result = Console.ReadLine();

      KeyValuePair<Guid, ConsoleInputOutputService> typedState = (KeyValuePair<Guid, ConsoleInputOutputService>)state;

      ConsoleInputOutputService service = typedState.Value as ConsoleInputOutputService;
      if ((service.ReadLineCompleted != null) && (result != null))
        service.ReadLineCompleted(null,
            new ReadLineEventArgs(typedState.Key, result));
    }
  }
}
