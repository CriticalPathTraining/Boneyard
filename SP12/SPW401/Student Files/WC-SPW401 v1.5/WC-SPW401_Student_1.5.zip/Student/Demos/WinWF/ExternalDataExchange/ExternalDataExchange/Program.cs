﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.Workflow.Activities;

namespace ExternalDataExchange
{
  class Program
  {
    static void Main(string[] args)
    {
      using (WorkflowRuntime workflowRuntime = new WorkflowRuntime())
      {
        AutoResetEvent waitHandle = new AutoResetEvent(false);
        workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) { waitHandle.Set(); };
        workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
        {
          Console.WriteLine(e.Exception.Message);
          waitHandle.Set();
        };

        workflowRuntime.AddService(new ExternalDataExchangeService());
        workflowRuntime.GetService<ExternalDataExchangeService>().AddService(new TimerService());
        workflowRuntime.GetService<ExternalDataExchangeService>().AddService(new CorrelatedTimerService());

        WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(ExternalDataExchange.TimerWorkflow));
        instance.Start();

        waitHandle.WaitOne();
      }
    }
  }
}
