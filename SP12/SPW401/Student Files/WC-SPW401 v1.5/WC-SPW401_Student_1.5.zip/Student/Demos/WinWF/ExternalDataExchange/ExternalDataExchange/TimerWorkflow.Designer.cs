﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace ExternalDataExchange
{
	partial class TimerWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding3 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding4 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding5 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding6 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            this.displayComplete2 = new System.Workflow.Activities.CodeActivity();
            this.onTimerComplete2 = new System.Workflow.Activities.HandleExternalEventActivity();
            this.startTime2 = new System.Workflow.Activities.CallExternalMethodActivity();
            this.displayComplete1 = new System.Workflow.Activities.CodeActivity();
            this.onTimerComplete1 = new System.Workflow.Activities.HandleExternalEventActivity();
            this.startTime1 = new System.Workflow.Activities.CallExternalMethodActivity();
            this.sequenceActivity2 = new System.Workflow.Activities.SequenceActivity();
            this.sequenceActivity1 = new System.Workflow.Activities.SequenceActivity();
            this.parallelActivity1 = new System.Workflow.Activities.ParallelActivity();
            // 
            // displayComplete2
            // 
            this.displayComplete2.Name = "displayComplete2";
            this.displayComplete2.ExecuteCode += new System.EventHandler(this.displayComplete2_ExecuteCode);
            // 
            // onTimerComplete2
            // 
            this.onTimerComplete2.EventName = "Complete";
            this.onTimerComplete2.InterfaceType = typeof(ExternalDataExchange.ITimerService);
            this.onTimerComplete2.Name = "onTimerComplete2";
            activitybind1.Name = "TimerWorkflow";
            activitybind1.Path = "TimerComplete2";
            workflowparameterbinding1.ParameterName = "e";
            workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            this.onTimerComplete2.ParameterBindings.Add(workflowparameterbinding1);
            // 
            // startTime2
            // 
            this.startTime2.InterfaceType = typeof(ExternalDataExchange.ITimerService);
            this.startTime2.MethodName = "StartTimer";
            this.startTime2.Name = "startTime2";
            workflowparameterbinding2.ParameterName = "delay";
            workflowparameterbinding2.Value = 1000;
            activitybind2.Name = "TimerWorkflow";
            activitybind2.Path = "TimerId2";
            workflowparameterbinding3.ParameterName = "TimerId";
            workflowparameterbinding3.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            this.startTime2.ParameterBindings.Add(workflowparameterbinding2);
            this.startTime2.ParameterBindings.Add(workflowparameterbinding3);
            // 
            // displayComplete1
            // 
            this.displayComplete1.Name = "displayComplete1";
            this.displayComplete1.ExecuteCode += new System.EventHandler(this.displayComplete1_ExecuteCode);
            // 
            // onTimerComplete1
            // 
            this.onTimerComplete1.EventName = "Complete";
            this.onTimerComplete1.InterfaceType = typeof(ExternalDataExchange.ITimerService);
            this.onTimerComplete1.Name = "onTimerComplete1";
            activitybind3.Name = "TimerWorkflow";
            activitybind3.Path = "TimerComplete1";
            workflowparameterbinding4.ParameterName = "e";
            workflowparameterbinding4.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            this.onTimerComplete1.ParameterBindings.Add(workflowparameterbinding4);
            // 
            // startTime1
            // 
            this.startTime1.InterfaceType = typeof(ExternalDataExchange.ITimerService);
            this.startTime1.MethodName = "StartTimer";
            this.startTime1.Name = "startTime1";
            workflowparameterbinding5.ParameterName = "delay";
            workflowparameterbinding5.Value = 5000;
            activitybind4.Name = "TimerWorkflow";
            activitybind4.Path = "TimerId1";
            workflowparameterbinding6.ParameterName = "TimerId";
            workflowparameterbinding6.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            this.startTime1.ParameterBindings.Add(workflowparameterbinding5);
            this.startTime1.ParameterBindings.Add(workflowparameterbinding6);
            // 
            // sequenceActivity2
            // 
            this.sequenceActivity2.Activities.Add(this.startTime2);
            this.sequenceActivity2.Activities.Add(this.onTimerComplete2);
            this.sequenceActivity2.Activities.Add(this.displayComplete2);
            this.sequenceActivity2.Name = "sequenceActivity2";
            // 
            // sequenceActivity1
            // 
            this.sequenceActivity1.Activities.Add(this.startTime1);
            this.sequenceActivity1.Activities.Add(this.onTimerComplete1);
            this.sequenceActivity1.Activities.Add(this.displayComplete1);
            this.sequenceActivity1.Name = "sequenceActivity1";
            // 
            // parallelActivity1
            // 
            this.parallelActivity1.Activities.Add(this.sequenceActivity1);
            this.parallelActivity1.Activities.Add(this.sequenceActivity2);
            this.parallelActivity1.Name = "parallelActivity1";
            // 
            // TimerWorkflow
            // 
            this.Activities.Add(this.parallelActivity1);
            this.Name = "TimerWorkflow";
            this.CanModifyActivities = false;

		}

		#endregion

        private CodeActivity displayComplete1;
        private HandleExternalEventActivity onTimerComplete1;
        private CodeActivity displayComplete2;
        private HandleExternalEventActivity onTimerComplete2;
        private CallExternalMethodActivity startTime2;
        private SequenceActivity sequenceActivity2;
        private SequenceActivity sequenceActivity1;
        private ParallelActivity parallelActivity1;
        private CallExternalMethodActivity startTime1;

















    }
}
