﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;

namespace DataBinding
{
  public class ConsoleReadActivity : Activity
  {
    public static readonly DependencyProperty ResultProperty =
      DependencyProperty.Register("Result", typeof(string), typeof(ConsoleReadActivity));

    public string Result
    {
      get { return (string)GetValue(ResultProperty); }
      set { SetValue(ResultProperty, value); }
    }

    protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
    {
      this.Result = Console.ReadLine();

      return base.Execute(executionContext);
    }
  }
}
