﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace DataBinding
{
	partial class WorkflowCode
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            this.writeData = new DataBinding.ConsoleWriteActivity();
            this.readData = new DataBinding.ConsoleReadActivity();
            this.prompt = new DataBinding.ConsoleWriteActivity();
            // 
            // writeData
            // 
            activitybind1.Name = "readData";
            activitybind1.Path = "Result";
            this.writeData.Name = "writeData";
            this.writeData.SetBinding(DataBinding.ConsoleWriteActivity.MessageProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // readData
            // 
            this.readData.Name = "readData";
            this.readData.Result = null;
            // 
            // prompt
            // 
            this.prompt.Message = "Enter some data:";
            this.prompt.Name = "prompt";
            // 
            // Workflow
            // 
            this.Activities.Add(this.prompt);
            this.Activities.Add(this.readData);
            this.Activities.Add(this.writeData);
            this.Name = "WorkflowCode";
            this.CanModifyActivities = false;

		}

		#endregion

        private ConsoleWriteActivity writeData;
        private ConsoleReadActivity readData;
        private ConsoleWriteActivity prompt;











    }
}
