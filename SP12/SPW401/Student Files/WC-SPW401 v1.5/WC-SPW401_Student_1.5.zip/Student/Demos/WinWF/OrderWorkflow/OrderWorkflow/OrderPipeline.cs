﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace OrderWorkflow
{
    public sealed partial class OrderPipeline : StateMachineWorkflowActivity
    {
      public const string SubmittedStatus = "Submitted";
      public const string ApprovedStatus = "Approved";
      public const string CompletedStatus = "Completed";
      public const string CancelledStatus = "Cancelled";

      public const string ApprovalType = "Approval";
      public const string ShipType = "Ship";
      
      public OrderPipeline()
        {
            InitializeComponent();
        }

      public static DependencyProperty TaskIdProperty = DependencyProperty.Register("TaskId", typeof(System.Int32), typeof(OrderWorkflow.OrderPipeline));

      [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
      [BrowsableAttribute(true)]
      [CategoryAttribute("Parameters")]
      public Int32 TaskId
      {
        get
        {
          return ((int)(base.GetValue(OrderWorkflow.OrderPipeline.TaskIdProperty)));
        }
        set
        {
          base.SetValue(OrderWorkflow.OrderPipeline.TaskIdProperty, value);
        }
      }
    }
}
