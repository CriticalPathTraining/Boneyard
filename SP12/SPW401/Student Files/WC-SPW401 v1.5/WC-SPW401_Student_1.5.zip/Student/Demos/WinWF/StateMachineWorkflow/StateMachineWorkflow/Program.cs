﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;
using System.Workflow.Activities;

namespace StateMachineWorkflow
{
    class Program
    {
        static void Main(string[] args)
        {
            using(WorkflowRuntime workflowRuntime = new WorkflowRuntime())
            {
                AutoResetEvent waitHandle = new AutoResetEvent(false);
                workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) {waitHandle.Set();};
                workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
                {
                    Console.WriteLine(e.Exception.Message);
                    waitHandle.Set();
                };

                workflowRuntime.AddService(new ExternalDataExchangeService());
                workflowRuntime.GetService<ExternalDataExchangeService>().AddService(new ConsoleInputOutputService());

                WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(StateMachineWorkflow.Workflow));
                workflowRuntime.GetService<ConsoleInputOutputService>().InstanceId = instance.InstanceId;
                instance.Start();

                waitHandle.WaitOne();
            }
        }
    }
}
