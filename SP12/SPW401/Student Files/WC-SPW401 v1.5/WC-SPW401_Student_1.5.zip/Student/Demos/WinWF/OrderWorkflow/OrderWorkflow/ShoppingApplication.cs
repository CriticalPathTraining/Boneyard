﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Workflow.Runtime;
using OrderWorkflow;
using System.Workflow.Activities;
using System.Workflow.Runtime.Hosting;
using System.Threading;

namespace OrderStateMachine
{
  public partial class ShoppingApplication : Form
  {
    WorkflowRuntime _runtime = new WorkflowRuntime("WorkflowRuntime");

    public ShoppingApplication()
    {
      InitializeComponent();
    }

    /// <summary>
    /// Initializes the workflow runtime and updates the display
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void ShoppingApplication_Load(object sender, EventArgs e)
    {
      // register the event handlers
      _runtime.WorkflowCompleted += new EventHandler<WorkflowCompletedEventArgs>(Runtime_WorkflowCompleted);
      _runtime.WorkflowPersisted += new EventHandler<WorkflowEventArgs>(Runtime_WorkflowPersisted);

      // add the external data exchange service
      _runtime.AddService(new ExternalDataExchangeService());

      // add the order manager and task manager services to the runtime
      _runtime.GetService<ExternalDataExchangeService>().AddService(
        new OrderManagerService());
      _runtime.GetService<ExternalDataExchangeService>().AddService(
        new TaskManagerService());

      // register two event handlers that will update the UI
      _runtime.GetService<OrderManagerService>().OrderChanged +=
        new EventHandler(ShoppingApplication_OrderChanged);
      _runtime.GetService<TaskManagerService>().TaskChanged +=
        new EventHandler(ShoppingApplication_TaskChanged);

      // start the runtime
      _runtime.StartRuntime();
    }

    /// <summary>
    /// Stops and disposes the workflow runtime.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void ShoppingApplication_FormClosing(object sender, FormClosingEventArgs e)
    {
      // shutdown the runtime
      _runtime.StopRuntime();
      _runtime.Dispose();
    }

    /// <summary>
    /// Receives the workflow completed event and displays information about the order.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void Runtime_WorkflowCompleted(object sender, WorkflowCompletedEventArgs e)
    {
      // find the order that just completed
      DataClassesDataContext context = new DataClassesDataContext();
      Order order = context.Orders.FirstOrDefault(n => n.Id == e.WorkflowInstance.InstanceId);

      // if the order exists, display a message and remove the order
      if (order != null)
      {
        // display the message
        MessageBox.Show(
            string.Format("Order '{0}' was '{1}'.",
            e.WorkflowInstance.InstanceId, order.Status));

        // delete the order
        context.Orders.DeleteOnSubmit(order);
        context.SubmitChanges();
      }

      // update the order display
      orderBindingSource.DataSource = context.Orders;
    }

    /// <summary>
    /// Starts a new workflow.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void btnSubmitOrder_Click(object sender, EventArgs e)
    {
      WorkflowInstance instance = _runtime.CreateWorkflow(typeof(OrderPipeline));
      instance.Start();
    }

    /// <summary>
    /// Cancels the selected order.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void gridOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.ColumnIndex == 2)
      {
        Order order = gridOrders.Rows[e.RowIndex].DataBoundItem as Order;
        _runtime.GetService<TaskManagerService>().OnCancel(order.Id);
      }
    }

    /// <summary>
    /// Complete the selected task.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void gridTasks_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.ColumnIndex == 2)
      {
        Task task = gridTasks.Rows[e.RowIndex].DataBoundItem as Task;
        _runtime.GetService<TaskManagerService>().OnComplete(task.OrderId);
      }
    }

    /// <summary>
    /// Handles the order manager service's changed event and refreshes the orders list.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void ShoppingApplication_OrderChanged(object sender, EventArgs e)
    {
      DataClassesDataContext context = new DataClassesDataContext();
      this.Invoke(new ThreadStart(delegate() { orderBindingSource.DataSource = context.Orders; }));
    }

    /// <summary>
    /// Handles the task manager service's changed event and refreshes the tasks list.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void ShoppingApplication_TaskChanged(object sender, EventArgs e)
    {
      DataClassesDataContext context = new DataClassesDataContext();
      this.Invoke(new ThreadStart(delegate() { taskBindingSource.DataSource = context.Tasks; }));
    }

    /// <summary>
    /// Resets the database by deleting all orders/tasks and updates the display.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void btnResetDatabase_Click(object sender, EventArgs e)
    {
      // delete all orders and tasks
      DataClassesDataContext context = new DataClassesDataContext();
      context.Tasks.DeleteAllOnSubmit(context.Tasks);
      context.Orders.DeleteAllOnSubmit(context.Orders);
      context.SubmitChanges();

      // update the display
      orderBindingSource.DataSource = context.Orders;
      taskBindingSource.DataSource = context.Tasks;
    }

    void Runtime_WorkflowLoaded(object sender, WorkflowEventArgs e)
    {
      this.Invoke(new ThreadStart(delegate()
        {
          if (textPersistenceLog.Text.Length != 0)
            textPersistenceLog.Text += Environment.NewLine;
          textPersistenceLog.Text += string.Format("Loading order '{0}'.", e.WorkflowInstance.InstanceId);
        }));
    }

    void Runtime_WorkflowPersisted(object sender, WorkflowEventArgs e)
    {
      this.Invoke(new ThreadStart(delegate()
        {
          if (textPersistenceLog.Text.Length != 0)
            textPersistenceLog.Text += Environment.NewLine;
          textPersistenceLog.Text += string.Format("Persisting order '{0}'.", e.WorkflowInstance.InstanceId);
        }));
    }
  }
}
