﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities;
using System.Timers;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;

namespace ExternalDataExchange
{
  [Serializable]
  public class TimerEventArgs : ExternalDataEventArgs
  {
    public TimerEventArgs(Guid instanceId, string timerId)
      : base(instanceId)
    {
      TimerId = timerId;
    }

    public string TimerId { get; private set; }
  }

  [ExternalDataExchange]
  public interface ITimerService
  {
    event EventHandler<TimerEventArgs> Complete;
    void StartTimer(string TimerId, int delay);
  }

  public class TimerService : ITimerService
  {
    public event EventHandler<TimerEventArgs> Complete;

    public void StartTimer(string TimerId, int delay)
    {
      Guid instanceId = WorkflowEnvironment.WorkflowInstanceId;

      Timer timer = new Timer(delay);
      timer.AutoReset = false;
      timer.Elapsed += delegate(object sender, ElapsedEventArgs args)
      {
        if (Complete != null)
          Complete(null, new TimerEventArgs(instanceId, TimerId));
      };
      timer.Start();
    }
  }
}
