﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SequentialWorkflows
{
	partial class ErrorWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
      this.CanModifyActivities = true;
      this.compensate = new System.Workflow.ComponentModel.CompensateActivity();
      this.writeExceptionCaught = new SequentialWorkflows.ConsoleWriteActivity();
      this.writeNotSeenCompensation = new SequentialWorkflows.ConsoleWriteActivity();
      this.writeUndo = new SequentialWorkflows.ConsoleWriteActivity();
      this.catchAllHandler = new System.Workflow.ComponentModel.FaultHandlerActivity();
      this.cancellationHandlerActivity1 = new System.Workflow.ComponentModel.CancellationHandlerActivity();
      this.faultHandlersActivity1 = new System.Workflow.ComponentModel.FaultHandlersActivity();
      this.compensationHandlerActivity2 = new System.Workflow.ComponentModel.CompensationHandlerActivity();
      this.throwException = new System.Workflow.ComponentModel.ThrowActivity();
      this.writeThrowingException = new SequentialWorkflows.ConsoleWriteActivity();
      this.compensationHandlerActivity1 = new System.Workflow.ComponentModel.CompensationHandlerActivity();
      this.writeDoingWork = new SequentialWorkflows.ConsoleWriteActivity();
      this.faultHandlersActivity = new System.Workflow.ComponentModel.FaultHandlersActivity();
      this.writeNotSeen = new SequentialWorkflows.ConsoleWriteActivity();
      this.errorSequence = new System.Workflow.Activities.CompensatableSequenceActivity();
      this.operationSequence = new System.Workflow.Activities.CompensatableSequenceActivity();
      // 
      // compensate
      // 
      this.compensate.Name = "compensate";
      this.compensate.TargetActivityName = "ErrorWorkflow";
      // 
      // writeExceptionCaught
      // 
      this.writeExceptionCaught.Message = "Exception was caught and handled.  Compensation starting.";
      this.writeExceptionCaught.Name = "writeExceptionCaught";
      // 
      // writeNotSeenCompensation
      // 
      this.writeNotSeenCompensation.Message = "The error compensation shouldn\'t run.";
      this.writeNotSeenCompensation.Name = "writeNotSeenCompensation";
      // 
      // writeUndo
      // 
      this.writeUndo.Message = "Undoing previous operation";
      this.writeUndo.Name = "writeUndo";
      // 
      // catchAllHandler
      // 
      this.catchAllHandler.Activities.Add(this.writeExceptionCaught);
      this.catchAllHandler.Activities.Add(this.compensate);
      this.catchAllHandler.FaultType = typeof(System.Exception);
      this.catchAllHandler.Name = "catchAllHandler";
      // 
      // cancellationHandlerActivity1
      // 
      this.cancellationHandlerActivity1.Name = "cancellationHandlerActivity1";
      // 
      // faultHandlersActivity1
      // 
      this.faultHandlersActivity1.Name = "faultHandlersActivity1";
      // 
      // compensationHandlerActivity2
      // 
      this.compensationHandlerActivity2.Activities.Add(this.writeNotSeenCompensation);
      this.compensationHandlerActivity2.Name = "compensationHandlerActivity2";
      // 
      // throwException
      // 
      this.throwException.FaultType = typeof(System.Exception);
      this.throwException.Name = "throwException";
      // 
      // writeThrowingException
      // 
      this.writeThrowingException.Message = "Throwing an exception";
      this.writeThrowingException.Name = "writeThrowingException";
      // 
      // compensationHandlerActivity1
      // 
      this.compensationHandlerActivity1.Activities.Add(this.writeUndo);
      this.compensationHandlerActivity1.Name = "compensationHandlerActivity1";
      // 
      // writeDoingWork
      // 
      this.writeDoingWork.Message = "Doing work";
      this.writeDoingWork.Name = "writeDoingWork";
      // 
      // faultHandlersActivity
      // 
      this.faultHandlersActivity.Activities.Add(this.catchAllHandler);
      this.faultHandlersActivity.Name = "faultHandlersActivity";
      // 
      // writeNotSeen
      // 
      this.writeNotSeen.Message = "This should never be seen";
      this.writeNotSeen.Name = "writeNotSeen";
      // 
      // errorSequence
      // 
      this.errorSequence.Activities.Add(this.writeThrowingException);
      this.errorSequence.Activities.Add(this.throwException);
      this.errorSequence.Activities.Add(this.compensationHandlerActivity2);
      this.errorSequence.Activities.Add(this.faultHandlersActivity1);
      this.errorSequence.Activities.Add(this.cancellationHandlerActivity1);
      this.errorSequence.Name = "errorSequence";
      // 
      // operationSequence
      // 
      this.operationSequence.Activities.Add(this.writeDoingWork);
      this.operationSequence.Activities.Add(this.compensationHandlerActivity1);
      this.operationSequence.Name = "operationSequence";
      // 
      // ErrorWorkflow
      // 
      this.Activities.Add(this.operationSequence);
      this.Activities.Add(this.errorSequence);
      this.Activities.Add(this.writeNotSeen);
      this.Activities.Add(this.faultHandlersActivity);
      this.Name = "ErrorWorkflow";
      this.CanModifyActivities = false;

		}

		#endregion

        private ThrowActivity throwException;
        private ConsoleWriteActivity writeExceptionCaught;
        private FaultHandlerActivity catchAllHandler;
        private FaultHandlersActivity faultHandlersActivity;
        private ConsoleWriteActivity writeNotSeen;
        private ConsoleWriteActivity writeUndo;
        private CompensationHandlerActivity compensationHandlerActivity1;
        private ConsoleWriteActivity writeThrowingException;
        private CompensatableSequenceActivity operationSequence;
        private CompensatableSequenceActivity errorSequence;
        private ConsoleWriteActivity writeNotSeenCompensation;
        private CompensationHandlerActivity compensationHandlerActivity2;
        private CompensateActivity compensate;
        private CancellationHandlerActivity cancellationHandlerActivity1;
        private FaultHandlersActivity faultHandlersActivity1;
        private ConsoleWriteActivity writeDoingWork;

















  }
}
