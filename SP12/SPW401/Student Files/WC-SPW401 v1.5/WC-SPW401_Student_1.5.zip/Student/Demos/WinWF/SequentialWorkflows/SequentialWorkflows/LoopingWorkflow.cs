﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.Collections.Generic;

namespace SequentialWorkflows
{
  public sealed partial class LoopingWorkflow : SequentialWorkflowActivity
  {
    public LoopingWorkflow()
    {
      InitializeComponent();

      this.Values = new List<string>();
      this.DoneEnteringValues = false;
    }

    public List<string> Values { get; private set; }
    public bool DoneEnteringValues { get; set; }

    private void ReadValueComplete(object sender, EventArgs e)
    {
      string result = (sender as ConsoleReadActivity).Result;
      this.DoneEnteringValues = string.IsNullOrEmpty(result);
      if (!this.DoneEnteringValues)
        Values.Add(result);
    }

    private void displayValues_ExecuteCode(object sender, EventArgs e)
    {
      Console.WriteLine("Writing values:");
      foreach (string value in this.Values)
        Console.WriteLine("  " + value);
    }

    private void ProcessValueInitialized(object sender, ReplicatorChildEventArgs e)
    {
      ConsoleWriteActivity writeResult =
          e.Activity.GetActivityByName("writeResult")
          as ConsoleWriteActivity;
      writeResult.Message =
          string.Format("  {0}", e.InstanceData);
    }
    
    private void InitializeSimulatedProcessing(object sender, EventArgs e)
    {
      Random random = new Random();
      int seconds = random.Next(3);

      (sender as DelayActivity).TimeoutDuration = TimeSpan.FromSeconds(seconds);
    }
  }
}
