﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SequentialWorkflows
{
	partial class ParallelWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            this.branch2Write = new SequentialWorkflows.ConsoleWriteActivity();
            this.branch1Write = new SequentialWorkflows.ConsoleWriteActivity();
            this.branch1Read = new SequentialWorkflows.ConsoleReadActivity();
            this.branch1Delay = new System.Workflow.Activities.DelayActivity();
            this.branch2 = new System.Workflow.Activities.SequenceActivity();
            this.branch1 = new System.Workflow.Activities.SequenceActivity();
            this.parallelActivity = new System.Workflow.Activities.ParallelActivity();
            // 
            // branch2Write
            // 
            this.branch2Write.Message = "Branch 2 completed";
            this.branch2Write.Name = "branch2Write";
            // 
            // branch1Write
            // 
            this.branch1Write.Message = "Branch 1 completed";
            this.branch1Write.Name = "branch1Write";
            // 
            // branch1Read
            // 
            this.branch1Read.Enabled = false;
            this.branch1Read.Name = "branch1Read";
            this.branch1Read.Prompt = "Enter a value:";
            this.branch1Read.Result = null;
            // 
            // branch1Delay
            // 
            this.branch1Delay.Name = "branch1Delay";
            this.branch1Delay.TimeoutDuration = System.TimeSpan.Parse("00:00:05");
            // 
            // branch2
            // 
            this.branch2.Activities.Add(this.branch2Write);
            this.branch2.Name = "branch2";
            // 
            // branch1
            // 
            this.branch1.Activities.Add(this.branch1Delay);
            this.branch1.Activities.Add(this.branch1Read);
            this.branch1.Activities.Add(this.branch1Write);
            this.branch1.Name = "branch1";
            // 
            // parallelActivity
            // 
            this.parallelActivity.Activities.Add(this.branch1);
            this.parallelActivity.Activities.Add(this.branch2);
            this.parallelActivity.Name = "parallelActivity";
            // 
            // ParallelWorkflow
            // 
            this.Activities.Add(this.parallelActivity);
            this.Name = "ParallelWorkflow";
            this.CanModifyActivities = false;

		}

		#endregion

        private SequenceActivity branch2;
        private SequenceActivity branch1;
        private ConsoleWriteActivity branch2Write;
        private ConsoleWriteActivity branch1Write;
        private ConsoleReadActivity branch1Read;
        private DelayActivity branch1Delay;
        private ParallelActivity parallelActivity;










    }
}
