﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;

namespace SequentialWorkflows
{
    public class ConsoleReadActivity : Activity
    {
        public static readonly DependencyProperty PromptProperty =
            DependencyProperty.Register("Prompt", typeof(string), typeof(ConsoleReadActivity));
        public static readonly DependencyProperty ResultProperty =
           DependencyProperty.Register("Result", typeof(string), typeof(ConsoleReadActivity));

        public static readonly DependencyProperty ReadCompleteEvent =
           DependencyProperty.Register("ReadComplete", typeof(EventHandler), typeof(ConsoleReadActivity));

        public event EventHandler ReadComplete
        {
            add { base.AddHandler(ReadCompleteEvent, value); }
            remove { base.RemoveHandler(ReadCompleteEvent, value); }
        }

        public string Prompt
        {
            get { return (string)GetValue(PromptProperty); }
            set { SetValue(PromptProperty, value); }
        }

        public string Result
        {
            get { return (string)GetValue(ResultProperty); }
            set { SetValue(ResultProperty, value); }
        }

        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            if (!string.IsNullOrEmpty(this.Prompt))
                Console.Write(this.Prompt);
            this.Result = Console.ReadLine();
            this.RaiseEvent(ReadCompleteEvent, this, EventArgs.Empty);

            return base.Execute(executionContext);
        }
    }
}
