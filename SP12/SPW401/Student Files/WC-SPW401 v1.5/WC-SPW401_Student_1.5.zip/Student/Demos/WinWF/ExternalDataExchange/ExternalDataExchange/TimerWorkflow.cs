﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace ExternalDataExchange
{
  public sealed partial class TimerWorkflow : SequentialWorkflowActivity
  {
    public TimerWorkflow()
    {
      InitializeComponent();
    }

    public const string TimerId1 = "One";
    public const string TimerId2 = "Two";

    public TimerEventArgs TimerComplete1 { get; set; }
    public TimerEventArgs TimerComplete2 { get; set; }

    private void displayComplete1_ExecuteCode(object sender, EventArgs e)
    {
      Console.WriteLine(string.Format("Timer '{0}' complete on branch '{1}'.", TimerComplete1.TimerId, TimerId1));
    }

    private void displayComplete2_ExecuteCode(object sender, EventArgs e)
    {
      Console.WriteLine(string.Format("Timer '{0}' complete on branch '{1}'.", TimerComplete2.TimerId, TimerId2));
    }
  }

}
