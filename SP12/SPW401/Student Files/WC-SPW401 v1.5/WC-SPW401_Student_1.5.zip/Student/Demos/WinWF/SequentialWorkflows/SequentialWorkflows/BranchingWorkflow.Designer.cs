﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SequentialWorkflows
{
	partial class BranchingWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.Activities.CodeCondition codecondition1 = new System.Workflow.Activities.CodeCondition();
            this.writeInvalid = new SequentialWorkflows.ConsoleWriteActivity();
            this.writeNo = new SequentialWorkflows.ConsoleWriteActivity();
            this.writeYes = new SequentialWorkflows.ConsoleWriteActivity();
            this.ifInvalid = new System.Workflow.Activities.IfElseBranchActivity();
            this.ifNo = new System.Workflow.Activities.IfElseBranchActivity();
            this.ifYes = new System.Workflow.Activities.IfElseBranchActivity();
            this.ifElseActivity = new System.Workflow.Activities.IfElseActivity();
            this.readChoice = new SequentialWorkflows.ConsoleReadActivity();
            // 
            // writeInvalid
            // 
            this.writeInvalid.Message = "You entered an invalid choice";
            this.writeInvalid.Name = "writeInvalid";
            // 
            // writeNo
            // 
            this.writeNo.Message = "You entered \'no\'";
            this.writeNo.Name = "writeNo";
            // 
            // writeYes
            // 
            this.writeYes.Message = "You entered \'yes\'";
            this.writeYes.Name = "writeYes";
            // 
            // ifInvalid
            // 
            this.ifInvalid.Activities.Add(this.writeInvalid);
            this.ifInvalid.Name = "ifInvalid";
            // 
            // ifNo
            // 
            this.ifNo.Activities.Add(this.writeNo);
            ruleconditionreference1.ConditionName = "IsResponseNo";
            this.ifNo.Condition = ruleconditionreference1;
            this.ifNo.Name = "ifNo";
            // 
            // ifYes
            // 
            this.ifYes.Activities.Add(this.writeYes);
            codecondition1.Condition += new System.EventHandler<System.Workflow.Activities.ConditionalEventArgs>(this.IsResponseYes);
            this.ifYes.Condition = codecondition1;
            this.ifYes.Name = "ifYes";
            // 
            // ifElseActivity
            // 
            this.ifElseActivity.Activities.Add(this.ifYes);
            this.ifElseActivity.Activities.Add(this.ifNo);
            this.ifElseActivity.Activities.Add(this.ifInvalid);
            this.ifElseActivity.Name = "ifElseActivity";
            // 
            // readChoice
            // 
            this.readChoice.Name = "readChoice";
            this.readChoice.Prompt = "Enter yes or no:";
            this.readChoice.Result = null;
            // 
            // BranchingWorkflow
            // 
            this.Activities.Add(this.readChoice);
            this.Activities.Add(this.ifElseActivity);
            this.Name = "BranchingWorkflow";
            this.CanModifyActivities = false;

		}

		#endregion

        private ConsoleWriteActivity writeNo;
        private ConsoleWriteActivity writeYes;
        private IfElseBranchActivity ifNo;
        private IfElseBranchActivity ifYes;
        private IfElseActivity ifElseActivity;
        private ConsoleWriteActivity writeInvalid;
        private ConsoleReadActivity readChoice;
        private IfElseBranchActivity ifInvalid;










    }
}
