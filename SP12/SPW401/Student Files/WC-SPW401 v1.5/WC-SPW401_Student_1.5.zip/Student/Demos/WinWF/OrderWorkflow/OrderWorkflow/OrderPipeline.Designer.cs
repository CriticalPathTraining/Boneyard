﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace OrderWorkflow
{
    partial class OrderPipeline
    {
        #region Designer generated code
        
        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
          this.CanModifyActivities = true;
          System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding3 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding4 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding5 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding6 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding7 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding8 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding9 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
          System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding10 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
          this.deleteApprovedtask = new System.Workflow.Activities.CallExternalMethodActivity();
          this.createApproveTask = new System.Workflow.Activities.CallExternalMethodActivity();
          this.setOrderStatus = new System.Workflow.Activities.CallExternalMethodActivity();
          this.setStateApproved = new System.Workflow.Activities.SetStateActivity();
          this.setOrderStateApproved = new System.Workflow.Activities.CallExternalMethodActivity();
          this.handleOrderApproved = new System.Workflow.Activities.HandleExternalEventActivity();
          this.deleteShipTask = new System.Workflow.Activities.CallExternalMethodActivity();
          this.createShipTask = new System.Workflow.Activities.CallExternalMethodActivity();
          this.setStatecompleted = new System.Workflow.Activities.SetStateActivity();
          this.setOrderStateCompleted = new System.Workflow.Activities.CallExternalMethodActivity();
          this.handleOrderCompleted = new System.Workflow.Activities.HandleExternalEventActivity();
          this.setStateCancelled = new System.Workflow.Activities.SetStateActivity();
          this.setOrderStateCancelled = new System.Workflow.Activities.CallExternalMethodActivity();
          this.handleOrderCancelled = new System.Workflow.Activities.HandleExternalEventActivity();
          this.submittedFinalized = new System.Workflow.Activities.StateFinalizationActivity();
          this.submittedInitialized = new System.Workflow.Activities.StateInitializationActivity();
          this.orderApproved = new System.Workflow.Activities.EventDrivenActivity();
          this.approvedFinalized = new System.Workflow.Activities.StateFinalizationActivity();
          this.approvedInitialized = new System.Workflow.Activities.StateInitializationActivity();
          this.orderCompleted = new System.Workflow.Activities.EventDrivenActivity();
          this.orderCancelled = new System.Workflow.Activities.EventDrivenActivity();
          this.SubmittedState = new System.Workflow.Activities.StateActivity();
          this.ApprovedState = new System.Workflow.Activities.StateActivity();
          this.ClosedState = new System.Workflow.Activities.StateActivity();
          // 
          // deleteApprovedtask
          // 
          this.deleteApprovedtask.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.deleteApprovedtask.MethodName = "RemoveTask";
          this.deleteApprovedtask.Name = "deleteApprovedtask";
          activitybind1.Name = "OrderPipeline";
          activitybind1.Path = "TaskId";
          workflowparameterbinding1.ParameterName = "taskId";
          workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
          this.deleteApprovedtask.ParameterBindings.Add(workflowparameterbinding1);
          // 
          // createApproveTask
          // 
          this.createApproveTask.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.createApproveTask.MethodName = "CreateTask";
          this.createApproveTask.Name = "createApproveTask";
          activitybind2.Name = "OrderPipeline";
          activitybind2.Path = "ApprovalType";
          workflowparameterbinding2.ParameterName = "type";
          workflowparameterbinding2.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
          activitybind3.Name = "OrderPipeline";
          activitybind3.Path = "TaskId";
          workflowparameterbinding3.ParameterName = "(ReturnValue)";
          workflowparameterbinding3.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
          this.createApproveTask.ParameterBindings.Add(workflowparameterbinding2);
          this.createApproveTask.ParameterBindings.Add(workflowparameterbinding3);
          // 
          // setOrderStatus
          // 
          this.setOrderStatus.InterfaceType = typeof(OrderWorkflow.IOrderManager);
          this.setOrderStatus.MethodName = "SetOrderStatus";
          this.setOrderStatus.Name = "setOrderStatus";
          activitybind4.Name = "OrderPipeline";
          activitybind4.Path = "SubmittedStatus";
          workflowparameterbinding4.ParameterName = "status";
          workflowparameterbinding4.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
          this.setOrderStatus.ParameterBindings.Add(workflowparameterbinding4);
          // 
          // setStateApproved
          // 
          this.setStateApproved.Name = "setStateApproved";
          this.setStateApproved.TargetStateName = "ApprovedState";
          // 
          // setOrderStateApproved
          // 
          this.setOrderStateApproved.InterfaceType = typeof(OrderWorkflow.IOrderManager);
          this.setOrderStateApproved.MethodName = "SetOrderStatus";
          this.setOrderStateApproved.Name = "setOrderStateApproved";
          activitybind5.Name = "OrderPipeline";
          activitybind5.Path = "ApprovedStatus";
          workflowparameterbinding5.ParameterName = "status";
          workflowparameterbinding5.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
          this.setOrderStateApproved.ParameterBindings.Add(workflowparameterbinding5);
          // 
          // handleOrderApproved
          // 
          this.handleOrderApproved.EventName = "Complete";
          this.handleOrderApproved.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.handleOrderApproved.Name = "handleOrderApproved";
          // 
          // deleteShipTask
          // 
          this.deleteShipTask.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.deleteShipTask.MethodName = "RemoveTask";
          this.deleteShipTask.Name = "deleteShipTask";
          activitybind6.Name = "OrderPipeline";
          activitybind6.Path = "TaskId";
          workflowparameterbinding6.ParameterName = "taskId";
          workflowparameterbinding6.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
          this.deleteShipTask.ParameterBindings.Add(workflowparameterbinding6);
          // 
          // createShipTask
          // 
          this.createShipTask.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.createShipTask.MethodName = "CreateTask";
          this.createShipTask.Name = "createShipTask";
          activitybind7.Name = "OrderPipeline";
          activitybind7.Path = "ShipType";
          workflowparameterbinding7.ParameterName = "type";
          workflowparameterbinding7.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
          activitybind8.Name = "OrderPipeline";
          activitybind8.Path = "TaskId";
          workflowparameterbinding8.ParameterName = "(ReturnValue)";
          workflowparameterbinding8.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
          this.createShipTask.ParameterBindings.Add(workflowparameterbinding7);
          this.createShipTask.ParameterBindings.Add(workflowparameterbinding8);
          // 
          // setStatecompleted
          // 
          this.setStatecompleted.Name = "setStatecompleted";
          this.setStatecompleted.TargetStateName = "ClosedState";
          // 
          // setOrderStateCompleted
          // 
          this.setOrderStateCompleted.InterfaceType = typeof(OrderWorkflow.IOrderManager);
          this.setOrderStateCompleted.MethodName = "SetOrderStatus";
          this.setOrderStateCompleted.Name = "setOrderStateCompleted";
          activitybind9.Name = "OrderPipeline";
          activitybind9.Path = "CompletedStatus";
          workflowparameterbinding9.ParameterName = "status";
          workflowparameterbinding9.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
          this.setOrderStateCompleted.ParameterBindings.Add(workflowparameterbinding9);
          // 
          // handleOrderCompleted
          // 
          this.handleOrderCompleted.EventName = "Complete";
          this.handleOrderCompleted.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.handleOrderCompleted.Name = "handleOrderCompleted";
          // 
          // setStateCancelled
          // 
          this.setStateCancelled.Name = "setStateCancelled";
          this.setStateCancelled.TargetStateName = "ClosedState";
          // 
          // setOrderStateCancelled
          // 
          this.setOrderStateCancelled.InterfaceType = typeof(OrderWorkflow.IOrderManager);
          this.setOrderStateCancelled.MethodName = "SetOrderStatus";
          this.setOrderStateCancelled.Name = "setOrderStateCancelled";
          activitybind10.Name = "OrderPipeline";
          activitybind10.Path = "CancelledStatus";
          workflowparameterbinding10.ParameterName = "status";
          workflowparameterbinding10.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
          this.setOrderStateCancelled.ParameterBindings.Add(workflowparameterbinding10);
          // 
          // handleOrderCancelled
          // 
          this.handleOrderCancelled.EventName = "Cancel";
          this.handleOrderCancelled.InterfaceType = typeof(OrderWorkflow.ITaskManager);
          this.handleOrderCancelled.Name = "handleOrderCancelled";
          // 
          // submittedFinalized
          // 
          this.submittedFinalized.Activities.Add(this.deleteApprovedtask);
          this.submittedFinalized.Name = "submittedFinalized";
          // 
          // submittedInitialized
          // 
          this.submittedInitialized.Activities.Add(this.setOrderStatus);
          this.submittedInitialized.Activities.Add(this.createApproveTask);
          this.submittedInitialized.Name = "submittedInitialized";
          // 
          // orderApproved
          // 
          this.orderApproved.Activities.Add(this.handleOrderApproved);
          this.orderApproved.Activities.Add(this.setOrderStateApproved);
          this.orderApproved.Activities.Add(this.setStateApproved);
          this.orderApproved.Name = "orderApproved";
          // 
          // approvedFinalized
          // 
          this.approvedFinalized.Activities.Add(this.deleteShipTask);
          this.approvedFinalized.Name = "approvedFinalized";
          // 
          // approvedInitialized
          // 
          this.approvedInitialized.Activities.Add(this.createShipTask);
          this.approvedInitialized.Name = "approvedInitialized";
          // 
          // orderCompleted
          // 
          this.orderCompleted.Activities.Add(this.handleOrderCompleted);
          this.orderCompleted.Activities.Add(this.setOrderStateCompleted);
          this.orderCompleted.Activities.Add(this.setStatecompleted);
          this.orderCompleted.Name = "orderCompleted";
          // 
          // orderCancelled
          // 
          this.orderCancelled.Activities.Add(this.handleOrderCancelled);
          this.orderCancelled.Activities.Add(this.setOrderStateCancelled);
          this.orderCancelled.Activities.Add(this.setStateCancelled);
          this.orderCancelled.Name = "orderCancelled";
          // 
          // SubmittedState
          // 
          this.SubmittedState.Activities.Add(this.orderApproved);
          this.SubmittedState.Activities.Add(this.submittedInitialized);
          this.SubmittedState.Activities.Add(this.submittedFinalized);
          this.SubmittedState.Name = "SubmittedState";
          // 
          // ApprovedState
          // 
          this.ApprovedState.Activities.Add(this.orderCompleted);
          this.ApprovedState.Activities.Add(this.approvedInitialized);
          this.ApprovedState.Activities.Add(this.approvedFinalized);
          this.ApprovedState.Name = "ApprovedState";
          // 
          // ClosedState
          // 
          this.ClosedState.Name = "ClosedState";
          // 
          // OrderPipeline
          // 
          this.Activities.Add(this.ClosedState);
          this.Activities.Add(this.ApprovedState);
          this.Activities.Add(this.SubmittedState);
          this.Activities.Add(this.orderCancelled);
          this.CompletedStateName = "ClosedState";
          this.DynamicUpdateCondition = null;
          this.InitialStateName = "SubmittedState";
          this.Name = "OrderPipeline";
          this.CanModifyActivities = false;

        }

        #endregion

        private CallExternalMethodActivity deleteApprovedtask;
        private CallExternalMethodActivity createShipTask;
        private StateInitializationActivity approvedInitialized;
        private CallExternalMethodActivity deleteShipTask;
        private StateFinalizationActivity approvedFinalized;
        private SetStateActivity setStateCancelled;
        private CallExternalMethodActivity setOrderStateCancelled;
        private HandleExternalEventActivity handleOrderCancelled;
        private EventDrivenActivity orderCancelled;
        private SetStateActivity setStatecompleted;
        private CallExternalMethodActivity setOrderStateCompleted;
        private HandleExternalEventActivity handleOrderCompleted;
        private EventDrivenActivity orderCompleted;
        private StateFinalizationActivity submittedFinalized;
        private StateInitializationActivity submittedInitialized;
        private CallExternalMethodActivity setOrderStatus;
        private CallExternalMethodActivity createApproveTask;
        private StateActivity SubmittedState;
        private StateActivity ApprovedState;
        private EventDrivenActivity orderApproved;
        private SetStateActivity setStateApproved;
        private CallExternalMethodActivity setOrderStateApproved;
        private HandleExternalEventActivity handleOrderApproved;
        private StateActivity ClosedState;
















    }
}
