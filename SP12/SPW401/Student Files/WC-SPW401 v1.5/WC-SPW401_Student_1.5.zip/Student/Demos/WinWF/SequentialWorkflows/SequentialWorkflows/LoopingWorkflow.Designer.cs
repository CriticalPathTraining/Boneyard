﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SequentialWorkflows
{
	partial class LoopingWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
            this.writeResult = new SequentialWorkflows.ConsoleWriteActivity();
            this.simulateProcessing = new System.Workflow.Activities.DelayActivity();
            this.sequenceActivity = new System.Workflow.Activities.SequenceActivity();
            this.readValue = new SequentialWorkflows.ConsoleReadActivity();
            this.processValues = new System.Workflow.Activities.ReplicatorActivity();
            this.displayValues = new System.Workflow.Activities.CodeActivity();
            this.whileEntering = new System.Workflow.Activities.WhileActivity();
            // 
            // writeResult
            // 
            this.writeResult.Message = null;
            this.writeResult.Name = "writeResult";
            // 
            // simulateProcessing
            // 
            this.simulateProcessing.Name = "simulateProcessing";
            this.simulateProcessing.TimeoutDuration = System.TimeSpan.Parse("00:00:00");
            this.simulateProcessing.InitializeTimeoutDuration += new System.EventHandler(this.InitializeSimulatedProcessing);
            // 
            // sequenceActivity
            // 
            this.sequenceActivity.Activities.Add(this.simulateProcessing);
            this.sequenceActivity.Activities.Add(this.writeResult);
            this.sequenceActivity.Name = "sequenceActivity";
            // 
            // readValue
            // 
            this.readValue.Name = "readValue";
            this.readValue.Prompt = "Enter a value (leave empty to continue):";
            this.readValue.Result = "";
            this.readValue.ReadComplete += new System.EventHandler(this.ReadValueComplete);
            activitybind1.Name = "LoopingWorkflow";
            activitybind1.Path = "Values";
            // 
            // processValues
            // 
            this.processValues.Activities.Add(this.sequenceActivity);
            this.processValues.ExecutionType = System.Workflow.Activities.ExecutionType.Parallel;
            this.processValues.Name = "processValues";
            this.processValues.ChildInitialized += new System.EventHandler<System.Workflow.Activities.ReplicatorChildEventArgs>(this.ProcessValueInitialized);
            this.processValues.SetBinding(System.Workflow.Activities.ReplicatorActivity.InitialChildDataProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // displayValues
            // 
            this.displayValues.Enabled = false;
            this.displayValues.Name = "displayValues";
            this.displayValues.ExecuteCode += new System.EventHandler(this.displayValues_ExecuteCode);
            // 
            // whileEntering
            // 
            this.whileEntering.Activities.Add(this.readValue);
            ruleconditionreference1.ConditionName = "WhileValueRead";
            this.whileEntering.Condition = ruleconditionreference1;
            this.whileEntering.Name = "whileEntering";
            // 
            // LoopingWorkflow
            // 
            this.Activities.Add(this.whileEntering);
            this.Activities.Add(this.displayValues);
            this.Activities.Add(this.processValues);
            this.Name = "LoopingWorkflow";
            this.CanModifyActivities = false;

		}

		#endregion

        private ConsoleReadActivity readValue;
        private CodeActivity displayValues;
        private ReplicatorActivity processValues;
        private DelayActivity simulateProcessing;
        private SequenceActivity sequenceActivity;
        private ConsoleWriteActivity writeResult;
        private WhileActivity whileEntering;

















    }
}
