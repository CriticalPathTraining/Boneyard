﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities;
using System.Workflow.Runtime;
using System.Timers;

namespace ExternalDataExchange
{
  [ExternalDataExchange]
  [CorrelationParameter("TimerId")]
  public interface ICorrelatedTimerService
  {
    [CorrelationAlias("TimerId", "e.TimerId")]
    event EventHandler<TimerEventArgs> Complete;

    [CorrelationInitializer]
    void StartTimer(string TimerId, int delay);
  }

  public class CorrelatedTimerService : ICorrelatedTimerService
  {
    #region ITimerService Members
    public event EventHandler<TimerEventArgs> Complete;

    public void StartTimer(string TimerId, int delay)
    {
      Guid instanceId = WorkflowEnvironment.WorkflowInstanceId;

      Timer timer = new Timer(delay);
      timer.AutoReset = false;
      timer.Elapsed += delegate(object sender, ElapsedEventArgs args)
      {
        if (Complete != null)
          Complete(null, new TimerEventArgs(instanceId, TimerId));
      };
      timer.Start();
    }
    #endregion
  }
}
