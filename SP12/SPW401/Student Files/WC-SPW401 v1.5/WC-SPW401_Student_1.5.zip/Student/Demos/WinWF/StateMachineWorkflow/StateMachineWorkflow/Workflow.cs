﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace StateMachineWorkflow
{
    public sealed partial class Workflow : StateMachineWorkflowActivity
    {
        public Workflow()
        {
            InitializeComponent();
        }

        public static DependencyProperty ReadLineResultsProperty = DependencyProperty.Register("ReadLineResults", typeof(StateMachineWorkflow.ReadLineEventArgs), typeof(StateMachineWorkflow.Workflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Parameters")]
        public ReadLineEventArgs ReadLineResults
        {
            get
            {
                return ((StateMachineWorkflow.ReadLineEventArgs)(base.GetValue(StateMachineWorkflow.Workflow.ReadLineResultsProperty)));
            }
            set
            {
                base.SetValue(StateMachineWorkflow.Workflow.ReadLineResultsProperty, value);
            }
        }
    }
}
