﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Activities;

namespace StateMachineWorkflow
{
  [Serializable]
  public class ReadLineEventArgs : ExternalDataEventArgs
  {
    public ReadLineEventArgs(Guid instanceId, string result)
      : base(instanceId)
    {
      Result = result;
    }

    public string Result { get; private set; }
  }

  [ExternalDataExchange]
  public interface IInputOutputService
  {
    event EventHandler<ReadLineEventArgs> ReadLineCompleted;
    event EventHandler<ExternalDataEventArgs> InputOutputShutdown;

    void WriteLine(string message);
    void ReadLine(string prompt);
  }
}
