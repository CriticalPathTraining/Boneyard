﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Runtime.Hosting;
using System.Workflow.Activities;
using System.Workflow.Runtime;

namespace OrderWorkflow
{
  [ExternalDataExchange]
  public interface IOrderManager
  {
    void SetOrderStatus(string status);
  }

  public class OrderManagerService : WorkflowRuntimeService, IOrderManager
	{
    public event EventHandler OrderChanged;

    public void SetOrderStatus(string status)
    {
      // lookup the current workflow instance id 
      Guid orderId = WorkflowEnvironment.WorkflowInstanceId;

      // find the order based on the current workflwo instance id 
      // FirstOrDefault return the order or null is none found
      DataClassesDataContext context = new DataClassesDataContext();
      Order order = context.Orders.FirstOrDefault(n => n.Id == orderId);

      // if the order wasn’t found create a new order and insert it
      if (order == null)
      {
        order = new Order();
        order.Id = orderId;
        context.Orders.InsertOnSubmit(order);
      }

      // update the status and commit the changes
      order.Status = status;
      context.SubmitChanges();

      // fire the order changed event
      if (OrderChanged != null)
        OrderChanged(this, EventArgs.Empty);
    }
  }
}
