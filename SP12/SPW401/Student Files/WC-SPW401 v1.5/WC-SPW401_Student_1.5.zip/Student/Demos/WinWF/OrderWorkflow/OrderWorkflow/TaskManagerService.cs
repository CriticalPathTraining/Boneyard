﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.Runtime.Hosting;
using System.Workflow.Activities;
using System.Workflow.Runtime;

namespace OrderWorkflow
{

  [ExternalDataExchange]
  public interface ITaskManager
  {
    int CreateTask(string type);
    void RemoveTask(int taskId);

    event EventHandler<ExternalDataEventArgs> Complete;
    event EventHandler<ExternalDataEventArgs> Cancel;
  }

  public class TaskManagerService : ITaskManager
  {
    public event EventHandler TaskChanged;
    
    public event EventHandler<ExternalDataEventArgs> Complete;
    public event EventHandler<ExternalDataEventArgs> Cancel;

    public int CreateTask(string type)
    {
      // lookup the id of the currently running workflow
      Guid orderId = WorkflowEnvironment.WorkflowInstanceId;

      // create the new task
      Task task = new Task();
      task.OrderId = orderId;
      task.Type = type;

      // attach the task to the context
      DataClassesDataContext context = new DataClassesDataContext();
      context.Tasks.InsertOnSubmit(task);
      context.SubmitChanges();

      // fire the task changed event
      if (TaskChanged != null)
        TaskChanged(this, EventArgs.Empty);

      // return new new task's id
      return task.Id;
    }

    public void RemoveTask(int taskId)
    {
      // find the task by id
      DataClassesDataContext context = new DataClassesDataContext();
      Task task = context.Tasks.FirstOrDefault(n => n.Id == taskId);

      // if the task was found, delete it
      if (task != null)
        context.Tasks.DeleteOnSubmit(task);
      context.SubmitChanges();

      // fire the task changed event
      if (TaskChanged != null)
        TaskChanged(this, EventArgs.Empty);
    }

    public void OnComplete(Guid orderId)
    {
      if (Complete != null)
        Complete(null, new ExternalDataEventArgs(orderId));
    }

    public void OnCancel(Guid orderId)
    {
      if (Cancel != null)
        Cancel(null, new ExternalDataEventArgs(orderId));
    }
  }
}
