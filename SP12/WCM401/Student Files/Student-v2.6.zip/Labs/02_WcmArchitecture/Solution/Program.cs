using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;

namespace Lab2Solution {
  class Program {
    static void Main (string[] args) {
      // get reference to the litware publishing site
      SPSite siteCollection = new SPSite("http://wcm.litwareinc.com");

      // get reference to the publishing site
      PublishingSite publishingSiteCollection = new PublishingSite(siteCollection);
      
      // write out some information about the publishing site
      Console.Out.WriteLine("Publishing site collection properties:");
      Console.Out.WriteLine("  Site collection URL: {0}", publishingSiteCollection.Site.Url);
      Console.Out.WriteLine("  Total content types in the collection: {0}", publishingSiteCollection.ContentTypes.Count.ToString());
      Console.Out.WriteLine("  Total page layouts in the Master Page Gallery: {0}", publishingSiteCollection.PageLayouts.Count.ToString());
      Console.Out.WriteLine("");
	  
      // get reference to the publishing web..
      SPWeb site = siteCollection.OpenWeb("PressReleases");
      if (PublishingWeb.IsPublishingWeb(site)) {
        PublishingWeb publishingSite = PublishingWeb.GetPublishingWeb(site);

        // write out some information about the publishing web
        Console.Out.WriteLine("Publishing web properties:");
        Console.Out.WriteLine("  Pages list name: {0}", publishingSite.PagesListName);
        Console.Out.WriteLine("  Total pages in the list: {0}", publishingSite.PagesList.ItemCount.ToString());
        Console.Out.WriteLine("");
        
        // write out all pages
        Console.Out.WriteLine("Publishing pages witin the root web's Pages library:");
        foreach (PublishingPage page in publishingSite.GetPublishingPages()) {
          Console.Out.WriteLine("  Page: {0}", page.Name);
          Console.Out.WriteLine("  Page URL: {0}", page.Url);
          Console.Out.WriteLine("  Underlying SPListItem ID: {0}", page.ListItem.ID.ToString());
        }
      }

      Console.Out.WriteLine("Press any key to continue...");
      Console.ReadLine();
    }
  }
}