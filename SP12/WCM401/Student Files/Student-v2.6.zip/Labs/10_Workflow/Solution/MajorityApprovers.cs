using System;
using System.Workflow.Activities;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;
using Microsoft.SharePoint.Utilities;

namespace Lab10Solution {
  public sealed partial class MajorityApprovers : SharePointSequentialWorkflowActivity {
    public MajorityApprovers () {
      InitializeComponent();
    }

    public Guid workflowId = default(System.Guid);
    public SPWorkflowActivationProperties workflowProperties = new SPWorkflowActivationProperties();
    public bool MajorityHasAnswered = false;
    public int ApproveAnswerCount = 0;
    public int RejectAnswerCount = 0;

    public string HistoryDescription = default(string);
    public string HistoryOutcome = default(string);

    private string _instructions = default(string);
    private string _alphaApprover = default(string);
    private string _betaApprover = default(string);
    private string _charlieApprover = default(string);

    public Guid AlphaTaskId = default(System.Guid);
    public SPWorkflowTaskProperties AlphaTaskProperties = new SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties AlphaTaskAfterProperties = new SPWorkflowTaskProperties();
 
    public Guid BetaTaskId = default(System.Guid);
    public SPWorkflowTaskProperties BetaTaskProperties = new SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties BetaTaskAfterProperties = new SPWorkflowTaskProperties();
  
    public Guid CharlieTaskId = default(System.Guid);
    public SPWorkflowTaskProperties CharlieTaskProperties = new SPWorkflowTaskProperties();
    public SPWorkflowTaskProperties CharlieTaskAfterProperties = new SPWorkflowTaskProperties();

    public ApprovalDecision AlphaTaskAnswer = ApprovalDecision.NoAnswer;
    public ApprovalDecision BetaTaskAnswer = ApprovalDecision.NoAnswer;
    public ApprovalDecision CharlieTaskAnswer = ApprovalDecision.NoAnswer;

    #region Workflow started and logged
    /// <summary>
    /// Handles the Invoked event of the onWorkflowActivated control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.Workflow.Activities.ExternalDataEventArgs"/> instance containing the event data.</param>
    private void onWorkflowActivated_Invoked (object sender, ExternalDataEventArgs e) {
      // load the data from the IP form 'InitForm' into a local object
      XmlSerializer serializer = new XmlSerializer(typeof(InitForm));
      XmlTextReader xrInitForm = new XmlTextReader(new System.IO.StringReader(workflowProperties.InitiationData));
      InitForm frmInit = serializer.Deserialize(xrInitForm) as InitForm;

      // get approvers submitted
      this._alphaApprover = @"LITWAREINC\" + frmInit.alphaApprover;
      this.EnsureUserIsRecognized(this._alphaApprover);
      this._betaApprover = @"LITWAREINC\" + frmInit.betaApprover;
      this.EnsureUserIsRecognized(this._betaApprover);
      this._charlieApprover = @"LITWAREINC\" + frmInit.charlieApprover;
      this.EnsureUserIsRecognized(this._charlieApprover);

      // get instructions
      this._instructions = frmInit.instructions;
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logWorkflowStarted control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logWorkflowStarted_MethodInvoking (object sender, EventArgs e) {
      // get reference to the item this workflow is associated with
      SPListItem page = workflowProperties.Item;

      // create log message & outcome
      this.HistoryOutcome = "Workflow successfully initiated...";
      this.HistoryDescription = String.Format("Collected three approvers: {0}, {1} & {2}. All received the following instructions: {3}",
        this._alphaApprover,
        this._betaApprover,
        this._charlieApprover,
        this._instructions);
    }
    #endregion

    #region Create and log three tasks
    /// <summary>
    /// Handles the MethodInvoking event of the createAlphaApprovalTask control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void createAlphaApprovalTask_MethodInvoking (object sender, EventArgs e) {
      this.AlphaTaskId = Guid.NewGuid();

      this.AlphaTaskProperties.Title = "Approval requested for " + workflowProperties.Item.Title;
      this.AlphaTaskProperties.Description = "Please review the item, then approve or reject it.";
      this.AlphaTaskProperties.AssignedTo = this._alphaApprover;
      this.AlphaTaskProperties.PercentComplete = 0;
      this.AlphaTaskProperties.StartDate = DateTime.Today;
      this.AlphaTaskProperties.DueDate = DateTime.Today.AddDays(7);
      this.AlphaTaskProperties.ExtendedProperties["instructions"] = this._instructions;
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logAlphaTaskCreated control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logAlphaTaskCreated_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = String.Format("Task created and assigned to first approver: {0}", this._alphaApprover);
      this.HistoryDescription = String.Format("Approval task 'alpha' created and assigned to {0}", this._alphaApprover);
    }

    /// <summary>
    /// Handles the MethodInvoking event of the createBetaApprovalTask control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void createBetaApprovalTask_MethodInvoking (object sender, EventArgs e) {
      this.BetaTaskId = Guid.NewGuid();

      this.BetaTaskProperties.Title = "Approval requested for " + workflowProperties.Item.Title;
      this.BetaTaskProperties.Description = "Please review the item, then approve or reject it.";
      this.BetaTaskProperties.AssignedTo = this._betaApprover;
      this.BetaTaskProperties.PercentComplete = 0;
      this.BetaTaskProperties.StartDate = DateTime.Today;
      this.BetaTaskProperties.DueDate = DateTime.Today.AddDays(7);
      this.BetaTaskProperties.ExtendedProperties["instructions"] = this._instructions;
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logBetaTaskCreated control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logBetaTaskCreated_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = String.Format("Task created and assigned to second approver: {0}", this._betaApprover);
      this.HistoryDescription = String.Format("Approval task 'beta' created and assigned to {0}", this._betaApprover);
    }

    /// <summary>
    /// Handles the MethodInvoking event of the createCharlieApprovalTask control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void createCharlieApprovalTask_MethodInvoking (object sender, EventArgs e) {
      this.CharlieTaskId = Guid.NewGuid();

      this.CharlieTaskProperties.Title = "Approval requested for " + workflowProperties.Item.Title;
      this.CharlieTaskProperties.Description = "Please review the item, then approve or reject it.";
      this.CharlieTaskProperties.AssignedTo = this._charlieApprover;
      this.CharlieTaskProperties.PercentComplete = 0;
      this.CharlieTaskProperties.StartDate = DateTime.Today;
      this.CharlieTaskProperties.DueDate = DateTime.Today.AddDays(7);
      this.CharlieTaskProperties.ExtendedProperties["instructions"] = this._instructions;
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logCharlieTaskCreated control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logCharlieTaskCreated_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = String.Format("Task created and assigned to third approver: {0}", this._charlieApprover);
      this.HistoryDescription = String.Format("Approval task 'charlie' created and assigned to {0}", this._charlieApprover);
    }
    #endregion

    #region Task listeners and loggers
    /// <summary>
    /// Handles the Invoked event of the onAlphaTaskChanged control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.Workflow.Activities.ExternalDataEventArgs"/> instance containing the event data.</param>
    private void onAlphaTaskChanged_Invoked (object sender, ExternalDataEventArgs e) {
      // check if the task was approved
      string taskResult = this.AlphaTaskAfterProperties.ExtendedProperties["decision"].ToString();
      if (taskResult.ToLower() == "approve")
        this.AlphaTaskAnswer = ApprovalDecision.Approved;
      else if (taskResult.ToLower() == "reject")
        this.AlphaTaskAnswer = ApprovalDecision.Rejected;

      // now, need to check all the other tasks to see 2/3 are approved
      //   b/c if so, need to mark whole thing as complete
      UpdateMajorityDecision();
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logAlphaTaskChanged control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logAlphaTaskChanged_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = ("First approver task answered.");
      this.HistoryDescription = String.Format("Approval task 'alpha' status is now: {0}. Current score: {1}-{2}. Approver entered the following comments: '{3}'.", 
        this.AlphaTaskAnswer.ToString(),
        this.ApproveAnswerCount.ToString(),
        this.RejectAnswerCount.ToString(),
        this.AlphaTaskAfterProperties.ExtendedProperties["comments"].ToString());
    }

    /// <summary>
    /// Handles the Invoked event of the onBetaTaskChanged control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.Workflow.Activities.ExternalDataEventArgs"/> instance containing the event data.</param>
    private void onBetaTaskChanged_Invoked (object sender, ExternalDataEventArgs e) {
      // check if the task was approved
      string taskResult = this.BetaTaskAfterProperties.ExtendedProperties["decision"].ToString();
      if (taskResult.ToLower() == "approve")
        this.BetaTaskAnswer = ApprovalDecision.Approved;
      else if (taskResult.ToLower() == "reject")
        this.BetaTaskAnswer = ApprovalDecision.Rejected;

      // now, need to check all the other tasks to see 2/3 are approved
      //   b/c if so, need to mark whole thing as complete
      UpdateMajorityDecision();
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logBetaTaskChanged control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logBetaTaskChanged_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = ("Second approver task answered.");
      this.HistoryDescription = String.Format("Approval task 'beta' status is now: {0}. Current score: {1}-{2}. Approver entered the following comments: '{3}'.",
        this.BetaTaskAnswer.ToString(),
        this.ApproveAnswerCount.ToString(),
        this.RejectAnswerCount.ToString(),
        this.BetaTaskAfterProperties.ExtendedProperties["comments"].ToString());
    }

    /// <summary>
    /// Handles the Invoked event of the onCharlieTaskChanged control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.Workflow.Activities.ExternalDataEventArgs"/> instance containing the event data.</param>
    private void onCharlieTaskChanged_Invoked (object sender, ExternalDataEventArgs e) {
      // check if the task was approved
      string taskResult = this.CharlieTaskAfterProperties.ExtendedProperties["decision"].ToString();
      if (taskResult.ToLower() == "approve")
        this.CharlieTaskAnswer = ApprovalDecision.Approved;
      else if (taskResult.ToLower() == "reject")
        this.CharlieTaskAnswer = ApprovalDecision.Rejected;

      // now, need to check all the other tasks to see 2/3 are approved
      //   b/c if so, need to mark whole thing as complete
      UpdateMajorityDecision();
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logCharlieTaskChanged control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logCharlieTaskChanged_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = ("Third approver task answered.");
      this.HistoryDescription = String.Format("Approval task 'charlie' status is now: {0}. Current score: {1}-{2}. Approver entered the following comments: '{3}'.",
        this.CharlieTaskAnswer.ToString(),
        this.ApproveAnswerCount.ToString(),
        this.RejectAnswerCount.ToString(),
        this.CharlieTaskAfterProperties.ExtendedProperties["comments"].ToString());
    }
    #endregion

    #region Approval and rejection section
    /// <summary>
    /// Handles the ExecuteCode event of the approveItem control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void approveItem_ExecuteCode (object sender, EventArgs e) {
      // get the item...
      SPListItem item = workflowProperties.Item;

      // approve the item
      item.File.Approve("Approved by a majority.");
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logItemApproved control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logItemApproved_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = "Item approved by a majority.";
      this.HistoryDescription = String.Format("The final score was {0} approvers & {1} rejecters. Once a majority of three approvers is reached, the workflow terminates.",
        this.ApproveAnswerCount.ToString(),
        this.RejectAnswerCount.ToString());
    }

    /// <summary>
    /// Handles the ExecuteCode event of the rejectItem control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void rejectItem_ExecuteCode (object sender, EventArgs e) {
      SPListItem item = workflowProperties.Item;
      item.File.Deny("Rejected by a majority.");
    }

    /// <summary>
    /// Handles the MethodInvoking event of the logItemRejected control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    private void logItemRejected_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = "Item rejected by a majority.";
      this.HistoryDescription = String.Format("The final score was {0} approvers & {1} rejecters. Once a majority of three approvers is reached, the workflow terminates.",
        this.ApproveAnswerCount.ToString(),
        this.RejectAnswerCount.ToString());
    }
    #endregion

    private void logWorkflowComplete_MethodInvoking (object sender, EventArgs e) {
      this.HistoryOutcome = "Workflow complete.";
      this.HistoryDescription = "Workflow finished... majority always wins (except in hand grenades & horseshoes).";
    }

    #region Utilty methods
    /// <summary>
    /// Updates the majority decision.
    /// </summary>
    private void UpdateMajorityDecision () {
      int countApproved = 0;
      int countRejected = 0;

      // check alpha approver
      if (this.AlphaTaskAnswer == ApprovalDecision.Approved)
        countApproved++;
      else if (this.AlphaTaskAnswer == ApprovalDecision.Rejected)
        countRejected++;

      // check beta approver
      if (this.BetaTaskAnswer == ApprovalDecision.Approved)
        countApproved++;
      else if (this.BetaTaskAnswer == ApprovalDecision.Rejected)
        countRejected++;

      // check charlie approver
      if (this.CharlieTaskAnswer == ApprovalDecision.Approved)
        countApproved++;
      else if (this.CharlieTaskAnswer == ApprovalDecision.Rejected)
        countRejected++;


      // set results
      this.ApproveAnswerCount = countApproved;
      this.RejectAnswerCount = countRejected;


      // if three respondants, no need to check futher
      if (countApproved + countRejected == 3) {
        this.MajorityHasAnswered = true;
      }// else if two of EITHER answer have responded, majority rules
      else if (countApproved == 2 || countRejected == 2)
        this.MajorityHasAnswered = true;
    }

    /// <summary>
    /// Ensures the user is recognized.
    /// </summary>
    /// <param name="userName">Name of the user.</param>
    private void EnsureUserIsRecognized (string userName) {
      // if the user isn't found in the site, add them
      if (this.GetUserIdFromUserName(workflowProperties.Web, userName) == -1)
        workflowProperties.Web.SiteUsers.Add(userName, "", "", "");
    }

    /// <summary>
    /// Gets the name of the user id from user.
    /// </summary>
    /// <param name="site">The site.</param>
    /// <param name="userName">Name of the user.</param>
    /// <returns></returns>
    private int GetUserIdFromUserName (SPWeb site, string userName) {
      // get the user's info
      Microsoft.SharePoint.Utilities.SPPrincipalInfo principalInfo =
        Microsoft.SharePoint.Utilities.SPUtility.ResolvePrincipal(site,
          userName,
          SPPrincipalType.All,
          SPPrincipalSource.All,
          null,
          false);

      // if the user was found, return their ID, else -1
      if (principalInfo != null)
        return principalInfo.PrincipalId;
      else
        return -1;
    }
    #endregion
  }
}
