using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace Lab10Solution
{
	public sealed partial class MajorityApprovers
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.CanModifyActivities = true;
      System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind11 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind12 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken3 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind13 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind14 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind15 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind16 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind17 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind18 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind19 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind20 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind21 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind22 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind23 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind24 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind25 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind26 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind27 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind28 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind29 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind30 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind31 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
      System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference2 = new System.Workflow.Activities.Rules.RuleConditionReference();
      System.Workflow.ComponentModel.ActivityBind activitybind32 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind33 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference3 = new System.Workflow.Activities.Rules.RuleConditionReference();
      System.Workflow.ComponentModel.ActivityBind activitybind34 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind35 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.ComponentModel.ActivityBind activitybind37 = new System.Workflow.ComponentModel.ActivityBind();
      System.Workflow.Runtime.CorrelationToken correlationtoken4 = new System.Workflow.Runtime.CorrelationToken();
      System.Workflow.ComponentModel.ActivityBind activitybind36 = new System.Workflow.ComponentModel.ActivityBind();
      this.logCharlieTaskChanged = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.completeTask3 = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
      this.onCharlieTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
      this.logBetaTaskChanged = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.completeTask2 = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
      this.onBetaTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
      this.logAlphaTaskChanged = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.completeTask1 = new Microsoft.SharePoint.WorkflowActions.CompleteTask();
      this.onAlphaTaskChanged = new Microsoft.SharePoint.WorkflowActions.OnTaskChanged();
      this.logItemRejected = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.rejectItem = new System.Workflow.Activities.CodeActivity();
      this.logItemApproved = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.approveItem = new System.Workflow.Activities.CodeActivity();
      this.eventDrivenActivity3 = new System.Workflow.Activities.EventDrivenActivity();
      this.eventDrivenActivity2 = new System.Workflow.Activities.EventDrivenActivity();
      this.eventDrivenActivity1 = new System.Workflow.Activities.EventDrivenActivity();
      this.logCharlieTaskCreated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.createCharlieApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
      this.logBetaTaskCreated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.createBetaApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
      this.logAlphaTaskCreated = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.createAlphaApprovalTask = new Microsoft.SharePoint.WorkflowActions.CreateTask();
      this.ifElseBranchActivity2 = new System.Workflow.Activities.IfElseBranchActivity();
      this.ifElseBranchActivity1 = new System.Workflow.Activities.IfElseBranchActivity();
      this.taskChangedListenActivity = new System.Workflow.Activities.ListenActivity();
      this.approverCharlieSequence = new System.Workflow.Activities.SequenceActivity();
      this.approverBetaSequence = new System.Workflow.Activities.SequenceActivity();
      this.approverAlphaSequence = new System.Workflow.Activities.SequenceActivity();
      this.logWorkflowComplete = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.ifElse = new System.Workflow.Activities.IfElseActivity();
      this.whileNoMajorityDecision = new System.Workflow.Activities.WhileActivity();
      this.createTasksParallel = new System.Workflow.Activities.ParallelActivity();
      this.logWorkflowStarted = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
      this.onWorkflowActivated = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
      // 
      // logCharlieTaskChanged
      // 
      this.logCharlieTaskChanged.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logCharlieTaskChanged.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind1.Name = "MajorityApprovers";
      activitybind1.Path = "HistoryDescription";
      activitybind2.Name = "MajorityApprovers";
      activitybind2.Path = "HistoryOutcome";
      this.logCharlieTaskChanged.Name = "logCharlieTaskChanged";
      this.logCharlieTaskChanged.OtherData = "";
      this.logCharlieTaskChanged.UserId = -1;
      this.logCharlieTaskChanged.MethodInvoking += new System.EventHandler(this.logCharlieTaskChanged_MethodInvoking);
      this.logCharlieTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
      this.logCharlieTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
      // 
      // completeTask3
      // 
      correlationtoken1.Name = "charlieTaskToken";
      correlationtoken1.OwnerActivityName = "MajorityApprovers";
      this.completeTask3.CorrelationToken = correlationtoken1;
      this.completeTask3.Name = "completeTask3";
      activitybind3.Name = "MajorityApprovers";
      activitybind3.Path = "CharlieTaskId";
      this.completeTask3.TaskOutcome = null;
      this.completeTask3.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
      // 
      // onCharlieTaskChanged
      // 
      activitybind4.Name = "MajorityApprovers";
      activitybind4.Path = "CharlieTaskAfterProperties";
      this.onCharlieTaskChanged.BeforeProperties = null;
      this.onCharlieTaskChanged.CorrelationToken = correlationtoken1;
      this.onCharlieTaskChanged.Executor = null;
      this.onCharlieTaskChanged.Name = "onCharlieTaskChanged";
      activitybind5.Name = "MajorityApprovers";
      activitybind5.Path = "CharlieTaskId";
      this.onCharlieTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onCharlieTaskChanged_Invoked);
      this.onCharlieTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
      this.onCharlieTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
      // 
      // logBetaTaskChanged
      // 
      this.logBetaTaskChanged.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logBetaTaskChanged.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind6.Name = "MajorityApprovers";
      activitybind6.Path = "HistoryDescription";
      activitybind7.Name = "MajorityApprovers";
      activitybind7.Path = "HistoryOutcome";
      this.logBetaTaskChanged.Name = "logBetaTaskChanged";
      this.logBetaTaskChanged.OtherData = "";
      this.logBetaTaskChanged.UserId = -1;
      this.logBetaTaskChanged.MethodInvoking += new System.EventHandler(this.logBetaTaskChanged_MethodInvoking);
      this.logBetaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
      this.logBetaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
      // 
      // completeTask2
      // 
      correlationtoken2.Name = "betaTaskToken";
      correlationtoken2.OwnerActivityName = "MajorityApprovers";
      this.completeTask2.CorrelationToken = correlationtoken2;
      this.completeTask2.Name = "completeTask2";
      activitybind8.Name = "MajorityApprovers";
      activitybind8.Path = "BetaTaskId";
      this.completeTask2.TaskOutcome = null;
      this.completeTask2.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
      // 
      // onBetaTaskChanged
      // 
      activitybind9.Name = "MajorityApprovers";
      activitybind9.Path = "BetaTaskAfterProperties";
      this.onBetaTaskChanged.BeforeProperties = null;
      this.onBetaTaskChanged.CorrelationToken = correlationtoken2;
      this.onBetaTaskChanged.Executor = null;
      this.onBetaTaskChanged.Name = "onBetaTaskChanged";
      activitybind10.Name = "MajorityApprovers";
      activitybind10.Path = "BetaTaskId";
      this.onBetaTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onBetaTaskChanged_Invoked);
      this.onBetaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
      this.onBetaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
      // 
      // logAlphaTaskChanged
      // 
      this.logAlphaTaskChanged.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logAlphaTaskChanged.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind11.Name = "MajorityApprovers";
      activitybind11.Path = "HistoryDescription";
      activitybind12.Name = "MajorityApprovers";
      activitybind12.Path = "HistoryOutcome";
      this.logAlphaTaskChanged.Name = "logAlphaTaskChanged";
      this.logAlphaTaskChanged.OtherData = "";
      this.logAlphaTaskChanged.UserId = -1;
      this.logAlphaTaskChanged.MethodInvoking += new System.EventHandler(this.logAlphaTaskChanged_MethodInvoking);
      this.logAlphaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind11)));
      this.logAlphaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind12)));
      // 
      // completeTask1
      // 
      correlationtoken3.Name = "alphaTaskToken";
      correlationtoken3.OwnerActivityName = "MajorityApprovers";
      this.completeTask1.CorrelationToken = correlationtoken3;
      this.completeTask1.Name = "completeTask1";
      activitybind13.Name = "MajorityApprovers";
      activitybind13.Path = "AlphaTaskId";
      this.completeTask1.TaskOutcome = null;
      this.completeTask1.SetBinding(Microsoft.SharePoint.WorkflowActions.CompleteTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind13)));
      // 
      // onAlphaTaskChanged
      // 
      activitybind14.Name = "MajorityApprovers";
      activitybind14.Path = "AlphaTaskAfterProperties";
      this.onAlphaTaskChanged.BeforeProperties = null;
      this.onAlphaTaskChanged.CorrelationToken = correlationtoken3;
      this.onAlphaTaskChanged.Executor = null;
      this.onAlphaTaskChanged.Name = "onAlphaTaskChanged";
      activitybind15.Name = "MajorityApprovers";
      activitybind15.Path = "AlphaTaskId";
      this.onAlphaTaskChanged.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onAlphaTaskChanged_Invoked);
      this.onAlphaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind15)));
      this.onAlphaTaskChanged.SetBinding(Microsoft.SharePoint.WorkflowActions.OnTaskChanged.AfterPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind14)));
      // 
      // logItemRejected
      // 
      this.logItemRejected.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logItemRejected.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind16.Name = "MajorityApprovers";
      activitybind16.Path = "HistoryDescription";
      activitybind17.Name = "MajorityApprovers";
      activitybind17.Path = "HistoryOutcome";
      this.logItemRejected.Name = "logItemRejected";
      this.logItemRejected.OtherData = "";
      this.logItemRejected.UserId = -1;
      this.logItemRejected.MethodInvoking += new System.EventHandler(this.logItemRejected_MethodInvoking);
      this.logItemRejected.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind16)));
      this.logItemRejected.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind17)));
      // 
      // rejectItem
      // 
      this.rejectItem.Name = "rejectItem";
      this.rejectItem.ExecuteCode += new System.EventHandler(this.rejectItem_ExecuteCode);
      // 
      // logItemApproved
      // 
      this.logItemApproved.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logItemApproved.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind18.Name = "MajorityApprovers";
      activitybind18.Path = "HistoryDescription";
      activitybind19.Name = "MajorityApprovers";
      activitybind19.Path = "HistoryOutcome";
      this.logItemApproved.Name = "logItemApproved";
      this.logItemApproved.OtherData = "";
      this.logItemApproved.UserId = -1;
      this.logItemApproved.MethodInvoking += new System.EventHandler(this.logItemApproved_MethodInvoking);
      this.logItemApproved.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind18)));
      this.logItemApproved.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind19)));
      // 
      // approveItem
      // 
      this.approveItem.Name = "approveItem";
      this.approveItem.ExecuteCode += new System.EventHandler(this.approveItem_ExecuteCode);
      // 
      // eventDrivenActivity3
      // 
      this.eventDrivenActivity3.Activities.Add(this.onCharlieTaskChanged);
      this.eventDrivenActivity3.Activities.Add(this.completeTask3);
      this.eventDrivenActivity3.Activities.Add(this.logCharlieTaskChanged);
      this.eventDrivenActivity3.Name = "eventDrivenActivity3";
      // 
      // eventDrivenActivity2
      // 
      this.eventDrivenActivity2.Activities.Add(this.onBetaTaskChanged);
      this.eventDrivenActivity2.Activities.Add(this.completeTask2);
      this.eventDrivenActivity2.Activities.Add(this.logBetaTaskChanged);
      this.eventDrivenActivity2.Name = "eventDrivenActivity2";
      // 
      // eventDrivenActivity1
      // 
      this.eventDrivenActivity1.Activities.Add(this.onAlphaTaskChanged);
      this.eventDrivenActivity1.Activities.Add(this.completeTask1);
      this.eventDrivenActivity1.Activities.Add(this.logAlphaTaskChanged);
      this.eventDrivenActivity1.Name = "eventDrivenActivity1";
      // 
      // logCharlieTaskCreated
      // 
      this.logCharlieTaskCreated.Description = "Logs that approval task for charlie approver has been created.";
      this.logCharlieTaskCreated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logCharlieTaskCreated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind20.Name = "MajorityApprovers";
      activitybind20.Path = "HistoryDescription";
      activitybind21.Name = "MajorityApprovers";
      activitybind21.Path = "HistoryOutcome";
      this.logCharlieTaskCreated.Name = "logCharlieTaskCreated";
      this.logCharlieTaskCreated.OtherData = "";
      this.logCharlieTaskCreated.UserId = -1;
      this.logCharlieTaskCreated.MethodInvoking += new System.EventHandler(this.logCharlieTaskCreated_MethodInvoking);
      this.logCharlieTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind20)));
      this.logCharlieTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind21)));
      // 
      // createCharlieApprovalTask
      // 
      this.createCharlieApprovalTask.CorrelationToken = correlationtoken1;
      this.createCharlieApprovalTask.Description = "Creates approval task for charlie approver.";
      this.createCharlieApprovalTask.ListItemId = -1;
      this.createCharlieApprovalTask.Name = "createCharlieApprovalTask";
      this.createCharlieApprovalTask.SpecialPermissions = null;
      activitybind22.Name = "MajorityApprovers";
      activitybind22.Path = "CharlieTaskId";
      activitybind23.Name = "MajorityApprovers";
      activitybind23.Path = "CharlieTaskProperties";
      this.createCharlieApprovalTask.MethodInvoking += new System.EventHandler(this.createCharlieApprovalTask_MethodInvoking);
      this.createCharlieApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind22)));
      this.createCharlieApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind23)));
      // 
      // logBetaTaskCreated
      // 
      this.logBetaTaskCreated.Description = "Logs that approval task for beta approver has been created.";
      this.logBetaTaskCreated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logBetaTaskCreated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind24.Name = "MajorityApprovers";
      activitybind24.Path = "HistoryDescription";
      activitybind25.Name = "MajorityApprovers";
      activitybind25.Path = "HistoryOutcome";
      this.logBetaTaskCreated.Name = "logBetaTaskCreated";
      this.logBetaTaskCreated.OtherData = "";
      this.logBetaTaskCreated.UserId = -1;
      this.logBetaTaskCreated.MethodInvoking += new System.EventHandler(this.logBetaTaskCreated_MethodInvoking);
      this.logBetaTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind24)));
      this.logBetaTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind25)));
      // 
      // createBetaApprovalTask
      // 
      this.createBetaApprovalTask.CorrelationToken = correlationtoken2;
      this.createBetaApprovalTask.Description = "Creates approval task for beta approver.";
      this.createBetaApprovalTask.ListItemId = -1;
      this.createBetaApprovalTask.Name = "createBetaApprovalTask";
      this.createBetaApprovalTask.SpecialPermissions = null;
      activitybind26.Name = "MajorityApprovers";
      activitybind26.Path = "BetaTaskId";
      activitybind27.Name = "MajorityApprovers";
      activitybind27.Path = "BetaTaskProperties";
      this.createBetaApprovalTask.MethodInvoking += new System.EventHandler(this.createBetaApprovalTask_MethodInvoking);
      this.createBetaApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind26)));
      this.createBetaApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind27)));
      // 
      // logAlphaTaskCreated
      // 
      this.logAlphaTaskCreated.Description = "Logs that approval task for alpha approver has been created.";
      this.logAlphaTaskCreated.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logAlphaTaskCreated.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind28.Name = "MajorityApprovers";
      activitybind28.Path = "HistoryDescription";
      activitybind29.Name = "MajorityApprovers";
      activitybind29.Path = "HistoryOutcome";
      this.logAlphaTaskCreated.Name = "logAlphaTaskCreated";
      this.logAlphaTaskCreated.OtherData = "";
      this.logAlphaTaskCreated.UserId = -1;
      this.logAlphaTaskCreated.MethodInvoking += new System.EventHandler(this.logAlphaTaskCreated_MethodInvoking);
      this.logAlphaTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind28)));
      this.logAlphaTaskCreated.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind29)));
      // 
      // createAlphaApprovalTask
      // 
      this.createAlphaApprovalTask.CorrelationToken = correlationtoken3;
      this.createAlphaApprovalTask.Description = "Creates approval task for alpha approver.";
      this.createAlphaApprovalTask.ListItemId = -1;
      this.createAlphaApprovalTask.Name = "createAlphaApprovalTask";
      this.createAlphaApprovalTask.SpecialPermissions = null;
      activitybind30.Name = "MajorityApprovers";
      activitybind30.Path = "AlphaTaskId";
      activitybind31.Name = "MajorityApprovers";
      activitybind31.Path = "AlphaTaskProperties";
      this.createAlphaApprovalTask.MethodInvoking += new System.EventHandler(this.createAlphaApprovalTask_MethodInvoking);
      this.createAlphaApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind30)));
      this.createAlphaApprovalTask.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTask.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind31)));
      // 
      // ifElseBranchActivity2
      // 
      this.ifElseBranchActivity2.Activities.Add(this.rejectItem);
      this.ifElseBranchActivity2.Activities.Add(this.logItemRejected);
      ruleconditionreference1.ConditionName = "Majority rejected";
      this.ifElseBranchActivity2.Condition = ruleconditionreference1;
      this.ifElseBranchActivity2.Name = "ifElseBranchActivity2";
      // 
      // ifElseBranchActivity1
      // 
      this.ifElseBranchActivity1.Activities.Add(this.approveItem);
      this.ifElseBranchActivity1.Activities.Add(this.logItemApproved);
      ruleconditionreference2.ConditionName = "Majority approved";
      this.ifElseBranchActivity1.Condition = ruleconditionreference2;
      this.ifElseBranchActivity1.Name = "ifElseBranchActivity1";
      // 
      // taskChangedListenActivity
      // 
      this.taskChangedListenActivity.Activities.Add(this.eventDrivenActivity1);
      this.taskChangedListenActivity.Activities.Add(this.eventDrivenActivity2);
      this.taskChangedListenActivity.Activities.Add(this.eventDrivenActivity3);
      this.taskChangedListenActivity.Name = "taskChangedListenActivity";
      // 
      // approverCharlieSequence
      // 
      this.approverCharlieSequence.Activities.Add(this.createCharlieApprovalTask);
      this.approverCharlieSequence.Activities.Add(this.logCharlieTaskCreated);
      this.approverCharlieSequence.Name = "approverCharlieSequence";
      // 
      // approverBetaSequence
      // 
      this.approverBetaSequence.Activities.Add(this.createBetaApprovalTask);
      this.approverBetaSequence.Activities.Add(this.logBetaTaskCreated);
      this.approverBetaSequence.Name = "approverBetaSequence";
      // 
      // approverAlphaSequence
      // 
      this.approverAlphaSequence.Activities.Add(this.createAlphaApprovalTask);
      this.approverAlphaSequence.Activities.Add(this.logAlphaTaskCreated);
      this.approverAlphaSequence.Name = "approverAlphaSequence";
      // 
      // logWorkflowComplete
      // 
      this.logWorkflowComplete.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logWorkflowComplete.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind32.Name = "MajorityApprovers";
      activitybind32.Path = "HistoryDescription";
      activitybind33.Name = "MajorityApprovers";
      activitybind33.Path = "HistoryOutcome";
      this.logWorkflowComplete.Name = "logWorkflowComplete";
      this.logWorkflowComplete.OtherData = "";
      this.logWorkflowComplete.UserId = -1;
      this.logWorkflowComplete.MethodInvoking += new System.EventHandler(this.logWorkflowComplete_MethodInvoking);
      this.logWorkflowComplete.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind32)));
      this.logWorkflowComplete.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind33)));
      // 
      // ifElse
      // 
      this.ifElse.Activities.Add(this.ifElseBranchActivity1);
      this.ifElse.Activities.Add(this.ifElseBranchActivity2);
      this.ifElse.Name = "ifElse";
      // 
      // whileNoMajorityDecision
      // 
      this.whileNoMajorityDecision.Activities.Add(this.taskChangedListenActivity);
      ruleconditionreference3.ConditionName = "Majority has not answered";
      this.whileNoMajorityDecision.Condition = ruleconditionreference3;
      this.whileNoMajorityDecision.Name = "whileNoMajorityDecision";
      // 
      // createTasksParallel
      // 
      this.createTasksParallel.Activities.Add(this.approverAlphaSequence);
      this.createTasksParallel.Activities.Add(this.approverBetaSequence);
      this.createTasksParallel.Activities.Add(this.approverCharlieSequence);
      this.createTasksParallel.Name = "createTasksParallel";
      // 
      // logWorkflowStarted
      // 
      this.logWorkflowStarted.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
      this.logWorkflowStarted.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
      activitybind34.Name = "MajorityApprovers";
      activitybind34.Path = "HistoryDescription";
      activitybind35.Name = "MajorityApprovers";
      activitybind35.Path = "HistoryOutcome";
      this.logWorkflowStarted.Name = "logWorkflowStarted";
      this.logWorkflowStarted.OtherData = "";
      this.logWorkflowStarted.UserId = -1;
      this.logWorkflowStarted.MethodInvoking += new System.EventHandler(this.logWorkflowStarted_MethodInvoking);
      this.logWorkflowStarted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryDescriptionProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind34)));
      this.logWorkflowStarted.SetBinding(Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity.HistoryOutcomeProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind35)));
      activitybind37.Name = "MajorityApprovers";
      activitybind37.Path = "workflowId";
      // 
      // onWorkflowActivated
      // 
      correlationtoken4.Name = "workflowToken";
      correlationtoken4.OwnerActivityName = "MajorityApprovers";
      this.onWorkflowActivated.CorrelationToken = correlationtoken4;
      this.onWorkflowActivated.EventName = "OnWorkflowActivated";
      this.onWorkflowActivated.Name = "onWorkflowActivated";
      activitybind36.Name = "MajorityApprovers";
      activitybind36.Path = "workflowProperties";
      this.onWorkflowActivated.Invoked += new System.EventHandler<System.Workflow.Activities.ExternalDataEventArgs>(this.onWorkflowActivated_Invoked);
      this.onWorkflowActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowIdProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind37)));
      this.onWorkflowActivated.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind36)));
      // 
      // MajorityApprovers
      // 
      this.Activities.Add(this.onWorkflowActivated);
      this.Activities.Add(this.logWorkflowStarted);
      this.Activities.Add(this.createTasksParallel);
      this.Activities.Add(this.whileNoMajorityDecision);
      this.Activities.Add(this.ifElse);
      this.Activities.Add(this.logWorkflowComplete);
      this.Name = "MajorityApprovers";
      this.CanModifyActivities = false;

		}

		#endregion

    private EventDrivenActivity eventDrivenActivity3;
    private EventDrivenActivity eventDrivenActivity2;
    private EventDrivenActivity eventDrivenActivity1;
    private ListenActivity taskChangedListenActivity;
    private Microsoft.SharePoint.WorkflowActions.CompleteTask completeTask3;
    private Microsoft.SharePoint.WorkflowActions.CompleteTask completeTask2;
    private Microsoft.SharePoint.WorkflowActions.CompleteTask completeTask1;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logCharlieTaskChanged;
    private Microsoft.SharePoint.WorkflowActions.OnTaskChanged onCharlieTaskChanged;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logBetaTaskChanged;
    private Microsoft.SharePoint.WorkflowActions.OnTaskChanged onBetaTaskChanged;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logAlphaTaskChanged;
    private Microsoft.SharePoint.WorkflowActions.OnTaskChanged onAlphaTaskChanged;
    private IfElseBranchActivity ifElseBranchActivity2;
    private IfElseBranchActivity ifElseBranchActivity1;
    private IfElseActivity ifElse;
    private CodeActivity approveItem;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logItemRejected;
    private CodeActivity rejectItem;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logItemApproved;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logWorkflowComplete;
    private WhileActivity whileNoMajorityDecision;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logCharlieTaskCreated;
    private Microsoft.SharePoint.WorkflowActions.CreateTask createCharlieApprovalTask;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logBetaTaskCreated;
    private Microsoft.SharePoint.WorkflowActions.CreateTask createBetaApprovalTask;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logAlphaTaskCreated;
    private Microsoft.SharePoint.WorkflowActions.CreateTask createAlphaApprovalTask;
    private SequenceActivity approverCharlieSequence;
    private SequenceActivity approverBetaSequence;
    private SequenceActivity approverAlphaSequence;
    private ParallelActivity createTasksParallel;
    private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logWorkflowStarted;
    private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated;























































































































  }
}
