using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;

namespace Lab7Solution {
  public class FieldResourceIconControl : BaseFieldControl, IDesignTimeHtmlProvider {
    private const string RENDERING_TEMPLATE_NAME = "FieldResourceIconControl";

    protected TextBox _txbTitle;
    protected TextBox _txbDescription;
    protected TextBox _txbUrlTarget;
    protected DropDownList _ddlIcon;

    /// <summary>
    /// Gets the name of the default template.
    /// </summary>
    /// <value>The name of the default template.</value>
    protected override string DefaultTemplateName {
      get {
        return RENDERING_TEMPLATE_NAME;
      }
    }

    /// <summary>
    /// Creates the child controls.
    /// </summary>
    protected override void CreateChildControls () {
      // don't do anything if this is display mode or if the field has nothing assigned to it
      if (this.Field == null || this.ControlMode == SPControlMode.Display || this.ControlMode == SPControlMode.Invalid)
        return;

      base.CreateChildControls();

      // get reference to the control
      this._txbTitle = TemplateContainer.FindControl("ResourceTitle") as TextBox;
      if (this._txbTitle == null)
        throw new System.Configuration.ConfigurationErrorsException("ResourceTitle TextBox not found. Corrupt control template.");

      this._txbDescription = TemplateContainer.FindControl("ResourceDescription") as TextBox;
      if (this._txbDescription == null)
        throw new System.Configuration.ConfigurationErrorsException("ResourceDescription TextBox not found. Corrupt control template.");


      this._txbUrlTarget = TemplateContainer.FindControl("ResourceUrl") as TextBox;
      if (this._txbUrlTarget == null)
        throw new System.Configuration.ConfigurationErrorsException("ResourceUrl TextBox not found. Corrupt control template.");

      this._ddlIcon = TemplateContainer.FindControl("ResourceIcon") as DropDownList;
      if (this._ddlIcon == null)
        throw new System.Configuration.ConfigurationErrorsException("ResourceIcon DropDownList not found. Corrupt control template.");

      // init the drop down list
      this._ddlIcon.Items.Add(new ListItem("Binoculars", "binoculars"));
      this._ddlIcon.Items.Add(new ListItem("Cantine", "cantine"));
      this._ddlIcon.Items.Add(new ListItem("Compass", "compass"));
      this._ddlIcon.Items.Add(new ListItem("Brown pith helmet", "pithHelmetBrown"));
      this._ddlIcon.Items.Add(new ListItem("White pith helmet", "pithHelmetWhite"));
    }

    /// <summary>
    /// Gets or sets the value.
    /// </summary>
    /// <value>The value.</value>
    public override object Value {
      get {
        EnsureChildControls();
        
        // fetch values from rendering control return back as an object
        FieldResourceIconValue field = new FieldResourceIconValue();
        field.Title = this._txbTitle.Text.Trim();
        field.Description = this._txbDescription.Text.Trim();
        field.UrlTarget = this._txbUrlTarget.Text.Trim();
        field.Icon = this._ddlIcon.SelectedValue;

        return field;
      }
      set {
        EnsureChildControls();

        // if something stored in the value, init controls in rendering control
        if (value != null && !string.IsNullOrEmpty(value.ToString())) {
          FieldResourceIconValue field = new FieldResourceIconValue(value.ToString());
          this._txbTitle.Text = field.Title;
          this._txbDescription.Text = field.Description;
          this._txbUrlTarget.Text = field.UrlTarget;
            
          this._ddlIcon.Items.FindByValue(field.Icon).Selected = true;            
        }
      }
    }

    /// <summary>
    /// Returns the control as design-time HTML for editing in Web site development 
    /// tools such as SharePoint Designer 2007.
    /// </summary>
    /// <returns>
    /// A string that contains the design-time HTML.
    /// </returns>
    string IDesignTimeHtmlProvider.GetDesignTimeHtml () {
      StringBuilder designTimePreview = new StringBuilder();

      // build out the SharePoint stock tabbed UI with placeholders for the field name & preview HTML
      designTimePreview.Append("<div align=\"left\" class=\"ms-formfieldcontainer\">");

      designTimePreview.Append("<div class=\"ms-formfieldlabelcontainer\" nowrap=\"nowrap\">");
      designTimePreview.Append("<span class=\"ms-formfieldlabel\" nowrap=\"nowrap\">{0}</span>");
      designTimePreview.Append("</div>");

      designTimePreview.Append("<div class=\"ms-formfieldvaluecontainer\">");
      designTimePreview.Append("{1}");
      designTimePreview.Append("</div>");

      designTimePreview.Append("</div>");

      string previewRendering = "<img src=\"/_layouts/1033/images/noresult.gif\" />&nbsp;<a href=\"#\">Lorem ipsum dolor sit amet</a>";

      return string.Format(designTimePreview.ToString(),
                            this.Field.Title,
                            previewRendering);
    }

  }
}