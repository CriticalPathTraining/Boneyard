using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Deployment;

namespace ContentDeployment {
  class Program {

    private static string destinationUrl = "http://cd3.litwareinc.com";
    private static string destinationRootWebUrl;

    static void Main (string[] args) {
      try {
        SPImportSettings importSettings = new SPImportSettings();

        importSettings.CommandLineVerbose = true;
        importSettings.RetainObjectIdentity = true;
        importSettings.FileLocation = @"C:\windows\temp";
        importSettings.BaseFileName = "export.cmp";
        importSettings.SiteUrl = destinationUrl;
        importSettings.IncludeSecurity = SPIncludeSecurity.All;
        importSettings.UserInfoDateTime = SPImportUserInfoDateTimeOption.ImportAll;
        importSettings.SuppressAfterEvents = true;
        importSettings.UpdateVersions = SPUpdateVersions.Append;

        SPImport import = new SPImport(importSettings);


        SPChangeToken startChangeToken, endChangeToken;
        using (SPSite destinationSite = new SPSite(importSettings.SiteUrl)) {
          startChangeToken = destinationSite.CurrentChangeToken;
          destinationRootWebUrl = destinationSite.RootWeb.ServerRelativeUrl;
        }

        // Run the import
        import.Run();

        using (SPSite destinationSite = new SPSite(importSettings.SiteUrl)) {
          endChangeToken = destinationSite.CurrentChangeToken;
        }
      } catch (Exception ex) {
        Console.Error.Write(ex.ToString());
        throw;
      }

    }
  }
}