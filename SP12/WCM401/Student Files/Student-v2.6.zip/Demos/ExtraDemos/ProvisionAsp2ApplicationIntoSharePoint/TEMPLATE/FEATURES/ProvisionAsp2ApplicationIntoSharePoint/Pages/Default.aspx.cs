#region namespace references
using System;
using System.Web.UI.WebControls;
#endregion

namespace AndrewConnell.SharePoint.Samples.ProvisionAsp2ApplicationIntoSharePoint {
  public class Default: System.Web.UI.Page {
    protected Label CurrentTimestampLabel;

    /// <summary>
    /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
    /// </summary>
    /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
    protected override void OnLoad (EventArgs e) {
      this.CurrentTimestampLabel.Text = DateTime.Now.ToString();
    }
  }
}