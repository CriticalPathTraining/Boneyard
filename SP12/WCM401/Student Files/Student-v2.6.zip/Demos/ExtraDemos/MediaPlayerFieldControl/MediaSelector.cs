using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.Publishing.Fields;

namespace Microsoft.SDK.SharePointServer.Samples

/// A Field control that binds to fields of type LinkField and is 
  /// specialized to select and render embedded media files.
  /// The RenderFieldForDisplay function generates the HTML markup to 
  /// display the media file.  The MediaSelector control is
  /// used at edit time to allow authors to select a media file in
  /// the Asset Picker dialog box.
{
  /// This edit control for the MediaPlayerFieldControl has 
  /// a toolbar and text box for selecting a media file URL.
  /// This example intentionally uses a separate toolbar button
  /// and text box for the AssetUrlSelctor to show a more complex
  /// example. You can use an AssetUrlSelector control instead of 
  /// a TextBox child control, which displays its own browse button.
  public class MediaSelector : WebControl {
    private TextBox _mediaUrlTextBox = new TextBox();

    public MediaSelector () {
    }

    /// This is the media URL value that you can edit in the text
    /// box or Asset Picker dialog box.
    public string MediaUrl {
      get { return this._mediaUrlTextBox.Text; }
      set { this._mediaUrlTextBox.Text = value; }
    }

    protected override void OnInit (EventArgs e) {
      base.OnInit(e);

      // This ensures that the TextBox child control receives
      // its postback.
      EnsureChildControls();
    }

    /// Gets JavaScript required to launch an Asset Picker dialog
    /// box for choosing a media file URL.
    private string GetAssetPickerButtonScript () {
      AssetUrlSelector mediaAssetSelector = new AssetUrlSelector();

      // When the AssetUrlSelector control is not added to the
      // page control tree, the Page and ID properties are
      // required because
      // AssetUrlSelector.GetClientLaunchPickerReference() 
      // needs register script in the page.
      mediaAssetSelector.Page = this.Page;
      mediaAssetSelector.ID = "MediaUrlAssetSelector";

      // Uses the TextBox client ID to connect the Asset Picker
      // dialog box to the text box.
      mediaAssetSelector.AssetUrlClientID = this._mediaUrlTextBox.ClientID;

      // Autopostback to see the new media file rendered after
      // clicking OK on the Asset Picker dialog box.
      mediaAssetSelector.AutoPostBack = true;

      mediaAssetSelector.OverrideDialogTitle = "Select a media file";
      mediaAssetSelector.OverrideDialogDescription = "Select a media file to embed in this page";
      mediaAssetSelector.UseImageAssetPicker = false;

      return mediaAssetSelector.GetClientLaunchPickerReference();
    }

    private Literal mediaPlayerOutput = new Literal();
    protected override void CreateChildControls () {
      SimpleToolbar mediaSelectorToolbar = new SimpleToolbar();
      mediaSelectorToolbar.ID = "ToolBar";

      this.Controls.Add(mediaSelectorToolbar);

      Label mediaUrlLabel = new Label();
      mediaUrlLabel.Text = "Selected media file URL: ";
      mediaUrlLabel.AssociatedControlID = "MediaUrlTextBox";
      this.Controls.Add(mediaUrlLabel);

      this._mediaUrlTextBox.ID = "MediaUrlTextBox";
      this._mediaUrlTextBox.CssClass = "ms-input ms-lactiontable sample-mediaselector-urltextbox";
      this.Controls.Add(this._mediaUrlTextBox);

      // Add the button after the rest so that the text box
      // ClientID is already determined and can be connected
      // in the Asset Picker dialog box client script.
      mediaSelectorToolbar.AddToolbarButton(
          "SelectMediaFile",
          "Select a media file",
          this.GetAssetPickerButtonScript(),
          "Open a picker to select a media file URL");

      // Add a refresh button to perform a basic postback to
      // to update the MediaUrl rendering.
      mediaSelectorToolbar.AddToolbarButton(
          "RefreshMediaFile",
          "Refresh",
          this.Page.ClientScript.GetPostBackEventReference(this,
            String.Empty),
            "Refresh the page to reload the current media file URL",
            "/_layouts/IMAGES/refresh.gif");

      // If there is a media file URL, this code creates
      // the media player markup.
      this.Controls.Add(this.mediaPlayerOutput);
    }

    protected override void OnPreRender (EventArgs e) {
      string mediaFileOutputHtml =
        MediaRenderingUtilities.GetMediaPlayerHtmlMarkup(this.MediaUrl);
      if (String.IsNullOrEmpty(mediaFileOutputHtml)) {
        this.mediaPlayerOutput.Text = "<BR>{There is no valid media file URL to display}<BR>";
      } else {
        this.mediaPlayerOutput.Text = "<BR>" + mediaFileOutputHtml + "<BR>";
      }

      base.OnPreRender(e);
    }
  }

  /// A simple toolbar class that matches the styles of the
  /// publishing field control toolbars.
  public class SimpleToolbar : RepeatedControls {
    public SimpleToolbar () {
      this.HeaderHtml = "<div class=\"ms-toolbarContainer\" width=\"100%\">";
      this.FooterHtml = "</div>";
      this.SeparatorHtml = "";
    }

    public void AddToolbarButton (
        string buttonId,
        string buttonText,
        string clientOnClick,
        string tooltipText) {
      Literal buttonMarkupLiteral = new Literal();

      buttonMarkupLiteral.Text = String.Format(
              SimpleToolbarButtonHtmlFormat,
              SPHttpUtility.HtmlEncode(buttonText),
              SPHttpUtility.HtmlEncode(clientOnClick),
              SPHttpUtility.HtmlEncode(tooltipText));
      buttonMarkupLiteral.ID = buttonId;

      this.Controls.Add(buttonMarkupLiteral);
    }

    public void AddToolbarButton (
        string buttonId,
        string buttonText,
        string clientOnClick,
        string tooltipText,
        string buttonImageSrc) {
      Literal buttonMarkupLiteral = new Literal();

      buttonMarkupLiteral.Text = String.Format(
              SimpleToolbarButtonImageHtmlFormat,
              SPHttpUtility.HtmlEncode(buttonText),
              SPHttpUtility.HtmlEncode(clientOnClick),
              SPHttpUtility.HtmlEncode(tooltipText),
              SPHttpUtility.HtmlUrlAttributeEncode(buttonImageSrc));
      buttonMarkupLiteral.ID = buttonId;

      this.Controls.Add(buttonMarkupLiteral);
    }

    // {0} = Button text
    // {1} = onclick script
    // {2} = Tooltip text
    private const string SimpleToolbarButtonHtmlFormat = @"
        <DIV class=""ms-toolbarItem ms-selectorlink"">
           <A href=""#"" onclick=""{1}"" title=""{2}"">&nbsp;{0}</A>
        </DIV>";

    // {0} = Button text
    // {1} = onclick script
    // {2} = Tooltip text
    // {3} = Button image markup
    private const string SimpleToolbarButtonImageHtmlFormat = @"
        <DIV class=""ms-toolbarItem ms-selectorlink"">
           <A href=""#"" onclick=""{1}"" title=""{2}"">
           <IMG alt=""{2}"" src=""{3}"" border=""0"">{0}</A>
        </DIV>";
  }

  public static class MediaRenderingUtilities {
    /// Take a media file URL and generate HTML markup
    /// for playing the file.
    /// <param name="mediaUrl"></param>
    public static string GetMediaPlayerHtmlMarkup (string mediaUrl) {
      // HtmlUrlAttributeEncode returns an empty string if the 
      // URL protocol is not allowed (e.g., JavaScript:)
      string encodedUrl =
          SPHttpUtility.HtmlUrlAttributeEncode(mediaUrl);

      if (String.IsNullOrEmpty(encodedUrl)) {
        return String.Empty;
      } else {
        return String.Format(MediaPlayerHtmlMarkupFormat, encodedUrl);
      }
    }

    // Currently, this code includes only a parameter for the media
    // file URL, but it could also include parameters for the
    // width, height, and other rendering properties from field
    // control properties or authored data value properties.
    private const string MediaPlayerHtmlMarkupFormat = @"
<object type=""video/x-ms-wmv""
  data=""{0}""
  width=""300"" height=""450"">
  <param name=""src"" value=""{0}"" />
  <param name=""autostart"" value=""true"" />
  <param name=""controller"" value=""true"" />
</object>
";
  }
}