Create new field of type Publishing Hyperlink

Add new field to Page Layout

Add following register directive:
<%@ Register Tagprefix="CustomFieldControl" Namespace="Microsoft.SDK.SharePointServer.Samples" Assembly="Microsoft.SDK.SharePointServer.Samples, Version=1.0.0.0, Culture=neutral, PublicKeyToken=0e79c3b861c1de08" %>

Replace field control tag for new Publishing Hyperlink field with the new server control tag:
<CustomFieldControl:MediaPlayerFieldControl id="SampleMediaPlayerFieldControl" FieldName="MediaLink" runat="server" />