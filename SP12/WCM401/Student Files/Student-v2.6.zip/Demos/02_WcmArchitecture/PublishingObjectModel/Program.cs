using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;

namespace PublishingObjectModel {
  class Program {
    static void Main (string[] args) {
      // get reference  to the litware publishing site
      using (SPSite siteCollection = new SPSite("http://wcm.litwareinc.com")) {
        // get reference to the publishing site
        PublishingSite publishingSite = new PublishingSite(siteCollection);
        Console.Out.WriteLine("Publising site collection properties:");
        Console.Out.WriteLine("  Underlying SPSite URL: {0}", publishingSite.Site.Url);
        Console.Out.WriteLine("  Total page layouts in Master Page Gallery: {0}", publishingSite.PageLayouts.Count.ToString());
        Console.Out.WriteLine("");

        // list all page layouts and their associated content types in the Master Page Gallery
        Console.Out.WriteLine("  Page Layouts in Master Page Gallery:");
        Console.Out.WriteLine("     Content Type  -  Page Layout");
        PageLayoutCollection layouts;

        // loop through all content types
        foreach (SPContentType contentType in publishingSite.ContentTypes) {
          // if there is at least one page layout for the specified content type, display it
          layouts = publishingSite.GetPageLayouts(contentType, true);
          if (layouts.Count > 0)
            foreach (PageLayout layout in layouts)
              Console.Out.WriteLine("     {0}  -  {1}", contentType.Name.ToString(), layout.Name.ToString());
        }

        Console.Out.WriteLine("");
        Console.Out.WriteLine("");

        // get reference to the publishing web
        PublishingWeb publishingWeb = PublishingWeb.GetPublishingWeb(siteCollection.RootWeb);
        
        // write out all pages within the root web
        Console.Out.WriteLine("Publishing pages within the root web's Pages library:");
        foreach (PublishingPage page in publishingWeb.GetPublishingPages()) {
          Console.Out.WriteLine("  Page: {0}", page.Name);
          Console.Out.WriteLine("  Page URL {0}", page.Url);
          Console.Out.WriteLine("  Underlying SPListItem ID: {0}", page.ListItem.ID.ToString());
        }

        publishingWeb.Close();
      }
      Console.Out.WriteLine("Press any key to continue...");
      Console.ReadLine();
    }
  }
}