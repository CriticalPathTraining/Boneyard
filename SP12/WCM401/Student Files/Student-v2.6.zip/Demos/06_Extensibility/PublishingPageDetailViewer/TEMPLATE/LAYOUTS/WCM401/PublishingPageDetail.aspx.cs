#region namespace references
using System;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
#endregion

namespace PublishingPageDetailViewer {
  public class PublishingPageDetail : LayoutsPageBase {
    protected Literal litPageName;
    protected Literal litPageUrl;
    protected Literal litPageVersion;
    protected HyperLink lnkPageContentType;
    protected Literal litPubStartDate;
    protected Literal litPubEndDate;
    protected Literal litPageContact;
    protected HyperLink lnkPageHistory;
    protected HyperLink lnkPageProperties;

    protected Literal litLayoutName;
    protected HyperLink lnkLayoutFileName;
    protected Literal litLayoutVersion;
    protected HyperLink lnkLayoutHistory;
    protected HyperLink lnkLayoutProperties;

    /// <summary>
    /// Gets the publishing page.
    /// </summary>
    /// <returns></returns>
    private PublishingPage GetPublishingPage () {
      // get querystring parms of the current web and page
      string pubPageID = Request.QueryString["pageid"].ToString();

      PublishingWeb pubWeb = null;
      PublishingPage page = null;

      try {
        // get reference to publishing web & specific page
        pubWeb = PublishingWeb.GetPublishingWeb(SPContext.Current.Web);

        string query = string.Format("<Where><Eq><FieldRef Name=\"ID\" /><Value Type=\"Counter\">{0}</Value></Eq></Where>", pubPageID);
        page = pubWeb.GetPublishingPages(query)[0];

      } catch (Exception ex) {
        throw new SPException(string.Format("Error obtaining reference to current PublishingPage {{{0}}}.", pubPageID));
      }

      return page;
    }

    /// <summary>
    /// Sets the page properties.
    /// </summary>
    /// <param name="page">The page.</param>
    private void SetPageProperties (PublishingPage page) {
      this.litPageName.Text = page.Title;
      this.litPageUrl.Text = String.Format("{0}/{1}",
                                              page.PublishingWeb.Url,
                                              page.Url);
      this.litPageVersion.Text = page.ListItem.Versions[0].VersionLabel;

      // build content type
      this.lnkPageContentType.NavigateUrl = String.Format("{0}/_layouts/ManageContentType.aspx?ctype={1}",
            page.PublishingWeb.Url.ToString(),
            page.ContentType.Id.ToString());
      this.lnkPageContentType.Text = page.ContentType.Name;


      // set date
      this.litPubStartDate.Text = page.StartDate != new DateTime(1900, 1, 1, 0, 0, 0, 0) ? page.StartDate.ToString("dddd, MMMM dd, yyyy @ hh:mm tt") : "Immediately";
      this.litPubEndDate.Text = page.EndDate != new DateTime(2050, 1, 1, 0, 0, 0, 0) ? page.EndDate.ToString("dddd, MMMM dd, yyyy @ hh:mm tt") : "Never";

      // set contact
      if (page.Contact != null) {
        this.litPageContact.Text = page.Contact.Name;
        if (!string.IsNullOrEmpty(page.Contact.Email))
          this.litPageContact.Text += String.Format(" - <a href=\"mailto:{0}\">{1}</a>",
                                        page.Contact.Email,
                                        page.Contact.Email);
      } else if (page.LocalContactName != null)
        this.litPageContact.Text = string.Format("{0} {1}", page.LocalContactName, page.LocalContactEmail);
      else
        this.litPageContact.Text = "<em>not specified</em>";

      // build page history link
      this.lnkPageHistory.NavigateUrl = String.Format("{0}/_layouts/Versions.aspx?ID={1}&List={2}&FileName={3}",
        page.PublishingWeb.Url.ToString(),
        page.ListItem.ID.ToString(),
        page.ListItem.ParentList.ID.ToString(),
        page.ListItem.Url.ToString());

      // build page properties link
      this.lnkPageProperties.NavigateUrl = String.Format("{0}/{1}/Forms/DispForm.aspx?ID={2}&RootFolder={3}",
        page.PublishingWeb.Url.ToString(),
        page.ListItem.ParentList.RootFolder.Url.ToString(),
        page.ListItem.ID.ToString(),
        page.ListItem.ParentList.RootFolder.Url.ToString());
    }

    /// <summary>
    /// Sets the page layout properties.
    /// </summary>
    /// <param name="page"></param>
    /// <param name="layout">The layout.</param>
    private void SetPageLayoutProperties (PublishingPage page, PageLayout layout) {
      this.litLayoutName.Text = layout.Title;
      this.lnkLayoutFileName.Text = layout.Name;
      this.litLayoutVersion.Text = layout.ListItem.Versions[0].VersionLabel;

      // build page history link
      this.lnkLayoutHistory.NavigateUrl = String.Format("{0}/_layouts/Versions.aspx?ID={1}&List={2}&FileName={3}",
       SPContext.Current.Site.Url.ToString(),
        layout.ListItem.ID.ToString(),
        layout.ListItem.ParentList.ID.ToString(),
        layout.ListItem.Url.ToString());
      
      // build layout properties link
      this.lnkLayoutProperties.NavigateUrl = String.Format("{0}/_catalogs/masterpage/Forms/DispForm.aspx?ID={1}&RootFolder={2}",
        SPContext.Current.Site.Url.ToString(),
        layout.ListItem.ID.ToString(),
        layout.ListItem.ParentList.RootFolder.Url.ToString());

      // set the filename link to be the same url for viewing props
      this.lnkLayoutFileName.NavigateUrl = this.lnkLayoutProperties.NavigateUrl;
    }

    /// <summary>
    /// Raises the <see cref="E:Load"/> event.
    /// </summary>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    protected override void OnLoad (EventArgs e) {
      // get the page requested
      PublishingPage page = this.GetPublishingPage();

      // set breadcrumb

      this.SetPageProperties(page);
      this.SetPageLayoutProperties(page, page.Layout);
    }
  }
}