#region namespace references
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.Publishing.Fields;
#endregion

namespace AndrewConnell.SharePoint.Publishing.Examples.WidgetContentBuilder
{
    public class FeatureReceiver : SPFeatureReceiver
    {

        #region private methods
        /// <summary>
        /// Creates the widget site.
        /// </summary>
        /// <param name="siteCollection">The site collection.</param>
        private void CreateWidgetSite(SPSite siteCollection)
        {
            // create new widget web
            using (SPWeb widgetWeb = siteCollection.AllWebs.Add("Widgets", "Widgets", "Widget Product List", 1033, "BLANKINTERNET#1", false, false))
            {
                // get reference to the widget publishing web
                PublishingWeb widgetPubWeb = PublishingWeb.GetPublishingWeb(widgetWeb);

                // get reference to the widget content site
                SPContentTypeId widgetProductContentTypeID = new SPContentTypeId("0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF3900C0C10D33091B4FDA84868B619DCDEF16");

                // get reference to the sole page layout for this content type
                PageLayout widgetPageLayout = widgetPubWeb.GetAvailablePageLayouts(widgetProductContentTypeID)[0];

                // create some new widget product pages
                CreateWidgetPages(widgetPubWeb, widgetPageLayout);
            }
        }

        /// <summary>
        /// Creates the widget pages.
        /// </summary>
        /// <param name="widgetPubWeb">The widget pub web.</param>
        /// <param name="widgetPageLayout">The widget page layout.</param>
        private void CreateWidgetPages(PublishingWeb widgetPubWeb, PageLayout widgetPageLayout)
        {
            string pageTitle;
            string pageName;

            // create 10 new pages
            PublishingPage widgetPage;
            for (int i = 0; i < 10; i++)
            {
                pageTitle = String.Format("Widget Product {0}", i.ToString());
                pageName = String.Format("WidgetProduct{0}.aspx", i.ToString());

                // create a new page
                widgetPage = widgetPubWeb.GetPublishingPages().Add(pageName, widgetPageLayout);
                widgetPage.Title = pageTitle;

                // fill in content
                widgetPage.ListItem["ProductName"] = String.Format("Widget {0}", i.ToString());
                widgetPage.ListItem["ProductDescription"] = "<p>Lorum ipsum dolor sit anum consecutum.  Lorum ipsum dolor sit anum consecutum.  Lorum ipsum dolor sit anum consecutum.</p><p>Lorum ipsum dolor sit anum consecutum.  Lorum ipsum dolor sit anum consecutum.  Lorum ipsum dolor sit anum consecutum.</p>";

                ImageFieldValue image = new ImageFieldValue();
                image.ImageUrl = "/SiteCollectionImages/PR.gif";
                image.BorderWidth = 0;
                image.AlternateText = "";
                widgetPage.ListItem["ProductImage"] = image;

                if (i < 5)
                    widgetPage.ListItem["Division"] = "North America";
                else if (i < 7)
                    widgetPage.ListItem["Division"] = "Europe";
                else
                    widgetPage.ListItem["Division"] = "Asia";
                widgetPage.Update();

                // if it's checked out... check it in
                if (widgetPage.ListItem.Level == SPFileLevel.Checkout)
                    widgetPage.CheckIn("");

                // publish and approve the page
                widgetPage.ListItem.File.Publish("");
                widgetPage.ListItem.File.Approve("");
            }
        }
        #endregion

        #region public methods
        /// <summary>
        /// Occurs after a Feature is installed. Nothing to do here.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }

        /// <summary>
        /// Occurs when a Feature is uninstalled. Nothing to do here.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }

        /// <summary>
        /// Occurs after a Feature is activated.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            using (SPSite siteCollection = properties.Feature.Parent as SPSite)
            {
                // create Widget subsite with content
                this.CreateWidgetSite(siteCollection);
            }
        }

        /// <summary>
        /// Occurs when a Feature is deactivated.
        /// </summary>
        /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            using (SPSite siteCollection = properties.Feature.Parent as SPSite)
            {
                // delete the widget content
                using (SPWeb web = siteCollection.OpenWeb("Widgets"))
                {
                    web.Delete();
                }

                // delete the provisioned page layout & preview image
                SPFile pageLayout = siteCollection.RootWeb.GetFile("/_catalogs/masterpage/ProductPageLeft.aspx");
                pageLayout.Delete();
                SPFolder previewImageFolder = siteCollection.RootWeb.GetFolder("_catalogs/masterpage/Preview Images/Widget Content Builder");
                previewImageFolder.Delete();
            }
        }
        #endregion
    }
}