using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;

namespace Lab1Solution {
  public class FeatureReceiver : SPFeatureReceiver {
    // nothing to do on install/uninstall
    public override void FeatureInstalled (SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling (SPFeatureReceiverProperties properties) { }

    public override void FeatureActivated (SPFeatureReceiverProperties properties) {
      // get reference to the current site's top navigation
      SPWeb site = properties.Feature.Parent as SPWeb;
      if (site == null)
        return;
      SPNavigationNodeCollection quickLaunch = site.Navigation.QuickLaunch;

      // create new nav element for new page
      SPNavigationNode taskCreatorPage = new SPNavigationNode("Task Creator", "CustomPages/TaskCreator.aspx", false);

      quickLaunch.AddAsLast(taskCreatorPage);
    }

    public override void FeatureDeactivating (SPFeatureReceiverProperties properties) {
      // get reference to the current site's top navigation
      SPWeb site = properties.Feature.Parent as SPWeb;
      if (site == null)
        return;
      SPNavigationNodeCollection quickLaunch = site.Navigation.QuickLaunch;

      for (int i = quickLaunch.Count-1; i >= 0; i--) {
        if (quickLaunch[i].Title == "Task Creator") {
          // delete the node
          quickLaunch[i].Delete();
          return;
        }
      }
    }
  }
}