using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using System.Web.UI.WebControls;

namespace Lab1Solution {
  public class PageTemplate : System.Web.UI.Page {

    protected void CreateTask_OnClick (object sender, EventArgs e) {
      // get reference to the textbox
      ContentPlaceHolder mainContentPlaceholder = this.Master.FindControl("PlaceHolderMain") as ContentPlaceHolder;
      if (mainContentPlaceholder == null)
        return;
      TextBox txbTaskTitle = mainContentPlaceholder.FindControl("txbTaskTitle") as TextBox;

      // get reference to this site's "tasks" list
      SPList tasksList = SPContext.Current.Web.Lists["Tasks"];
      if (tasksList == null)
        return;
      SPListItem taskItem = tasksList.Items.Add();
      taskItem["Title"] = txbTaskTitle.Text;

      taskItem.Update();
    }

  }
}