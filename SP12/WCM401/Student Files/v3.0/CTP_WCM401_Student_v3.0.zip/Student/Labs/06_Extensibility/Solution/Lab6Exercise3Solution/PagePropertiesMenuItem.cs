#region namespace references
using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.Publishing.WebControls.EditingMenuActions;
#endregion

namespace Lab6Exercise3Solution {
  public class PagePropertiesMenuItem : ConsoleAction {
    /// <summary>
    /// Anyone who can see the Page Editing Toolbar can use this.
    /// </summary>
    public override SPBasePermissions UserRights {
      get { return SPBasePermissions.EmptyMask; }
    }

    /// <summary>
    /// If the Page Editing Toolbar is present, show this button.
    /// </summary>
    public override AuthoringStates RequiredStates {
      get { return AuthoringStates.EditingMenuEnabled; }
    }

    /// <summary>
    /// Use the stock OOTB info icon for the menu item.
    /// </summary>
    public override string ImageUrl {
      get {
        return "~/_layouts/images/info16by16.gif";
      }
    }

    /// <summary>
    /// Construct the target URL for the menu item.
    /// </summary>
    public override string NavigateUrl {
      get {
        return String.Format("javascript:window.location='{0}/Pages/Forms/DispForm.aspx?ID={1}';", 
          SPContext.Current.Web.Url.ToString(),
          SPContext.Current.ListItem.ID.ToString());
      }
    }
  }
}