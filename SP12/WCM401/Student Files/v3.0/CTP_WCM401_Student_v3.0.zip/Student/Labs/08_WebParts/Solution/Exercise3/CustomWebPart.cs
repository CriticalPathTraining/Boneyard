using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


namespace Lab8Solution
{
    public class CustomWebPart: WebPart
    {
        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            // create a new label containing the date & time and add 
            //   to to the controls collection
            Label lblDateTime = new Label();
            lblDateTime.Text = DateTime.Now.ToString();
            Controls.Add(lblDateTime);

            // create a new button that, when clicked, changes the web part 
            //   title to the current date & time
            Button btnDateTime = new Button();
            btnDateTime.Text = "Set Title to Current Date/Time";
            btnDateTime.Click += new EventHandler(OnDateTime_Click);
            Controls.Add(btnDateTime);
        }

        void OnDateTime_Click(object sender, EventArgs e)
        {
            this.Title = DateTime.Now.ToString();
        }
    }
}
