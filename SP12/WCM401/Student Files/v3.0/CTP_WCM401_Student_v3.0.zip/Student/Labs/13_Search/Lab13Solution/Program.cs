﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint;
using Microsoft.Office.Server.Search.Query;
using System.Data;

namespace SharePointSearchApiSample
{
  class Program
  {
    static void Main(string[] args)
    {
      using (SPSite siteCollection = new SPSite("http://wcm.litwareinc.com"))
      {
        using (FullTextSqlQuery ftQuery = new FullTextSqlQuery(siteCollection))
        {
          string queryString = "SELECT title, path, rank FROM Scope() WHERE (\"scope\" ='Litware COM') AND FREETEXT(defaultproperties,'Jacksonville') ORDER BY rank desc";
          ftQuery.QueryText = queryString;

          ftQuery.StartRow = 0;
          ftQuery.RowLimit = 10;
          ftQuery.TrimDuplicates = true;
          ftQuery.ResultTypes = ResultType.RelevantResults;

          ResultTableCollection results = ftQuery.Execute();
          ResultTable relevantResults = results[ResultType.RelevantResults];
          
          DataTable resultTable = new DataTable();
          resultTable.Load(relevantResults, LoadOption.OverwriteChanges);

          foreach (DataRow row in resultTable.Rows)
          {
            Console.WriteLine("title:" + row["title"].ToString());
            Console.WriteLine("path:" + row["path"].ToString());
            Console.WriteLine();
          }

          Console.ReadLine();
        }
      }
    }

  }
}