using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;

namespace Lab7Solution {
  public class FieldResourceIconValue : SPFieldMultiColumnValue {
    private const int NUM_OF_FIELDS = 4;

    /// <summary>
    /// Initializes a new instance of the FieldResourceIconValue class.
    /// </summary>
    public FieldResourceIconValue () 
      : base(NUM_OF_FIELDS) { }

    /// <summary>
    /// Initializes a new instance of the FieldResourceIconValue class.
    /// </summary>
    public FieldResourceIconValue (string value)
      : base(value) { }

    /// <summary>
    /// Gets or sets the display name for the field.
    /// </summary>
    /// <value></value>
    /// <returns>A string that contains the display name.</returns>
    public string Title {
      get {
        return this[0];
      }
      set {
        this[0] = value;
      }
    }

    /// <summary>
    /// Gets or sets the description for a field.
    /// </summary>
    /// <value></value>
    /// <returns>A string that contains the description.</returns>
    public string Description {
      get {
        return this[1];
      }
      set {
        this[1] = value;
      }
    }

    /// <summary>
    /// Gets or sets the URL target.
    /// </summary>
    /// <value>The URL target.</value>
    public string UrlTarget {
      get {
        return this[2];
      }
      set {
        this[2] = value;
      }
    }

    /// <summary>
    /// Gets or sets the icon.
    /// </summary>
    /// <value>The icon.</value>
    public string Icon {
      get {
        return this[3];
      }
      set
      {
      	this[3] = value;
      }
    }
  }
}