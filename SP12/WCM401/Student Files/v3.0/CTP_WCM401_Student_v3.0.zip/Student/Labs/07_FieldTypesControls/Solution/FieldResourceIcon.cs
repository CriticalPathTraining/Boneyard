using System;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Lab7Solution {
  public class FieldResourceIcon : SPFieldMultiColumn {
    /// <summary>
    /// Initializes a new instance of the FieldResourceIcon class.
    /// </summary>
    /// <param name="fields">The fields.</param>
    /// <param name="fieldName">Name of the field.</param>
    public FieldResourceIcon (SPFieldCollection fields, string fieldName) 
      : base(fields, fieldName) { }

    /// <summary>
    /// Initializes a new instance of the FieldResourceIcon class.
    /// </summary>
    /// <param name="fields">The fields.</param>
    /// <param name="typeName">Name of the type.</param>
    /// <param name="displayName">The display name.</param>
    public FieldResourceIcon (SPFieldCollection fields, string typeName, string displayName) 
      : base(fields, typeName, displayName) { }

    /// <summary>
    /// Returns the field value as a field value object. Use this method when the field type 
    /// requires a complex data type that is different from that of the parent type.
    /// </summary>
    /// <param name="value">The value.</param>
    /// <returns></returns>
    public override object GetFieldValue (string value) {
      if (string.IsNullOrEmpty(value))
        return null;
      return new FieldResourceIconValue(value);
    }

    /// <summary>
    /// Returns the field type control used to render the field. This control is used to render 
    /// the field in display, edit and new forms, the Data Form Web part, and any pages that use 
    /// field controls.
    /// </summary>
    /// <value>The field rendering control.</value>
    public override BaseFieldControl FieldRenderingControl {
      get {
        BaseFieldControl fieldControl = new FieldResourceIconControl();
        fieldControl.FieldName = this.InternalName;
        return fieldControl;
      }
    }

    /// <summary>
    /// Gets the validated string.
    /// </summary>
    /// <param name="value">The value.</param>
    /// <returns></returns>
    public override string GetValidatedString (object value) {
      if (value==null) {
        // if nothing in the field and it's reqired, throw SP error
        if (this.Required) 
          throw new SPFieldValidationException("Invalid value for required field.");
        return string.Empty;
      } else {
        FieldResourceIconValue field = value as FieldResourceIconValue;
        // if no value returned, error in the field
        if (field==null)
          throw new ArgumentException("Invalid Value.");

        // if the field is required...
        if (this.Required) {
          // ensure that the title, URL and icon are selected... 
          //    the description (tooltip) is optional
          if (string.IsNullOrEmpty(field.Title) ||
                string.IsNullOrEmpty(field.UrlTarget) ||
                string.IsNullOrEmpty(field.Icon))
            throw new SPFieldValidationException("Title, Url and Icon must be completed as a minimal requirement for this field.");
        }else {
          // not required... so check if anything is filled in... 
          //    if so, make sure the 3 minimal fields are filled in
          if (!string.IsNullOrEmpty(field.Title) ||
                !string.IsNullOrEmpty(field.Description) ||
                !string.IsNullOrEmpty(field.UrlTarget) ||
                !string.IsNullOrEmpty(field.Icon)
             ) {
            // something was filled in... 
            //  so make sure that at least the three minimal ones are filled in
            if (string.IsNullOrEmpty(field.Title) ||
             string.IsNullOrEmpty(field.UrlTarget) ||
             string.IsNullOrEmpty(field.Icon))
              throw new SPFieldValidationException("Title, Url and Icon must be completed as a minimal requirement for this field.");
          }
       }

        // else everything is good to kick back the string value of the field
        return field.ToString();
      }
    }
  }
}