using System;

namespace Lab10Solution
{
  public enum ApprovalDecision
  {
    Approved,
    Rejected,
    NoAnswer
  }
}