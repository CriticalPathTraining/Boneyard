﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Publishing;

namespace MSDN.SharePoint.Samples {
  public class PageLayoutTemplate : PublishingLayoutPage {
    protected Label CurrentDateTimeLabel;

    protected override void OnLoad (EventArgs e) {
      this.CurrentDateTimeLabel.Text = DateTime.Now.ToString("hh:mm:ss");
    }
  }
}