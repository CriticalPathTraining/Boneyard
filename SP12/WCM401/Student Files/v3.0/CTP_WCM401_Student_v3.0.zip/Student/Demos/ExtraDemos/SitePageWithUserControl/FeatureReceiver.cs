#region namespace references
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Navigation;
#endregion

namespace AndrewConnell.SitePageWithUserControl {
  public class FeatureReceiver : SPFeatureReceiver {
    private const string NAV_MENU_ITEM_TEXT = "Site Page with ASCX";

    /// <summary>
    /// Occurs after a Feature is activated.
    /// </summary>
    /// <remarks>
    /// Creates menu item.
    /// </remarks>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
    public override void FeatureActivated (SPFeatureReceiverProperties properties) {
      SPWeb site = properties.Feature.Parent as SPWeb;
      if (site == null)
        throw new SPException("Error obtaining reference to Feature's parent (SPWeb)");

      // add new item to top nav
      SPNavigationNodeCollection topNav = site.Navigation.TopNavigationBar;
      topNav[0].Children.AddAsLast(new SPNavigationNode(NAV_MENU_ITEM_TEXT, "/SitePageWithUserControlDemo/default.aspx"));
    }

    /// <summary>
    /// Occurs when a Feature is deactivated.
    /// </summary>
    /// <remarks>
    /// Removes menu item.
    /// </remarks>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
    public override void FeatureDeactivating (SPFeatureReceiverProperties properties) {
      SPWeb site = properties.Feature.Parent as SPWeb;
      if (site == null)
        throw new SPException("Error obtaining reference to Feature's parent (SPWeb)");
      
      // delete folder created
      SPFolder demoFolder = site.GetFolder("SitePageWithUserControlDemo");
      demoFolder.Delete();
      
      // delete item from nav
      SPNavigationNodeCollection topNav = site.Navigation.TopNavigationBar;
      for (int i = topNav[0].Children.Count-1; i>=0; i--) {
        if (topNav[0].Children[i].Title==NAV_MENU_ITEM_TEXT)
          topNav[0].Children[i].Delete();
      }

    }

    // unnecessary
    public override void FeatureInstalled (SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling (SPFeatureReceiverProperties properties) { }
  }
}