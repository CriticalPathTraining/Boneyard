using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.Publishing.Fields;

namespace Microsoft.SDK.SharePointServer.Samples {
  public class MediaPlayerFieldControl : BaseFieldControl {
    private MediaSelector _mediaSelector = new MediaSelector();

    public MediaPlayerFieldControl () {
    }

    /// Gets and sets the value in the edit controls
    public override object Value {
      get {
        LinkFieldValue mediaUrlValue = new LinkFieldValue();
        mediaUrlValue.NavigateUrl = this._mediaSelector.MediaUrl;
        mediaUrlValue.Text = LinkFieldValue.GetDefaultDisplayText(mediaUrlValue.NavigateUrl);

        return mediaUrlValue;
      }
      set {
        LinkFieldValue mediaLinkFieldValue =
          value as LinkFieldValue;
        if (null != mediaLinkFieldValue) {
          this._mediaSelector.MediaUrl = mediaLinkFieldValue.NavigateUrl;
        } else {
          this._mediaSelector.MediaUrl = String.Empty;
        }
      }
    }

    /// Get the default name used to find the template and 
    /// control for the MediaPlayerSelector in the control 
    /// template ASCX files.
    protected override string DefaultTemplateName {
      get { return "MediaPlayerFieldControl"; }
    }

    private const string AllowExternalUrlsViewStateKey = "AllowExternalUrls";
    /// A flag that determines whether to allow saving of external 
    /// media URLs.
    public bool AllowExternalUrls {
      get {
        // Return true by default if not already in view state.
        if (ViewState[AllowExternalUrlsViewStateKey] == null) {
          return true;
        }
        return (bool)ViewState[AllowExternalUrlsViewStateKey];
      }
      set {
        ViewState[AllowExternalUrlsViewStateKey] = value;
      }
    }

    /// Creates the edit control when not in display mode.
    protected override void CreateChildControls () {

      base.CreateChildControls();

      if (this.ControlMode != SPControlMode.Display) {
        MediaSelector mediaSelectorInTemplate = this.TemplateContainer.FindControl(this.TemplateName)
          as MediaSelector;

        if (null == mediaSelectorInTemplate) {
          // No media selector was found in the control
          // template ASCX files. Add the default selector.
          this.Controls.Add(this._mediaSelector);
        } else {
          // Get the media selector from the control 
          // template ASCX file.
          mediaSelectorInTemplate.MediaUrl = this._mediaSelector.MediaUrl;
          this._mediaSelector = mediaSelectorInTemplate;
        }
      }
    }

    /// Gets the current value for the media URL as stored
    /// in the list item.
    private string itemFieldValueMediaUrl {
      get {
        LinkFieldValue currentLinkValue = this.ItemFieldValue as LinkFieldValue;
        if (null != currentLinkValue) {
          return currentLinkValue.NavigateUrl;
        } else {
          return String.Empty;
        }
      }
    }

    /// Renders the current list item value for the media URL
    /// with embedded media player markup.
    /// <param name="output"></param>
    protected override void RenderFieldForDisplay (System.Web.UI.HtmlTextWriter output) {
      if (!String.IsNullOrEmpty(this.itemFieldValueMediaUrl)) {
        output.Write(MediaRenderingUtilities.GetMediaPlayerHtmlMarkup(this.itemFieldValueMediaUrl));
      }
    }

    /// Verifies that the MediaUrl is valid.
    public override void Validate () {
      base.Validate();
      if (this.IsValid) {
        LinkFieldValue currentMediaUrlValue = this.Value as LinkFieldValue;

        if (currentMediaUrlValue ==
          null || String.IsNullOrEmpty(currentMediaUrlValue.NavigateUrl)) {
          // Ensure the field is not required.
          if (this.Field != null && this.Field.Required) {
            this.IsValid = false;
            this.ErrorMessage =
              "This field is required and must contain a media file URL.";
            return;
          } else {
            // The field is empty and not required.
            // The data is valid.
            return;
          }
        }

        // Perform validation on the media file URL.
        HtmlValidationContext validationContext = new HtmlValidationContext();

        if (!this.AllowExternalUrls) {
          // Restrict URLs to be either from the current site
          // collection or server-relative.
          validationContext.RestrictUrlsToSiteCollection = true;
          validationContext.GuidOfThisSiteCollection = SPContext.Current.Site.ID;
        }

        bool droppedTags;
        bool droppedUrls;
        LinkFieldValue validatedValue = validationContext.ValidateLinkValue(
                currentMediaUrlValue,
                out droppedTags,
                out droppedUrls);

        if (droppedUrls || String.IsNullOrEmpty(validatedValue.NavigateUrl)) {
          // The media file URL in the link field value was
          // not valid so report the error message.
          // Setting IsValid to false stops saving the page.
          this.IsValid = false;
          this.ErrorMessage =
            "The URL for the media file was invalid.";
          if (!this.AllowExternalUrls) {
            this.ErrorMessage +=
              "  You must select a URL within the current site collection.";
          }
        }
      }
    }
  }
}
