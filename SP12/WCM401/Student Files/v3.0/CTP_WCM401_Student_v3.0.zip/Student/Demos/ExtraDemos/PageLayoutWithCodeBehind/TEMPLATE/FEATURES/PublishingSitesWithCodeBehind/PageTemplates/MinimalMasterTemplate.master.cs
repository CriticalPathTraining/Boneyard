using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MSDN.SharePoint.Samples {
  public class MinimalMasterTemplate : MasterPage {
    protected Label CurrentDateTimeLabel;

    protected override void OnLoad (EventArgs e) {
      this.CurrentDateTimeLabel.Text = DateTime.Now.ToString("hh:mm:ss");
    }
  }
}