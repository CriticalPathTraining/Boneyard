#region namespace references
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
#endregion

namespace AndrewConnell.SitePageWithUserControl {
  public class UselessUserControl : UserControl {
    protected Label CurrentDateTimeLabel;

    /// <summary>
    /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
    /// </summary>
    /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
    protected override void OnLoad (EventArgs e) {
      this.CurrentDateTimeLabel.Text = DateTime.Now.ToString();
    }
  }
}