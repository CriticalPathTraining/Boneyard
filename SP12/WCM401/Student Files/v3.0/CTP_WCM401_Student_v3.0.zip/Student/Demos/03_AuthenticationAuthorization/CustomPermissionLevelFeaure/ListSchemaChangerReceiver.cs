using System;
using Microsoft.SharePoint;

namespace CustomPermissionLevelFeature {
  public class ListSchemaChangerReceiver  : SPListEventReceiver {
    /// <summary>
    /// Occurs when a field link is being added to a content type.
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPListEventProperties"></see> object that represents properties of the event handler.</param>
    public override void FieldAdding (SPListEventProperties properties) {
      if (!this.IsUserAllowedToUpdateSchema(properties.Web)) {
        properties.Cancel = true;
        properties.ErrorMessage = "Current user does not have permission to change the list schema. Only users assigned the permission level 'List Schema Manager' can change the list.";
      }
    }

    /// <summary>
    /// Occurs when a field is in the process of being removed from the list.
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPListEventProperties"></see> object that represents properties of the event handler.</param>
    public override void FieldDeleting (SPListEventProperties properties) {
      if (!this.IsUserAllowedToUpdateSchema(properties.Web)) {
        properties.Cancel = true;
        properties.ErrorMessage = "Current user does not have permission to change the list schema. Only users assigned the permission level 'List Schema Manager' can change the list.";
      }
    }

    /// <summary>
    /// Occurs when a field link is being updated
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPListEventProperties"></see> object that represents properties of the event handler.</param>
    public override void FieldUpdating (SPListEventProperties properties) {
      if (!this.IsUserAllowedToUpdateSchema(properties.Web)) {
        properties.Cancel = true;
        properties.ErrorMessage = "Current user does not have permission to change the list schema. Only users assigned the permission level 'List Schema Manager' can change the list.";
      }
    }

    /// <summary>
    /// Determines whether user is allowed to update schema.
    /// </summary>
    private bool IsUserAllowedToUpdateSchema(SPWeb currentWeb) {
      // get the 'List Schema Changer' permission level from the current site
      SPRoleDefinition listSchemaChangerPermission = currentWeb.RoleDefinitions["List Schema Manager"];

      // if the permission level isn't defined, throw an exception
      if (listSchemaChangerPermission == null)
        throw new SPException("Permission level 'List Schema Manager' not found. Corrupt feature 'CustomPermissionLevelFeaure'.");

      // if the current user has a binding to the permission level, return true, else false
      return currentWeb.AllRolesForCurrentUser.Contains(listSchemaChangerPermission);
    }
  }
}