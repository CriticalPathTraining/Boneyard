using System;
using Microsoft.SharePoint;

namespace CustomPermissionLevelFeature {
  public class FeatureReceiver : SPFeatureReceiver {
    // nothing to do when installed
    public override void FeatureInstalled (SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling (SPFeatureReceiverProperties properties) { }

    /// <summary>
    /// Creates a new permission level.
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
    public override void FeatureActivated (SPFeatureReceiverProperties properties) {
      // create new permission level 'List Schema Manager'
      SPRoleDefinition listSchemaChangerPermission = new SPRoleDefinition();
      listSchemaChangerPermission.Name = "List Schema Manager";
      listSchemaChangerPermission.Description = "Users with this permission can change the schema on the Announcements list.";

      // set the minimal permission for this permission level
      listSchemaChangerPermission.BasePermissions = SPBasePermissions.EmptyMask;

      // add new permission level to the current site collection
      using (SPWeb site = properties.Feature.Parent as SPWeb) {
        site.RoleDefinitions.Add(listSchemaChangerPermission);
      }
    }

    /// <summary>
    /// Removes permission level.
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
    public override void FeatureDeactivating (SPFeatureReceiverProperties properties) {
      // find the permission level and remove it
      using (SPWeb site = properties.Feature.Parent as SPWeb) {
        site.RoleDefinitions.Delete("List Schema Manager");
      }
    }
  }
}