using System;
using System.IO;
using Microsoft.SharePoint;

namespace WssCreatePageObjectModel {
  class Program {
    static void Main (string[] args) {

      // get reference to current site collection
      using (SPSite siteCollection = new SPSite("http://litwareinc.com")) {
        using (SPWeb site = siteCollection.RootWeb) {

          // create a new page in a memory stream
          MemoryStream memoryStream = new MemoryStream();
          StreamWriter streamWriter = new StreamWriter(memoryStream);
          streamWriter.WriteLine("<html><body>");
          streamWriter.WriteLine("<h1>Litware Inc.</h1>");
          streamWriter.WriteLine("</body></html>");
          streamWriter.Flush();

          // add page to the site
          site.Files.Add("LitwareInc.htm", memoryStream);
        }
      }
    }
  }
}
