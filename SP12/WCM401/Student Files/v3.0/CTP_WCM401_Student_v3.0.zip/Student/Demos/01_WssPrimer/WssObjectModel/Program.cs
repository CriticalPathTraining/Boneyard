using System;
using Microsoft.SharePoint;

namespace WssObjectModel {
  class Program {

    static void Main (string[] args) {
      // get reference to the litware site collection
      using (SPSite siteCollection = new SPSite("http://litwareinc.com")) {
        // get reference to the top-level site
        using (SPWeb site = siteCollection.RootWeb) {
          // list the properties of the site
          Console.Out.WriteLine("Site Title: {0}", site.Title);
          Console.Out.WriteLine("Site Description: {0}", site.Description);
          Console.Out.WriteLine("Site URL: {0}", site.Url);
          Console.Out.WriteLine("");
          Console.Out.WriteLine("Site Lists:");

          // enumerate through all lists in the web
          foreach (SPList list in site.Lists) {
            Console.Out.WriteLine("  List Name: {0}", list.Title);
            Console.Out.WriteLine("  # of Items in List: {0}", list.ItemCount.ToString());
            Console.Out.WriteLine("");
          }
          Console.Out.WriteLine("Press any key to continue...");
          Console.ReadLine();
        }
      }
    }
  }
}