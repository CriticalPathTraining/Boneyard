using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Navigation;

namespace WssCreatePageFeature {
  public class FeatureReceiver : SPFeatureReceiver {
    // don't do anything when feature installed/uninstalled
    public override void FeatureInstalled (SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling (SPFeatureReceiverProperties properties) { }

    /// <summary>
    /// Occurs after a Feature is activated.
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
    public override void FeatureActivated (SPFeatureReceiverProperties properties) {
      // get a reference to the current site's top navigation
      SPWeb site = properties.Feature.Parent as SPWeb;
      if (site == null)
        throw new SPException("Error obtaining reference to the parent SPWeb within FeatureActivated event handler.");
      SPNavigationNodeCollection topNavigation = site.Navigation.TopNavigationBar;

      // create new drop down menu for our new pages
      SPNavigationNode newMenu = new SPNavigationNode("WssCreatePageFeature's Pages", "", false);
      // add the new menu to the end of the top nav bar
      topNavigation[0].Children.AddAsLast(newMenu);

      // add three links to the three created pages
      newMenu.Children.AddAsLast(new SPNavigationNode("Custom Site Page", "CustomPages/Page01.aspx"));
      newMenu.Children.AddAsLast(new SPNavigationNode("Custom Web Part Page (with no Web Parts)", "CustomPages/WebPartPage01.aspx"));
      newMenu.Children.AddAsLast(new SPNavigationNode("Custom Web Part Page (with one Web Parts)", "CustomPages/WebPartPage02.aspx"));

      site.Update();
    }

    /// <summary>
    /// Occurs when a Feature is deactivated.
    /// </summary>
    /// <param name="properties">An <see cref="T:Microsoft.SharePoint.SPFeatureReceiverProperties"></see> object that represents the properties of the event.</param>
    public override void FeatureDeactivating (SPFeatureReceiverProperties properties) {
      // get a reference to the current site's top navigation
      SPWeb site = properties.Feature.Parent as SPWeb;
      if (site == null)
        throw new SPException("Error obtaining reference to the parent SPWeb within FeatureActivated event handler.");
      SPNavigationNodeCollection topNavigation = site.Navigation.TopNavigationBar;

      // delete the created pages
      SPFolder customPagesFolder = site.GetFolder("CustomPages");
      customPagesFolder.Delete();

      // find the created drop down menu and delete it
      foreach (SPNavigationNode navNode in topNavigation) {
        if (navNode.Title == "WssCreatePageFeature's Pages") {
          navNode.Delete();
          break;
        }
      }
    }

  }
}