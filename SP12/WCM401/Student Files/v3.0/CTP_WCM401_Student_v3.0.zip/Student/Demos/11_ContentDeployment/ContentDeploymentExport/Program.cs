using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.Deployment;
using Microsoft.SharePoint;

namespace ContentDeployment {
  class Program {
    private static string _sourceUrl = "http://wcm.litwareinc.com";

    static void Main (string[] args) {
      try {
        SPExportSettings exportSettings = new SPExportSettings();
        // echo output
        exportSettings.CommandLineVerbose = true;
        // CMP file to export
        exportSettings.BaseFileName = "export.cmp";
        // Path to export CMP
        exportSettings.FileLocation = @"C:\windows\temp";

        exportSettings.OverwriteExistingDataFile = true;
        exportSettings.IncludeSecurity = SPIncludeSecurity.All;
        exportSettings.SiteUrl = _sourceUrl;
        exportSettings.IncludeVersions = SPIncludeVersions.LastMajorAndMinor;
        exportSettings.FileCompression = true;

        SPExport export = new SPExport(exportSettings);

        // Run the export
        export.Run();
      } catch (Exception ex) {
        Console.Error.Write(ex.ToString());
        throw;
      }

    }
  }
}