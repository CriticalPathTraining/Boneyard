using System;
using Microsoft.SharePoint.Publishing.Administration;

namespace ConnectedServers {
  class Program {

    static void Main (string[] args) {

      ContentDeploymentPath cdPath = null;
      ContentDeploymentJob cdJob = null;

      try {
        SetThisFarmConfiguration();
        
        // Create a deployment path.
        cdPath = ContentDeploymentPath.GetAllPaths().Add();
        cdPath.Name = "WCM401 Demo Deployment Path";

        // configure source and destination server settings
        SetSourceServerSettings(cdPath);
        SetDestinationServerSettings(cdPath);
        cdPath.Update();

        // Create a job associated with the path you created.
        cdJob = ContentDeploymentJob.GetAllJobs().Add();
        cdJob.Name = "WCM401 Demo Deployment Job";
        ConfigureContentDeploymentJob(cdPath, cdJob);
        
        
        // execute the job
        cdJob.Run();

        Console.Out.WriteLine("Finished... Press any key to continue...");
        Console.ReadLine();

      } catch (Exception ex) {
        Console.Error.WriteLine(ex.StackTrace);
        throw;
      } finally {
        if (cdJob != null)
          cdJob.Delete();
        if (cdPath != null)
          cdPath.Delete();
      }

    }

    /// <summary>
    /// Sets the this farm configuration.
    /// </summary>
    private static void SetThisFarmConfiguration() {
      // configure the farm this is running on (source & destination)...
      ContentDeploymentConfiguration config = ContentDeploymentConfiguration.GetInstance();
      config.AcceptIncomingJobs = true;

      // only for demo purposes... in production, this should always be TRUE (HTTPS)
      config.RequiresSecureConnection = false;
      config.Update();
    }

    /// <summary>
    /// Sets the source server settings.
    /// </summary>
    /// <param name="path">The path.</param>
    private static void SetSourceServerSettings(ContentDeploymentPath path) {
      path.SourceServerUri = new Uri("http://wcm.litwareinc.com");
      path.SourceSiteCollection = "/";
    }

    /// <summary>
    /// Sets the destination server settings.
    /// </summary>
    /// <param name="path">The path.</param>
    private static void SetDestinationServerSettings(ContentDeploymentPath path) {
      path.DestinationAdminServerUri = new Uri("http://litwareserver:9999");
      path.DestinationServerUri = new Uri("http://cd2.litwareinc.com");
      path.DestinationSiteCollection = "/";
    }

    /// <summary>
    /// Configures the content deployment job.
    /// </summary>
    /// <param name="path">The path.</param>
    /// <param name="job">The job.</param>
    private static void ConfigureContentDeploymentJob(ContentDeploymentPath path, ContentDeploymentJob job) {
      job.JobType = ContentDeploymentJobType.ServerToServer;
      job.Path = path;
      job.Update();
    }
  }
}