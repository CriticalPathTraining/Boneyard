#region namespace references
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.Publishing.WebControls.EditingMenuActions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing;
using Microsoft.SharePoint.Utilities;
#endregion

namespace PublishingPageDetailViewer {
  public class PublishingPageDetailMenuItem : ConsoleAction {
    public PublishingPageDetailMenuItem ()
      : base() {
      this.DisplayText = "Page Details";
    }

    /// <summary>
    /// Gets the user rights.
    /// </summary>
    /// <value>The user rights.</value>
    public override SPBasePermissions UserRights {
      get { return SPBasePermissions.EmptyMask; }
    }

    /// <summary>
    /// Gets the required states.
    /// </summary>
    /// <value>The required states.</value>
    public override AuthoringStates RequiredStates {
      get {
        return AuthoringStates.EditingMenuEnabled;
      }
    }

    /// <summary>
    /// Gets the image URL.
    /// </summary>
    /// <value>The image URL.</value>
    public override string ImageUrl {
      get {
        return "~/_layouts/images/info16by16.gif";
      }
    }

    /// <summary>
    /// Gets the URL to execute when the button is clicked.
    /// </summary>
    /// <value>The navigate URL.</value>
    public override string NavigateUrl {
      get {
        PublishingPage page = PublishingPage.GetPublishingPage(SPContext.Current.ListItem);

        return String.Format("javascript:window.location='{0}/_layouts/WCM401/PublishingPageDetail.aspx?pageid={1}';",
                 SPContext.Current.Web.Url.ToString(),
                 page.ListItem.ID.ToString());
      }
    }
  }
}