using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Lab3 {

  public class DocumentInfo : LayoutsPageBase {

    // add control fields to match controls tags on .aspx page
    protected SPGridView grdSiteProperties;

    protected override void OnLoad(EventArgs e) {
      
      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      
      // program against controls on .aspx page
      PropertyCollectionBinder binder = new PropertyCollectionBinder();

      // remove the next line and begin your work here
      binder.AddProperty("Test Property", "Test Value");

      binder.BindGrid(grdSiteProperties);

    }

  }
}
