Imports System
Imports System.Data
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls

Public Class PropertyCollectionBinder

    Protected PropertyCollection As DataTable = New DataTable()

    Public Sub New()
        PropertyCollection.Columns.Add("PropertyName", GetType(String))
        PropertyCollection.Columns.Add("PropertyValue", GetType(String))
    End Sub 'New

    Public Sub AddProperty(ByVal PropertyName As String, ByVal PropertyValue As String)
        Dim newRow As DataRow = PropertyCollection.Rows.Add()
        newRow("PropertyName") = PropertyName
        newRow("PropertyValue") = PropertyValue
    End Sub 'AddProperty

    Public Sub BindGrid(ByVal grid As SPGridView)

        Dim fldPropertyName As New SPBoundField()
        fldPropertyName.HeaderText = "Property Name"
        fldPropertyName.DataField = "PropertyName"
        grid.Columns.Add(fldPropertyName)

        Dim fldPropertyValue As New SPBoundField()
        fldPropertyValue.HeaderText = "Value"
        fldPropertyValue.DataField = "PropertyValue"
        grid.Columns.Add(fldPropertyValue)

        grid.Width = New Unit(400)

        grid.AutoGenerateColumns = False
        grid.DataSource = PropertyCollection.DefaultView
        grid.DataBind()
    End Sub 'BindGrid 

End Class
