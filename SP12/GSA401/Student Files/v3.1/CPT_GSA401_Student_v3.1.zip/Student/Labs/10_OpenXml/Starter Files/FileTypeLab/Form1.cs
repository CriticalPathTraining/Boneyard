using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
// Insert code here!

namespace FileTypeLab
{
    public partial class Form1 : Form
    {
        #region Finished code
        public Form1()
        {
            InitializeComponent();
            directoryTextBox.Text = @"..\..\..\..\CaseStudies";
        }

        private void selectDirectoryButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                directoryTextBox.Text = dialog.SelectedPath;
            }
        }

        private void displayDocumentsButton_Click(object sender, EventArgs e)
        {
            filesListBox.Items.Clear();

            System.IO.DirectoryInfo dirInfo = 
                new System.IO.DirectoryInfo(directoryTextBox.Text);

            foreach (System.IO.FileInfo fileInfo
                in dirInfo.GetFiles("*.docx"))
            {
                filesListBox.Items.Add(fileInfo.Name);
            }
        }

        private void filesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filesListBox.SelectedItem != null)
            {
                // There is a selected file
                string fullFileName = directoryTextBox.Text + "\\" + filesListBox.SelectedItem.ToString();
                ProcessDocument(fullFileName);
            }
            else
            {
                titleTextBox.Text = string.Empty;
                authorTextBox.Text = string.Empty;
                paragraphsTextBox.Text = string.Empty;
                wordsTextBox.Text = string.Empty;
                characterTextBox.Text = string.Empty;
                linesTextBox.Text = string.Empty;
                contentsListBox.Items.Clear();
            }
        }

        private void createNewDocBtn_Click(object sender, EventArgs e)
        {
            CreateNewDocument();
        }
        #endregion

        #region Exercise 2
        private void ProcessDocument(string fullFileName)
        {
            // Insert code here!
        }
        #endregion

        #region Exercise 3
        private void CreateNewDocument()
        {
            // Insert code here!

	    MessageBox.Show("Document created!");
        }
        #endregion
    }
}