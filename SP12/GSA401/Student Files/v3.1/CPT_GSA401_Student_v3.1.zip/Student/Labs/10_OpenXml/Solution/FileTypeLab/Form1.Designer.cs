namespace FileTypeLab
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.filesListBox = new System.Windows.Forms.ListBox();
            this.displayDocumentsButton = new System.Windows.Forms.Button();
            this.selectDirectoryButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.directoryTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.contentsListBox = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.createNewDocBtn = new System.Windows.Forms.Button();
            this.newAuthorTextBox = new System.Windows.Forms.TextBox();
            this.newTitleTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.linesTextBox = new System.Windows.Forms.Label();
            this.characterTextBox = new System.Windows.Forms.Label();
            this.wordsTextBox = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.paragraphsTextBox = new System.Windows.Forms.Label();
            this.authorTextBox = new System.Windows.Forms.Label();
            this.titleTextBox = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.filesListBox);
            this.splitContainer1.Panel1.Controls.Add(this.displayDocumentsButton);
            this.splitContainer1.Panel1.Controls.Add(this.selectDirectoryButton);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Controls.Add(this.directoryTextBox);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label10);
            this.splitContainer1.Panel2.Controls.Add(this.contentsListBox);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel2.Controls.Add(this.linesTextBox);
            this.splitContainer1.Panel2.Controls.Add(this.characterTextBox);
            this.splitContainer1.Panel2.Controls.Add(this.wordsTextBox);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.label6);
            this.splitContainer1.Panel2.Controls.Add(this.label7);
            this.splitContainer1.Panel2.Controls.Add(this.paragraphsTextBox);
            this.splitContainer1.Panel2.Controls.Add(this.authorTextBox);
            this.splitContainer1.Panel2.Controls.Add(this.titleTextBox);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Size = new System.Drawing.Size(654, 375);
            this.splitContainer1.SplitterDistance = 313;
            this.splitContainer1.TabIndex = 1;
            // 
            // filesListBox
            // 
            this.filesListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.filesListBox.FormattingEnabled = true;
            this.filesListBox.Location = new System.Drawing.Point(9, 71);
            this.filesListBox.Name = "filesListBox";
            this.filesListBox.Size = new System.Drawing.Size(301, 290);
            this.filesListBox.TabIndex = 4;
            this.filesListBox.SelectedIndexChanged += new System.EventHandler(this.filesListBox_SelectedIndexChanged);
            this.filesListBox.Click += new System.EventHandler(this.filesListBox_SelectedIndexChanged);
            // 
            // displayDocumentsButton
            // 
            this.displayDocumentsButton.Location = new System.Drawing.Point(5, 42);
            this.displayDocumentsButton.Name = "displayDocumentsButton";
            this.displayDocumentsButton.Size = new System.Drawing.Size(124, 23);
            this.displayDocumentsButton.TabIndex = 3;
            this.displayDocumentsButton.Text = "Display documents";
            this.displayDocumentsButton.UseVisualStyleBackColor = true;
            this.displayDocumentsButton.Click += new System.EventHandler(this.displayDocumentsButton_Click);
            // 
            // selectDirectoryButton
            // 
            this.selectDirectoryButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.selectDirectoryButton.Location = new System.Drawing.Point(286, 14);
            this.selectDirectoryButton.Name = "selectDirectoryButton";
            this.selectDirectoryButton.Size = new System.Drawing.Size(24, 23);
            this.selectDirectoryButton.TabIndex = 2;
            this.selectDirectoryButton.Text = "...";
            this.selectDirectoryButton.UseVisualStyleBackColor = true;
            this.selectDirectoryButton.Click += new System.EventHandler(this.selectDirectoryButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Directory";
            // 
            // directoryTextBox
            // 
            this.directoryTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.directoryTextBox.Location = new System.Drawing.Point(5, 16);
            this.directoryTextBox.Name = "directoryTextBox";
            this.directoryTextBox.Size = new System.Drawing.Size(275, 20);
            this.directoryTextBox.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 166);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Contents";
            // 
            // contentsListBox
            // 
            this.contentsListBox.FormattingEnabled = true;
            this.contentsListBox.Location = new System.Drawing.Point(94, 166);
            this.contentsListBox.Name = "contentsListBox";
            this.contentsListBox.Size = new System.Drawing.Size(222, 82);
            this.contentsListBox.TabIndex = 14;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.createNewDocBtn);
            this.groupBox1.Controls.Add(this.newAuthorTextBox);
            this.groupBox1.Controls.Add(this.newTitleTextBox);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(6, 272);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(326, 98);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Create new document";
            // 
            // createNewDocBtn
            // 
            this.createNewDocBtn.Location = new System.Drawing.Point(9, 67);
            this.createNewDocBtn.Name = "createNewDocBtn";
            this.createNewDocBtn.Size = new System.Drawing.Size(75, 23);
            this.createNewDocBtn.TabIndex = 8;
            this.createNewDocBtn.Text = "Create!";
            this.createNewDocBtn.UseVisualStyleBackColor = true;
            this.createNewDocBtn.Click += new System.EventHandler(this.createNewDocBtn_Click);
            // 
            // newAuthorTextBox
            // 
            this.newAuthorTextBox.Location = new System.Drawing.Point(66, 41);
            this.newAuthorTextBox.Name = "newAuthorTextBox";
            this.newAuthorTextBox.Size = new System.Drawing.Size(244, 20);
            this.newAuthorTextBox.TabIndex = 7;
            // 
            // newTitleTextBox
            // 
            this.newTitleTextBox.Location = new System.Drawing.Point(66, 19);
            this.newTitleTextBox.Name = "newTitleTextBox";
            this.newTitleTextBox.Size = new System.Drawing.Size(244, 20);
            this.newTitleTextBox.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Author";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Title";
            // 
            // linesTextBox
            // 
            this.linesTextBox.AutoSize = true;
            this.linesTextBox.Location = new System.Drawing.Point(91, 140);
            this.linesTextBox.Name = "linesTextBox";
            this.linesTextBox.Size = new System.Drawing.Size(19, 13);
            this.linesTextBox.TabIndex = 12;
            this.linesTextBox.Text = "na";
            // 
            // characterTextBox
            // 
            this.characterTextBox.AutoSize = true;
            this.characterTextBox.Location = new System.Drawing.Point(91, 114);
            this.characterTextBox.Name = "characterTextBox";
            this.characterTextBox.Size = new System.Drawing.Size(19, 13);
            this.characterTextBox.TabIndex = 11;
            this.characterTextBox.Text = "na";
            // 
            // wordsTextBox
            // 
            this.wordsTextBox.AutoSize = true;
            this.wordsTextBox.Location = new System.Drawing.Point(91, 88);
            this.wordsTextBox.Name = "wordsTextBox";
            this.wordsTextBox.Size = new System.Drawing.Size(19, 13);
            this.wordsTextBox.TabIndex = 10;
            this.wordsTextBox.Text = "na";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Lines";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Characters";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Words";
            // 
            // paragraphsTextBox
            // 
            this.paragraphsTextBox.AutoSize = true;
            this.paragraphsTextBox.Location = new System.Drawing.Point(91, 62);
            this.paragraphsTextBox.Name = "paragraphsTextBox";
            this.paragraphsTextBox.Size = new System.Drawing.Size(19, 13);
            this.paragraphsTextBox.TabIndex = 6;
            this.paragraphsTextBox.Text = "na";
            // 
            // authorTextBox
            // 
            this.authorTextBox.AutoSize = true;
            this.authorTextBox.Location = new System.Drawing.Point(91, 36);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(19, 13);
            this.authorTextBox.TabIndex = 5;
            this.authorTextBox.Text = "na";
            // 
            // titleTextBox
            // 
            this.titleTextBox.AutoSize = true;
            this.titleTextBox.Location = new System.Drawing.Point(91, 10);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(19, 13);
            this.titleTextBox.TabIndex = 4;
            this.titleTextBox.Text = "na";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Paragraphs";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Author";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Title";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 375);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "File Type Lab";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox filesListBox;
        private System.Windows.Forms.Button displayDocumentsButton;
        private System.Windows.Forms.Button selectDirectoryButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox directoryTextBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button createNewDocBtn;
        private System.Windows.Forms.TextBox newAuthorTextBox;
        private System.Windows.Forms.TextBox newTitleTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label linesTextBox;
        private System.Windows.Forms.Label characterTextBox;
        private System.Windows.Forms.Label wordsTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label paragraphsTextBox;
        private System.Windows.Forms.Label authorTextBox;
        private System.Windows.Forms.Label titleTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListBox contentsListBox;
    }
}

