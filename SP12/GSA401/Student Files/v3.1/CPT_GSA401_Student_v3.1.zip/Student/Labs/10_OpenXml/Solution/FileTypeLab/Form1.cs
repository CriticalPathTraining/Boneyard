using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.IO.Packaging;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;

namespace FileTypeLab
{
    public partial class Form1 : Form
    {
        #region Finished code
        public Form1()
        {
            InitializeComponent();
            directoryTextBox.Text = @"..\..\..\CaseStudies";
        }

        private void selectDirectoryButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                directoryTextBox.Text = dialog.SelectedPath;
            }
        }

        private void displayDocumentsButton_Click(object sender, EventArgs e)
        {
            filesListBox.Items.Clear();

            System.IO.DirectoryInfo dirInfo = 
                new System.IO.DirectoryInfo(directoryTextBox.Text);

            foreach (System.IO.FileInfo fileInfo
                in dirInfo.GetFiles("*.docx"))
            {
                filesListBox.Items.Add(fileInfo.Name);
            }
        }

        private void filesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filesListBox.SelectedItem != null)
            {
                // There is a selected file
                string fullFileName = directoryTextBox.Text + "\\" + filesListBox.SelectedItem.ToString();
                ProcessDocument(fullFileName);
            }
            else
            {
                titleTextBox.Text = string.Empty;
                authorTextBox.Text = string.Empty;
                paragraphsTextBox.Text = string.Empty;
                wordsTextBox.Text = string.Empty;
                characterTextBox.Text = string.Empty;
                linesTextBox.Text = string.Empty;
                contentsListBox.Items.Clear();
            }
        }

        private void createNewDocBtn_Click(object sender, EventArgs e)
        {
            CreateNewDocument();
        }
        #endregion

        #region Exercise 2
        private void ProcessDocument(string fullFileName)
        {
            Package package = Package.Open(fullFileName, FileMode.Open);

            // Get core properties
            XmlDataDocument doc = new XmlDataDocument();
            Uri uri = new Uri("/docProps/core.xml", UriKind.Relative);
            PackagePart propsPart = package.GetPart(uri);
            doc.Load(propsPart.GetStream(FileMode.Open));

            XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("cp",
                "http://schemas.openxmlformats.org/package/2006/metadata/core-properties");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            titleTextBox.Text =
                doc.SelectSingleNode("cp:coreProperties/dc:title", nsmgr).InnerText;
            authorTextBox.Text =
                doc.SelectSingleNode("cp:coreProperties/dc:creator", nsmgr).InnerText;

            // Get application specific properties
            doc = new XmlDataDocument();
            uri = new Uri("/docProps/app.xml", UriKind.Relative);
            if (package.PartExists(uri))
            {
                PackagePart appPart = package.GetPart(uri);
                doc.Load(appPart.GetStream(FileMode.Open));

                nsmgr = new XmlNamespaceManager(doc.NameTable);
                nsmgr.AddNamespace("ap", "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties");
                paragraphsTextBox.Text =
                    doc.SelectSingleNode("ap:Properties/ap:Paragraphs", nsmgr).InnerText;
                wordsTextBox.Text =
                    doc.SelectSingleNode("ap:Properties/ap:Words", nsmgr).InnerText;
                characterTextBox.Text =
                    doc.SelectSingleNode("ap:Properties/ap:Characters", nsmgr).InnerText;
                linesTextBox.Text =
                    doc.SelectSingleNode("ap:Properties/ap:Lines", nsmgr).InnerText;
            }
            else
            {
                paragraphsTextBox.Text = "na";
                wordsTextBox.Text = "na";
                characterTextBox.Text = "na";
                linesTextBox.Text = "na";
            }

            // Get contents
            contentsListBox.Items.Clear();
            doc = new XmlDataDocument();
            uri = new Uri("/word/document.xml", UriKind.Relative);
            PackagePart docPart = package.GetPart(uri);
            doc.Load(docPart.GetStream(FileMode.Open));

            nsmgr = new XmlNamespaceManager(doc.NameTable);
            nsmgr.AddNamespace("cp",
                "http://schemas.openxmlformats.org/package/2006/metadata/core-properties");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            foreach (XmlNode node in doc.SelectNodes("//*[name()='w:pStyle']", nsmgr))
            {
                if (node.Attributes["w:val"].Value == "Heading2")
                {
                    System.Xml.XPath.XPathNavigator nav = node.CreateNavigator();
                    nav.MoveToParent();
                    nav.MoveToNext();

                    nav.MoveToChild("t", "http://schemas.openxmlformats.org/wordprocessingml/2006/3/main");
                    contentsListBox.Items.Add(nav.Value);
                }
            }

            // Close the package
            package.Close();
        }
        #endregion

        #region Exercise 3
        private void CreateNewDocument()
        {
            // Create the word document
            string fullFileName = directoryTextBox.Text + "\\" + newTitleTextBox.Text + ".docx";

            using (WordprocessingDocument wordDoc =
                   WordprocessingDocument.Create(fullFileName,
                   WordprocessingDocumentType.Document))
            {
                // Set the content of the document so that Word can open it.
                MainDocumentPart mainPart = wordDoc.AddMainDocumentPart();
                StreamWriter partWriter =
                    new StreamWriter(wordDoc.MainDocumentPart.GetStream(FileMode.Create, FileAccess.Write));
                XmlDocument doc = new XmlDocument();
                doc.Load(@"..\..\part_main.xml");
                doc.Save(partWriter);
                partWriter.Close();

                // Add properties part
                CoreFilePropertiesPart propertiesPart = wordDoc.AddCoreFilePropertiesPart();
                StreamWriter propWriter =
                    new StreamWriter(wordDoc.CoreFilePropertiesPart.GetStream(FileMode.Create, FileAccess.Write));
                // First load the part_core.xml file 
                XmlDocument propdoc = new XmlDocument();
                propdoc.Load(@"..\..\part_core.xml");

                // Manage namespaces to perform XML XPath queries.
                NameTable nt = new NameTable();
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(nt);
                nsmgr.AddNamespace("cp", "http://schemas.openxmlformats.org/package/2006/metadata/core-properties");
                nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
                
                // Then set our own values                
                propdoc.SelectSingleNode("cp:coreProperties/dc:title", nsmgr).InnerText =
                    newTitleTextBox.Text;
                propdoc.SelectSingleNode("cp:coreProperties/dc:creator", nsmgr).InnerText =
                    newAuthorTextBox.Text;
                propdoc.Save(propWriter);
                propWriter.Close();

                // no relationship to create anymore!!!

                // add styles to it
                if (wordDoc.MainDocumentPart.StyleDefinitionsPart != null)
                {
                    wordDoc.MainDocumentPart.DeletePart(wordDoc.MainDocumentPart.StyleDefinitionsPart);
                    StyleDefinitionsPart stylePart = wordDoc.MainDocumentPart.AddNewPart<StyleDefinitionsPart>();

                    StreamWriter styleWriter =
                        new StreamWriter(stylePart.GetStream(FileMode.Create, FileAccess.Write));
                    XmlDocument styledoc = new XmlDocument();
                    styledoc.Load(@"..\..\part_styles.xml");
                    styledoc.Save(styleWriter);
                    styleWriter.Close();
                }

                // Set application specific properties                
                ExtendedFilePropertiesPart extpropsPart = wordDoc.AddExtendedFilePropertiesPart();
                StreamWriter extpropsWriter =
                    new StreamWriter(extpropsPart.GetStream(FileMode.Create, FileAccess.Write));
                XmlDocument extdoc = new XmlDocument();
                extdoc.Load(@"..\..\part_ext.xml");
                extdoc.Save(extpropsWriter);
                extpropsWriter.Close();

                if (wordDoc.ExtendedFilePropertiesPart != null)
                {
                    extdoc.Load(extpropsPart.GetStream(FileMode.Open));
                    nsmgr = new XmlNamespaceManager(doc.NameTable);
                    nsmgr.AddNamespace("ap", "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties");
                    paragraphsTextBox.Text =
                        extdoc.SelectSingleNode("ap:Properties/ap:Paragraphs", nsmgr).InnerText;
                    wordsTextBox.Text =
                        extdoc.SelectSingleNode("ap:Properties/ap:Words", nsmgr).InnerText;
                    characterTextBox.Text =
                        extdoc.SelectSingleNode("ap:Properties/ap:Characters", nsmgr).InnerText;
                    linesTextBox.Text =
                        extdoc.SelectSingleNode("ap:Properties/ap:Lines", nsmgr).InnerText;
                }
                else
                {
                    paragraphsTextBox.Text = "na";
                    wordsTextBox.Text = "na";
                    characterTextBox.Text = "na";
                    linesTextBox.Text = "na";
                }            
            }

            MessageBox.Show("Document created!");
        }
        #endregion
    }
}