Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls.WebParts
Imports Microsoft.SharePoint

  public class RevenueWebPart
    Inherits WebPart

    Protected _ShowTextAsBold As Boolean = True
    <Personalizable(), WebBrowsable(True), WebDisplayName("Show Text As Bold"), _
                 WebDescription("Enable to turn on bold font output")> _
    Public Property ShowTextAsBold() As Boolean
        Get
            Return _ShowTextAsBold
        End Get
        Set(ByVal value As Boolean)
            _ShowTextAsBold = value
        End Set
    End Property

    Protected Overrides Sub RenderContents(ByVal writer As System.Web.UI.HtmlTextWriter)
        MyBase.RenderContents(writer)

        Dim ProjectManagementSite As SPWeb = SPContext.Current.Web
        Dim Projects As SPList = ProjectManagementSite.Lists("Projects")
        Dim TotalRevenue As Decimal = 0
        Dim Project As SPListItem
        For Each Project In Projects.Items
            TotalRevenue += Convert.ToDecimal(Project("Contract Amount"))
        Next Project

        If _ShowTextAsBold Then
            writer.AddStyleAttribute(HtmlTextWriterStyle.FontWeight, "Bold")
            writer.AddStyleAttribute(HtmlTextWriterStyle.FontSize, "12pt")
            writer.AddStyleAttribute(HtmlTextWriterStyle.Color, "Red")
            writer.RenderBeginTag(HtmlTextWriterTag.Span)
            writer.Write(("Total Revenue: " + TotalRevenue.ToString("$#,###")))
            writer.RenderEndTag() ' </Span>
        Else
            writer.Write(("Total Revenue: " + TotalRevenue.ToString("$#,###")))
        End If

    End Sub
  End Class

