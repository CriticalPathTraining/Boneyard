﻿Public Class ThisAddIn

    Friend projectsTaskPane As Microsoft.Office.Tools.CustomTaskPane

    Private Sub ThisAddIn_Startup(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Startup
        projectsTaskPane = Me.CustomTaskPanes.Add(New ProjectsPane(), "Projects Info")
    End Sub

    Private Sub ThisAddIn_Shutdown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shutdown

    End Sub

End Class
