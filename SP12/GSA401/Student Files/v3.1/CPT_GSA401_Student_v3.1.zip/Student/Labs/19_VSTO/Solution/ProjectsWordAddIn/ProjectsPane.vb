﻿Public Class ProjectsPane
    Dim projectList As List(Of Project)
    Dim selectedProject As Project

    Private Sub ProjectsPane_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim helper As New ProjectsHelper("Projects")
        projectList = helper.GetProjects()
        ProjectComboBox.DataSource = projectList
    End Sub

    Private Sub ProjectComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProjectComboBox.SelectedIndexChanged
        selectedProject = projectList(ProjectComboBox.SelectedIndex)
        NameTextBox.Text = selectedProject.Name
        ClientTextBox.Text = selectedProject.Client
        AmountTextBox.Text = selectedProject.ContractAmount.ToString(System.Globalization.CultureInfo.InvariantCulture) + "$"
        BeginDateTextBox.Text = selectedProject.ProjectBeginDate.Date().ToString()
        EndDateTextBox.Text = selectedProject.ProjectEndDate.Date.ToString()
        ContractCheckBox.Checked = selectedProject.ContractSigned
    End Sub

    Private Sub InsertButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InsertButton.Click
        Globals.ThisAddIn.Application.Selection.Range.Text = _
            String.Format("The contract {0} is signed for an amount of {1}, starting {2} and ending {3}.", _
            selectedProject.Name, AmountTextBox.Text, _
            BeginDateTextBox.Text, EndDateTextBox.Text)
    End Sub

End Class
