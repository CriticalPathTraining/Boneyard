﻿Partial Class ProjectRibbon
    Inherits Microsoft.Office.Tools.Ribbon.OfficeRibbon

    <System.Diagnostics.DebuggerNonUserCode()> _
   Public Sub New(ByVal container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        If (container IsNot Nothing) Then
            container.Add(Me)
        End If

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()> _
    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

    End Sub

    'Component overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LitwareTab = New Microsoft.Office.Tools.Ribbon.RibbonTab
        Me.LitwareGroup = New Microsoft.Office.Tools.Ribbon.RibbonGroup
        Me.ProjectsButton = New Microsoft.Office.Tools.Ribbon.RibbonToggleButton
        Me.LitwareTab.SuspendLayout()
        Me.LitwareGroup.SuspendLayout()
        Me.SuspendLayout()
        '
        'LitwareTab
        '
        Me.LitwareTab.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office
        Me.LitwareTab.Groups.Add(Me.LitwareGroup)
        Me.LitwareTab.Label = "Litware"
        Me.LitwareTab.Name = "LitwareTab"
        '
        'LitwareGroup
        '
        Me.LitwareGroup.Items.Add(Me.ProjectsButton)
        Me.LitwareGroup.Label = "Litware Projects"
        Me.LitwareGroup.Name = "LitwareGroup"
        '
        'ProjectsButton
        '
        Me.ProjectsButton.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.ProjectsButton.Label = "Show Projects"
        Me.ProjectsButton.Name = "ProjectsButton"
        Me.ProjectsButton.OfficeImageId = "AddressBook"
        Me.ProjectsButton.ShowImage = True
        '
        'ProjectRibbon
        '
        Me.Name = "ProjectRibbon"
        Me.RibbonType = "Microsoft.Word.Document"
        Me.Tabs.Add(Me.LitwareTab)
        Me.LitwareTab.ResumeLayout(False)
        Me.LitwareTab.PerformLayout()
        Me.LitwareGroup.ResumeLayout(False)
        Me.LitwareGroup.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents LitwareTab As Microsoft.Office.Tools.Ribbon.RibbonTab
    Friend WithEvents LitwareGroup As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents ProjectsButton As Microsoft.Office.Tools.Ribbon.RibbonToggleButton
End Class

Partial Class ThisRibbonCollection
    Inherits Microsoft.Office.Tools.Ribbon.RibbonReadOnlyCollection

    <System.Diagnostics.DebuggerNonUserCode()> _
    Friend ReadOnly Property ProjectRibbon() As ProjectRibbon
        Get
            Return Me.GetRibbon(Of ProjectRibbon)()
        End Get
    End Property
End Class
