﻿Imports Microsoft.Office.Tools.Ribbon

Public Class ProjectRibbon

    Private Sub ProjectRibbon_Load(ByVal sender As System.Object, ByVal e As RibbonUIEventArgs) Handles MyBase.Load

    End Sub

    Private Sub ProjectsButton_Click(ByVal sender As System.Object, ByVal e As Microsoft.Office.Tools.Ribbon.RibbonControlEventArgs) Handles ProjectsButton.Click
        If (ProjectsButton.Checked) Then
            ProjectsButton.Label = "Hide Products"
        Else
            ProjectsButton.Label = "Show Products"
        End If
        Globals.ThisAddIn.projectsTaskPane.Visible = ProjectsButton.Checked
    End Sub

End Class
