﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProjectsPane
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.InsertButton = New System.Windows.Forms.Button
        Me.ClientTextBox = New System.Windows.Forms.TextBox
        Me.ClientLabel = New System.Windows.Forms.Label
        Me.NameTextBox = New System.Windows.Forms.TextBox
        Me.NameLabel = New System.Windows.Forms.Label
        Me.ProjectComboBox = New System.Windows.Forms.ComboBox
        Me.ProjectLabel = New System.Windows.Forms.Label
        Me.ContractCheckBox = New System.Windows.Forms.CheckBox
        Me.BeginDateTextBox = New System.Windows.Forms.TextBox
        Me.BeginDateLabel = New System.Windows.Forms.Label
        Me.EndDateTextBox = New System.Windows.Forms.TextBox
        Me.EndDateLabel = New System.Windows.Forms.Label
        Me.AmountTextBox = New System.Windows.Forms.TextBox
        Me.AmountLabel = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'InsertButton
        '
        Me.InsertButton.Location = New System.Drawing.Point(11, 368)
        Me.InsertButton.Name = "InsertButton"
        Me.InsertButton.Size = New System.Drawing.Size(75, 23)
        Me.InsertButton.TabIndex = 19
        Me.InsertButton.Text = "<< Insert"
        Me.InsertButton.UseVisualStyleBackColor = True
        '
        'ClientTextBox
        '
        Me.ClientTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClientTextBox.Location = New System.Drawing.Point(11, 157)
        Me.ClientTextBox.Name = "ClientTextBox"
        Me.ClientTextBox.Size = New System.Drawing.Size(199, 20)
        Me.ClientTextBox.TabIndex = 17
        '
        'ClientLabel
        '
        Me.ClientLabel.AutoSize = True
        Me.ClientLabel.Location = New System.Drawing.Point(12, 141)
        Me.ClientLabel.Name = "ClientLabel"
        Me.ClientLabel.Size = New System.Drawing.Size(36, 13)
        Me.ClientLabel.TabIndex = 16
        Me.ClientLabel.Text = "Client:"
        '
        'NameTextBox
        '
        Me.NameTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.NameTextBox.Location = New System.Drawing.Point(12, 107)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(199, 20)
        Me.NameTextBox.TabIndex = 15
        '
        'NameLabel
        '
        Me.NameLabel.AutoSize = True
        Me.NameLabel.Location = New System.Drawing.Point(14, 86)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(72, 13)
        Me.NameLabel.TabIndex = 14
        Me.NameLabel.Text = "Project name:"
        '
        'ProjectComboBox
        '
        Me.ProjectComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProjectComboBox.DisplayMember = "Name"
        Me.ProjectComboBox.FormattingEnabled = True
        Me.ProjectComboBox.Location = New System.Drawing.Point(12, 39)
        Me.ProjectComboBox.Name = "ProjectComboBox"
        Me.ProjectComboBox.Size = New System.Drawing.Size(200, 21)
        Me.ProjectComboBox.TabIndex = 13
        '
        'ProjectLabel
        '
        Me.ProjectLabel.AutoSize = True
        Me.ProjectLabel.Location = New System.Drawing.Point(11, 14)
        Me.ProjectLabel.Name = "ProjectLabel"
        Me.ProjectLabel.Size = New System.Drawing.Size(84, 13)
        Me.ProjectLabel.TabIndex = 12
        Me.ProjectLabel.Text = "Select a project:"
        '
        'ContractCheckBox
        '
        Me.ContractCheckBox.AutoSize = True
        Me.ContractCheckBox.Location = New System.Drawing.Point(12, 337)
        Me.ContractCheckBox.Name = "ContractCheckBox"
        Me.ContractCheckBox.Size = New System.Drawing.Size(100, 17)
        Me.ContractCheckBox.TabIndex = 20
        Me.ContractCheckBox.Text = "Contract signed"
        Me.ContractCheckBox.UseVisualStyleBackColor = True
        '
        'BeginDateTextBox
        '
        Me.BeginDateTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BeginDateTextBox.Location = New System.Drawing.Point(12, 252)
        Me.BeginDateTextBox.Name = "BeginDateTextBox"
        Me.BeginDateTextBox.Size = New System.Drawing.Size(199, 20)
        Me.BeginDateTextBox.TabIndex = 22
        '
        'BeginDateLabel
        '
        Me.BeginDateLabel.AutoSize = True
        Me.BeginDateLabel.Location = New System.Drawing.Point(11, 236)
        Me.BeginDateLabel.Name = "BeginDateLabel"
        Me.BeginDateLabel.Size = New System.Drawing.Size(61, 13)
        Me.BeginDateLabel.TabIndex = 21
        Me.BeginDateLabel.Text = "Begin date:"
        '
        'EndDateTextBox
        '
        Me.EndDateTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EndDateTextBox.Location = New System.Drawing.Point(11, 300)
        Me.EndDateTextBox.Name = "EndDateTextBox"
        Me.EndDateTextBox.Size = New System.Drawing.Size(199, 20)
        Me.EndDateTextBox.TabIndex = 24
        '
        'EndDateLabel
        '
        Me.EndDateLabel.AutoSize = True
        Me.EndDateLabel.Location = New System.Drawing.Point(12, 284)
        Me.EndDateLabel.Name = "EndDateLabel"
        Me.EndDateLabel.Size = New System.Drawing.Size(53, 13)
        Me.EndDateLabel.TabIndex = 23
        Me.EndDateLabel.Text = "End date:"
        '
        'AmountTextBox
        '
        Me.AmountTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AmountTextBox.Location = New System.Drawing.Point(11, 204)
        Me.AmountTextBox.Name = "AmountTextBox"
        Me.AmountTextBox.Size = New System.Drawing.Size(199, 20)
        Me.AmountTextBox.TabIndex = 26
        '
        'AmountLabel
        '
        Me.AmountLabel.AutoSize = True
        Me.AmountLabel.Location = New System.Drawing.Point(12, 188)
        Me.AmountLabel.Name = "AmountLabel"
        Me.AmountLabel.Size = New System.Drawing.Size(88, 13)
        Me.AmountLabel.TabIndex = 25
        Me.AmountLabel.Text = "Contract amount:"
        '
        'ProjectsPane
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.AmountTextBox)
        Me.Controls.Add(Me.AmountLabel)
        Me.Controls.Add(Me.EndDateTextBox)
        Me.Controls.Add(Me.EndDateLabel)
        Me.Controls.Add(Me.BeginDateTextBox)
        Me.Controls.Add(Me.BeginDateLabel)
        Me.Controls.Add(Me.ContractCheckBox)
        Me.Controls.Add(Me.InsertButton)
        Me.Controls.Add(Me.ClientTextBox)
        Me.Controls.Add(Me.ClientLabel)
        Me.Controls.Add(Me.NameTextBox)
        Me.Controls.Add(Me.NameLabel)
        Me.Controls.Add(Me.ProjectComboBox)
        Me.Controls.Add(Me.ProjectLabel)
        Me.Name = "ProjectsPane"
        Me.Size = New System.Drawing.Size(220, 403)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents InsertButton As System.Windows.Forms.Button
    Friend WithEvents ClientTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ClientLabel As System.Windows.Forms.Label
    Friend WithEvents NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NameLabel As System.Windows.Forms.Label
    Friend WithEvents ProjectComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ProjectLabel As System.Windows.Forms.Label
    Friend WithEvents ContractCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents BeginDateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BeginDateLabel As System.Windows.Forms.Label
    Friend WithEvents EndDateTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EndDateLabel As System.Windows.Forms.Label
    Friend WithEvents AmountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AmountLabel As System.Windows.Forms.Label

End Class
