﻿Imports System.Xml
Imports System.Net
Imports Microsoft.SharePoint.Utilities

Public Class Project
    Public Name As String
    Public Client As String
    Public ContractSigned As Boolean
    Public ContractAmount As Double
    Public ProjectBeginDate As Date
    Public ProjectEndDate As Date

    Public Sub New()
    End Sub

    Public Sub New(ByVal project As String, ByVal customer As String, _
                    ByVal signed As Boolean, ByVal beginDate As Date, ByVal endDate As Date)
        Name = project
        Client = customer
        ContractSigned = signed
        ProjectBeginDate = beginDate
        ProjectEndDate = endDate
    End Sub

    Public Overrides Function ToString() As String
        Return Name
    End Function
End Class

Public Class ProjectsHelper
    Private listsWS As SPListsService.Lists
    Private list As String

    Public Property ListName() As String
        Get
            Return list
        End Get
        Set(ByVal value As String)
            list = value
        End Set
    End Property
    Public Property ListsWebService() As SPListsService.Lists
        Get
            If listsWS Is Nothing Then
                listsWS = New SPListsService.Lists()
                listsWS.Credentials = CredentialCache.DefaultNetworkCredentials
                listsWS.Url = "http://litwareinc.com/sites/ProjectManagementLab/_vti_bin/Lists.asmx"
            End If
            Return listsWS
        End Get
        Set(ByVal value As SPListsService.Lists)
            listsWS = value
        End Set
    End Property

    Public Sub New(ByVal listname As String)
        Me.ListName = listname
    End Sub

    Public Function GetProjects() As List(Of Project)
        Dim projectList As New List(Of Project)
        Dim xdoc As New XmlDocument

        'query
        Dim query As XmlElement = xdoc.CreateElement("Query")
        query.InnerXml = "<OrderBy><FieldRef Name='Title' Ascending='True' /><FieldRef Name='Client' Ascending='True' /></OrderBy>"

        Dim viewfields As XmlElement = xdoc.CreateElement("ViewFields")
        viewfields.InnerXml = "<FieldRef Name='Title' /><FieldRef Name='Client' />" _
        + "<FieldRef Name='Contract_x0020_Signed' /><FieldRef Name='Contract_x0020_Amount' />" _
        + "<FieldRef Name='Begin_x0020_Date' /><FieldRef Name='End_x0020_Date' />"

        Dim resultsNode As XmlNode = ListsWebService.GetListItems( _
            ListName, Nothing, query, viewfields, "1000", Nothing, Nothing)

        'Dim id As Integer
        Dim results As XDocument = XDocument.Parse(resultsNode.OuterXml)

        Dim projects = From item In results.Descendants(XName.Get("row", "#RowsetSchema")) _
                      Select New Project With { _
                                .Name = item.Attribute("ows_Title").Value, _
                                .Client = item.Attribute("ows_Client").Value, _
                                .ContractAmount = Double.Parse(item.Attribute("ows_Contract_x0020_Amount").Value), _
                                .ProjectBeginDate = SPUtility.CreateDateTimeFromISO8601DateTimeString(item.Attribute("ows_Begin_x0020_Date").Value), _
                                .ProjectEndDate = SPUtility.CreateDateTimeFromISO8601DateTimeString(item.Attribute("ows_End_x0020_Date").Value), _
                                .ContractSigned = ConvertToBoolean(item.Attribute("ows_Contract_x0020_Signed").Value) _
                            }
        projectList = projects.ToList()
        Return projectList

        '.ProjectBeginDate = item.Attribute("ows_Begin_x0200_Date").Value, _
        '.ProjectEndDate = item.Attribute("ows_Begin_x0200_Date").Value _
    End Function

    Private Function ConvertToBoolean(ByVal booleanvalue As String) As Boolean
        If booleanvalue = "1" Or booleanvalue = "True" Or booleanvalue = "TRUE" Then
            Return True
        Else
            Return False
        End If
    End Function






End Class


