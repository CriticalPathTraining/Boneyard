using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Navigation;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebPartPages;

namespace Lab4 {

  public class SitePageCreator : LayoutsPageBase {

    // add control fields to match controls tags on .aspx page
    protected TextBox txtPageName;
    protected TextBox txtPageTitle;
    protected TextBox txtPageContent;

    protected override void OnLoad(EventArgs e) {
      
      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
          
    }

    protected void btnCreateStandardPage_Click(object sender, EventArgs e) {

        MemoryStream stream = new MemoryStream();
      StreamWriter writer = new StreamWriter(stream);
      writer.WriteLine("<%@ Page MasterPageFile='~masterurl/default.master' meta:progid='SharePoint.WebPartPage.Document' %>");
      writer.WriteLine("<asp:Content runat='server' ContentPlaceHolderID='PlaceHolderMain'>");
      writer.WriteLine("<h3>" + txtPageTitle.Text + "</h3>");
      writer.WriteLine(txtPageContent.Text);
      writer.WriteLine("</asp:Content>");
      writer.Flush();

      string NewPageUrl = @"SitePages/" + txtPageName.Text + ".aspx"; 
      this.Web.Files.Add(NewPageUrl, stream);

      // grab the existing site TopNavigationBar for our use
      SPNavigationNodeCollection topNav = this.Web.Navigation.TopNavigationBar;

      // create dropdown menu for custom site pages
      
      foreach (SPNavigationNode node in topNav[0].Children) {
		    if(node.Title.Equals("Site Pages")) {
          SPNavigationNode newNode = new SPNavigationNode(txtPageName.Text, NewPageUrl);
          node.Children.AddAsLast(newNode);
        }
	    }


      SPUtility.Redirect(Web.Url + @"/" + NewPageUrl, SPRedirectFlags.Default, this.Context);

    }

    protected void btnCreateWebPartPage_Click(object sender, EventArgs e) {

        // clone Web Part Page template to create new Web Part Page
        string NewPageUrl = @"SitePages/" + txtPageName.Text + ".aspx";
        SPFile template = Web.GetFile(@"Template\WebPartPage.aspx");
        template.CopyTo(NewPageUrl);

        // add Content Editor Web Part
        SPFile NewPage = Web.GetFile(NewPageUrl);
        SPLimitedWebPartManager mgr;
        mgr = NewPage.GetLimitedWebPartManager(PersonalizationScope.Shared);

        ContentEditorWebPart wp1 = new ContentEditorWebPart();
        wp1.Title = txtPageTitle.Text;
        wp1.ChromeType = PartChromeType.TitleOnly;
        wp1.AllowClose = false;
        XmlDocument doc = new XmlDocument();
        string ns1 = "http://schemas.microsoft.com/WebPart/v2/ContentEditor";
        XmlElement elm = doc.CreateElement("Content", ns1);
        elm.InnerText = txtPageContent.Text;
        wp1.Content = elm;

        // add Web Part to Left Zone
        mgr.AddWebPart(wp1, "Left", 0);

        // add naviation node
        SPNavigationNodeCollection topNav = this.Web.Navigation.TopNavigationBar;
        foreach (SPNavigationNode node in topNav[0].Children)
        {
            if (node.Title.Equals("Site Pages"))
            {
                SPNavigationNode newNode = new SPNavigationNode(txtPageName.Text, NewPageUrl);
                node.Children.AddAsLast(newNode);
            }
        }

        // navigate directly to the newly created Web Part Page
        SPUtility.Redirect(Web.Url + @"/" + NewPageUrl, SPRedirectFlags.Default, this.Context);
    }

  }
}
