﻿using System.Security;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web;
using System.Security.Permissions;
using Microsoft.SharePoint.Security;

// Strong name: 
// LitwareWebParts, Version=1.0.0.0, Culture=neutral, PublicKeyToken=74bad7277fe0d19e

[assembly: AssemblyVersion("1.0.0.0")]

// Allow the strong named assembly to run from the bin:
[assembly: AllowPartiallyTrustedCallers()]

// Web resources needed for client runtime:
// [assembly: WebResource(@"LitwareWebParts.Resources.RSS.xslt", @"text/xml")]
[assembly: WebResource(@"LitwareWebParts.Resources.help.html", @"text/html")]

