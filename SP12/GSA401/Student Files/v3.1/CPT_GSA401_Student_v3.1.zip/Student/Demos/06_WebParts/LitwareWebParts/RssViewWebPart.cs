using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace LitwareWebParts {

  public enum RenderMode {
    Full,
    Titles
  }

  public class RssViewWebPart : WebPart, IWebEditable {

    #region Verbs example 

    public override WebPartVerbCollection Verbs {
      get {
        List<WebPartVerb> verbs = new List<WebPartVerb>();

        if (!string.IsNullOrEmpty(this.XmlUrl)) {
          WebPartVerb verb1 = new WebPartVerb(this.ID + "_ClientSideRssOpenerVerb",
                                             string.Format("window.open('{0}','RSSXML')", this.XmlUrl));
          verb1.Description = "Open RSS Feed in an external window";
          verb1.Text = "Open RSS Feed";
          verbs.Add(verb1);

          WebPartVerb verb2 = new WebPartVerb(this.ID + "_ServerSideRssOpenerVerb",
                                             new WebPartEventHandler(ServerSideVerbHandler));
          verb2.Description = "Load the RSS Source Feed.";
          verb2.Text = "View RSS Source Feed";
          verbs.Add(verb2);
        }
        WebPartVerbCollection allverbs = new WebPartVerbCollection(base.Verbs, verbs);
        return allverbs;
      }
    }

    public void ServerSideVerbHandler(object sender, WebPartEventArgs e) {
      if (!string.IsNullOrEmpty(this.XmlUrl))
        Context.Response.Redirect(this.XmlUrl);
    }

    #endregion Verbs example

    private Stream xmlResponseStream = null;
    private WebRequest xmlReq;
    private string exceptionDetails = null;
    private string xmlUrl;

    #region properties and editor parts

    [Personalizable(PersonalizationScope.Shared),
     WebBrowsable(false)]
    public string XmlUrl {
      get { return xmlUrl; }
      set { xmlUrl = value; }
    }

    private RenderMode headlineMode = RenderMode.Full;
    [Personalizable(PersonalizationScope.User),
     WebBrowsable(false)]
    public RenderMode HeadlineMode {
      get { return headlineMode; }
      set { headlineMode = value; }
    }

    public override EditorPartCollection CreateEditorParts() {
      List<EditorPart> editorParts = new List<EditorPart>(1);
      EditorPart part = new RssViewEditorPart();
      part.ID = this.ID + "_rssViewEditor";
      editorParts.Add(part);
      EditorPartCollection baseParts = base.CreateEditorParts();
      return new EditorPartCollection(baseParts, editorParts);
    }


    #endregion properties and editor parts

    #region HTML help resources

    protected override void OnInit(EventArgs e) {
      base.OnInit(e);
      string helpUrl = this.Page.ClientScript.GetWebResourceUrl(this.GetType(),
          @"LitwareWebParts.Resources.help.html");
      this.HelpUrl = helpUrl;
      this.HelpMode = WebPartHelpMode.Modeless;
    }

    #endregion

    #region async tasks

    // Handle any prerender tasks
    // including async operation initiation
    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);
      if (string.IsNullOrEmpty(this.xmlUrl))
        return;

      // Check to see if we're in design mode. 
      // If we're in design mode, skip the request. 
      if (this.WebPartManager.DisplayMode.AllowPageDesign) {
        this.Controls.Add(new LiteralControl("No display while in design mode."));
        return;
      }

      try {
        Uri xmlUri = new Uri(this.xmlUrl);

        xmlReq = WebRequest.CreateDefault(xmlUri);
        xmlReq.Credentials = CredentialCache.DefaultCredentials;
        xmlReq.Timeout = 10000; // 10 seconds

        this.Page.RegisterAsyncTask(
            new PageAsyncTask(new BeginEventHandler(BeginXmlRequest),
                              new EndEventHandler(EndXmlRequest),
                              new EndEventHandler(XmlRequestTimeout),
                              null,
                              true)
            );
      } catch (System.Security.SecurityException) {
        this.Controls.Add(
          new LiteralControl("Permission denied - please set trust level to WSS_Medium."));
      }
    }

    IAsyncResult BeginXmlRequest(object src, EventArgs args, AsyncCallback callback, object state) {
      return this.xmlReq.BeginGetResponse(callback, state);
    }

    void XmlRequestTimeout(IAsyncResult ar) {
      Label timeoutLabel = new Label();
      timeoutLabel.Text = string.Format(
          "The request timed out while waiting for {0}.", this.XmlUrl);
      this.Controls.Add(timeoutLabel);
    }

    void EndXmlRequest(IAsyncResult ar) {
      try {
        WebResponse response = this.xmlReq.EndGetResponse(ar);
        this.xmlResponseStream = response.GetResponseStream();
      } catch (WebException wex) {
        this.exceptionDetails = wex.Message;
      }
    }

    #endregion async tasks

    #region connections

    // Get the connection
    [ConnectionConsumer("Xml URL Consumer", AllowsMultipleConnections = false)]
    public void SetConnectionInterface(IWebPartField provider) {
      provider.GetFieldValue(new FieldCallback(GetXmlUrl));

    }

    // A callback method for the IWebPartField's delegate
    private void GetXmlUrl(object providedUrl) {
      if (providedUrl != null) {
        // A workaround for the Url field type
        string[] urls = ((string)providedUrl).Split(',');
        if (urls.Length > 0)
          this.XmlUrl = urls[0];
      }
    }

    #endregion connections

    #region render with XSLT

    protected override void RenderContents(HtmlTextWriter writer) {
      base.RenderContents(writer);

      if (this.exceptionDetails != null) {
        writer.Write(this.exceptionDetails);
        return;
      }
      if (string.IsNullOrEmpty(this.xmlUrl) || this.xmlResponseStream == null)
        return;

      XslCompiledTransform transform = new XslCompiledTransform();
      string xslt;
      if (this.HeadlineMode == RenderMode.Full)
        xslt = @"Resources.RSS.xslt";
      else
        xslt = @"Resources.RssTitles.xslt";
      using (Stream res = WebPartResources.GetNamedResourceStream(this, xslt)) {
        using (XmlTextReader stylesheet = new XmlTextReader(res)) {
          transform.Load(stylesheet);
        }
      }

      try {
        using (XmlReader reader = new XmlTextReader(this.xmlResponseStream)) {
          XmlTextWriter results = new XmlTextWriter(writer.InnerWriter);
          transform.Transform(reader, results);
          reader.Close();
        }
      } catch (Exception ex) {
        writer.Write(ex.Message);
        if (this.xmlResponseStream != null) {
          this.xmlResponseStream.Close();
          this.xmlResponseStream.Dispose();
        }
      }
    }

    #endregion render with XSLT

  }
}
