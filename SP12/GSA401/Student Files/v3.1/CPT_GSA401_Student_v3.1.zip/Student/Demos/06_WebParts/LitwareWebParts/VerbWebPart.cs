using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;

namespace LitwareWebParts {
  public class VerbWebPart : WebPart {

    public override WebPartVerbCollection Verbs {
      get {
        List<WebPartVerb> verbs = new List<WebPartVerb>();

        WebPartVerb verb1 = new WebPartVerb(this.ID + "_ExampleClientSideVerb",
                                           "VerbWebPart_onClientClick()");
        verb1.Description = "An example Verb for Inside WSS";
        verb1.Text = "Custom client-side Verb";
        verbs.Add(verb1);

        WebPartVerb verb2 = new WebPartVerb(this.ID + "_ExampleServerSideVerb",
                                           new WebPartEventHandler(ServerSideVerbHandler));
        verb2.Description = "An example Verb for Inside WSS";
        verb2.Text = "Custom server-side Verb";
        verbs.Add(verb2);
        
        WebPartVerbCollection allverbs = new WebPartVerbCollection(base.Verbs, verbs);
        return allverbs;
      }
    }

    public void ServerSideVerbHandler(object sender, WebPartEventArgs e) {
      Context.Response.Redirect("http://msdn.microsoft.com");
    }

    protected override void OnPreRender(EventArgs e) {
      const string script = @"function VerbWebPart_onClientClick(){alert('Hello from client-side JavaScript verb handler');}";
      this.Page.ClientScript.RegisterClientScriptBlock(typeof(VerbWebPart),
        "VerbWebPart_onClientClick", script, true);
    }

    protected override void RenderContents(HtmlTextWriter writer) {
      writer.Write("An example showing Web Part verbs with a client-side handler and a server-side handler");
    }
  }

}
