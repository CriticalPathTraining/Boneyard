using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareWebParts {
  public class UserControlHost : WebPart {

    protected Control userControl;    

    protected override void CreateChildControls() {
      this.Controls.Clear();

      string userControlPath = @"/_controltemplates/Litware/LitwareUserControl.ascx";
      this.userControl = this.Page.LoadControl(userControlPath);
      this.Controls.Add(this.userControl);

    }

//  Optional method for writing custom output around the control: 
    //protected override void RenderContents(System.Web.UI.HtmlTextWriter writer) {
    //  userControl.RenderControl(writer);
    //}

  }
}

