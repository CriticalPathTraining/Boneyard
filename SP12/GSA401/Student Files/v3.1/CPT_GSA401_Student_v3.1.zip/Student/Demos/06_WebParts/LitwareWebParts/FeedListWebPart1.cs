using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;

namespace LitwareWebParts {

  public class FeedListWebPart1 : WebPart {

    private SPGridView listsView;
    private DataTable dt;
    
    // The selected url
    string xmlUrl;
    
    protected override void CreateChildControls() {
      base.CreateChildControls();


      List<SPList> lists = new List<SPList>();
      this.AddLists(lists, SPContext.Current.Web);

      listsView = new SPGridView();
      listsView.AutoGenerateColumns = false;
      BoundField colTitle = new BoundField();
      colTitle.DataField = "Title";
      colTitle.HeaderText = "Title";
      listsView.Columns.Add(colTitle);
      this.Controls.Add(listsView);
      listsView.SelectedIndexChanged += new EventHandler(view_SelectedIndexChanged);

      if (!this.Page.IsPostBack) {
        BoundField colXml = new BoundField();
        colXml.DataField = "Description";
        colXml.HeaderText = "Description";
        listsView.Columns.Add(colXml);

        dt = new DataTable();
        dt.Columns.Add("Title");
        dt.Columns.Add("Description");
        dt.Columns.Add("XmlUrl");
        dt.Columns.Add("ID");

        foreach (SPList list in lists) {
          DataRow dr = dt.NewRow();
          dr["Title"] = list.Title;
          dr["Description"] = list.Description;
          dr["ID"] = list.ID;
          string url = this.Page.Request.Url.GetLeftPart(UriPartial.Authority)
          + SPUtility.MapWebURLToVirtualServerURL(
              list.ParentWeb,
              string.Format("{0}/_layouts/listfeed.aspx?List={1}",
              list.ParentWebUrl, list.ID.ToString()));
          dr["XmlUrl"] = url;
          dt.Rows.Add(dr);
        }
        listsView.AutoGenerateSelectButton = true;
        listsView.DataKeyNames = new string[] { "XmlUrl" };
        listsView.DataSource = dt;
        listsView.DataBind();
      }
    }

    void view_SelectedIndexChanged(object sender, EventArgs e) {
      GridViewRow row = listsView.SelectedRow;
      this.xmlUrl = listsView.SelectedValue.ToString();
    }

    private void AddLists(List<SPList> lists, SPWeb web) {
      foreach (SPList list in web.Lists)
        if (list.AllowRssFeeds && list.EnableSyndication &&
                list.BaseTemplate != SPListTemplateType.Categories &&
                list.BaseTemplate != SPListTemplateType.ListTemplateCatalog &&
                list.BaseTemplate != SPListTemplateType.MasterPageCatalog &&
                list.BaseTemplate != SPListTemplateType.WebPageLibrary &&
                list.BaseTemplate != SPListTemplateType.WebPartCatalog &&
                list.BaseTemplate != SPListTemplateType.WebTemplateCatalog &&
                list.DoesUserHavePermissions(SPBasePermissions.ViewListItems))
          lists.Add(list);

      foreach (SPWeb subweb in web.Webs) {
        if (web.DoesUserHavePermissions(SPBasePermissions.ViewListItems))
          this.AddLists(lists, subweb);
      }
    }
  }
}
