using System;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI;

namespace LitwareWebParts {
 
  // A very simple webpart 
  public class LocalizedWebPart : WebPart {
    protected override void RenderContents(HtmlTextWriter writer) {
      writer.Write("{0} {1}", 
        Resources.LitwareControlStrings.Hello,
        Context.User.Identity.Name);
    }
  }
}