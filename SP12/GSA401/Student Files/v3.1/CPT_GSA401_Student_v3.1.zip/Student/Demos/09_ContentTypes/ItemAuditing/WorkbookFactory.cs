using System;
using System.IO;
using System.IO.Packaging;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace ItemAuditing {

  public class AuditLogWorkbook {

    #region "Constants"

    const string spreadsheetML = @"http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    const string worksheetSchema = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    const string relationSchema = @"http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    const string documentRelationshipType = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
    const string sharedStringsRelationshipType = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings";
    const string sharedStringSchema = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    const string workbookContentType = @"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml";
    const string worksheetContentType = @"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml";
    const string stylesheetContentType = @"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml";
    const string stringsContentType = @"application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml";
    const string sheetName = "Sheet1";

    #endregion

    #region "Private Fields"
 
    MemoryStream stream = null;
    Package pkgOutputDoc = null;

    #endregion

    public AuditLogWorkbook() {
      byte[] document = Properties.Resources.Template;
      stream = new MemoryStream();
      stream.Write(document, 0, document.GetLength(0));
      pkgOutputDoc = Package.Open(stream, FileMode.Open, FileAccess.ReadWrite);
    }

    public void WriteHeaderInfo(string library, string document, DateTime date) {
      WriteCell("b2", library);
      WriteCell("b3", document);
      WriteCell("b4", date.ToLocalTime().ToString());
    }

    private int row = 6;
    public void WriteEntry(string User, string Occurred, string Event, string Version) {

      WriteCell("b" + row.ToString(), User);
      WriteCell("c" + row.ToString(), Occurred);
      WriteCell("d" + row.ToString(), Event);
      WriteCell("e" + row.ToString(), Version);
      row += 1;
    }

    public Stream GetDocument() {
      return stream;
    }

    public bool WriteCell(string celladdress, string cellvalue) {
      if (IsInteger(cellvalue)) {
        XLInsertNumberIntoCell(celladdress, Int32.Parse(cellvalue));
      }
      else {
        XLInsertStringIntoCell(sheetName, celladdress, cellvalue);
      }
      return true;
    }

    private bool IsInteger(string strNumber) {
      Regex objNotIntPattern = new Regex("[^0-9-]");
      Regex objIntPattern = new Regex("^-[0-9]+$|^[0-9]+$");

      return !objNotIntPattern.IsMatch(strNumber) &&
              objIntPattern.IsMatch(strNumber);
    }

    private void XLInsertNumberIntoCell(string addressName, int value) {
      PackagePart documentPart = null;
      Uri documentUri = null;

      foreach (PackageRelationship relationship in pkgOutputDoc.GetRelationshipsByType(documentRelationshipType)) {
        documentUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative), relationship.TargetUri);
        documentPart = pkgOutputDoc.GetPart(documentUri);
        break;
      }

      if (documentPart != null) {
        XmlDocument doc = new XmlDocument();
        doc.Load(documentPart.GetStream());
        XmlNamespaceManager nsManager = new XmlNamespaceManager(doc.NameTable);
        nsManager.AddNamespace("d", doc.DocumentElement.NamespaceURI);

        string searchString = string.Format("//d:sheet[@name='{0}']", sheetName);
        XmlNode sheetNode = doc.SelectSingleNode(searchString, nsManager);
        if (sheetNode != null) {
          XmlAttribute relationAttribute = sheetNode.Attributes["r:id"];
          if (relationAttribute != null) {
            string relId = relationAttribute.Value;
            PackageRelationship sheetRelation = documentPart.GetRelationship(relId);
            Uri sheetUri = PackUriHelper.ResolvePartUri(documentUri, sheetRelation.TargetUri);
            PackagePart sheetPart = pkgOutputDoc.GetPart(sheetUri);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(sheetPart.GetStream());
            System.Text.RegularExpressions.Regex r = new System.Text.RegularExpressions.Regex(@"^(?<col>\D+)(?<row>\d+)");
            string rowNumber = r.Match(addressName).Result("${row}");
            XmlNode cellnode = xDoc.SelectSingleNode(string.Format("//d:sheetData/d:row/d:c[@r='{0}']", addressName), nsManager);
            if (cellnode == null) {
              XmlElement cellElement = xDoc.CreateElement("c", worksheetSchema);
              cellElement.Attributes.Append(xDoc.CreateAttribute("r"));
              cellElement.Attributes["r"].Value = addressName;
              XmlElement valueElement = xDoc.CreateElement("v", worksheetSchema);
              valueElement.InnerText = value.ToString();
              cellElement.AppendChild(valueElement);
              cellElement.Attributes.Append(xDoc.CreateAttribute("s"));
              cellElement.Attributes["s"].Value = "0";

              XmlNode rowNode = xDoc.SelectSingleNode(string.Format("//d:sheetData/d:row[@r='{0}']", rowNumber), nsManager);
              if (rowNode == null) {
                XmlNode sheetDataNode = xDoc.SelectSingleNode("//d:sheetData", nsManager);
                if (sheetDataNode != null) {
                  XmlElement rowElement = xDoc.CreateElement("row", worksheetSchema);
                  rowElement.Attributes.Append(xDoc.CreateAttribute("r"));
                  rowElement.Attributes["r"].Value = rowNumber;
                  rowElement.AppendChild(cellElement);
                  sheetDataNode.AppendChild(rowElement);
                }
              }
              else {
                XmlAttribute styleAttr = ((XmlAttribute)(rowNode.Attributes.GetNamedItem("s")));
                if (styleAttr != null) {
                  cellElement.Attributes["s"].Value = styleAttr.Value;
                }

                XmlNode biggerNode = null;
                XmlNodeList cellNodes = rowNode.SelectNodes("./d:c", nsManager);
                if (cellNodes != null) {
                  foreach (XmlNode node in cellNodes) {
                    if (String.Compare(node.Attributes["r"].Value, addressName) > 0) {
                      biggerNode = node;
                      break;
                    }
                  }
                }
                if (biggerNode == null) {
                  rowNode.AppendChild(cellElement);
                }
                else {
                  rowNode.InsertBefore(cellElement, biggerNode);
                }
              }
            }
            else {
              cellnode.Attributes.RemoveNamedItem("t");
              XmlNode valueNode = cellnode.SelectSingleNode("d:v", nsManager);
              if (valueNode == null) {
                valueNode = xDoc.CreateElement("v", worksheetSchema);
                cellnode.AppendChild(valueNode);
              }
              valueNode.InnerText = value.ToString();
            }

            xDoc.Save(sheetPart.GetStream(FileMode.Create, FileAccess.Write));
          }
        }
      }

    }

    private bool XLInsertStringIntoCell(string sheetName, string addressName, string value) {

      PackagePart documentPart = null;
      Uri documentUri = null;
      bool returnValue = false;

      //  Get the main document part (workbook.xml).
      foreach (System.IO.Packaging.PackageRelationship relationship in pkgOutputDoc.GetRelationshipsByType(documentRelationshipType)) {
        //  There should only be one document part in the package. 
        documentUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative), relationship.TargetUri);
        documentPart = pkgOutputDoc.GetPart(documentUri);
        //  There should only be one instance, but get out no matter what.
        break;
      }

      if (documentPart != null) {
        // Load the contents of the workbook.
        XmlDocument doc = new XmlDocument();
        doc.Load(documentPart.GetStream());

        //  Create a namespace manager, so you can search.
        //  Add a prefix (d) for the default namespace.
        NameTable nt = new NameTable();
        XmlNamespaceManager nsManager = new XmlNamespaceManager(nt);
        nsManager.AddNamespace("d", worksheetSchema);
        nsManager.AddNamespace("s", sharedStringSchema);

        string searchString = string.Format("//d:sheet[@name='{0}']", sheetName);
        XmlNode sheetNode = doc.SelectSingleNode(searchString, nsManager);
        if (sheetNode != null) {
          //  Get the relId attribute:
          XmlAttribute relationAttribute = sheetNode.Attributes["r:id"];
          if (relationAttribute != null) {
            string relId = relationAttribute.Value;

            //  First, get the relation between the document and the sheet.
            PackageRelationship sheetRelation = documentPart.GetRelationship(relId);
            Uri sheetUri = PackUriHelper.ResolvePartUri(documentUri, sheetRelation.TargetUri);
            PackagePart sheetPart = pkgOutputDoc.GetPart(sheetUri);

            //  Load the contents of the workbook.
            XmlDocument xDoc = new XmlDocument(nt);
            xDoc.Load(sheetPart.GetStream());

            //  Set up the string information, so you can find and/or insert the string you need.
            foreach (System.IO.Packaging.PackageRelationship stringRelationship in documentPart.GetRelationshipsByType(sharedStringsRelationshipType)) {
              //  There should only be one shared string reference.
              Uri sharedStringsUri = PackUriHelper.ResolvePartUri(documentUri, stringRelationship.TargetUri);
              PackagePart stringPart = pkgOutputDoc.GetPart(sharedStringsUri);
              if (stringPart != null) {
                //  Load the contents of the shared strings.
                XmlDocument stringDoc = new XmlDocument(nt);
                stringDoc.Load(stringPart.GetStream());

                //  Assume the string won't be found (assign it an impossible index):
                int index = -1;

                //  Check to see if the string already exists. If so, retrieve its index.
                //  This search is case-sensitive, but Excel stores differently cased
                //  strings separately within the string file.
                XmlNode stringNode = stringDoc.SelectSingleNode(string.Format("//s:si[s:t='{0}']", value), nsManager);
                if (stringNode == null) {
                  //  You didn't find the string in the table, so add it now.
                  stringNode = stringDoc.CreateElement("si", sharedStringSchema);
                  XmlElement textNode = stringDoc.CreateElement("t", sharedStringSchema);
                  textNode.InnerText = value;
                  stringNode.AppendChild(textNode);
                  stringDoc.DocumentElement.AppendChild(stringNode);
                }

                if (stringNode != null) {
                  //  You've found the node, or you've just added it.
                  //  It had better not be a null reference. But it never hurts to check.

                  //  Retrieve the index of the selected node.
                  //  To do that, count the number of preceding
                  //  nodes by retrieving a reference to those nodes.
                  XmlNodeList nodes = stringNode.SelectNodes("preceding-sibling::d:si", nsManager);
                  index = nodes.Count;

                  //  Use regular expressions to get the row number.
                  //  If the parameter wasn't well formed, this code
                  //  will fail:
                  System.Text.RegularExpressions.Regex r = new System.Text.RegularExpressions.Regex(@"^(?<col>\D+)(?<row>\d+)");
                  string rowNumber = r.Match(addressName).Result("${row}");

                  //  Search for the existing cell:
                  XmlNode cellNode = xDoc.SelectSingleNode(string.Format("//d:sheetData/d:row/d:c[@r='{0}']", addressName), nsManager);
                  if (cellNode == null) {
                    //  Didn't find the cell. Look for the row. You're going to need to create
                    //  the cell whether you find the row or not, so create that XML element now:
                    XmlElement cellElement = xDoc.CreateElement("c", worksheetSchema);
                    cellElement.Attributes.Append(xDoc.CreateAttribute("r"));
                    cellElement.Attributes["r"].Value = addressName;

                    //  Indicate that this cell will contain a string.
                    cellElement.Attributes.Append(xDoc.CreateAttribute("t"));
                    cellElement.Attributes["t"].Value = "s";

                    //  Default style is "0"
                    cellElement.Attributes.Append(xDoc.CreateAttribute("s"));
                    cellElement.Attributes["s"].Value = "0";

                    //  Set the cell's value:
                    XmlElement valueElement = xDoc.CreateElement("v", worksheetSchema);
                    valueElement.InnerText = index.ToString();
                    cellElement.AppendChild(valueElement);

                    //  Look for the row:
                    XmlNode rowNode = xDoc.SelectSingleNode(string.Format("//d:sheetData/d:row[@r='{0}']", rowNumber), nsManager);
                    if (rowNode == null) {
                      //  Didn't find the row, either. Just add a new row element:
                      XmlNode sheetDataNode = xDoc.SelectSingleNode("//d:sheetData", nsManager);
                      if (sheetDataNode != null) {
                        XmlElement rowElement = xDoc.CreateElement("row", worksheetSchema);
                        rowElement.Attributes.Append(xDoc.CreateAttribute("r"));
                        rowElement.Attributes["r"].Value = rowNumber;
                        rowElement.AppendChild(cellElement);
                        sheetDataNode.AppendChild(rowElement);
                        returnValue = true;
                      }
                    }
                    else {
                      //  The row exists, but the cell does not. Add the cell information now.
                      //  Get the style information from the parent row, if it exists.
                      XmlAttribute styleAttr = ((XmlAttribute)(rowNode.Attributes.GetNamedItem("s")));
                      if (styleAttr != null) {
                        //  You know cellElement has an "s" attribute -- you
                        //  added it yourself.
                        cellElement.Attributes["s"].Value = styleAttr.Value;
                      }
                      // You must insert the new cell at the correct location.
                      // Loop through the children, looking for the first cell that is
                      // beyond the cell you're trying to insert. Insert before that cell.
                      XmlNode biggerNode = null;
                      XmlNodeList cellNodes = rowNode.SelectNodes("./d:c", nsManager);
                      if (cellNodes != null) {
                        foreach (XmlNode node in cellNodes) {
                          if (String.Compare(node.Attributes["r"].Value, addressName) > 0) {
                            biggerNode = node;
                            break;
                          }
                        }
                      }
                      if (biggerNode == null) {
                        rowNode.AppendChild(cellElement);
                      }
                      else {
                        rowNode.InsertBefore(cellElement, biggerNode);
                      }
                      returnValue = true;
                    }
                  }
                  else {
                    //  You found XML corresponding to the cell location.
                    //  If there's a "t" attribute, make sure its value is "s".
                    //  If not, add the "t" attribute with the value "s".
                    if (cellNode.Attributes["t"] == null) {
                      cellNode.Attributes.Append(xDoc.CreateAttribute("t"));
                    }
                    cellNode.Attributes["t"].Value = "s";
                    XmlNode valueNode = cellNode.SelectSingleNode("d:v", nsManager);
                    if (valueNode == null) {
                      //  Cell with deleted value. Add a value element now.
                      valueNode = xDoc.CreateElement("v", worksheetSchema);
                      cellNode.AppendChild(valueNode);
                    }
                    valueNode.InnerText = index.ToString();
                    returnValue = true;
                  }

                  //  Save the string file back to its part.
                  stringDoc.Save(stringPart.GetStream(FileMode.Create, FileAccess.Write));

                  //  Save the XML back to its part.
                  xDoc.Save(sheetPart.GetStream(FileMode.Create, FileAccess.Write));
                }
              }
              //  Once you've found the match, get out:
              break;
            }
          }
        }
      }
      return returnValue;
    }

    public void Close() {
      pkgOutputDoc.Flush();
      pkgOutputDoc.Close();
    }

  }
}
