using System;
using Microsoft.SharePoint;

namespace ItemAuditing {
  public class ItemAuditingFeatureReceiver : SPFeatureReceiver {

    // no code for feature installation/uninstallation
    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }

    // feature activation event handler
    public override void FeatureActivated(SPFeatureReceiverProperties properties) {

      SPSite siteCollection = (SPSite)properties.Feature.Parent;

      // turn on auditing flags
      siteCollection.Audit.AuditFlags = SPAuditMaskType.All;
      siteCollection.Audit.Update();

      // modify title of top-level site
      SPWeb site = siteCollection.RootWeb;
      site.Title += " (audited)";
      site.Update();

      // create document library for audit logs unless it already exists
      if (!ListExists("AuditLogs", site)) {
        SPListTemplate template = site.ListTemplates["Document Library"];
        Guid docLibID = site.Lists.Add("AuditLogs", "Library for Audit Log Workbooks", template);
        SPList docLib = site.Lists[docLibID];
        docLib.OnQuickLaunch = true;
        docLib.Update();
      }

    }

    // feature deactivation event handler
    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {

      SPSite siteCollection = (SPSite)properties.Feature.Parent;

      // 
      SPWeb site = siteCollection.RootWeb;
      if (site.Title.EndsWith(" (audited)")) {
        site.Title = site.Title.Substring(0, (site.Title.Length - (" (audited)").Length));
        site.Update();
      }

    }

    // utility function
    private bool ListExists(string listName, SPWeb targetSite) {
      foreach (SPList list in targetSite.Lists) {
        if (list.Title == listName)
          return true;
      }
      return false;
    }

  }
}
