using System;
using Microsoft.SharePoint;

namespace LitwareTypes {
public class CompanyItemEventReceiver : SPItemEventReceiver {

  private string FormatCompanyName(string value) {
    return value.ToUpper();
  }

  public override void ItemAdded(SPItemEventProperties properties) {
    DisableEventFiring();
    string CompanyName = properties.ListItem["Company"].ToString();
    properties.ListItem["Company"] = FormatCompanyName(CompanyName);
    properties.ListItem.Update();
    EnableEventFiring();
  }

  public override void ItemUpdated(SPItemEventProperties properties) {
    DisableEventFiring();
    string CompanyName = properties.ListItem["Company"].ToString();
    properties.ListItem["Company"] = FormatCompanyName(CompanyName);
    properties.ListItem.Update();
    EnableEventFiring();
  }

}
}
