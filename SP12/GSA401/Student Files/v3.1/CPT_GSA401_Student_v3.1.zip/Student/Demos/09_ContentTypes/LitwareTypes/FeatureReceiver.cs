using System;
using Microsoft.SharePoint;

namespace LitwareTypes {
  public class FeatureReceiver : SPFeatureReceiver {

public override void FeatureActivated(SPFeatureReceiverProperties properties) {

  // access SPSite object for current site collection
  SPSite siteCollection = (SPSite)properties.Feature.Parent;
  
  // access SPWeb object for top-level site
  SPWeb site = siteCollection.RootWeb;

  // enabled content type management for Customers list
  SPList lstCustomers = site.Lists["Customers"];
  lstCustomers.ContentTypesEnabled = true;
  lstCustomers.Update();

  // enabled content type management for vendors list
  SPList lstVendors = site.Lists["Vendors"];
  lstVendors.ContentTypesEnabled = true;
  lstVendors.Update();
  
  // add event handlers to vendors list
  string asmName = "LitwareTypes, Version=1.0.0.0, Culture=neutral, PublicKeyToken=74bad7277fe0d19e";
  string listReceiverName = "LitwareTypes.VendorListEventReceiver";
  string itemReceiverName = "LitwareTypes.VendorItemEventReceiver";

  // add event receiver to fire before new column is added
  lstVendors.EventReceivers.Add(SPEventReceiverType.FieldAdding,
                                asmName,
                                listReceiverName);

  // add event receiver to fire before existing column is updated
  lstVendors.EventReceivers.Add(SPEventReceiverType.FieldUpdating,
                                asmName,
                                listReceiverName);

  // add event receiver to fire before existing column is updated
  lstVendors.EventReceivers.Add(SPEventReceiverType.FieldDeleting,
                                asmName,
                                listReceiverName);

  // add event receiver to fire before existing item is deleted
  lstVendors.EventReceivers.Add(SPEventReceiverType.ItemAdding,
                                asmName,
                                itemReceiverName);

  // add event receiver to fire before existing item is deleted
  lstVendors.EventReceivers.Add(SPEventReceiverType.ItemUpdating,
                                asmName,
                                itemReceiverName);

  // add event receiver to fire before existing item is deleted
  lstVendors.EventReceivers.Add(SPEventReceiverType.ItemDeleting,
                                asmName,
                                itemReceiverName);
}

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      // no-op implementation
    }

    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { 
      // no-op implementation
    }

    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) {
      // no-op implementation
    }
  }
}
