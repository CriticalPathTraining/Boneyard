﻿using System.Reflection;

// ItemAuditing, Version=1.0.0.0, Culture=neutral, PublicKeyToken=7fd3ed697555604d
[assembly: AssemblyVersion("1.0.0.0")]

[assembly: System.Security.AllowPartiallyTrustedCallers()]



