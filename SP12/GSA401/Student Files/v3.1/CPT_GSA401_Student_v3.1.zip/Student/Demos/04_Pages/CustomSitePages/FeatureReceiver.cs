
using System;
using System.Web.UI.WebControls.WebParts;
using System.Xml;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Navigation;

namespace CustomSitePages {
  public class FeatureReceiver : SPFeatureReceiver {

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {

      // get a hold off current site in context of feature activation
      SPWeb site = (SPWeb)properties.Feature.Parent;
      SPNavigationNodeCollection topNav = site.Navigation.TopNavigationBar;      
      
      // create dropdown menu for custom site pages
      SPNavigationNode DropDownMenu1 = 
                       new SPNavigationNode("Custom Site Pages", "", false);
      topNav[0].Children.AddAsLast(DropDownMenu1);
      DropDownMenu1.Children.AddAsLast(
        new SPNavigationNode("Site Page 1", "SitePages/Page01.aspx"));

      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 2", "SitePages/Page02.aspx"));
      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 3", "SitePages/Page03.aspx"));
      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 4", "SitePages/Page04.aspx"));
      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 5", "SitePages/Page05.aspx"));
      DropDownMenu1.Children.AddAsLast(new SPNavigationNode("Site Page 6", "SitePages/Page06.aspx"));
      
      // create dropdown menu for custom Web Part Pages
      SPNavigationNode DropDownMenu2 = new SPNavigationNode("Custom Web Part Pages", "", false);
      topNav[0].Children.AddAsLast(DropDownMenu2);      
      DropDownMenu2.Children.AddAsLast(new SPNavigationNode("Web Part Page 1", "SitePages/WebPartPage01.aspx"));
      DropDownMenu2.Children.AddAsLast(new SPNavigationNode("Web Part Page 2", "SitePages/WebPartPage02.aspx"));
      DropDownMenu2.Children.AddAsLast(new SPNavigationNode("Web Part Page 3", "SitePages/WebPartPage03.aspx"));

      SPFile page = site.GetFile("SitePages/WebPartPage02.aspx");
      SPLimitedWebPartManager mgr;
      mgr = page.GetLimitedWebPartManager(PersonalizationScope.Shared);
      // add Web Part to Left Zone
      ContentEditorWebPart wp1 = new ContentEditorWebPart();
      wp1.Title = "My Most Excellent Title";
      wp1.ChromeType = PartChromeType.TitleOnly;
      wp1.AllowClose = false;
      XmlDocument doc = new XmlDocument();
      string ns1 = "http://schemas.microsoft.com/WebPart/v2/ContentEditor";
      XmlElement elm = doc.CreateElement("Content", ns1);
      elm.InnerText = "This Web Part was added through code";
      wp1.Content = elm;
      mgr.AddWebPart(wp1, "Left", 0);
      // add Web Part to Right Zone
      ImageWebPart wp2 = new ImageWebPart();
      wp2.ChromeType = PartChromeType.None;
      wp2.ImageLink = @"/_layouts/images/IPVW.GIF";
      mgr.AddWebPart(wp2, "Right", 0);
  }


    public override void FeatureDeactivating(SPFeatureReceiverProperties properties)  {

      SPWeb site = (SPWeb)properties.Feature.Parent;
      // delete folder of site pages provisioned during activation
      SPFolder sitePagesFolder = site.GetFolder("SitePages");
      sitePagesFolder.Delete();

      SPNavigationNodeCollection topNav = site.Navigation.TopNavigationBar;

      for (int i = topNav[0].Children.Count - 1; i >= 0; i--) {
        if(topNav[0].Children[i].Title ==  "Custom Site Pages" || 
           topNav[0].Children[i].Title ==  "Custom Web Part Pages")  {
          // delete node
          topNav[0].Children[i].Delete();
        }
      }
    }

    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { /* no op */}
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { /* no op */}

  }
}
