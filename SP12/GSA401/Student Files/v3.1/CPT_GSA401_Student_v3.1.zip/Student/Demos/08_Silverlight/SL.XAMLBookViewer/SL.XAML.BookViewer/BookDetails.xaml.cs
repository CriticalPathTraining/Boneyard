﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;

namespace SL.XAML.BookViewer
{
    public partial class BookDetails : UserControl
    {
        public BookDetails()
        {
            InitializeComponent();
        }

        private string siteUrl = null;
        private string listName = null;

        public string SiteUrl
        {
            get { return siteUrl; }
            set { siteUrl = value; }
        }

        public string ListName
        {
            get { return listName; }
            set { listName = value; }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Visibility = Visibility.Collapsed;
        }

    }
}
