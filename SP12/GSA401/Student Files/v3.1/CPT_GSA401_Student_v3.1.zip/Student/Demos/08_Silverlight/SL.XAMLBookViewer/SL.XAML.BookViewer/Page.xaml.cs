﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Threading;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Globalization;

namespace SL.XAML.BookViewer
{
    public partial class Page : UserControl
    {
        private string siteUrl;
        private string listName;
        private string responsestring = null;
        ObservableCollection<Book> books = null;
        private SynchronizationContext syncContext;
        private Stream body;

        public Page(string siteUrl, string listName)
        {
            InitializeComponent();

            this.siteUrl = siteUrl;
            this.listName = listName;

            PopulateListBox();
        }

        private void BooksList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Book book = (Book)BooksList.SelectedItem;

            if (book != null)
            {
                DetailsView.DataContext = book;
                DetailsView.SiteUrl = siteUrl;
                DetailsView.ListName = listName;
                DetailsView.Visibility = Visibility.Visible;
            }
        }

        #region HttpWebRequest
        private void PopulateListBox()
        {
            MessageTextBlock.Visibility = Visibility.Collapsed;
            LoadRotator.Visibility = Visibility.Visible;

            // Grab SynchronizationContext while on UI Thread   
            syncContext = SynchronizationContext.Current;

            // Information of the products that should be downloaded is obtained by calling the SharePoint Lists.asmx web service 
            // using HttpWebRequest. The call to the Request as to the Response are asynchronous.
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(new Uri(siteUrl + "/_vti_bin/Lists.asmx", 
                UriKind.Absolute));
            request.Method = "POST";
            request.BeginGetRequestStream(new AsyncCallback(RequestCallback), request);
        }

        // in the request a soap envelop is build based on the schema needed by the Lists.asmx. The GetListItems method is called on 
        // the AdventureWorks Products list passed in via the Web Part.
        private void RequestCallback(IAsyncResult asyncResult)
        {
            try
            {
                string envelope = @"<?xml version=""1.0"" encoding=""utf-8""?>
                <soap12:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:soap12=""http://www.w3.org/2003/05/soap-envelope"">
                <soap12:Body>
                    <GetListItems xmlns=""http://schemas.microsoft.com/sharepoint/soap/"">
                    <listName>{0}</listName>
                    <query><Query xmlns=""""><OrderBy><FieldRef Name=""BookAuthor"" /><FieldRef Name=""Title"" /></OrderBy></Query></query>
                    <viewFields><ViewFields xmlns="""">
                        <FieldRef Name=""ID"" />
                        <FieldRef Name=""Title"" />
                        <FieldRef Name=""SubTitle"" />
                        <FieldRef Name=""BookAuthor"" />
                        <FieldRef Name=""Thumbnail"" />
                        <FieldRef Name=""ISBN"" />
                        <FieldRef Name=""Publisher"" />
                        <FieldRef Name=""Description"" />
                        </ViewFields>
                    </viewFields>
                    <queryOptions><QueryOptions xmlns=""""><IncludeMandatoryColumns>False</IncludeMandatoryColumns></QueryOptions></queryOptions>
                    </GetListItems>
                </soap12:Body>
                </soap12:Envelope>";

                envelope = string.Format(envelope, listName);
                HttpWebRequest request = (HttpWebRequest)asyncResult.AsyncState;
                request.ContentType = "application/soap+xml; charset=utf-8";
                request.Headers["ClientType"] = "Silverlight";

                Stream requestStream = request.EndGetRequestStream(asyncResult);
                StreamWriter body = new StreamWriter(requestStream);
                body.Write(envelope);
                body.Close();

                request.BeginGetResponse(new AsyncCallback(ResponseCallback), request);
            }
            catch (WebException ex)
            {
                responsestring = ex.Message;
            }

        }

        private void ResponseCallback(IAsyncResult asyncResult)
        {
            HttpWebRequest request = (HttpWebRequest)asyncResult.AsyncState;
            WebResponse response = null;

            try
            {
                response = request.EndGetResponse(asyncResult);
            }
            catch (WebException we)
            {
                responsestring = we.Status.ToString();
            }
            catch (System.Security.SecurityException se)
            {
                responsestring = se.Message;
                if (responsestring == "")
                    responsestring = se.InnerException.Message;
            }
            syncContext.Post(ExtractResponse, response);
        }

        private void ExtractResponse(object state)
        {
            HttpWebResponse response = state as HttpWebResponse;

            if (response != null && response.StatusCode == HttpStatusCode.OK)
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    responsestring = reader.ReadToEnd();
                    ProcessResponse();
                }
            }
            else
                ProcessMessage();
        }

        private void ProcessMessage()
        {
            LoadRotator.Visibility = Visibility.Collapsed;
            MessageTextBlock.Visibility = Visibility.Visible;
            MessageTextBlock.Text = responsestring;
        }

        private void ProcessResponse()
        {
            LoadRotator.Visibility = Visibility.Collapsed;
            books = new ObservableCollection<Book>();

            XDocument results = XDocument.Parse(responsestring);

            var query = from item in results.Descendants(XName.Get("row", "#RowsetSchema"))
                        select new Book()
                        {
                            Id = System.Convert.ToInt32(item.Attribute("ows_ID").Value, CultureInfo.InvariantCulture),
                            Title = item.Attribute("ows_Title").Value,
                            SubTitle = item.Attribute("ows_SubTitle") != null ? item.Attribute("ows_SubTitle").Value : string.Empty,
                            Author = item.Attribute("ows_BookAuthor") != null ? item.Attribute("ows_BookAuthor").Value : string.Empty,
                            ISBN = item.Attribute("ows_ISBN") != null ? item.Attribute("ows_ISBN").Value : string.Empty,
                            Publisher = item.Attribute("ows_Publisher") != null ? item.Attribute("ows_Publisher").Value : string.Empty,
                            Description = item.Attribute("ows_Description") != null ? item.Attribute("ows_Description").Value : string.Empty,
                            ThumbNail = GetThumbnailUrl(item.Attribute("ows_Thumbnail"))
                        };

            foreach (Book p in query.ToList())
            {
                books.Add(p);
            }
            BooksList.ItemsSource = books;
        }

        private string GetThumbnailUrl(XAttribute thumbnailAttribute)
        {
            string url = null;

            if (thumbnailAttribute != null)
            {
                url = thumbnailAttribute.Value;
                string[] urlvalues = url.Split(',');
                if (urlvalues.Length == 2)
                    url = urlvalues[0];
            }
            return url;
        }
        #endregion
    }
}
