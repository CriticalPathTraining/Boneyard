using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts {
  public class Hello3 : WebPart {

    #region "Custom Properties"

    public enum BackgroundColorEnum {
      White,
      Gray,
      Teal,
      Yellow
    }

    private BackgroundColorEnum _BackgroundColor;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(true), WebDisplayName("Background Color"),
      WebDescription("This value will be used to set background color"),
      Category("Litware Custom Properties")]
    public BackgroundColorEnum BackgroundColor {
      get { return _BackgroundColor; }
      set { _BackgroundColor = value; }
    }


    public enum FontColorEnum {
      Black,
      Red,
      Green,
      Blue
    }

    private FontColorEnum _FontColor = FontColorEnum.Blue;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(true), WebDisplayName("Font Color"),
     WebDescription("This value will be used to set font color"),
     Category("Litware Custom Properties")]
    public FontColorEnum FontColor {
      get { return _FontColor; }
      set { _FontColor = value; }
    }
	

    private double _Number1Default;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(true), WebDisplayName("Number 1 Default Value"),
      WebDescription("This value will be persisted for number 1 default value"),
    Category("Litware Custom Properties")]
    public double Number1Default {
      get { return _Number1Default; }
      set { _Number1Default = value; }
    }
    

    private double _Number2Default;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(true), WebDisplayName("Number 2 Default Value"),
      WebDescription("This value will be persisted for number 2 default value"),
      Category("Litware Custom Properties")]
    public double Number2Default {
      get { return _Number2Default; }
      set { _Number2Default = value; }
    }

    private bool _PersistUserEntries;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(true), WebDisplayName("Save User Entries"),
      WebDescription("Save last values entered"),
      Category("Litware Custom Properties")]
    public bool PersistUserEntries {
      get { return _PersistUserEntries; }
      set { _PersistUserEntries = value; }
    }

    #endregion

    // field to hold onto UserControl instance
    protected Hello3UserControlBase userControl;
    
    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      this.Controls.Clear();
      userControl = (Hello3UserControlBase)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello3.ascx");
      this.Controls.Add(userControl);      
      // pass back-pointer reference to user control base class
      userControl.SetWebPartReference(this, _PersistUserEntries);
    }

    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);
      // pass peristed property values to user control base class
      userControl.SetBackgroundColor(this.BackgroundColor.ToString());
      userControl.SetFontColor(this.FontColor.ToString());            
      userControl.SetControlValues(_Number1Default, _Number2Default);
    }

  }
}
