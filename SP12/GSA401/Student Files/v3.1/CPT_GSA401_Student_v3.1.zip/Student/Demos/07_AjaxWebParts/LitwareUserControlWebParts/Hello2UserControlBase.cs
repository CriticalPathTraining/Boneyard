using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace LitwareUserControlWebParts {

  public class Hello2UserControlBase : UserControl {

    // fields to sync with control tages in .ascx file
    protected HtmlTable tableMain;
    protected TextBox txtNumber1;
    protected TextBox txtNumber2;
    protected Button cmdAdd;
    protected Label lblSum;

    #region "Initialize User Control colors"

    public void SetBackgroundColor(string BackgroundColor) {
      tableMain.Style.Add(HtmlTextWriterStyle.BackgroundColor, BackgroundColor);
    }

    public void SetFontColor(string FontColor) {
      foreach (Control control in this.Controls) {
        SetControlFontColor(control, FontColor);
      }
    }

    private void SetControlFontColor(Control control, string FontColor) {
      if (control is WebControl) {
        ((WebControl)control).ForeColor = System.Drawing.Color.FromName(FontColor);
      }
      // use recursion to crawl down control tree
      foreach (Control innerControl in control.Controls) {
        SetControlFontColor(innerControl, FontColor);
      }
    }

    #endregion

    protected override void OnLoad(EventArgs e) {
      SetBackgroundColor("Yellow");
      SetFontColor("Blue");
      txtNumber1.Focus();
    }

    protected void cmdAdd_Click(object sender, EventArgs e) {
      double x1 = System.Convert.ToDouble(txtNumber1.Text);
      double x2 = System.Convert.ToDouble(txtNumber2.Text);
      double sum = x1 + x2;
      lblSum.Text = sum.ToString();
      txtNumber1.Focus();
    }
 
  }
}
