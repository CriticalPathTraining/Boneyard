﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LitwareUserControlWebParts
{
    public class Hello6UserControlBase : UserControl
    {
        protected DropDownList CategoryDropDownList;
        protected DropDownList SubCategoryDropDownList;
        protected GridView ProductsGridView;

        protected void CategoryDropDownList_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            SubCategoryDropDownList.DataSourceID = "SubCategoryDataSource";
        }

        protected void SubCategoryDropDownList_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            ProductsGridView.DataSourceID = "ProductDataSource";
        }
    }
}
