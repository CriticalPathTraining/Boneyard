﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using AjaxControlToolkit;

namespace LitwareUserControlWebParts
{
    public class Hello7: WebPart
    {
        // field to hold onto UserControl instance
        protected Hello7UserControlBase userControl;

        private void EnsureScriptManager()
        {
            if (ScriptManager.GetCurrent(this.Page) == null)
            {
                this.Page.Form.Controls.AddAt(0, new ScriptManager());
            }
        }

        protected override void OnInit(EventArgs e)
        {
            EnsureScriptManager();
            EnsureUpdatePanelFixups();
            base.OnInit(e);
        }

        private void EnsureUpdatePanelFixups()
        {
            if (this.Page.Form != null)
            {
                string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
                if (formOnSubmitAtt == "return _spFormOnSubmitWrapper();")
                {
                    this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
                }
            }
            ScriptManager.RegisterStartupScript(this, this.GetType(), "UpdatePanelFixup",
                "_spOriginalFormAction = document.forms[0].action; _spSuppressFormOnSubmitWrapper=true;", true);
        }

        // load .ascx file and create UserControl instance
        protected override void CreateChildControls()
        {
            UpdatePanel up = new UpdatePanel();
            up.ID = this.ID + "_AjaxUpdatePanel";
            up.ChildrenAsTriggers = true;
            up.UpdateMode = UpdatePanelUpdateMode.Conditional;
            this.Controls.Add(up);

            userControl = (Hello7UserControlBase)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello7.ascx");
            up.ContentTemplateContainer.Controls.Add(userControl);      

            // pass back-pointer reference to user control base class
            userControl.SetWebPartReference(this);
        }
    }
}
