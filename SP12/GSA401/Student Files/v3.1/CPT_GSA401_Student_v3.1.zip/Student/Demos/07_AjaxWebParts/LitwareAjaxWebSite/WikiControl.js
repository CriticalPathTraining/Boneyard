﻿/// <reference name="MicrosoftAjax.debug.js" />

// Defines the Micro Wiki Component tied to the WikiList
Litware.WikiControl = function(element,wikiID){
   Litware.WikiControl.initializeBase(this, [element]);
   this.wikiID = wikiID ;
   element.controlType='Litware.WikiControl';
   element.WikiControl = this;
}
Litware.WikiControl.prototype = {
   wikiID : null,
   makeEditable : function(){
      Litware.WikiControl.callBaseMethod(this, 'makeEditable');        
      if (this.editElement.contentEditable == 'false'){
         this.editElement.innerHTML = this.wikiToHtml(this.editElement.innerHTML);
         this.addWikiHandlers(this.editElement);
         // Save the wiki in the wiki service
         // Litware.WikiWebService.set_path(window.spWebUrl+'/_vti_bin/Litware/WikiWebService.asmx');
         Litware.WikiWebService.SetContent(this.wikiID, 
          this.editElement.innerHTML);
      }
      else // Convert to wiki syntax
         this.convertToWiki(this.editElement);
   },   
   initialize : function(){
      Litware.WikiControl.callBaseMethod(
         this, 'initialize',[ 'Loading...' ]);
      this.loadContent(this.wikiID);
   },
   loadContent : function(wikiID){
      this.wikiID = wikiID;
      // Litware.WikiWebService.set_path(window.spWebUrl+'/_vti_bin/Litware/WikiWebService.asmx');    
      Litware.WikiWebService.GetContent(wikiID, 
         Litware.WikiControl.OnGetContent, 
         Litware.WikiControl.OnGetFail, 
         this);
   },
   setContent : function(html){
      this.editElement.innerHTML = html;
      this.addWikiHandlers(this.editElement);
   },
   
   // Adds click handlers to the WIKILINK spans
   addWikiHandlers : function(element){
      var links = element.getElementsByTagName('span');
      for(var i=0;i<links.length;i++){
         if (links[i].className=='WIKILINK')         
            $addHandler(links[i],'click', Litware.wikiLink);            
      }
   }
}

Litware.wikiLink = function(evt){
   var wiki = SharePoint.Ajax.FindParentControl(evt.target,'Litware.WikiControl');
   var link;
   if (evt.target.innerText)
      link = evt.target.innerText;
   else if (evt.target.textContent)
      link = evt.target.textContent;
   if (wiki != null && link != null && link != '')
      wiki.WikiControl.loadContent(link);
}

Litware.WikiControl.OnGetContent = function(contentResponse, WikiControl){
    WikiControl.setContent(contentResponse);
}

Litware.WikiControl.OnGetFail = function(error){   
   alert(error.get_message() + '\n' + error.get_stackTrace());
}

Litware.WikiControl.registerClass('Litware.WikiControl', 
    Litware.EditableControl);
Litware.WikiControl.inheritsFrom(Litware.EditableControl);

// WebPart initialization script:
Litware.WikiControl.Init = function(){
   if( window.WikiControlTemplates ){
      for(var i=0;i<window.WikiControlTemplates.length;i++){
         var o =  window.WikiControlTemplates[i];
         if (o != null){                                            
            var wiki = new Litware.WikiControl( $get(o.Control), o.WikiID );
            wiki.initialize();
            o = null;  
         }
      }
      window.WikiControlTemplates = null;
   }
}
Sys.Application.add_load(Litware.WikiControl.Init);

