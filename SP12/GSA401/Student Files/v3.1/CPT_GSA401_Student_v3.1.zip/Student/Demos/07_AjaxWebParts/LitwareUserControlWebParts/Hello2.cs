using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts {
  public class Hello2 : WebPart {

    // field to hold onto UserControl instance
    protected UserControl userControl;
    
    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      this.Controls.Clear();
      userControl = (UserControl)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello2.ascx");
      this.Controls.Add(userControl);
    } 
  }
}
