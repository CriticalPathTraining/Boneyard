using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts {
  public class Hello5 : WebPart {

    #region "Custom Properties"

    public enum BackgroundColorEnum {
      White,
      Gray,
      Teal,
      Yellow
    }

    private BackgroundColorEnum _BackgroundColor;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public BackgroundColorEnum BackgroundColor {
      get { return _BackgroundColor; }
      set { _BackgroundColor = value; }
    }


    public enum FontColorEnum {
      Black,
      Red,
      Green,
      Blue
    }

    private FontColorEnum _FontColor = FontColorEnum.Blue;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public FontColorEnum FontColor {
      get { return _FontColor; }
      set { _FontColor = value; }
    }
	

    private double _Number1Default;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public double Number1Default {
      get { return _Number1Default; }
      set { _Number1Default = value; }
    }
    

    private double _Number2Default;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public double Number2Default {
      get { return _Number2Default; }
      set { _Number2Default = value; }
    }

    private bool _PersistUserEntries;
    [ Personalizable(PersonalizationScope.User),
      WebBrowsable(false)]
    public bool PersistUserEntries {
      get { return _PersistUserEntries; }
      set { _PersistUserEntries = value; }
    }

    #endregion

    // field to hold onto UserControl instance
    protected Hello5UserControlBase userControl;

    private void EnsureScriptManager() {
      if (ScriptManager.GetCurrent(this.Page) == null) {
        this.Controls.Add(new ScriptManager());
      }
    }

    private void EnsureUpdatePanelFixups() {
      if (this.Page.Form != null) {
        string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
        if (formOnSubmitAtt == "return _spFormOnSubmitWrapper();") {
          this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
        }
      }
      ScriptManager.RegisterStartupScript(this, this.GetType(), "UpdatePanelFixup", "_spOriginalFormAction = document.forms[0].action; _spSuppressFormOnSubmitWrapper=true;", true);
    }

    // load .ascx file and create UserControl instance
    protected override void CreateChildControls() {
      this.Controls.Clear();
      EnsureScriptManager();
      EnsureUpdatePanelFixups();

      UpdatePanel up = new UpdatePanel();
      up.ID = this.ID + "_AjaxUpdatePanel";
      up.ChildrenAsTriggers = true;
      up.UpdateMode = UpdatePanelUpdateMode.Conditional;
      this.Controls.Add(up);



      userControl = (Hello5UserControlBase)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello5.ascx");
      up.ContentTemplateContainer.Controls.Add(userControl);      
      // pass back-pointer reference to user control base class
      userControl.SetWebPartReference(this, _PersistUserEntries);
    }

    public override EditorPartCollection CreateEditorParts() {
      EditorPart part = new Hello5Editor();
      part.ID = this.ID + "_Editor";
      EditorPart[] parts = { part };
      return new EditorPartCollection(parts);
    }

    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);
      // pass peristed property values to user control base class
      userControl.SetBackgroundColor(this.BackgroundColor.ToString());
      userControl.SetFontColor(this.FontColor.ToString());            
      userControl.SetControlValues(_Number1Default, _Number2Default);
    }

  }
}
