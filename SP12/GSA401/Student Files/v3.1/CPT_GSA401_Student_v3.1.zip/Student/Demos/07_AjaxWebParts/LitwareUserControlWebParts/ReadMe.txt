﻿When doing this demo after slide 4, you can only demo the following webparts:
- Hello
- Hello1
- Hello2
- Hello3
- Hello4

This is because the web.config of the SharePoint Web Application is not yet upgraded for use with AJAX.

After slide 22, you can demo 
- Hello5 (which uses UpdatePanel)
- Hello6 (which uses SQLDataSource and UpdatePanel)
- Hello7 (which uses the AJAX Control Toolkit)

Hello6:
This demo uses the SQL Server 2008 Sample database AdventureWorks
Before starting the demo, make sure that the element <tagMapping> has been removed from the <pages> section in the web.config. 
This tagMapping element maps the SQLDataSource control of the System.Web.dll to the SQLDataSource control of the Microsoft.SharePoint.dll
1. The first steps shows the participant that you can use ASP.NET data controls without any code 
   (except from the SelectedIndexChanged event handlers) like DropDownList, GridView and SQLDataSource
2. In a second step you can use an UpdatePanel control to avoid blinking of the page because of the postbacks
   a. uncomment the code in the Hello6.CreateChildControls method to ensure the existance of a script 
      manager and the updatepanel fix ups.
   b. Add a Register directive to the Hello6.ascx
      <%@ Register Assembly="System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" 
      Namespace="System.Web.UI" TagPrefix="asp"  %>
   c. Put all controls in a UpdatePanel control.
 	  <asp:UpdatePanel ID="AwUpdatePanel" runat="server" ChildrenAsTriggers="true" UpdateMode="Conditional">
	 	 <ContentTemplate>
		 </ContentTemplate>
	  </asp:UpdatePanel>   

Hello7:
This demo uses the Calendar control extender of the AJAX Control Toolkit.
1. The AjaxControlToolkit.dll must be dropped in the Global Assembly Cache. You can find the dll in this directory:
   C:\AjaxControlToolkit-Framework3.5SP1-NoSource\SampleWebSite\Bin
2. An extra element must be added in the <Assemblies> element of the web.config
   <add assembly="AjaxControlToolkit, Version=3.0.20820.16598, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e"/>
3. Add an extra element within the <controls> element:
   <add namespace="AjaxControlToolkit" assembly="AjaxControlToolkit" tagPrefix="ajaxToolkit"/>
3. In this case you cannot create the ScriptManager from the CreateChildControls() method. It must be created
   In the OnInit event.
4. Add the Web Part to the Web Part page. Place the cursor in the textbox to make the Calender pop up.
   
