﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareUserControlWebParts
{
    public class Hello6 : WebPart
    {
        // field to hold onto UserControl instance
        protected Hello6UserControlBase userControl;

        private void EnsureScriptManager()
        {
            if (ScriptManager.GetCurrent(this.Page) == null)
            {
                this.Controls.Add(new ScriptManager());
            }
        }

        private void EnsureUpdatePanelFixups()
        {
            if (this.Page.Form != null)
            {
                string formOnSubmitAtt = this.Page.Form.Attributes["onsubmit"];
                if (formOnSubmitAtt == "return _spFormOnSubmitWrapper();")
                {
                    this.Page.Form.Attributes["onsubmit"] = "_spFormOnSubmitWrapper();";
                }
            }
            ScriptManager.RegisterStartupScript(this, this.GetType(), "UpdatePanelFixup", 
                "_spOriginalFormAction = document.forms[0].action; _spSuppressFormOnSubmitWrapper=true;", true);
        }

        // load .ascx file and create UserControl instance
        protected override void CreateChildControls()
        {
            this.Controls.Clear();
            //EnsureScriptManager();
            //EnsureUpdatePanelFixups();


            userControl = (Hello6UserControlBase)this.Page.LoadControl(@"/_controltemplates/LitwareUserControlWebParts/Hello6.ascx");
            this.Controls.Add(userControl);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
        }
    }
}
