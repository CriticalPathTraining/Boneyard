﻿Public Class MyFormRegion

#Region "Form Region Factory"

    <Microsoft.Office.Tools.Outlook.FormRegionMessageClass(Microsoft.Office.Tools.Outlook.FormRegionMessageClassAttribute.Contact)> _
    <Microsoft.Office.Tools.Outlook.FormRegionName("CustomRegionOutlookAddIn.MyFormRegion")> _
    Partial Public Class MyFormRegionFactory

    ' Occurs before the form region is initialized.
    ' To prevent the form region from appearing, set e.Cancel to true.
    ' Use e.OutlookItem to get a reference to the current Outlook item.
        Private Sub MyFormRegionFactory_FormRegionInitializing(ByVal sender As Object, ByVal e As Microsoft.Office.Tools.Outlook.FormRegionInitializingEventArgs) Handles Me.FormRegionInitializing

    End Sub

    End Class

#End Region

    Dim customerList As List(Of Customer)
    Dim selectedCustomer As Customer

    'Occurs before the form region is displayed. 
    'Use Me.OutlookItem to get a reference to the current Outlook item.
    'Use Me.OutlookFormRegion to get a reference to the form region.
    Private Sub MyFormRegion_FormRegionShowing(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.FormRegionShowing
        PopulateCustomers()
        CustomerComboBox.DataSource = customerList
    End Sub

    'Occurs when the form region is closed.   
    'Use Me.OutlookItem to get a reference to the current Outlook item.
    'Use Me.OutlookFormRegion to get a reference to the form region.
    Private Sub MyFormRegion_FormRegionClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.FormRegionClosed

    End Sub

    Private Sub CustomerComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerComboBox.SelectedIndexChanged
        selectedCustomer = customerList(CustomerComboBox.SelectedIndex)
        NameTextBox.Text = selectedCustomer.Name
        AddressTextBox.Text = selectedCustomer.Address
        ZipTextBox.Text = selectedCustomer.Zip
        CityTextBox.Text = selectedCustomer.City
        CountryTextBox.Text = selectedCustomer.Country
    End Sub

    Private Sub PopulateCustomers()
        customerList = New List(Of Customer)
        customerList.Add(New Customer("ALFKI", "Alfreds Futterkiste", "Obere Str. 57", "12209", "Berlin", "Germany"))
        customerList.Add(New Customer("GOURL", "Gourmet Lanchonetes", "Av. Brasil, 442", "04876-786", "Campinas", "Brazil"))
        customerList.Add(New Customer("OLDWO", "Old World Delicatessen", "2743 Bering St.", "99508", "Anchorage", "USA"))
        customerList.Add(New Customer("THECR", "The Cracker Box", "55 Grizzly Peak Rd.", "59801", "Butte", "USA"))
        customerList.Add(New Customer("WOLZA", "Wolski  Zajazd", "ul. Filtrowa 68", "01-012", "Warszawa", "Poland"))
    End Sub

    Private Sub SelectButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectButton.Click
        'Dim x As Outlook.ContactItem = New Outlook.ContactItem()
        Dim currentItem As Outlook.ContactItem = CType(Me.OutlookItem, Outlook.ContactItem)
        currentItem.CompanyName = selectedCustomer.Name
    End Sub
End Class
