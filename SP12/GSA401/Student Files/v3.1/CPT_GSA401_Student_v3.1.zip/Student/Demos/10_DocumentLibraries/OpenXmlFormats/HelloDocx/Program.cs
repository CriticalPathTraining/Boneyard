using System;
using System.IO;
using System.IO.Packaging;
using System.Xml;

namespace HelloDocx
{
    class Program
    {
        private const string NS_VML = "urn:schemas-microsoft-com:vml";
        private const string NS_WORDML = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private const string NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

        static void Main()
        {
            Package package = Package.Open(@"c:\Data\minimal.docx",
                              FileMode.Create,
                              FileAccess.ReadWrite);

            // create main document part (document.xml) ...
            Uri uri = new Uri("/word/document.xml", UriKind.Relative);
            string partContentType;
            partContentType = "application/vnd.openxmlformats" +
                              "-officedocument.wordprocessingml.document.main+xml";
            PackagePart part = package.CreatePart(uri, partContentType);

            // get stream for document.xml
            StreamWriter streamPart;
            streamPart = new StreamWriter(part.GetStream(FileMode.Create,
                                                         FileAccess.Write));


            // create the start part, set up the nested structure ...
            XmlWriter writer = XmlWriter.Create(streamPart);
            writer.WriteStartDocument();
            writer.WriteStartElement("w", "document", NS_WORDML);
            writer.WriteStartElement("body", NS_WORDML);
            writer.WriteStartElement("p", NS_WORDML);
            writer.WriteStartElement("r", NS_WORDML);
            writer.WriteStartElement("t", NS_WORDML);

            writer.WriteValue("My First DOCX File");

            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndDocument();

            writer.Close();

            streamPart.Close();
            package.Flush();

            // show the document XML
            XmlDocument doc = new XmlDocument();
            doc.Load(part.GetStream());
            Console.WriteLine("The document in xml:");
            Console.WriteLine(doc.OuterXml);

            // create the relationship part
            string relationshipType;
            relationshipType = NS_REL + "/officeDocument";
            package.CreateRelationship(uri, TargetMode.Internal, relationshipType, "rId1");
            package.Flush();

            // close package
            package.Close();

            Console.ReadLine();
        }
    }
}
