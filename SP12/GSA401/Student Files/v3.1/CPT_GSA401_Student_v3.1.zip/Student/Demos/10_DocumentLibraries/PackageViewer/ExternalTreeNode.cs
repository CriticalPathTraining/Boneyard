using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace PackageViewer {
  class ExternalTreeNode : UriTreeNode {
    #region Private Fields
    public string m_relationshipType;
    public string m_relationshipId;
    #endregion

    #region Constructor
    public ExternalTreeNode(Uri partUri, string relationshipType, string relationshipId)
      : base(partUri) {
      m_relationshipType = relationshipType;
      m_relationshipId = relationshipId;

      base.Text = Path.GetFileName(partUri.ToString());
      base.ImageIndex = 2;
      base.SelectedImageIndex = 2;
    }
    #endregion

    #region Public Properties
    public string RelationshipType {
      get { return m_relationshipType; }
    }

    public string RelationshipId {
      get { return m_relationshipId; }
    }
    #endregion
  }
}
