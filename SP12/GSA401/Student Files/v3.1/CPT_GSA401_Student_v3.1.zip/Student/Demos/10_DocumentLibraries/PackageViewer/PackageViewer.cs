using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Packaging;

namespace PackageViewer {
  public partial class PackageViewer : Form {
    #region Private Fields
    private string m_fileName;
    #endregion

    #region Constructor
    public PackageViewer() {
      InitializeComponent();
    }
    #endregion

    #region Form Event Handlers
    private void openToolStripMenuItem_Click(object sender, EventArgs e) {
      // get the fileName
      if (OpenFileDialog.ShowDialog() == DialogResult.OK) {
        // store the file name
        m_fileName = OpenFileDialog.FileName;

        // create the package node
        TreeNode node = CreatePackageNode(m_fileName);

        // clear the node list and add the new one
        PackageView.Nodes.Clear();
        PackageView.Nodes.Add(node);

        // create the items under the root node, then expand it
        BuildRelationships(node);
        node.Expand();
      }
    }

    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      this.Close();
    }

    private void PackageView_BeforeExpand(object sender, TreeViewCancelEventArgs e) {
      foreach (TreeNode node in e.Node.Nodes)
        if (node is PackagePartTreeNode)
          BuildRelationships(node);
    }

    private void PackageView_AfterSelect(object sender, TreeViewEventArgs e) {
      if (e.Node is PackagePartTreeNode)
        SelectPackagePartNode(e.Node.Parent as UriTreeNode,
            e.Node as PackagePartTreeNode);
      else if (e.Node is PackageTreeNode)
        SelectPackageNode(e.Node as PackageTreeNode);
      else if (e.Node is ExternalTreeNode)
        SelectExternalNode(e.Node.Parent as UriTreeNode,
            e.Node as ExternalTreeNode);
    }
    #endregion

    #region Relationship Building Methods
    private void BuildRelationships(TreeNode expandedNode) {
      // open the package
      using (Package package = Package.Open(m_fileName)) {
        // get the relationships for the node                
        PackageRelationshipCollection relationships = GetRelationshipsForNode(package, expandedNode);

        // add a node for each relationshipType
        SortedList<string, TreeNode> nodes = new SortedList<string, TreeNode>();
        foreach (PackageRelationship relationship in relationships) {
          TreeNode node = null;
          if (relationship.TargetMode == TargetMode.External)
            node = CreateExternalNode(relationship);
          else
            node = CreatePackagePartNode(package, relationship);

          // add the node to the sorted list
            if (!nodes.ContainsKey(node.Text))
                  nodes.Add(node.Text, node);
        }

        // add the nodes to the parent node
        foreach (KeyValuePair<string, TreeNode> node in nodes)
          expandedNode.Nodes.Add(node.Value);
      }
    }

    private PackageRelationshipCollection GetRelationshipsForNode(Package package, TreeNode treeNode) {
      // check if the node is a package part node
      if (treeNode is PackagePartTreeNode) {
        PackagePartTreeNode packagePartNode = treeNode as PackagePartTreeNode;
        return package.GetPart(packagePartNode.PartUri).GetRelationships();
      }
      else {
        return package.GetRelationships();
      }
    }
    #endregion

    #region Package Node Creation Methods
    public TreeNode CreatePackageNode(string fileName) {
      // create the package node
      return new PackageTreeNode(fileName);
    }

    public TreeNode CreatePackagePartNode(Package package, PackageRelationship relationship) {
      // get the package part
      Uri partUri = PackUriHelper.ResolvePartUri(
          relationship.SourceUri, relationship.TargetUri);
      PackagePart part = package.GetPart(partUri);

      // create the tree node for the package part
      return new PackagePartTreeNode(
          relationship.TargetUri,
          partUri,
          part.ContentType,
          relationship.RelationshipType,
          relationship.Id);
    }

    public TreeNode CreateExternalNode(PackageRelationship relationship) {
      // create the external tree node
      return new ExternalTreeNode(
          relationship.TargetUri,
          relationship.RelationshipType,
          relationship.Id);
    }
    #endregion

    #region Package Node Selection Methods
    private void SelectPackageNode(PackageTreeNode node) {
      // setup the package information 
      this.CurrentNodeText.Text = node.PartUri.ToString();
      this.NodeTypeText.Text = "Package";
      this.ContentTypeText.Text = string.Empty;
      this.ParentText.Text = string.Empty;
      this.RelationshipTypeText.Text = string.Empty;
      this.RelationshipIdText.Text = string.Empty;

      // hide the part preview
      DisplayPackage();
    }

    private void SelectPackagePartNode(UriTreeNode parentNode, PackagePartTreeNode node) {
      // setup the package part information
      this.CurrentNodeText.Text = node.PartUri.ToString();
      this.NodeTypeText.Text = "Part";
      this.ContentTypeText.Text = node.ContentType;
      this.ParentText.Text = parentNode.PartUri.ToString();
      this.RelationshipTypeText.Text = node.RelationshipType;
      this.RelationshipIdText.Text = node.RelationshipId;

      // load the package part data
      DisplayPackagePart(node.PartUri);
    }

    private void SelectExternalNode(UriTreeNode parentNode, ExternalTreeNode node) {
      // setup the external resource information
      this.CurrentNodeText.Text = node.PartUri.ToString();
      this.NodeTypeText.Text = "External File";
      this.ContentTypeText.Text = string.Empty;
      this.ParentText.Text = parentNode.PartUri.ToString();
      this.RelationshipTypeText.Text = node.RelationshipType;
      this.RelationshipIdText.Text = node.RelationshipId;

      // hide the part preview
      DisplayExternal();
    }
    #endregion

    #region Browser Display Methods
    private void DisplayPackagePart(Uri partUri) {
      // get the temp filename
      string fileName = Path.ChangeExtension(Path.GetTempFileName(),
          Path.GetExtension(partUri.OriginalString));
      using (FileStream stream = File.Create(fileName)) {
        // open the package
        using (Package package = Package.Open(m_fileName)) {
          // copy the data from the package part to the file
          PackagePart part = package.GetPart(partUri);
          using (BufferedStream partStream = new BufferedStream(part.GetStream())) {
            int data = partStream.ReadByte();
            while (data != -1) {
              stream.WriteByte((byte)data);
              data = partStream.ReadByte();
            }
          }
        }
      }

      // setup the browser window
      PackagePartPreview.Visible = true;
      PackagePartPreview.Navigate("file://" + fileName);
    }

    private void DisplayPackage() {
      // hide the browser window
      PackagePartPreview.Visible = false;
    }

    private void DisplayExternal() {
      // hide the browser window
      PackagePartPreview.Visible = false;
    }


    private void PackagePartPreview_Navigated(object sender, WebBrowserNavigatedEventArgs e) {
      File.Delete(e.Url.LocalPath);
    }
    #endregion
  }
}