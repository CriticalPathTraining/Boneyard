Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.IO
Imports System.IO.Packaging
Imports System.Text
Imports System.Xml

Partial Class HelloWorld
  Inherits System.Web.UI.Page

  Protected Sub WriteContentToPackage(ByVal pack As Package)

    '*** create main document part (document.xml) ...
    Dim uri As Uri = New Uri("/word/document.xml", UriKind.Relative)
    Dim partContentType As String
    partContentType = "application/vnd.openxmlformats" & _
                      "-officedocument.wordprocessingml.document.main+xml"
    Dim part As PackagePart = pack.CreatePart(uri, partContentType)

    '*** get stream for document.xml
    Dim streamPart As New StreamWriter(part.GetStream(FileMode.Create, _
                                                      FileAccess.Write))


    '*** define string variable for Open XML namespace for nsWP:
    Dim nsWP As String = "http://schemas.openxmlformats.org" & _
                         "/wordprocessingml/2006/3/main"

    '***  create the start part, set up the nested structure ...
    Dim xmlPart As XmlDocument = New XmlDocument()
    Dim tagDocument As XmlElement
    tagDocument = xmlPart.CreateElement("w:document", nsWP)
    xmlPart.AppendChild(tagDocument)
    Dim tagBody As XmlElement
    tagBody = xmlPart.CreateElement("w:body", nsWP)
    tagDocument.AppendChild(tagBody)
    Dim tagParagraph As XmlElement
    tagParagraph = xmlPart.CreateElement("w:p", nsWP)
    tagBody.AppendChild(tagParagraph)
    Dim tagRun As XmlElement
    tagRun = xmlPart.CreateElement("w:r", nsWP)
    tagParagraph.AppendChild(tagRun)
    Dim tagText As XmlElement
    tagText = xmlPart.CreateElement("w:t", nsWP)
    tagRun.AppendChild(tagText)
    '*** insert text into part as a Text node 
    Dim nodeText As XmlNode
    nodeText = xmlPart.CreateNode(XmlNodeType.Text, "w:t", nsWP)
    nodeText.Value = Me.TextBox1.Text
    tagText.AppendChild(nodeText)
    '*** save XML to part and close stream
    xmlPart.Save(streamPart)

    streamPart.Close()
    pack.Flush()

    '*** create the relationship part
    Dim relationshipType As String
    relationshipType = "http://schemas.openxmlformats.org" & _
                        "/officeDocument/2006/relationships/officeDocument"
    pack.CreateRelationship(uri, TargetMode.Internal, relationshipType, "rId1")
    pack.Flush()


  End Sub

  Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

    '*** create in-memory stream as buffer
    Dim bufferStream As MemoryStream = New MemoryStream()
    '*** create new package in memory stream
    Dim pack As Package = Package.Open(bufferStream, _
                                       FileMode.Create, _
                                       FileAccess.ReadWrite)

    '*** this calls same code shown in Hello World example
    WriteContentToPackage(pack)

    '*** save/close package object leaving DOCX file in MemoryStream
    pack.Close()

    Response.ClearHeaders()
        Response.AddHeader("content-disposition", _
                           "attachment; filename=BobYourUnkle.docx")

    Response.ClearContent()
    Response.ContentEncoding = System.Text.Encoding.UTF8
    Response.ContentType = "application/vnd.ms-word.document.12"
    '*** write package to response stream
    bufferStream.Position = 0
    Dim writer As New BinaryWriter(Response.OutputStream)
    Dim reader As New BinaryReader(bufferStream)
    writer.Write(reader.ReadBytes(bufferStream.Length))
    reader.Close()
    writer.Close()
    bufferStream.Close()

    '*** flush and close the response object
    Response.Flush()
    Response.Close()

  End Sub
End Class
