namespace PackageViewer
{
    partial class PackageViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label HeaderLabel;
            System.Windows.Forms.Label CurrentNodeLabel;
            System.Windows.Forms.Label NodeTypeLabel;
            System.Windows.Forms.Label ContentTypeLabel;
            System.Windows.Forms.Label ParentLabel;
            System.Windows.Forms.Label RelationshipTypeLabel;
            System.Windows.Forms.Label RelationshipIdLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PackageViewer));
            this.ContentTypeText = new System.Windows.Forms.TextBox();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.PackageView = new System.Windows.Forms.TreeView();
            this.ImageList = new System.Windows.Forms.ImageList(this.components);
            this.RelationshipIdText = new System.Windows.Forms.TextBox();
            this.PackagePartPreview = new System.Windows.Forms.WebBrowser();
            this.RelationshipTypeText = new System.Windows.Forms.TextBox();
            this.CurrentNodeText = new System.Windows.Forms.TextBox();
            this.ParentText = new System.Windows.Forms.TextBox();
            this.NodeTypeText = new System.Windows.Forms.TextBox();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            HeaderLabel = new System.Windows.Forms.Label();
            CurrentNodeLabel = new System.Windows.Forms.Label();
            NodeTypeLabel = new System.Windows.Forms.Label();
            ContentTypeLabel = new System.Windows.Forms.Label();
            ParentLabel = new System.Windows.Forms.Label();
            RelationshipTypeLabel = new System.Windows.Forms.Label();
            RelationshipIdLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.MainMenu.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // HeaderLabel
            // 
            HeaderLabel.AutoSize = true;
            HeaderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            HeaderLabel.Location = new System.Drawing.Point(2, 9);
            HeaderLabel.Name = "HeaderLabel";
            HeaderLabel.Size = new System.Drawing.Size(245, 24);
            HeaderLabel.TabIndex = 0;
            HeaderLabel.Text = "Current Node Information";
            // 
            // CurrentNodeLabel
            // 
            CurrentNodeLabel.AutoSize = true;
            CurrentNodeLabel.Location = new System.Drawing.Point(3, 39);
            CurrentNodeLabel.Name = "CurrentNodeLabel";
            CurrentNodeLabel.Size = new System.Drawing.Size(73, 13);
            CurrentNodeLabel.TabIndex = 7;
            CurrentNodeLabel.Text = "Current Node:";
            CurrentNodeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // NodeTypeLabel
            // 
            NodeTypeLabel.AutoSize = true;
            NodeTypeLabel.Location = new System.Drawing.Point(3, 58);
            NodeTypeLabel.Name = "NodeTypeLabel";
            NodeTypeLabel.Size = new System.Drawing.Size(63, 13);
            NodeTypeLabel.TabIndex = 8;
            NodeTypeLabel.Text = "Node Type:";
            NodeTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ContentTypeLabel
            // 
            ContentTypeLabel.AutoSize = true;
            ContentTypeLabel.Location = new System.Drawing.Point(3, 77);
            ContentTypeLabel.Name = "ContentTypeLabel";
            ContentTypeLabel.Size = new System.Drawing.Size(74, 13);
            ContentTypeLabel.TabIndex = 9;
            ContentTypeLabel.Text = "Content Type:";
            ContentTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ParentLabel
            // 
            ParentLabel.AutoSize = true;
            ParentLabel.Location = new System.Drawing.Point(3, 96);
            ParentLabel.Name = "ParentLabel";
            ParentLabel.Size = new System.Drawing.Size(41, 13);
            ParentLabel.TabIndex = 10;
            ParentLabel.Text = "Parent:";
            ParentLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RelationshipTypeLabel
            // 
            RelationshipTypeLabel.AutoSize = true;
            RelationshipTypeLabel.Location = new System.Drawing.Point(3, 115);
            RelationshipTypeLabel.Name = "RelationshipTypeLabel";
            RelationshipTypeLabel.Size = new System.Drawing.Size(95, 13);
            RelationshipTypeLabel.TabIndex = 11;
            RelationshipTypeLabel.Text = "Relationship Type:";
            RelationshipTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // RelationshipIdLabel
            // 
            RelationshipIdLabel.AutoSize = true;
            RelationshipIdLabel.Location = new System.Drawing.Point(3, 134);
            RelationshipIdLabel.Name = "RelationshipIdLabel";
            RelationshipIdLabel.Size = new System.Drawing.Size(80, 13);
            RelationshipIdLabel.TabIndex = 12;
            RelationshipIdLabel.Text = "Relationship Id:";
            RelationshipIdLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = System.Windows.Forms.DockStyle.Fill;
            label1.Location = new System.Drawing.Point(3, 100);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(119, 20);
            label1.TabIndex = 12;
            label1.Text = "RelationshipType Id:";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = System.Windows.Forms.DockStyle.Fill;
            label2.Location = new System.Drawing.Point(3, 80);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(119, 20);
            label2.TabIndex = 11;
            label2.Text = "RelationshipType Type:";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = System.Windows.Forms.DockStyle.Fill;
            label3.Location = new System.Drawing.Point(3, 78);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(119, 26);
            label3.TabIndex = 10;
            label3.Text = "Parent:";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ContentTypeText
            // 
            this.ContentTypeText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ContentTypeText.Location = new System.Drawing.Point(104, 74);
            this.ContentTypeText.Name = "ContentTypeText";
            this.ContentTypeText.Size = new System.Drawing.Size(432, 20);
            this.ContentTypeText.TabIndex = 3;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 24);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.PackageView);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(CurrentNodeLabel);
            this.splitContainer.Panel2.Controls.Add(NodeTypeLabel);
            this.splitContainer.Panel2.Controls.Add(ContentTypeLabel);
            this.splitContainer.Panel2.Controls.Add(ParentLabel);
            this.splitContainer.Panel2.Controls.Add(RelationshipTypeLabel);
            this.splitContainer.Panel2.Controls.Add(RelationshipIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.RelationshipIdText);
            this.splitContainer.Panel2.Controls.Add(this.PackagePartPreview);
            this.splitContainer.Panel2.Controls.Add(HeaderLabel);
            this.splitContainer.Panel2.Controls.Add(this.RelationshipTypeText);
            this.splitContainer.Panel2.Controls.Add(this.CurrentNodeText);
            this.splitContainer.Panel2.Controls.Add(this.ParentText);
            this.splitContainer.Panel2.Controls.Add(this.NodeTypeText);
            this.splitContainer.Panel2.Controls.Add(this.ContentTypeText);
            this.splitContainer.Size = new System.Drawing.Size(794, 420);
            this.splitContainer.SplitterDistance = 251;
            this.splitContainer.TabIndex = 0;
            // 
            // PackageView
            // 
            this.PackageView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PackageView.ImageIndex = 0;
            this.PackageView.ImageList = this.ImageList;
            this.PackageView.Location = new System.Drawing.Point(0, 0);
            this.PackageView.Name = "PackageView";
            this.PackageView.SelectedImageIndex = 0;
            this.PackageView.Size = new System.Drawing.Size(251, 420);
            this.PackageView.TabIndex = 0;
            this.PackageView.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.PackageView_BeforeExpand);
            this.PackageView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.PackageView_AfterSelect);
            // 
            // ImageList
            // 
            this.ImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList.ImageStream")));
            this.ImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList.Images.SetKeyName(0, "ICZIP.GIF");
            this.ImageList.Images.SetKeyName(1, "icc16.gif");
            this.ImageList.Images.SetKeyName(2, "DOCLINK.GIF");
            // 
            // RelationshipIdText
            // 
            this.RelationshipIdText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.RelationshipIdText.Location = new System.Drawing.Point(104, 131);
            this.RelationshipIdText.Name = "RelationshipIdText";
            this.RelationshipIdText.Size = new System.Drawing.Size(432, 20);
            this.RelationshipIdText.TabIndex = 7;
            // 
            // PackagePartPreview
            // 
            this.PackagePartPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.PackagePartPreview.Location = new System.Drawing.Point(2, 157);
            this.PackagePartPreview.MinimumSize = new System.Drawing.Size(20, 20);
            this.PackagePartPreview.Name = "PackagePartPreview";
            this.PackagePartPreview.Size = new System.Drawing.Size(534, 260);
            this.PackagePartPreview.TabIndex = 2;
            this.PackagePartPreview.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.PackagePartPreview_Navigated);
            // 
            // RelationshipTypeText
            // 
            this.RelationshipTypeText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.RelationshipTypeText.Location = new System.Drawing.Point(104, 112);
            this.RelationshipTypeText.Name = "RelationshipTypeText";
            this.RelationshipTypeText.Size = new System.Drawing.Size(432, 20);
            this.RelationshipTypeText.TabIndex = 5;
            // 
            // CurrentNodeText
            // 
            this.CurrentNodeText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.CurrentNodeText.Location = new System.Drawing.Point(104, 36);
            this.CurrentNodeText.Name = "CurrentNodeText";
            this.CurrentNodeText.Size = new System.Drawing.Size(432, 20);
            this.CurrentNodeText.TabIndex = 2;
            // 
            // ParentText
            // 
            this.ParentText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ParentText.Location = new System.Drawing.Point(104, 93);
            this.ParentText.Name = "ParentText";
            this.ParentText.Size = new System.Drawing.Size(432, 20);
            this.ParentText.TabIndex = 4;
            // 
            // NodeTypeText
            // 
            this.NodeTypeText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.NodeTypeText.Location = new System.Drawing.Point(104, 55);
            this.NodeTypeText.Name = "NodeTypeText";
            this.NodeTypeText.Size = new System.Drawing.Size(432, 20);
            this.NodeTypeText.TabIndex = 1;
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.Filter = "Word Documents|*.docx|Excel Workbooks|*.xlsx|PowerPoint Slide Deck|*.pptx";
            // 
            // MainMenu
            // 
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(794, 24);
            this.MainMenu.TabIndex = 1;
            this.MainMenu.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.openToolStripMenuItem.Text = "&Open...";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(120, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(label1, 0, 5);
            this.tableLayoutPanel2.Controls.Add(label2, 0, 4);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // PackageViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 444);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.MainMenu);
            this.Name = "PackageViewer";
            this.Text = "Package Viewer - Office Open XML File Formats Demo";
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            this.splitContainer.ResumeLayout(false);
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TreeView PackageView;
        private System.Windows.Forms.TextBox CurrentNodeText;
        private System.Windows.Forms.TextBox NodeTypeText;
        private System.Windows.Forms.TextBox ParentText;
        private System.Windows.Forms.TextBox RelationshipTypeText;
        private System.Windows.Forms.WebBrowser PackagePartPreview;
        private System.Windows.Forms.ImageList ImageList;
        private System.Windows.Forms.TextBox ContentTypeText;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox RelationshipIdText;
    }
}

