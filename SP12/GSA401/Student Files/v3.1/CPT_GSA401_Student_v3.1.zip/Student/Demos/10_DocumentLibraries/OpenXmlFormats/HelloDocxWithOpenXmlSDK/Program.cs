﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using System.IO;
using System.Xml;

namespace HelloDocxWithOpenXmlSDK
{
    class Program
    {
        private const string NS_VML = "urn:schemas-microsoft-com:vml";
        private const string NS_WORDML = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        private const string NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

        static void Main(string[] args)
        {
            // Create the word document
            using (WordprocessingDocument wordDoc =
                WordprocessingDocument.Create(@"c:\Data\a less minimal.docx", 
                WordprocessingDocumentType.Document))
            {
                // Set the content of the document so that Word can open it.
                MainDocumentPart mainPart = wordDoc.AddMainDocumentPart();
                SetMainDocumentContent(mainPart);

                // Add a picture to the document
                ImagePart imagePart = wordDoc.MainDocumentPart.AddImagePart(ImagePartType.Jpeg, "rId1");
                SetPictureContent(imagePart);

                // Following code modifies the main document part and is necessary, 
                // otherwise the picture will not show up
                mainPart = wordDoc.MainDocumentPart;
                ModifyMainPart(mainPart);
            }
        }

        // Set the content of MainDocumentPart.
        public static void SetMainDocumentContent(MainDocumentPart part)
        {            
            const string docXml = @"<?xml version=""1.0"" encoding=""UTF-8"" standalone=""yes""?>" 
                + @"<w:document xmlns:w=""http://schemas.openxmlformats.org/wordprocessingml/2006/main"">"
                + "<w:body><w:p><w:r><w:t>Hello OpenXML!</w:t></w:r></w:p></w:body>"
                + "</w:document>";

            using (Stream stream = part.GetStream())
            {
                byte[] buf = (new UTF8Encoding()).GetBytes(docXml);
                stream.Write(buf, 0, buf.Length);
                stream.Flush();
            }
        }

        public static void SetPictureContent(ImagePart part)
        {
            using (FileStream stream = new FileStream(@"..\..\Images\OpenXml.jpg", FileMode.Open))
            {
                part.FeedData(stream);
            }
        }

        protected static void ModifyMainPart(MainDocumentPart part)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(part.GetStream());

            Console.WriteLine("The original xml:");
            Console.WriteLine(doc.OuterXml);

            XmlElement pEl = doc.CreateElement("w:p", NS_WORDML);
            doc.DocumentElement.FirstChild.AppendChild(pEl);
            XmlElement rEl = doc.CreateElement("w:r", NS_WORDML);
            pEl.AppendChild(rEl);
            XmlElement picEl = doc.CreateElement("w:pict", NS_WORDML);
            rEl.AppendChild(picEl);
            XmlElement shapeEl = doc.CreateElement("v:shape", NS_VML);
            picEl.AppendChild(shapeEl);
            XmlElement imageDataEl = doc.CreateElement("v:imageData", NS_VML);
            shapeEl.AppendChild(imageDataEl);
            XmlAttribute idAtt = doc.CreateAttribute("r:id", NS_REL);
            idAtt.Value = "rId1";
            imageDataEl.Attributes.Append(idAtt);

            Console.WriteLine();
            Console.WriteLine("The modified xml:");
            Console.WriteLine(doc.OuterXml);

            StreamWriter partWrt = new StreamWriter(part.GetStream(FileMode.Create, FileAccess.Write));
            doc.Save(partWrt);
            partWrt.Close();

            Console.ReadLine();
        }
    }
}
