Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls

Public Class DocumentInfo
    Inherits LayoutsPageBase

' add control fields to match controls tags on .aspx page
    Protected grdSiteProperties As SPGridView

    Protected Overrides Sub OnLoad(ByVal e As EventArgs)

        ' get current site and web
        Dim siteCollection As SPSite = Me.Site
        Dim site As SPWeb = Me.Web

        ' program against controls on .aspx page
        Dim binder As PropertyCollectionBinder = New PropertyCollectionBinder()

        ' remove the next line and begin your work here

        ' get list information
        Dim ListId As String = Request.QueryString("ListId")
        binder.AddProperty("List ID", ListId)
        Dim list As SPList = site.Lists(New Guid(ListId))
        binder.AddProperty("List Title", list.Title)
        binder.AddProperty("List Root Folder", list.RootFolder.Url)

        ' get list item information
        Dim ItemId As String = Request.QueryString("ItemId")
        binder.AddProperty("Item ID", ItemId)
        Dim item As SPListItem = list.Items.GetItemById(Convert.ToInt32(ItemId))
        binder.AddProperty("Item Name", item.Name)
        binder.AddProperty("Item URL", item.Url)

        ' provided the list is a Document Library, get the fine info for the list item
        If TypeOf list Is SPDocumentLibrary Then
            Dim documentLibrary As SPDocumentLibrary = CType(list, SPDocumentLibrary)
            binder.AddProperty("Document Template Url", documentLibrary.DocumentTemplateUrl)
            Dim file As SPFile = site.GetFile(item.Url)
            binder.AddProperty("Document Author", file.Author.Name)
            binder.AddProperty("Document Size", file.TotalLength.ToString("0,###") + " bits")
            binder.AddProperty("Last Modified", "By " + file.ModifiedBy.Name + " on " + file.TimeLastModified.ToLocalTime().ToString())
            binder.AddProperty("File Checkout Status", file.CheckOutStatus.ToString())
        End If

        binder.BindGrid(grdSiteProperties)


    End Sub
End Class

