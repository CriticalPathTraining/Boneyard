using System.Web.UI;
using System.Web.UI.WebControls.WebParts;

namespace LitwareWebParts {
  public class RssViewWebPart1 : WebPart {
    protected override void CreateChildControls() {
      base.CreateChildControls();
      Controls.Add(new LiteralControl("Hello, World"));
    }
  }
}
