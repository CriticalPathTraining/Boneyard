using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace LitwareWebParts {

  public interface ICustomerProvider {
    string CustomerID { get; }
  }

  public class SimpleProviderExample : WebPart, ICustomerProvider {
    private string customerID = "P1284";

    protected override void RenderContents(HtmlTextWriter writer) {
      writer.Write("Customer ID: " + this.CustomerID);
    }

    public string CustomerID {
      get { return this.customerID; }
    }

    [ConnectionProvider("Customer ID", AllowsMultipleConnections = true)]
    public ICustomerProvider GetCustomerProvider() {
      return this;
    }
  }

  public class SimpleConsumerExample : WebPart {
    private ICustomerProvider customerProvider;

    [ConnectionConsumer("Customer ID")]
    public void RegisterCustomerProvider(ICustomerProvider provider) {
      this.customerProvider = provider;
    }

    protected override void RenderContents(HtmlTextWriter writer) {
      if (this.customerProvider != null)
        writer.Write(this.customerProvider.CustomerID);
      else
        writer.Write("No connection");
    }
  }

}