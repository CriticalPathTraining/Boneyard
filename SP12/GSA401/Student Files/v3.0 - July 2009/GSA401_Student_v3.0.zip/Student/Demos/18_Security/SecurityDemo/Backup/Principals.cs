using System;
using System.Security;
using System.Security.Principal;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;


namespace SecurityDemo {
  public class Principals : LayoutsPageBase {

    protected SPGridView grdUsers;
    protected SPGridView grdSiteUsers;
    protected SPGridView grdAllUsers;
    protected SPGridView grdWssGroups;
    protected SPGridView grdWssSiteGroups;
    protected SPGridView grdWssGroups2;

    protected override void OnLoad(EventArgs e) {

      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;

      SPUserCollection users = site.Users;
      DisplayUserCollection(users, grdUsers, "SPWeb.Users");

      SPUserCollection allUsers = site.AllUsers;
      DisplayUserCollection(allUsers, grdAllUsers, "SPWeb.AllUsers");

      SPUserCollection siteUsers = site.SiteUsers;
      DisplayUserCollection(siteUsers, grdSiteUsers, "SPWeb.SiteUsers");
      
      SPGroupCollection groups = site.Groups;
      DisplayGroupCollection(groups, grdWssGroups, "SPWeb.Groups");

      SPGroupCollection siteGroups = site.SiteGroups;
      DisplayGroupCollection(siteGroups, grdWssSiteGroups, "SPWeb.SiteGroups");

    }

    void DisplayUserCollection(SPUserCollection users, SPGridView grid, string Name) {
      ListCollectionBinder lcbUsers = new ListCollectionBinder(Name);
      foreach (SPUser user in users) {
        lcbUsers.AddValue(user.Name + " [" + user.ID.ToString() + "]");
      }
      lcbUsers.BindGrid(grid);
    }

    
    void DisplayGroupCollection(SPGroupCollection groups, SPGridView grid, string Name) {
      ListCollectionBinder lcbWssGroups = new ListCollectionBinder(Name);
      foreach (SPGroup Group in groups) {
        lcbWssGroups.AddValue(Group.Name + " [" + Group.ID.ToString() + "]");
      }
      lcbWssGroups.BindGrid(grid);
    }
  }
}
