using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Web.UI.WebControls;

namespace SecurityDemo {

  public class SiteActionsCustomSubMenu : WebControl {    

    protected override void OnLoad(EventArgs e) {
      this.EnsureChildControls();
      base.OnLoad(e);
    }

    protected override void CreateChildControls() {

      SPWeb site = SPContext.Current.Web;

      string sitePath = site.Url;
      if (!sitePath.EndsWith(@"/"))
        sitePath += "/";

      SubMenuTemplate smt = new SubMenuTemplate();
      smt.Text = "Security Demo";
      smt.ID = "CustomSubMenu";
      smt.Description = "SharePoint Security Programming";
      smt.Sequence = 400;      

      MenuItemTemplate mit1 = new MenuItemTemplate();
      mit1.ID = "submenu1";
      mit1.Text = "Current User Information" ;
      mit1.Description = "Windows, ASP.NET and WSS Info";
      mit1.Sequence = 401;
      mit1.ClientOnClickNavigateUrl = sitePath + "_layouts/SecurityDemo/UserInfo.aspx";
      mit1.ImageUrl = sitePath + @"_layouts/images/TPG/small_binoculars.gif";
      smt.Controls.Add(mit1);

      MenuItemTemplate mit2 = new MenuItemTemplate();
      mit2.ID = "submenu2";
      mit2.Text = "WSS Security Principals";
      mit2.Description = "WSS collections of users and groups";
      mit2.Sequence = 402;
      mit2.ClientOnClickNavigateUrl = sitePath + "_layouts/SecurityDemo/Principals.aspx";
      mit2.ImageUrl = sitePath+ @"_layouts/images/TPG/small_compass.gif";
      smt.Controls.Add(mit2);

      MenuItemTemplate mit3 = new MenuItemTemplate();
      mit3.ID = "submenu3";
      mit3.Text = "Create Security Principal";
      mit3.Description = "Create user or group";
      mit3.Sequence = 403;
      mit3.ClientOnClickNavigateUrl = sitePath + "_layouts/SecurityDemo/CreatePrincipal.aspx";
      mit3.ImageUrl = sitePath + @"_layouts/images/TPG/small_PithHelmet.gif";
      smt.Controls.Add(mit3);

      MenuItemTemplate mit4 = new MenuItemTemplate();
      mit4.ID = "submenu4";
      mit4.Text = "Elevation and Impersonation";
      mit4.Description = "Changing the Calling Context";
      mit4.Sequence = 404;
      mit4.ClientOnClickNavigateUrl = sitePath + "_layouts/SecurityDemo/Elevation.aspx";
      mit4.ImageUrl = sitePath + @"_layouts/images/TPG/small_binoculars.gif";
      smt.Controls.Add(mit4);

      MenuItemTemplate mit5 = new MenuItemTemplate();
      mit5.ID = "submenu5";
      mit5.Text = "Securing Objects";
      mit5.Description = "Changing permissions with code";
      mit5.Sequence = 405;
      mit5.ClientOnClickNavigateUrl = sitePath + "_layouts/SecurityDemo/SecuringObjects.aspx";
      mit5.ImageUrl = sitePath + @"_layouts/images/TPG/small_PithHelmet.gif";
      smt.Controls.Add(mit5);      

      this.Controls.Add(smt);
    }

  }


}
