using System;
using System.Security;
using System.Security.Principal;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;

namespace SecurityDemo {
  class CodeForListings {

    void Listing01() {
      WindowsIdentity identity = WindowsIdentity.GetCurrent();
      string WindowsLogin = identity.Name;
    }

    void Listing02() {

      // System.Security.Principal namespace
      WindowsIdentity identity = WindowsIdentity.GetCurrent();

      // get Windows account name of current user
      string WindowsLogin = identity.Name;

      WindowsPrincipal principal = new WindowsPrincipal(identity);
      if (principal.IsInRole(@"LITWAREINC\AllFTE")) {
        // perform operation allowed for fulltime employees
      }

    }

    void Listing03() {


      // System.Web.Security namepace
      IPrincipal AspUser = HttpContext.Current.User;

      // get account name of current user
      string AspUserName = AspUser.Identity.Name;

      if(AspUser.IsInRole("Site Administrators")) {
        // perform privileged operation
      }
    
    
    }


    void Listing1() {


      // Microsoft.SharePoint namespace
      SPWeb site = SPContext.Current.Web;
      SPUserCollection c1 = site.Users;
      SPUserCollection c2 = site.AllUsers;
      SPUserCollection c3 = site.SiteUsers;

    }

    void Listing2() {

      SPWeb site = SPContext.Current.Web;
      SPUser user = site.CurrentUser;
      SPUserCollection c1 = site.Users;
      SPUserCollection c2 = site.AllUsers;
      SPUserCollection c3 = site.SiteUsers;
    }

    void Listing3() {

      SPWeb site = SPContext.Current.Web;

      site.SiteUsers.Add(@"LITWAREINC\BrianC",
                          "brianc@litwareinc.com",
                          "Brian Cox",
                          "Notes about Brian Cox");

      site.SiteUsers.Add(@"LITWAREINC\AllFTE",
                          "allFTE@litwareinc.com",
                          "All Full-time Employees",
                          "Notes about FTE DL");


    }

    void Listing4() {

      
      SPWeb site = SPContext.Current.Web;      
      // get built-in permission level named Contribute
      SPRoleDefinition role = site.RoleDefinitions["Contribute"];
      // add user to site by creating role assignment
      SPRoleAssignment roleAssignment;
      roleAssignment = new SPRoleAssignment(@"LITWAREINC\BrianC",
                                             "brianc@litwareinc.com",
                                             "Brian Cox",
                                             "Notes about Brian Cox");
      // add Contribute permission level of role assignment
      roleAssignment.RoleDefinitionBindings.Add(role);
      // add role assignment to current site
      site.RoleAssignments.Add(roleAssignment);

    }

    void Listing5() {

      SPWeb site = SPContext.Current.Web;
      SPUser currentUser = site.CurrentUser;
      
      // create new WSS group
      site.SiteGroups.Add("Site Members", currentUser, currentUser,
                          "Site Group created at " + DateTime.Now.ToString());
      
      // assign permission level to new group
      SPGroup NewGroup = site.SiteGroups["Site Members"];
      SPRoleAssignment roleAssignment = new SPRoleAssignment(NewGroup);
      SPRoleDefinition permLevel = site.RoleDefinitions["Contribute"];
      roleAssignment.RoleDefinitionBindings.Add(permLevel);
      site.RoleAssignments.Add(roleAssignment);

    }

    void Listing6() {
      SPWeb site = SPContext.Current.Web;
      SPUser currentUser = site.CurrentUser;
      SPGroup group = site.SiteGroups["Site Members"];
      SPUser user1 = site.SiteUsers[@"LITWAREINC\BrianC"];
      SPUser user2 = site.SiteUsers[@"LITWAREINC\AllFTE"];
      group.AddUser(user1);
      group.AddUser(user2);

    }

    void Listing7() {

    }

    void Listing8() {

      // BEFORE ELEVATION
      // WSS User identity = LITWAREINC\BrianC
      // Windows identity = LITWAREINC\BrianC

      SPSecurity.RunWithElevatedPrivileges(delegate() {
        // AFTER ELEVATION
        // WSS User identity = SHAREPOINT\System
        // Windows identity = LITWAREINC\SP_WorkerProcess
      });


    }

    void Listing9() {
      SPSite siteCollection = SPContext.Current.Site;
      SPWeb site = SPContext.Current.Web;
      // get SPUser object and aquire token
      SPUser targetUser = site.SiteUsers[@"LITWAREINC\BrianC"];
      SPUserToken token = targetUser.UserToken;
      // impersonate user
      using (SPSite impersonatedSiteCollection = new SPSite(siteCollection.ID, token)) {
        using (SPWeb impersonatedSite = impersonatedSiteCollection.OpenWeb(site.ID)) {
          WindowsIdentity impersonatedIdentity = WindowsIdentity.GetCurrent();
          SPUser impersonatedUser = impersonatedSite.CurrentUser;
          // WSS identity switched to impersonate BrianC
          // Windows identity does not change
        }
      }
    }

    void Listing10() {


      SPWeb site = SPContext.Current.Web;
      // create document library
      Guid listID = site.Lists.Add("Proposals",
                                   "Library desc",
                                   SPListTemplateType.DocumentLibrary);

      SPDocumentLibrary doclib = (SPDocumentLibrary)site.Lists[listID];
      doclib.OnQuickLaunch = true;
      
      // break free of parent site's ACL and start with blank ACL
      doclib.BreakRoleInheritance(false);

      // create Read role assignment for AD group
      SPUser AllFteGroup = site.SiteUsers[@"LITWAREINC\AllFTE"];
      SPRoleAssignment assignAllFteGroup = new SPRoleAssignment(AllFteGroup);
      SPRoleDefinition roleDesign = site.RoleDefinitions["Read"];
      assignAllFteGroup.RoleDefinitionBindings.Add(roleDesign);
      doclib.RoleAssignments.Add(assignAllFteGroup);
      doclib.Update();

    }

    void Listing11() {
      SPWeb site = SPContext.Current.Web;
      Guid listID = site.Lists.Add("Proposals",
                                  "Library desc",
                                  SPListTemplateType.DocumentLibrary);

      SPDocumentLibrary doclib = (SPDocumentLibrary)site.Lists[listID];
      doclib.OnQuickLaunch = true;
      doclib.Update();
      SPFile doc1 = null; // WriteDocument(doclib, "Adventure Works Merger.docx");
      doc1.Item.BreakRoleInheritance(false);
      SPGroup group = site.Groups["Litware Contact Managers"];
      SPRoleAssignment assignContribute = new SPRoleAssignment(group);
      SPRoleDefinition roleContibute = site.RoleDefinitions["Contribute"];
      assignContribute.RoleDefinitionBindings.Add(roleContibute);
      doc1.Item.RoleAssignments.Add(assignContribute);
      doc1.Item.Update();
    }

  }
}
