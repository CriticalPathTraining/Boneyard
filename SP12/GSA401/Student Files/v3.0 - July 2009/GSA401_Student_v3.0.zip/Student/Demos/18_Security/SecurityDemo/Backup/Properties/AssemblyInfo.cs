﻿using System.Reflection;

// SecurityDemo, Version=1.0.0.0, Culture=neutral, PublicKeyToken=e142cf15fe476cfb
[assembly: AssemblyVersion("1.0.0.0")]

