using System;
using System.Security;
using System.Security.Principal;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;


namespace SecurityDemo {
  public class Elevation : LayoutsPageBase {

    protected SPGridView grdBefore;
    protected SPGridView grdElevated;
    protected SPGridView grdMiddle;
    protected SPGridView grdImpersonated;
    protected SPGridView grdAfter;
    protected DropDownList lstUsers;

    protected override void OnLoad(EventArgs e) {

      WindowsIdentity identity = WindowsIdentity.GetCurrent();
      SPUser user = SPContext.Current.Web.CurrentUser;

      // SECTION 1 - The Original Calling Context
      DisplayCurrentUserInfo(identity, user, grdBefore);

      // SECTION 2 - The Elevated Calling Context
      SPSecurity.RunWithElevatedPrivileges(delegate() {
        using (SPSite elevatedSiteCollection = new SPSite(this.Site.ID)) {
          using (SPWeb elevatedSite = elevatedSiteCollection.OpenWeb(this.Web.ID)) {
            WindowsIdentity elevatedIdentity = WindowsIdentity.GetCurrent();
            SPUser elevatedUser = elevatedSite.CurrentUser;
            DisplayCurrentUserInfo(elevatedIdentity, elevatedUser, grdElevated);
          }
        }
      });

      // SECTION 3 - The Restored Calling Context
      DisplayCurrentUserInfo(identity, user, grdMiddle);

      // SECTION 4 - The Impersonated Calling Context
      SPSecurity.RunWithElevatedPrivileges(delegate() {
        using (SPSite elevatedSiteCollection = new SPSite(this.Site.ID)) {
          using (SPWeb elevatedSite = elevatedSiteCollection.OpenWeb(this.Web.ID)) {
            int userId;
            if (lstUsers.SelectedIndex == -1) {
              userId = elevatedSiteCollection.Owner.ID;
            }
            else {
              userId = Convert.ToInt32(lstUsers.Items[lstUsers.SelectedIndex].Value);
            }
            SPUser targetUser = elevatedSite.SiteUsers.GetByID(userId);
            SPUserToken token = targetUser.UserToken;
            using (SPSite impersonatedSiteCollection = new SPSite(this.Site.ID, token)) {
              using (SPWeb impersonatedSite = impersonatedSiteCollection.OpenWeb(this.Web.ID)) {
                WindowsIdentity impersonatedIdentity = WindowsIdentity.GetCurrent();
                SPUser impersonatedUser = impersonatedSite.CurrentUser;
                DisplayCurrentUserInfo(impersonatedIdentity, impersonatedUser, grdImpersonated);
              }
            }
          }
        }

       
      });
      
      // SECTION 5 - The Restored Calling Context
      DisplayCurrentUserInfo(identity, user, grdAfter);

    }

    void DisplayCurrentUserInfo(WindowsIdentity identity, SPUser user, SPGridView grid) {
      PropertyCollectionBinder pcbUserInfo = new PropertyCollectionBinder();
      pcbUserInfo.AddProperty("Windows User Identity", identity.Name);
      pcbUserInfo.AddProperty("WSS User Identity", user.Name);
      pcbUserInfo.BindGrid(grid);
    }

    protected override void OnPreRender(EventArgs e) {
      if (!this.IsPostBack) {
        lstUsers.Items.Clear();
        foreach (SPUser user in this.Web.SiteUsers) {
          ListItem userItem = new ListItem(user.Name, user.ID.ToString());
          lstUsers.Items.Add(userItem);
        }
      }
    }
  }
}
