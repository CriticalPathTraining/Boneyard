using System;
using System.IO;
using System.IO.Packaging;
using System.Xml;


namespace SecurityDemo {
  public class DocumentFactory {

    public static Stream CreateTextFile(string content) {
      Stream documentStream = new MemoryStream();
      StreamWriter writer = new StreamWriter(documentStream);
      writer.Write(content);
      writer.Flush();
      return documentStream;
    }

    public static Stream CreateWordDocument(string content) {
      
      MemoryStream documentStream = new MemoryStream();
      // create new package in memory stream
      Package package = Package.Open(documentStream, FileMode.Create,FileAccess.ReadWrite);

      // generate DOCX file from list content
      // create main document part (document.xml) ...
      Uri uri = new Uri("/word/document.xml", UriKind.Relative);
      string partContentType;
      partContentType = "application/vnd.openxmlformats" +
                        "-officedocument.wordprocessingml.document.main+xml";
      PackagePart part = package.CreatePart(uri, partContentType);

      // get stream for document.xml
      StreamWriter streamPart;
      streamPart = new StreamWriter(part.GetStream(FileMode.Create,
                                                   FileAccess.Write));

      const string wordNamespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

      XmlWriter writer = XmlWriter.Create(streamPart);
      writer.WriteStartDocument();

      writer.WriteStartElement("w", "document", wordNamespace);
      writer.WriteStartElement("body", wordNamespace);
      writer.WriteStartElement("p", wordNamespace);
      writer.WriteStartElement("r", wordNamespace);
      writer.WriteStartElement("t", wordNamespace);
      writer.WriteValue(content);
      writer.WriteEndElement();  // <w:/t>
      writer.WriteEndElement();  // <w:/r>
      writer.WriteEndElement();  // <w:/p>
      writer.WriteEndElement();  // <w:/body>
      
      writer.WriteEndDocument(); // <w:/document>

      writer.Close();
      streamPart.Close();
      package.Flush();

      // create the relationship part
      string relationshipType;
      relationshipType = "http://schemas.openxmlformats.org" +
                         "/officeDocument/2006/relationships/officeDocument";
      package.CreateRelationship(uri, TargetMode.Internal, relationshipType, "rId1");
      package.Flush();

      // save/close package object leaving DOCX file in MemoryStream
      package.Close();

      return documentStream;
    }

    public const string StandardBodyText = @"And all of them knew that as time went by, that they would get a little slower and a little older. " +
                                           @"And all of them knew that as time went by, that they would get a little slower and a little older. " +
                                           @"And all of them knew that as time went by, that they would get a little slower and a little older. ";
  
  }
}
