using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Security;
using System.Security.Principal;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;


namespace SecurityDemo {

  public class SecuringObjects : LayoutsPageBase {

    protected SPGridView grdWssGroups;
    protected SPGridView grdWssSiteGroups;
    protected SPTreeView treeObjects;

    protected override void OnPreRender(EventArgs e) {
      DisplayGroupCollection(Web.Groups, grdWssGroups, "SPWeb.Groups");
      DisplayGroupCollection(Web.SiteGroups, grdWssSiteGroups, "SPWeb.SiteGroups");
      DisplayObjects(Web.RootFolder, treeObjects);
    }

    protected void cmdCreateGroups_Click(object sender, EventArgs e) {
      string group1Name = "Indigestion Workers";
      string group1Description = "The business guys on the front lines reading and updating content and documents";      
      string group2Name = "Content Manglers";
      string group2Description = "Staff workers who seek out bad content and then make it worse";
      string group3Name = "Administrugglers";
      string group3Description = "The administrative folks that install WSS/MOSS and maintain the farm";
      string group4Name = "Dweebvelopers";
      string group4Description = "The dev folks that get blamed for all those bugs";

      // create site groups
      SPUser currentUser = Web.CurrentUser;
      Web.SiteGroups.Add(group1Name, currentUser, currentUser, group1Description);
      Web.SiteGroups.Add(group2Name, currentUser, currentUser, group2Description);
      Web.SiteGroups.Add(group3Name, currentUser, currentUser, group3Description);
      Web.SiteGroups.Add(group4Name, currentUser, currentUser, group4Description);

      // assign Read role in current site
      SPRoleAssignment assignRead = new SPRoleAssignment(Web.SiteGroups[group1Name]);
      SPRoleDefinition roleRead = Web.RoleDefinitions["Read"];
      assignRead.RoleDefinitionBindings.Add(roleRead);
      Web.RoleAssignments.Add(assignRead);

      // assign Contribute role in current site
      SPRoleAssignment assignContribute = new SPRoleAssignment(Web.SiteGroups[group2Name]);
      SPRoleDefinition roleContribute = Web.RoleDefinitions["Contribute"];
      assignContribute.RoleDefinitionBindings.Add(roleContribute);
      Web.RoleAssignments.Add(assignContribute);

      // assign Design role in current site
      SPRoleAssignment assignDesign = new SPRoleAssignment(Web.SiteGroups[group3Name]);
      SPRoleDefinition roleDesign = Web.RoleDefinitions["Design"];
      assignDesign.RoleDefinitionBindings.Add(roleDesign);
      Web.RoleAssignments.Add(assignDesign);

      // assign Full Control role in current site
      SPRoleAssignment assignFullControl = new SPRoleAssignment(Web.SiteGroups[group4Name]);
      SPRoleDefinition roleFullControl = Web.RoleDefinitions["Full Control"];
      assignFullControl.RoleDefinitionBindings.Add(roleFullControl);
      Web.RoleAssignments.Add(assignFullControl);

      // add external principals to groups
      Web.SiteGroups[group1Name].AddUser(@"LITWAREINC\ALLFTE", "", "Full time employees","All full-time employees who work at Litware Inc.");
      Web.SiteGroups[group2Name].AddUser(@"LITWAREINC\BrianC", "", "Brian Cox", "");
      Web.SiteGroups[group3Name].AddUser(@"LITWAREINC\AngelaB", "", "Angela Barbariol", "");
      Web.SiteGroups[group4Name].AddUser(@"LITWAREINC\JayH", "", "Jay Henningsen", "");

    }

    protected void cmdDeleteGroups_Click(object sender, EventArgs e) {
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      while (Web.SiteGroups.Count > 0) {
        this.Web.SiteGroups.Remove(0);
      }
    }

    protected void cmdCreateObjects_Click(object sender, EventArgs e) {
      string Library1Name = "HR Policies";
      string Library1Description = "Documents with HR policy listings and explanations";
      string Library2Name = "Proposals";
      string Library2Description = "Library full of technical writing";
      string Library3Name = "Serious Contracts";
      string Library3Description = "Library full of secret stuff";

      Guid lib1Id = Web.Lists.Add(Library1Name, Library1Description, SPListTemplateType.DocumentLibrary);
      SPDocumentLibrary lib1 = (SPDocumentLibrary)Web.Lists[lib1Id];
      lib1.OnQuickLaunch = true;
      lib1.Update();
      WriteDocument(lib1, "Rules For Eating Lunch In Public.docx", DocumentFactory.StandardBodyText);
      WriteDocument(lib1, "Rules For Submitting Expense Reports.docx", DocumentFactory.StandardBodyText);
      WriteDocument(lib1, "Rules For Going Over Your Boss's Head", DocumentFactory.StandardBodyText);

      Guid lib2Id = Web.Lists.Add(Library2Name, Library2Description, SPListTemplateType.DocumentLibrary);
      SPDocumentLibrary lib2 = (SPDocumentLibrary)Web.Lists[lib2Id];
      lib2.OnQuickLaunch = true;      
      lib2.BreakRoleInheritance(false);
      SPUser AllFteGroup = Web.SiteUsers[@"LITWAREINC\AllFTE"];
      SPRoleAssignment assignAllFteGroup = new SPRoleAssignment(AllFteGroup);
      SPRoleDefinition roleDesign = this.Web.RoleDefinitions["Read"];
      assignAllFteGroup.RoleDefinitionBindings.Add(roleDesign);
      lib2.RoleAssignments.Add(assignAllFteGroup);
      lib2.Update();
      WriteDocument(lib2, "Adventure Works Merger.docx", DocumentFactory.StandardBodyText);
      WriteDocument(lib2, "Litware Expansion into Europe.docx", DocumentFactory.StandardBodyText);
      WriteDocument(lib2, "Dramatic Payraise for Executive Board Members.docx", DocumentFactory.StandardBodyText);
      

      Guid lib3Id = Web.Lists.Add(Library3Name, Library3Description, SPListTemplateType.DocumentLibrary);
      SPDocumentLibrary lib3 = (SPDocumentLibrary)Web.Lists[lib3Id];
      lib3.OnQuickLaunch = true;
      lib3.Update();
      WriteDocument(lib3, "Litware Independent Contractor Agreement.docx", DocumentFactory.StandardBodyText);
      SPFile doc1 = WriteDocument(lib3, "Contoso Bankruptcy Resolution.docx", DocumentFactory.StandardBodyText);
      doc1.Item.BreakRoleInheritance(false);
      SPGroup group = Web.Groups["Content Manglers"];
      SPRoleAssignment assignContribute = new SPRoleAssignment(group);
      SPRoleDefinition roleContibute = this.Web.RoleDefinitions["Contribute"];
      assignContribute.RoleDefinitionBindings.Add(roleContibute);
      doc1.Item.RoleAssignments.Add(assignContribute);
      doc1.Item.Update();
 

    }

    protected SPFile WriteDocument(SPDocumentLibrary library, string FileName, string content) {
      Stream document = DocumentFactory.CreateWordDocument(content);
      return library.RootFolder.Files.Add(FileName, document);
    }

    protected void cmdDeleteObjects_Click(object sender, EventArgs e) {

      List<Guid> ListIDs = new List<Guid>();
      foreach (SPList list in Web.Lists) {
        if (list is SPDocumentLibrary && !list.Hidden) {
          ListIDs.Add(list.ID);
        }
      }

      foreach(Guid listID in ListIDs){
        Web.Lists.Delete(listID);
      }
      
    }  

    void DisplayGroupCollection(SPGroupCollection groups, SPGridView grid, string Name) {
      ListCollectionBinder lcbWssGroups = new ListCollectionBinder(Name);
      foreach (SPGroup Group in groups) {
        lcbWssGroups.AddValue(Group.Name + " [" + Group.ID.ToString() + "]");
      }
      lcbWssGroups.BindGrid(grid);
    }

    #region paths to images
    const string SITE_IMG = @"\_layouts\images\CSWEB.GIF";
    const string DOCLIB_IMG = @"\_layouts\images\FOLDER.GIF";
    const string FOLDER_IMG = @"\_layouts\images\FOLDER16.GIF";
    const string FILE_IMG = @"\_layouts\images\DOC16.GIF";
    #endregion

    void DisplayObjects(SPFolder rootFolder, SPTreeView treeObjects) {

      treeObjects.Nodes.Clear();

      TreeNode siteNode = new TreeNode("Current Site at " + Web.Url, Web.Url, SITE_IMG);

      foreach (SPList list in Web.Lists) {
       if (list is SPDocumentLibrary && !list.Hidden) {
         SPDocumentLibrary docLib = (SPDocumentLibrary)list;
         SPFolder folder = docLib.RootFolder;
         TreeNode docLibNode = new TreeNode(docLib.Title, docLib.DefaultViewUrl, DOCLIB_IMG);
         LoadFolderNodes(folder, docLibNode);
         siteNode.ChildNodes.Add(docLibNode);
       }      
      }
      treeObjects.Nodes.Add(siteNode);
      treeObjects.ExpandAll();

    }

    protected void LoadFolderNodes(SPFolder folder, TreeNode folderNode) {
      foreach (SPFolder childFolder in folder.SubFolders) {
        if (childFolder.Name != "Forms") {
          TreeNode childFolderNode = new TreeNode(childFolder.Name, childFolder.Name, FOLDER_IMG);
          LoadFolderNodes(childFolder, childFolderNode);
          folderNode.ChildNodes.Add(childFolderNode);
        }
      }
      foreach (SPFile file in folder.Files) {
        TreeNode fileNode;
        fileNode = new TreeNode(file.Name, file.Name, FILE_IMG);
        fileNode.NavigateUrl = Site.MakeFullUrl(file.ServerRelativeUrl);
        folderNode.ChildNodes.Add(fileNode);
      }
    }
  }
}
