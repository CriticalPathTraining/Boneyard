using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace SecurityDemo {
  class ListCollectionBinder {
    
    protected DataTable ValueCollection = new DataTable();

    private string _ColumnHeading;

    public ListCollectionBinder(string ColumnHeading) {
      _ColumnHeading = ColumnHeading;
      ValueCollection.Columns.Add("Value", typeof(string));
    }

    public void AddValue(string Value) {
      DataRow newRow = ValueCollection.Rows.Add();
      newRow["Value"] = Value;
    }

    public void BindGrid(SPGridView grid) {

      grid.Columns.Clear();
      grid.ShowHeader = true;

      SPBoundField fldValue = new SPBoundField();
      fldValue.HeaderText = _ColumnHeading;
      fldValue.DataField = "Value";
      grid.Columns.Add(fldValue);

      grid.AutoGenerateColumns = false;
      grid.DataSource = ValueCollection.DefaultView;
      grid.DataBind();
    }

  }
}
