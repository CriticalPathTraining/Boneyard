using System;
using System.Collections;
using System.Collections.Generic;
using System.Security;
using System.Security.Principal;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;


namespace SecurityDemo {
  public class UserInfo : LayoutsPageBase {

    protected SPGridView grdWindowsUserInfo;
    protected SPGridView grdWindowsGroups;
    protected SPGridView grdAspnetUserInfo;
    protected SPGridView grdFbaRoles;
    protected Label lblRolesEnabled;
    protected SPGridView grdWssUserInfo;
    protected SPGridView grdWssGroups;

    protected override void OnLoad(EventArgs e) {

      // get windows info about current user
      // programming against System.Security namespace
      WindowsIdentity identity = WindowsIdentity.GetCurrent();
      WindowsPrincipal principal = new WindowsPrincipal(identity);
      if (principal.IsInRole(@"LITWAREINC\AllFTE")) {
        // perform operation allowed for fulltime employees
      }
      string WindowsLogin = identity.Name;

      DisplayWindowsUserInfo(identity, grdWindowsUserInfo);
      DisplayWindowsGroups(identity, grdWindowsGroups);


      // get ASP.NET info about current user
      IPrincipal AspUser = HttpContext.Current.User;
      string AspUserName = AspUser.Identity.Name;

      DisplayAspnetUserInfo(AspUser, grdAspnetUserInfo);
      if (Roles.Enabled) {
        DisplayFbaRoles(AspUser, grdFbaRoles);
        lblRolesEnabled.Visible = false;
      }
      else {
        lblRolesEnabled.Visible = true;
        lblRolesEnabled.Text = "FBA roles are not enabled";
      }

      // get WSS  info about current user
      SPUser user = SPContext.Current.Web.CurrentUser;
      DisplayWssUserInfo(user, grdWssUserInfo);
      DisplayWssGroups(user, grdWssGroups);

    }

    void DisplayWindowsUserInfo(WindowsIdentity identity, SPGridView grid) {
      PropertyCollectionBinder pcbWindows = new PropertyCollectionBinder();
      pcbWindows.AddProperty("Is Anonymous", identity.IsAnonymous.ToString());
      pcbWindows.AddProperty("Is Authenticated", identity.IsAuthenticated.ToString());
      pcbWindows.AddProperty("User Account Name", identity.Name);
      pcbWindows.AddProperty("Authentication Type", identity.AuthenticationType);
      pcbWindows.AddProperty("Security ID (SID)", identity.User.ToString());
      pcbWindows.BindGrid(grid);
    }

    void DisplayWindowsGroups(WindowsIdentity identity, SPGridView grid) {
      ListCollectionBinder lcbAdGroups = new ListCollectionBinder("Windows Groups");
      List<string> groups = new List<string>();
      IdentityReferenceCollection irc = identity.Groups.Translate(typeof(NTAccount));
      foreach (NTAccount acc in irc) {
        lcbAdGroups.AddValue(acc.Value);
      }
      lcbAdGroups.BindGrid(grid);
    }

    void DisplayAspnetUserInfo(IPrincipal AspUser, SPGridView grid) {
      PropertyCollectionBinder pcbAspnet = new PropertyCollectionBinder();
      pcbAspnet.AddProperty("Is Authenticated", AspUser.Identity.IsAuthenticated.ToString());
      pcbAspnet.AddProperty("Authentication Type", AspUser.Identity.AuthenticationType);
      pcbAspnet.AddProperty("User", AspUser.Identity.Name);
      pcbAspnet.AddProperty("User Object", AspUser.GetType().ToString());
      pcbAspnet.BindGrid(grid);
    }

    void DisplayFbaRoles(IPrincipal AspUser, SPGridView grid) {
      ListCollectionBinder lcbFbaRoles = new ListCollectionBinder("FBA Roles");
      foreach (string Role in Roles.GetAllRoles()) {
        if (AspUser.IsInRole(Role)) {
          lcbFbaRoles.AddValue(Role);
        }
      }
      lcbFbaRoles.BindGrid(grdFbaRoles);
    }

    void DisplayWssUserInfo(SPUser user, SPGridView grid) {
      PropertyCollectionBinder pcbWss = new PropertyCollectionBinder();
      pcbWss.AddProperty("User Name", user.Name);
      pcbWss.AddProperty("User Logon", user.LoginName);
      pcbWss.AddProperty("User Email", user.Email);
      pcbWss.BindGrid(grid);
    }

    void DisplayWssGroups(SPUser user, SPGridView grid) {
      ListCollectionBinder lcbWssGroups = new ListCollectionBinder("WSS Groups");
      foreach (SPGroup Group in user.Groups) {
        lcbWssGroups.AddValue(Group.Name);
      }
      lcbWssGroups.BindGrid(grid);
    }
  }
}
