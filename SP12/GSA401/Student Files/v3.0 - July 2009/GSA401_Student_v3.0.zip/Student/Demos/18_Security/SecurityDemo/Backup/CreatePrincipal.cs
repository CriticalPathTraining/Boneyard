using System;
using System.Collections;
using System.Security;
using System.Security.Principal;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.WebControls;


namespace SecurityDemo {
  public class CreatePrincipal : LayoutsPageBase {

    protected PeopleEditor pickerPrincipal;
    protected Label lblUserCreatedMessage;
    protected CheckBoxList lstPermissionLevels;
    protected TextBox txtGroupName;
    protected Label lblGroupCreateMessage;

    protected override void OnLoad(EventArgs e) {
    }

    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);
      lstPermissionLevels.Items.Clear();
      SPWeb site = this.Web;
      foreach (SPRoleDefinition role in site.RoleDefinitions) {
        lstPermissionLevels.Items.Add(new ListItem(role.Name, role.Id.ToString()));
      }      
    }

    protected void cmdCreateUser_Click(object sender, EventArgs e) {
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      if (pickerPrincipal.ResolvedEntities.Count > 0) {
        string LoginName = pickerPrincipal.Accounts[0].ToString();
        PickerEntity Entity = (PickerEntity)pickerPrincipal.ResolvedEntities[0];
        string PrincipalType = Entity.EntityData["PrincipalType"] != null ? Entity.EntityData["PrincipalType"].ToString() : "Unknown";
        string DisplayName = Entity.EntityData["DisplayName"].ToString();
        if (string.IsNullOrEmpty(DisplayName)) {
          DisplayName = LoginName;
        }
        string Email = string.Empty;
        if (Entity.EntityData["Email"] != null) {
          Email = Entity.EntityData["Email"].ToString();
        }        
        string Notes = "User account created at " + DateTime.Now.ToString();
        // DO NOT DO THIS >> site.SiteUsers.Add(LoginName, Email, DisplayName, Notes);        
        // Instead add user by assigning permission level
        SPRoleDefinition role = site.RoleDefinitions["Contribute"];
        SPRoleAssignment roleAssignment = new SPRoleAssignment(LoginName, Email, DisplayName, Notes);
        roleAssignment.RoleDefinitionBindings.Add(role);
        site.RoleAssignments.Add(roleAssignment);
        lblUserCreatedMessage.Text = "SPUser Account " + DisplayName +
                                      " created from " + PrincipalType +
                                      " with login of " + LoginName;
      }
      else {
        lblUserCreatedMessage.Text = "Select a user of group";
      }
    }

    protected void cmdCreateGroup_Click(object sender, EventArgs e) {
      string NewGroupName = txtGroupName.Text;      
      // make sure group name is not blank
      if(string.IsNullOrEmpty(NewGroupName)) {
        lblGroupCreateMessage.Text = "You must enter a group name";
        return;
      }
      // make sure Site Group doesn't already exists
      foreach (SPGroup group in this.Web.SiteGroups) {
        if (group.Name == NewGroupName) {
          lblGroupCreateMessage.Text = "A site group named " + NewGroupName + " already exists";
          return;
        }
      }

      // make sure at least one permission level is selected
      bool PermissionLevelSelected = false;
      foreach(ListItem item in lstPermissionLevels.Items) {
        if(item.Selected) {
          PermissionLevelSelected = true;
          break;
        }
      }
      if (!PermissionLevelSelected) {
        lblGroupCreateMessage.Text = "You must select at least permission level";
        return;
      }

      // create new Site Group
SPUser currentUser = this.Web.CurrentUser;
this.Web.SiteGroups.Add(NewGroupName, currentUser, currentUser,
                        "Site Group created at " + DateTime.Now.ToString());

// assign permission levels to new group
SPGroup NewGroup = this.Web.SiteGroups[NewGroupName];
SPRoleAssignment roleAssignment = new SPRoleAssignment(NewGroup);

foreach(ListItem roleItem in lstPermissionLevels.Items) {
  if (roleItem.Selected) {
    SPRoleDefinition permLevel = this.Web.RoleDefinitions[roleItem.Text];
    roleAssignment.RoleDefinitionBindings.Add(permLevel);
  }        
}      
this.Web.RoleAssignments.Add(roleAssignment);
      lblGroupCreateMessage.Text = NewGroupName + " has been created";
    }
  }
}
