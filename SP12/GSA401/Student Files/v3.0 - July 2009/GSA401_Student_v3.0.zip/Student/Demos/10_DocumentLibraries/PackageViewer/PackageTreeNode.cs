using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace PackageViewer {
  class PackageTreeNode : UriTreeNode {
    public PackageTreeNode(string fileName)
      : base(new Uri("file://" + fileName)) {
      base.Text = System.IO.Path.GetFileName(fileName);
      base.ImageIndex = 0;
      base.SelectedImageIndex = 0;
    }
  }
}
