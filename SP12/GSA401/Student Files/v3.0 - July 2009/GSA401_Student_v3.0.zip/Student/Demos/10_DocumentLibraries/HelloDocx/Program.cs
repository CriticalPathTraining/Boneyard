using System;
using System.IO;
using System.IO.Packaging;
using System.Xml;

namespace HelloDocx {
  class Program {
    static void Main() {

      Package package = Package.Open(@"c:\Data\minimal.docx",
                        FileMode.Create,
                        FileAccess.ReadWrite);

      // create main document part (document.xml) ...
      Uri uri = new Uri("/word/document.xml", UriKind.Relative);
      string partContentType;
      partContentType = "application/vnd.openxmlformats" +
                        "-officedocument.wordprocessingml.document.main+xml";
      PackagePart part = package.CreatePart(uri, partContentType);

      // get stream for document.xml
      StreamWriter streamPart;
      streamPart = new StreamWriter(part.GetStream(FileMode.Create,
                                                   FileAccess.Write));


      // define string variable for Open XML namespace for nsWP:
      string nsWP = "http://schemas.openxmlformats.org" +
                     "/wordprocessingml/2006/main";

      // create the start part, set up the nested structure ...
      XmlWriter writer = XmlWriter.Create(streamPart);
      writer.WriteStartDocument();
      writer.WriteStartElement("w", "document", nsWP);
      writer.WriteStartElement("body", nsWP);
      writer.WriteStartElement("p", nsWP);
      writer.WriteStartElement("r", nsWP);      
      writer.WriteStartElement("t", nsWP);

      writer.WriteValue("My First DOCX File");
      
      writer.WriteEndElement();
      writer.WriteEndElement();
      writer.WriteEndElement();
      writer.WriteEndElement();
      writer.WriteEndElement();
      writer.WriteEndDocument();

      writer.Close();
      
      streamPart.Close();
      package.Flush();

      // create the relationship part
      string relationshipType;
      relationshipType = "http://schemas.openxmlformats.org" +
                         "/officeDocument/2006/relationships/officeDocument";
      package.CreateRelationship(uri, TargetMode.Internal, relationshipType, "rId1");
      package.Flush();

      // close package
      package.Close();
    }
  }
}
