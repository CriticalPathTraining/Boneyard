using System;
using Microsoft.SharePoint;

namespace NotSoBlankSite {
  public class ProvisioningProvider : SPWebProvisioningProvider {

    public override void Provision(SPWebProvisioningProperties props) {
      props.Web.ApplyWebTemplate("STS#0");
      // elevate permissions to get work done
      SPSecurity.RunWithElevatedPrivileges(delegate() {
        using (SPSite siteCollection = new SPSite(props.Web.Site.ID)) {
          using (SPWeb site = siteCollection.OpenWeb(props.Web.ID)) {

            // modify site
            site.Title = props.Data;
            site.Update();
            // add child sites
            site.Webs.Add("Child1", "Child site 1", "", 1033, "STS#1", false, false);
            site.Webs.Add("Child2", "Child site 2", "", 1033, "STS#1", false, false);                          
          }
        }
      });
    }
  }
}
