using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

namespace WebPartScratchPad {

  public class Pad3UserControlBase : UserControl {

    protected Label lblHello;

    protected override void OnLoad(EventArgs e) {
      base.OnLoad(e);
      lblHello.Text = "Starting point for scratch pad 3";
    }
    
  }
}
