﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;
using System.Xml;
using System.Collections.ObjectModel;
using System.IO;

namespace WebExtensionsConfigurator
{
    public struct WebConfigModificationEntry
    {
        public string Name;
        public string XPath;
        public uint PrioritySequence;
        public string Value;
        public SPWebConfigModification.SPWebConfigModificationType ModType;

        public WebConfigModificationEntry(string Name, string XPath, string Value, uint PrioritySequence, SPWebConfigModification.SPWebConfigModificationType ModType)
        {
            this.Name = Name;
            this.XPath = XPath;
            this.Value = Value;
            this.PrioritySequence = PrioritySequence;
            this.ModType = ModType;
        }
    }

    public class WebConfigModificationManager
    {
        private const string assemblyBindingElement =
            "<dependentAssembly><assemblyIdentity name=\"{0}\" publicKeyToken=\"{1}\" culture=\"neutral\" /><bindingRedirect oldVersion=\"{2}\" newVersion=\"{3}\" /></dependentAssembly>";

        public string ModificationOwner;
        private SPWebApplication webApplication = null;
        private XmlDocument webConfig = null;
        private bool updatesMade = false;

        public WebConfigModificationManager(SPWebApplication webApplication)
        {
            this.ModificationOwner = this.GetType().Assembly.GetName().Name;
            this.webApplication = webApplication;
        }

        #region ConfigSection entries
        private WebConfigModificationEntry[] configSections =
        {
              new WebConfigModificationEntry("sectionGroup[@name=\"system.web.extensions\"]",
                                             "configuration/configSections",
                                             "<sectionGroup name=\"system.web.extensions\" type=\"System.Web.Configuration.SystemWebExtensionsSectionGroup, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("sectionGroup[@name=\"scripting\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]",
                                             "<sectionGroup name=\"scripting\" type=\"System.Web.Configuration.ScriptingSectionGroup, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("section[@name=\"scriptResourceHandler\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]/sectionGroup[@name=\"scripting\"]",
                                             "<section name=\"scriptResourceHandler\" type=\"System.Web.Configuration.ScriptingScriptResourceHandlerSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" requirePermission=\"false\" allowDefinition=\"MachineToApplication\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("sectionGroup[@name=\"webServices\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]/sectionGroup[@name=\"scripting\"]",
                                             "<sectionGroup name=\"webServices\" type=\"System.Web.Configuration.ScriptingWebServicesSectionGroup, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("section[@name=\"jsonSerialization\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]/sectionGroup[@name=\"scripting\"]/sectionGroup[@name=\"webServices\"]",
                                             "<section name=\"jsonSerialization\" type=\"System.Web.Configuration.ScriptingJsonSerializationSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" requirePermission=\"false\" allowDefinition=\"Everywhere\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("section[@name=\"profileService\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]/sectionGroup[@name=\"scripting\"]/sectionGroup[@name=\"webServices\"]",
                                             "<section name=\"profileService\" type=\"System.Web.Configuration.ScriptingProfileServiceSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral,  PublicKeyToken=31bf3856ad364e35\" requirePermission=\"false\" allowDefinition=\"MachineToApplication\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("section[@name=\"authenticationService\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]/sectionGroup[@name=\"scripting\"]/sectionGroup[@name=\"webServices\"]",
                                             "<section name=\"authenticationService\" type=\"System.Web.Configuration.ScriptingAuthenticationServiceSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" requirePermission=\"false\" allowDefinition=\"MachineToApplication\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("section[@name=\"roleService\"]",
                                             "configuration/configSections/sectionGroup[@name=\"system.web.extensions\"]/sectionGroup[@name=\"scripting\"]/sectionGroup[@name=\"webServices\"]",
                                             "<section name=\"roleService\" type=\"System.Web.Configuration.ScriptingRoleServiceSection, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" requirePermission=\"false\" allowDefinition=\"MachineToApplication\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };
        #endregion

        #region System.Web entries
        private WebConfigModificationEntry[] WebEntries = 
        {
            // assemblies section
               new WebConfigModificationEntry("add[@assembly=\"System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089\"]",
                                              "configuration/system.web/compilation/assemblies",
                                              "<add assembly=\"System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089\"/>",
                                              1,
                                              SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

               new WebConfigModificationEntry("add[@assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                              "configuration/system.web/compilation/assemblies",
                                              "<add assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                              1,
                                              SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

               new WebConfigModificationEntry("add[@assembly=\"System.Data.DataSetExtensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089\"]",
                                              "configuration/system.web/compilation/assemblies",
                                              "<add assembly=\"System.Data.DataSetExtensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089\"/>",
                                              1,
                                              SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
               
               new WebConfigModificationEntry("add[@assembly=\"System.Xml.Linq, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089\"]",
                                              "configuration/system.web/compilation/assemblies",
                                              "<add assembly=\"System.Xml.Linq, Version=3.5.0.0, Culture=neutral, PublicKeyToken=B77A5C561934E089\"/>",
                                              1,
                                              SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

            // httphandlers section
              new WebConfigModificationEntry("add[@path=\"*.asmx\"]",
                                             "configuration/system.web/httpHandlers",
                                             "<add verb=\"*\" path=\"*.asmx\" validate=\"false\" type=\"System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@path=\"*_AppService.axd\"]",
                                             "configuration/system.web/httpHandlers",
                                             "<add verb=\"*\" path=\"*_AppService.axd\" validate=\"false\" type=\"System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@path=\"ScriptResource.axd\"]",
                                             "configuration/system.web/httpHandlers",
                                             "<add verb=\"GET,HEAD\" path=\"ScriptResource.axd\" type=\"System.Web.Handlers.ScriptResourceHandler, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" validate=\"false\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

            // httpmodules section
              new WebConfigModificationEntry("add[@name=\"ScriptModule\"][@type=\"System.Web.Handlers.ScriptModule, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                             "configuration/system.web/httpModules",
                                             "<add name=\"ScriptModule\" type=\"System.Web.Handlers.ScriptModule, System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

            // Pages Section
              new WebConfigModificationEntry("controls",
                                             "configuration/system.web/pages",
                                             "<controls></controls>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@tagPrefix=\"asp\"][@namespace=\"System.Web.UI\"][@assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                             "configuration/system.web/pages/controls",
                                             "<add tagPrefix=\"asp\" namespace=\"System.Web.UI\" assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@tagPrefix=\"asp\"][@namespace=\"System.Web.UI.WebControls\"][@assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                             "configuration/system.web/pages/controls",
                                             "<add tagPrefix=\"asp\" namespace=\"System.Web.UI.WebControls\" assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              // Safe Controls
              new WebConfigModificationEntry("SafeControl[@Assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                             "configuration/SharePoint/SafeControls",
                                             "<SafeControl Assembly=\"System.Web.Extensions, Version=3.5.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" Namespace=\"System.Web.UI\" TypeName=\"*\" Safe=\"True\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };
        #endregion

        #region AssemblyBinding entries
        private WebConfigModificationEntry[] assemblyBindings =
        {
      new WebConfigModificationEntry("*[namespace-uri()=\"urn:schemas-microsoft-com:asm.v1\" and local-name()=\"dependentAssembly\"]/*[namespace-uri()=\"urn:schemas-microsoft-com:asm.v1\" and local-name()=\"assemblyIdentity\"][@name=\"System.Web.Extensions\"]/parent::*",
                                     "configuration/runtime/*[namespace-uri()=\"urn:schemas-microsoft-com:asm.v1\" and local-name()=\"assemblyBinding\"]",
                                     "<dependentAssembly>"
                                         + "<assemblyIdentity name=\"System.Web.Extensions\" publicKeyToken=\"31bf3856ad364e35\" />"
                                         + " <bindingRedirect oldVersion=\"1.0.0.0-1.1.0.0\" newVersion=\"3.5.0.0\" />"
                                      + "</dependentAssembly>",
                                     1,
                                     SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
    

      new WebConfigModificationEntry("*[namespace-uri()=\"urn:schemas-microsoft-com:asm.v1\" and local-name()=\"dependentAssembly\"]/*[namespace-uri()=\"urn:schemas-microsoft-com:asm.v1\" and local-name()=\"assemblyIdentity\"][@name=\"System.Web.Extensions.Design\"]/parent::*",
                                     "configuration/runtime/*[namespace-uri()=\"urn:schemas-microsoft-com:asm.v1\" and local-name()=\"assemblyBinding\"]",
                                     "<dependentAssembly>"
                                     + " <assemblyIdentity name=\"System.Web.Extensions.Design\" publicKeyToken=\"31bf3856ad364e35\" />"
                                     + "      <bindingRedirect oldVersion=\"1.0.0.0-1.1.0.0\" "
                                     + "                       newVersion=\"3.5.0.0\" />"
                                     + "</dependentAssembly>",
                                     1,
                                     SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };
        #endregion

        #region Silverlight entries
        private WebConfigModificationEntry[] silverlight2Entries = 
        {
            // assemblies section
            new WebConfigModificationEntry("add[@assembly=\"System.Web.Silverlight, Version=2.0.5.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                      "configuration/system.web/compilation/assemblies",
                                      "<add assembly=\"System.Web.Silverlight, Version=2.0.5.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                      1,
                                      SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),


            // controls section
            new WebConfigModificationEntry("add[@tagPrefix=\"asp\"][@assembly=\"System.Web.Silverlight, Version=2.0.5.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                     "configuration/system.web/pages/controls",
                                     "<add tagPrefix=\"asp\" namespace=\"System.Web.UI.SilverlightControls\" assembly=\"System.Web.Silverlight, Version=2.0.5.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                     1,
                                     SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
        
           // Safe Controls
           new WebConfigModificationEntry("SafeControl[@Assembly=\"System.Web.Silverlight, Version=2.0.5.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                     "configuration/SharePoint/SafeControls",
                                     "<SafeControl Assembly=\"System.Web.Silverlight, Version=2.0.5.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" Namespace=\"System.Web.UI.SilverlightControls\" TypeName=\"*\" Safe=\"True\" />",
                                     1,
                                     SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };

        private WebConfigModificationEntry[] silverlight3Entries = 
        {
            // assemblies section
            new WebConfigModificationEntry("add[@assembly=\"System.Web.Silverlight, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                      "configuration/system.web/compilation/assemblies",
                                      "<add assembly=\"System.Web.Silverlight, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                      1,
                                      SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

            // controls section
            new WebConfigModificationEntry("add[@tagPrefix=\"asp\"][@assembly=\"System.Web.Silverlight, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                     "configuration/system.web/pages/controls",
                                     "<add tagPrefix=\"asp\" namespace=\"System.Web.UI.SilverlightControls\" assembly=\"System.Web.Silverlight, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                     1,
                                     SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
        
           // Safe Controls
           new WebConfigModificationEntry("SafeControl[@Assembly=\"System.Web.Silverlight, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"]",
                                     "configuration/SharePoint/SafeControls",
                                     "<SafeControl Assembly=\"System.Web.Silverlight, Version=3.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\" Namespace=\"System.Web.UI.SilverlightControls\" TypeName=\"*\" Safe=\"True\" />",
                                     1,
                                     SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };
        #endregion

        #region Web Services entries
        private WebConfigModificationEntry[] webServicesEntries = 
        {
              new WebConfigModificationEntry("webServices",
                                             "configuration/system.web",
                                             "<webServices></webServices>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("protocols",
                                             "configuration/system.web/webServices",
                                             "<protocols></protocols>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@name=\"HttpGet\"]",
                                             "configuration/system.web/webServices/protocols",
                                             "<add name=\"HttpGet\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@name=\"HttpPost\"]",
                                             "configuration/system.web/webServices/protocols",
                                             "<add name=\"HttpPost\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };

        #endregion

        #region IIS7 entries
        private WebConfigModificationEntry[] IIS7Entries =
        {
           // AJAX System.webServer Section
              new WebConfigModificationEntry("system.webServer",
                                             "configuration",
                                             "<system.webServer></system.webServer>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("validation[@validateIntegratedModeConfiguration=\"false\"]",
                                             "configuration/system.webServer",
                                             "<validation validateIntegratedModeConfiguration=\"false\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("modules",
                                             "configuration/system.webServer",
                                             "<modules></modules>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
           
              new WebConfigModificationEntry("remove[@name=\"ScriptModule\"]",
                                             "configuration/system.webServer/modules",
                                             "<remove name=\"ScriptModule\" />",
                                             0,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
         
              new WebConfigModificationEntry("add[@name=\"ScriptModule\"][@preCondition=\"managedHandler\"]",
                                             "configuration/system.webServer/modules",                                   
                                             "<add name=\"ScriptModule\" preCondition=\"managedHandler\" type=\"System.Web.Handlers.ScriptModule, System.Web.Extensions, Version=3.5.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("remove[@name=\"ScriptModule\"]",
                                             "configuration/system.webServer/modules",
                                             "<remove name=\"ScriptModule\" />",
                                             0,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("handlers",
                                             "configuration/system.webServer",
                                             "<handlers></handlers>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
          
              new WebConfigModificationEntry("remove[@name=\"ScriptResource\"]",
                                             "configuration/system.webServer/handlers",
                                             "<remove name=\"ScriptResource\" />",
                                             0,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),      

              new WebConfigModificationEntry("remove[@name=\"ScriptHandlerFactoryAppServices\"]",
                                             "configuration/system.webServer/handlers",
                                             "<remove name=\"ScriptHandlerFactoryAppServices\" />",
                                             0,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("remove[@name=\"ScriptHandlerFactory\"]",
                                             "configuration/system.webServer/handlers",
                                             "<remove name=\"ScriptHandlerFactory\" />",
                                             0,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("../handlers[1=1]/remove[@name=\"WebServiceHandlerFactory-Integrated\"]",
                                             "configuration/system.webServer/handlers",
                                             "<remove name=\"WebServiceHandlerFactory-Integrated\" />",
                                             0,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@name=\"ScriptHandlerFactory\"]",
                                             "configuration/system.webServer/handlers",
                                             "<add name=\"ScriptHandlerFactory\" verb=\"*\" path=\"*.asmx\" preCondition=\"integratedMode\" type=\"System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@name=\"ScriptHandlerFactoryAppServices\"]",
                                             "configuration/system.webServer/handlers",
                                             "<add name=\"ScriptHandlerFactoryAppServices\" verb=\"*\" path=\"*_AppService.axd\" preCondition=\"integratedMode\" type=\"System.Web.Script.Services.ScriptHandlerFactory, System.Web.Extensions, Version=3.5.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),

              new WebConfigModificationEntry("add[@name=\"ScriptResource\"][@preCondition=\"integratedMode\"]",
                                             "configuration/system.webServer/handlers",
                                             "<add name=\"ScriptResource\" preCondition=\"integratedMode\" verb=\"GET,HEAD\" path=\"ScriptResource.axd\" type=\"System.Web.Handlers.ScriptResourceHandler, System.Web.Extensions, Version=3.5.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35\"/>",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode),
        };
        #endregion

        #region WCF Entries
        private WebConfigModificationEntry[] WcfEntries =
        {
           // <system.web><httpModules> Section
              new WebConfigModificationEntry("add[@name=\"WCFVirtualPathProviderRegistrationModule\"]",
                                             "configuration/system.web/httpModules",
                                             "<add name=\"WCFVirtualPathProviderRegistrationModule\" type=\"WCFLibrary.WCFVirtualPathProviderRegistrationModule, WCFLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=841f382b41c47c60\" />",
                                             1,
                                             SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode)
        };
        #endregion

        private XmlDocument WebConfig
        {
            get
            {
                if (webConfig == null)
                {
                    // get the physical path of the SharePoint web application
                    Dictionary<SPUrlZone, SPIisSettings> result = webApplication.IisSettings;
                    DirectoryInfo virtualDirectory = result[SPUrlZone.Default].Path;

                    if (virtualDirectory != null)
                    {
                        // open the web.config with XML
                        webConfig = new XmlDocument();
                        webConfig.Load(virtualDirectory.FullName + @"\web.config");
                    }
                }
                return webConfig;
            }
        }

        public bool CheckNet35Configuration(ref bool isConfigSectionConfigured,
               ref bool isWebConfigured, ref bool isAssemblyBindingsConfigured, ref bool isIIS7Configured)
        {
            bool isNet35Configured = false;

            isConfigSectionConfigured = CheckConfigModifications(configSections);
            isWebConfigured = CheckConfigModifications(WebEntries);
            isIIS7Configured = CheckConfigModifications(IIS7Entries);
            // this results always in a false because of the namespace
            //isAssemblyBindingsConfigured = CheckConfigModifications(assemblyBindings);

            if (isConfigSectionConfigured && isWebConfigured && isIIS7Configured)
                isNet35Configured = isAssemblyBindingsConfigured = true;

            return isNet35Configured;
        }

        public bool CheckSilverlightConfiguration(bool isSilverlight2Installed, bool isSilverlight3Installed)
        {
            bool isSilverlightConfigured = false;

            if (isSilverlight2Installed)
                isSilverlightConfigured = CheckConfigModifications(silverlight2Entries);
            else if (isSilverlight3Installed)
                isSilverlightConfigured = CheckConfigModifications(silverlight3Entries);

            return isSilverlightConfigured;
        }

        public bool CheckWcfConfiguration()
        {
            return CheckConfigModifications(WcfEntries);
        }

        private bool CheckConfigModifications(WebConfigModificationEntry[] entries)
        {
            bool isConfigured = false;
            if (WebConfig != null)
            {
                foreach (WebConfigModificationEntry entry in entries)
                {
                    XmlNode node = WebConfig.SelectSingleNode(entry.XPath);
                    if (node != null && node.ChildNodes != null && node.ChildNodes.Count > 0)
                    {
                        foreach (XmlNode child in node.ChildNodes)
                        {
                            if (child.OuterXml == entry.Value)
                            {
                                isConfigured = true;
                            }
                        }
                    }
                }
            }
            return isConfigured;
        }

        #region Configure Framework 3.5 Web Extensions modifications
        public void ConfigureWebExtensions(bool isConfigSectionConfigured)
        {
            // configure the configsection
            ConfigureModifications(configSections);

            // configure the Web Extensions
            ConfigureModifications(WebEntries);

            // configure the assembly bindings            
            ConfigureModifications(assemblyBindings);
        }

        public void ConfigureIISModifications()
        {
            ConfigureModifications(IIS7Entries);
        }

        public void RemoveWebExtensions()
        {
            RemoveModifications(configSections);
            RemoveModifications(WebEntries);
            RemoveModifications(assemblyBindings);
        }

        #endregion

        #region Configure Silverlight modifications
        public void ConfigureSilverlightModifications(bool isSilverlight2Installed, bool isSilverlight3Installed)
        {
            if (isSilverlight2Installed)
                ConfigureModifications(silverlight2Entries);
            else if (isSilverlight3Installed)
                ConfigureModifications(silverlight3Entries);
        }

        public void RemoveSilverlightModifications(bool isSilverlight2Installed, bool isSilverlight3Installed)
        {
            if (isSilverlight2Installed)
                RemoveModifications(silverlight2Entries);
            else if (isSilverlight3Installed)
                RemoveModifications(silverlight3Entries);
        }
        #endregion

        #region Configure WCF modifications
        public void ConfigureWcfModifications()
        {
            ConfigureModifications(WcfEntries);
        }

        public void RemoveWcfModifications()
        {
            RemoveModifications(WcfEntries);
        }

        #endregion

        public void UpdateWebConfigModifications()
        {
            if (updatesMade)
            {
                webApplication.Update();
                webApplication.WebService.Update();
                webApplication.WebService.ApplyWebConfigModifications();
            }
        }


        private void RemoveModifications(WebConfigModificationEntry[] entries)
        {
            Collection<SPWebConfigModification> ConfigModifications = webApplication.WebConfigModifications;
            int ConfigModificationsCount = ConfigModifications.Count;

            foreach(WebConfigModificationEntry entry in entries)
            {
                SPWebConfigModification configEntry = CreateModification(entry.Name, entry.XPath, entry.Value,
                    entry.PrioritySequence, entry.ModType);
                if (ConfigModifications.Contains(configEntry))
                {
                    ConfigModifications.Remove(configEntry);
                    updatesMade = true;
                }
            }
        }

        private void RemoveAllModifications()
        {
            Collection<SPWebConfigModification> ConfigModifications = webApplication.WebConfigModifications;
            int ConfigModificationsCount = ConfigModifications.Count;

            for (int i = ConfigModificationsCount - 1; i >= 0; i--)
            {
                SPWebConfigModification Mod = ConfigModifications[i];
                // check if this assembly is the owner                
                if (Mod.Owner.Equals(ModificationOwner))
                {
                    try
                    {
                        ConfigModifications.Remove(Mod);
                        updatesMade = true;
                    }
                    catch { /* Do nothing upon error */ }
                }
            }
        }

        private bool ConfigureModifications(WebConfigModificationEntry[] entries)
        {
            bool hasChanged = false;

            foreach (WebConfigModificationEntry entry in entries)
            {
                SPWebConfigModification modification = CreateModification(
                    entry.Name, entry.XPath, entry.Value, entry.PrioritySequence, entry.ModType);
                if (!webApplication.WebConfigModifications.Contains(modification))
                {
                    webApplication.WebConfigModifications.Add(modification);
                    updatesMade = true;
                    hasChanged = true;
                }
                //}
            }
            return hasChanged;
        }

        private SPWebConfigModification CreateModification(string Name, string XPath, string Value, uint PrioritySequence, SPWebConfigModification.SPWebConfigModificationType ModType)
        {
            SPWebConfigModification modification = new SPWebConfigModification(Name, XPath);
            // assign simple assembly name as modifcation owner
            modification.Owner = ModificationOwner;
            modification.Sequence = PrioritySequence;
            modification.Type = ModType;
            modification.Value = Value;
            return modification;
        }
    }
}
