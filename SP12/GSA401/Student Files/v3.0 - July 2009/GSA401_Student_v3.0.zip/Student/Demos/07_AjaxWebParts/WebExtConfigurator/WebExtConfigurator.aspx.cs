﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using System.IO;
using System.Xml;

using Microsoft.SharePoint;
using Microsoft.SharePoint.ApplicationPages;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.Win32;
using System.EnterpriseServices.Internal;
using System.Collections.ObjectModel;

namespace WebExtensionsConfigurator
{
    public class WebExtConfiguratorPage : GlobalAdminPageBase
    {
        static string silverlightAssemblyPath = null;

        protected Label MessageLabel;
        protected Button CancelButton;
        protected Button DisableButton;
        protected Button SubmitButton;
        protected CheckBoxList InstallationsCheckBoxList;
        protected CheckBoxList WebExtensionsCheckBoxList;


        protected WebApplicationSelector WebAppSelector;

        private SPWebApplication currentWebApp;
        private FileInfo copyWebConfig;

        private bool isConfigSectionConfigured = false;
        private bool isWebExtensionsConfigured = false;
        private bool isAssemblyBindingsConfigured = false;
        private bool isIIS7Configured = false;

        private bool isSilverlightConfigured = false;
        private bool isSilverlight2Installed = false;
        private bool isSilverlight3Installed = false;
        private string silverlightVersion;

        private bool isWcfConfigured = false;

        
        //private bool isConfigSectionOk = true;
        //private bool isWebConfigurationOK = true;
        //private bool isAssemblyBindingsOK = true;
        //private bool isIIS7ConfigurationOK = true;
        //private bool isSilverlightConfigurationOK = true;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }

        protected void WebAppSelector_OnContextChange(object sender, EventArgs e)
        {
            currentWebApp = WebAppSelector.CurrentItem;
            if (currentWebApp != null)
                CheckInstallations(true);
        }

        public void CancelButton_Click(object sender, System.EventArgs e)
        {
            // _admin\operations.aspx
            SPUtility.Redirect(SPContext.Current.Web.Url + "/_admin/operations.aspx", SPRedirectFlags.DoNotEncodeUrl, HttpContext.Current);

        }

        public void SubmitButton_Click(object sender, System.EventArgs e)
        {
            if (currentWebApp == null && WebAppSelector.CurrentItem != null)
                currentWebApp = WebAppSelector.CurrentItem;
            CheckInstallations(false);

            // get the physical path of the SharePoint web application
            Dictionary<SPUrlZone, SPIisSettings> result = currentWebApp.IisSettings;
            DirectoryInfo virtualDirectory = result[SPUrlZone.Default].Path;

            if (virtualDirectory != null)
            {
                // backup the existing web.config
                BackupWebConfig(virtualDirectory);

                WebConfigModificationManager mgr = new WebConfigModificationManager(currentWebApp);

                if (WebExtensionsCheckBoxList.Items[0].Selected || WebExtensionsCheckBoxList.Items[1].Selected)
                {
                    // configure web extensions 3.5 in web.config
                    mgr.ConfigureWebExtensions(isConfigSectionConfigured);

                    // check also if it is IIS 7, because this need extra configuration
                    if (CheckIIS7Installation())
                        mgr.ConfigureIISModifications();
                }
                else if (!WebExtensionsCheckBoxList.Items[0].Selected && isWebExtensionsConfigured)
                {
                    // remove Silverlight from the web.config
                    mgr.RemoveWebExtensions();
                }

                if (WebExtensionsCheckBoxList.Items[1].Selected)
                {
                    // configure silverlight in web.config
                    mgr.ConfigureSilverlightModifications(isSilverlight2Installed, isSilverlight3Installed);

                    // drop silverlight dll in GAC
                    if (!string.IsNullOrEmpty(silverlightAssemblyPath))
                    {
                        Publish publish = new Publish();
                        publish.GacInstall(silverlightAssemblyPath);
                    }
                }
                else if (!WebExtensionsCheckBoxList.Items[1].Selected && isSilverlightConfigured)
                {
                    // remove Silverlight from the web.config
                    mgr.RemoveSilverlightModifications(isSilverlight2Installed, isSilverlight3Installed);
                }

                if (WebExtensionsCheckBoxList.Items[2].Selected && !isWcfConfigured)
                {
                    // configure WCF Virtual Path provider in web.config
                    mgr.ConfigureWcfModifications();
                }
                else if (!WebExtensionsCheckBoxList.Items[2].Selected && isWcfConfigured)
                {
                    // remove WCF Virtual Path provider in web.config
                    mgr.RemoveWcfModifications();
                }

                // save the enries that could be added by using SPWebConfigModifications
                mgr.UpdateWebConfigModifications();

                // redirect to the operations page
                SPUtility.Redirect(SPContext.Current.Web.Url + "/_admin/operations.aspx", SPRedirectFlags.DoNotEncodeUrl, HttpContext.Current);
            }
        }

        #region Check Installations
        private void CheckInstallations(bool setConfigurationChecks)
        {
            MessageLabel.Visible = false;
            WebConfigModificationManager mgr = new WebConfigModificationManager(currentWebApp);

            // Check if the necessary installations are done
            // 1. are Web Extensions 3.5 installed?
            InstallationsCheckBoxList.Items[0].Selected = CheckNetFrameworkInstallation();

            // 2. is Silverlight runtime installed?
            InstallationsCheckBoxList.Items[1].Selected = CheckSilverlightRuntimeInstallation(
                ref isSilverlight2Installed, ref isSilverlight3Installed);
            InstallationsCheckBoxList.Items[1].Text = string.Format(InstallationsCheckBoxList.Items[1].Text, silverlightVersion);

            // 3. is Silverlight SDK installed?
            InstallationsCheckBoxList.Items[2].Selected = CheckSilverlightSDKInstallation();

            // take the necessary decissions based on the installations
            if (InstallationsCheckBoxList.Items[0].Selected
                && InstallationsCheckBoxList.Items[1].Selected
                && InstallationsCheckBoxList.Items[2].Selected)
            {
                // check if web extensions 3.5 is configured in the web.config
                bool isNet35Configured = mgr.CheckNet35Configuration(ref isConfigSectionConfigured,
                    ref isWebExtensionsConfigured, ref isAssemblyBindingsConfigured, ref isIIS7Configured);

                // check if silverlight is configured in the web.config
                isSilverlightConfigured =
                    mgr.CheckSilverlightConfiguration(isSilverlight2Installed, isSilverlight3Installed);

                // check if the WCF http module for the Virtual Path Provider is configured in the web.config
                isWcfConfigured = mgr.CheckWcfConfiguration();

                if (setConfigurationChecks)
                {
                    if (isConfigSectionConfigured && isWebExtensionsConfigured && isAssemblyBindingsConfigured
                        && isAssemblyBindingsConfigured)
                        WebExtensionsCheckBoxList.Items[0].Selected = true;
                    else
                        WebExtensionsCheckBoxList.Items[0].Selected = false;

                    WebExtensionsCheckBoxList.Items[1].Selected = isSilverlightConfigured;
                    WebExtensionsCheckBoxList.Items[2].Selected = isWcfConfigured;
                }
            }
            else
            {
                WebExtensionsCheckBoxList.Enabled = false;
                MessageLabel.Text = "Your SharePoint web application(s) cannot be configured for use with the Web Extensions 3.5 "
                    + "or Silvelight because the necessary installations are not performed. Read more on the help page.";
                MessageLabel.Visible = true;
            }
        }

        private bool CheckNetFrameworkInstallation()
        {
            bool isNet35Installed = false;

            string keyname = @"SOFTWARE\Microsoft\NET Framework Setup\NDP\v3.5";
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyname))
            {
                if (key != null)
                {
                    string version = key.GetValue("Version") as string;
                    if (version != null)
                    {
                        Version buildVersion = new Version(version);
                        if (buildVersion.Major == 3 && buildVersion.Minor == 5)
                        {
                            isNet35Installed = true;
                        }
                    }
                }
            }
            return isNet35Installed;
        }

        private bool CheckSilverlightRuntimeInstallation(ref bool isSilverlight2Installed, 
            ref bool isSilverlight3Installed)
        {
            bool isSilverlightRuntimeInstalled = false;
            isSilverlight2Installed = false;
            isSilverlight3Installed = false;

            string keyname = @"SOFTWARE\Microsoft\Silverlight";
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyname))
            {
                if (key != null)
                {
                    silverlightVersion = key.GetValue("Version") as string;
                    if (silverlightVersion != null)
                    {
                        Version buildVersion = new Version(silverlightVersion);
                        switch (buildVersion.Major)
                        {
                            case 2:
                                isSilverlightRuntimeInstalled = true;
                                isSilverlight2Installed = true;
                                break;
                            case 3:
                                isSilverlightRuntimeInstalled = true;
                                isSilverlight3Installed = true;
                                break;
                        }
                    }
                }
            }
            return isSilverlightRuntimeInstalled;
        }

        private bool CheckSilverlightSDKInstallation()
        {
            bool isSilverlightSdkInstalled = false;
            string keyname = @"SOFTWARE\Microsoft\Microsoft SDKs\Silverlight\";

            if (isSilverlight2Installed)
                keyname += "v2.0";
            else if (isSilverlight3Installed)
                keyname += "v3.0";

            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyname))
            {
                if (key != null)
                {
                    string version = key.GetValue("Version") as string;
                    if (version != null)
                    {
                        Version buildVersion = new Version(version);
                        if (isSilverlight2Installed && buildVersion.Major == 2)
                            isSilverlightSdkInstalled = true;
                        else if (isSilverlight3Installed && buildVersion.Major == 3)
                            isSilverlightSdkInstalled = true;
                    }
                }
            }

            // while in the Registry for Silerlight, get the installation path
            keyname = keyname + @"\Install Path";
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyname))
            {
                if (key != null)
                {
                    silverlightAssemblyPath = key.GetValue("Install Path") as string;
                }
            }

            return isSilverlightSdkInstalled;
        }

        private bool CheckIIS7Installation()
        {
            bool isIIS7 = false;
            string keyname = @"SOFTWARE\Microsoft\InetStp";
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyname))
            {
                if (key != null)
                {
                    string version = key.GetValue("SetupString") as string;
                    if (version != null && version == "IIS 7.0")
                    {
                        isIIS7 = true;
                    }
                }
            }
            return isIIS7;
        }


        #endregion

        private void BackupWebConfig(DirectoryInfo virtualDirectory)
        {
            if (virtualDirectory != null)
            {
                // check if there is a backup file
                FileInfo backupFile = new FileInfo(virtualDirectory.FullName + @"\web.bak");
                if (backupFile.Exists)
                {
                    // rename the backup file
                    string newBackupName = "web_{0}.bak";
                    string datestring = backupFile.CreationTime.Year.ToString() + "_"
                        + backupFile.CreationTime.Month.ToString() + "_"
                        + backupFile.CreationTime.Day.ToString() + "_"
                        + backupFile.CreationTime.Hour.ToString() + "_"
                        + backupFile.CreationTime.Minute.ToString() + "_"
                        + backupFile.CreationTime.Second.ToString();
                    newBackupName = string.Format(newBackupName, datestring);
                    FileInfo newBackupFile = new FileInfo(virtualDirectory.FullName + @"\" + newBackupName);
                    if (newBackupFile.Exists)
                        newBackupFile.Delete();
                    backupFile.CopyTo(virtualDirectory.FullName + @"\" + newBackupName);
                    backupFile.Delete();
                }

                FileInfo webconfigFile = new FileInfo(virtualDirectory.FullName + @"\web.config");
                if (webconfigFile.Exists)
                {
                    // Save a local copy of the web.config so that it can be used when rollbacking
                    copyWebConfig = webconfigFile;

                    // make a copy of the web config
                    webconfigFile.CopyTo(virtualDirectory.FullName + @"\web.bak");
                }
            }
        }
    }
}
