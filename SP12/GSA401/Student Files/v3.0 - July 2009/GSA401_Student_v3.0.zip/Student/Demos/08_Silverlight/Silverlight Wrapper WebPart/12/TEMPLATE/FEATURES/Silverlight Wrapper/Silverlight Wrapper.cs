﻿using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.ComponentModel;
using System.Web.UI.HtmlControls;

namespace SilverlightWrapper
{
    [Guid("d3beb6e8-2f44-4f7a-a3bf-08ccf2147852")]
    public class SilverlightWrapperWebPart : System.Web.UI.WebControls.WebParts.WebPart
    {
        public SilverlightWrapperWebPart()
        {
        }

        private string source;
        private string initParams;
        private HtmlInputHidden urlField;
        private System.Web.UI.SilverlightControls.Silverlight silverlightControl = null;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            // Script manager instance may appear only once on a page
            ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
            if (scriptManager == null)
            {
                scriptManager = new ScriptManager();
                this.Controls.AddAt(0, scriptManager);
            }
        }

        [Personalizable(PersonalizationScope.Shared),
           WebBrowsable(true),
           WebDisplayName("Silverlight Source"),
           WebDescription("Relative path to the Silverlight application, f.e. /XAPS/SL.HelloWorld.xap:"),
           Category("Binding")]
        public string Source
        {
            get { return source; }
            set { source = value; }
        }

        [Personalizable(PersonalizationScope.Shared),
           WebBrowsable(true),
           WebDisplayName("Silverlight Parameters"),
           WebDescription("Silverlight initparams"),
           Category("Binding")]
        public string InitParams
        {
            get { return initParams; }
            set { initParams = value; }
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            EnsureChildControls();
            if (silverlightControl != null)
                silverlightControl.RenderControl(writer);
        }

        protected override void CreateChildControls()
        {
            // instantiation of the silverlight control
            silverlightControl = new System.Web.UI.SilverlightControls.Silverlight();
            silverlightControl.ID = "Silverlight1";
            silverlightControl.MinimumVersion = "2.0.31005.0";
            silverlightControl.Width = new System.Web.UI.WebControls.Unit(600);
            silverlightControl.Height = new System.Web.UI.WebControls.Unit(300);
            silverlightControl.Source = Source;
            if (!string.IsNullOrEmpty(InitParams))
                silverlightControl.InitParameters = InitParams;

            this.Controls.Add(silverlightControl);
        }
    }
}
