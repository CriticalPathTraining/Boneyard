﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SL.XAML.BookViewer
{
    public partial class Rotator : UserControl
    {
        public Rotator()
        {
            InitializeComponent();
            LoadingCanvas.Loaded += new RoutedEventHandler(LoadingCanvas_Loaded);
        }

        private void LoadingCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            Storyboard storyboard = FindName("LoadingAnimation") as Storyboard;
            if (storyboard != null)
                storyboard.Begin();
        }

        public string Text
        {
            get { return LoadingTextBlock.Text; }
            set { LoadingTextBlock.Text = value; }
        }

        public void StopLoader()
        {
            Storyboard storyboard = FindName("LoadingAnimation") as Storyboard;
            if (storyboard != null)
                storyboard.Stop();
        }

        public void StartLoader()
        {
            Storyboard storyboard = FindName("LoadingAnimation") as Storyboard;
            if (storyboard != null)
                storyboard.Begin();
        }
    }
}
