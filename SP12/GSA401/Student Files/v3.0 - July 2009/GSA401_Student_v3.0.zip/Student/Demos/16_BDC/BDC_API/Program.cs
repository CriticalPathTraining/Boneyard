using System;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Office.Server.ApplicationRegistry.Runtime;
using Microsoft.Office.Server.ApplicationRegistry.Infrastructure;
using Microsoft.Office.Server.ApplicationRegistry.MetadataModel;
using Microsoft.Office.Server.ApplicationRegistry.SystemSpecific.Db;
using Microsoft.Office;

namespace BDC_API {
  class Program {
    static void Main() {

      SqlSessionProvider.Instance().SetSharedResourceProviderToUse("Litware SSP");
      NamedLobSystemInstanceDictionary ApplicationInstances = ApplicationRegistry.GetLobSystemInstances();
      LobSystemInstance BdcApplication = ApplicationInstances["AdventureWorks"];
      Entity ProductEntity = BdcApplication.GetEntities()["Product"];
      Console.WriteLine("Entity Name: " + ProductEntity.Name);
      Console.WriteLine();
      Console.WriteLine("Looking for product information...");
      int ProductKey = 486;
      IEntityInstance ProductEntityInstance = ProductEntity.FindSpecific(ProductKey, BdcApplication);
      Console.WriteLine("Product key: " + ProductEntityInstance["ProductKey"].ToString());
      Console.WriteLine("Product name: " + ProductEntityInstance["EnglishProductName"].ToString());
      Console.WriteLine("Standard cost: " + ProductEntityInstance["StandardCost"].ToString());
      Console.WriteLine("List price: " + ProductEntityInstance["ListPrice"].ToString());

      Console.ReadLine();
    }
  }
}
