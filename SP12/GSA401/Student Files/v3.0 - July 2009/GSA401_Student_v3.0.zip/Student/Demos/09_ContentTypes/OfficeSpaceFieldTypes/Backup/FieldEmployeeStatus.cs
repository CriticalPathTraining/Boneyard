﻿using System;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;


namespace OfficeSpaceFieldTypes {

  public class FieldEmployeeStatus : SPFieldText {
    public FieldEmployeeStatus(SPFieldCollection fields, string fieldName)
      : base(fields, fieldName) { }

    public FieldEmployeeStatus(SPFieldCollection fields, string typeName, string displayName)
      : base(fields, typeName, displayName) { }

    public override BaseFieldControl FieldRenderingControl {
      get {
        BaseFieldControl ctr = new EmployeeStatusFieldControl();
        ctr.FieldName = this.InternalName;
        return ctr;
      }
    }
    public override string DefaultValue {
      get {
        return "Full-time Employee";
      }
    }
  }

  public class EmployeeStatusFieldControl : BaseFieldControl {
    protected RadioButtonList lstEmployeeStatus;
    protected override string DefaultTemplateName {
      get {
        return "EmployeeStatusRenderingTemplate";
      }
    }

    protected override void CreateChildControls() {
      base.CreateChildControls();
      lstEmployeeStatus = (RadioButtonList)TemplateContainer.FindControl("lstEmployeeStatus");
      if (lstEmployeeStatus != null) {
        lstEmployeeStatus.Items.Clear();
        lstEmployeeStatus.Items.Add("Full-time Employee");
        lstEmployeeStatus.Items.Add("Part-time Employee");
        // check to see if contractors are allowed
        bool AllowContactors = (bool)this.Field.GetCustomProperty("AllowContractors");
        if (AllowContactors) {
          lstEmployeeStatus.Items.Add("Contractor");
        }
        // check to see if interns are allowed
        bool AllowInterns = (bool)this.Field.GetCustomProperty("AllowInterns");
        if (AllowInterns) {
          lstEmployeeStatus.Items.Add("Intern");
        }
      }
    }

    public override object Value {
      get {
        this.EnsureChildControls();
        return lstEmployeeStatus.SelectedValue;
      }
      set {
        this.EnsureChildControls();
        lstEmployeeStatus.Items.FindByValue(ItemFieldValue.ToString()).Selected = true;
      }
    }
  }
}
