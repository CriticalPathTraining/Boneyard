using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint.Navigation;
using Microsoft.SharePoint.Administration;

namespace AuditingDemo {
  public class FeatureReceiver : SPFeatureReceiver {

    public SPRoleDefinition CreatePermissionLevel(string Name, string Description) {
      return CreatePermissionLevel(Name, Description, string.Empty, SPBasePermissions.EmptyMask);
    }

    public SPRoleDefinition CreatePermissionLevel(string Name, string Description, string PermissionLevelCopySource) {
      return CreatePermissionLevel(Name, Description, PermissionLevelCopySource, SPBasePermissions.EmptyMask);
    }

    public SPRoleDefinition CreatePermissionLevel(string Name, string Description, string PermissionLevelCopySource, SPBasePermissions ExtraPermissions) {
      SPWeb TopLevelSite = SPContext.Current.Site.RootWeb;
      SPRoleDefinitionCollection PermissionLevels = TopLevelSite.RoleDefinitions;
      // delete permission level if it already exists
      foreach (SPRoleDefinition PermissionLevel in PermissionLevels) {
        if (PermissionLevel.Name.Equals(Name)) {
          PermissionLevels.DeleteById(PermissionLevel.Id);
          break;
        }
      }
      // add new permission level
      SPRoleDefinition NewPermissionLevel = null;
      if (string.IsNullOrEmpty(PermissionLevelCopySource)) {
        NewPermissionLevel = new SPRoleDefinition();
      }
      else {
        NewPermissionLevel = new SPRoleDefinition(TopLevelSite.RoleDefinitions[PermissionLevelCopySource]);
      }
      NewPermissionLevel.Name = Name;
      NewPermissionLevel.Description = Description;
      NewPermissionLevel.BasePermissions |= ExtraPermissions;
      PermissionLevels.Add(NewPermissionLevel);
      TopLevelSite.Update();
      // return new SPRoleDefinition object
      return TopLevelSite.RoleDefinitions[Name];
    }

    public SPGroup CreateGroup(string GroupName, string GroupDescription) {
      SPWeb TopLevelSite = SPContext.Current.Site.RootWeb;
      SPGroupCollection siteGroups = TopLevelSite.SiteGroups;
      SPUser siteCollectionOwner = SPContext.Current.Site.Owner;
      // delete group if it already exists
      foreach (SPGroup group in siteGroups) {
        if (group.Name.Equals(GroupName)) {
          siteGroups.RemoveByID(group.ID);
          break;
        }
      }
      // add new group      
      siteGroups.Add(GroupName, siteCollectionOwner, siteCollectionOwner, GroupDescription);
      SPGroup newGroup = siteGroups[GroupName];      
      TopLevelSite.AssociatedGroups.Add(newGroup);
      string AssociateMemberGroup = TopLevelSite.Properties["vti_associatemembergroup"];
      if (string.IsNullOrEmpty(AssociateMemberGroup)) {
        AssociateMemberGroup = newGroup.ID.ToString();
      }
      else {
        AssociateMemberGroup += ";" + newGroup.ID.ToString();
      }
      TopLevelSite.Properties["vti_associatemembergroup"] = AssociateMemberGroup;
      TopLevelSite.Update();
      return siteGroups[GroupName];
    }

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      using (SPSite siteCollection = (SPSite)properties.Feature.Parent) {
        SPWeb TopLevelSite = siteCollection.RootWeb;
        // Turn on auditing flags.
        siteCollection.Audit.AuditFlags = SPAuditMaskType.All;
        siteCollection.Audit.Update();
        // create permission levels 
        SPRoleDefinition AuditorPermissions, AuditManagerPermissions;
        AuditorPermissions = CreatePermissionLevel("Auditor Permissions",
                                                   "Can view audit logs",
                                                   "Read");
        AuditManagerPermissions = CreatePermissionLevel("Audit Manager Permissions",
                                                        "Can view audit logs and configure auditing support",
                                                        "Design",
                                                        SPBasePermissions.ManageWeb);
        // create Auditors group
        SPGroup Auditors = CreateGroup("Auditors", "A SharePoint group for those that need to audit activity");
        SPRoleAssignment AuditorRoleAssignment = new SPRoleAssignment(Auditors);
        AuditorRoleAssignment.RoleDefinitionBindings.Add(AuditorPermissions);
        TopLevelSite.RoleAssignments.Add(AuditorRoleAssignment);

        // create Audit Managers group
        SPGroup AuditManagers = CreateGroup("Audit Managers", "A SharePoint group for those that need to configure WSS auditing support");
        SPRoleAssignment AuditManagerRoleAssignment = new SPRoleAssignment(AuditManagers);
        AuditManagerRoleAssignment.RoleDefinitionBindings.Add(AuditManagerPermissions);
        TopLevelSite.RoleAssignments.Add(AuditManagerRoleAssignment);       

      }
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      using (SPSite siteCollection = (SPSite)properties.Feature.Parent) {
        // Turn off auditing flags.
        siteCollection.Audit.AuditFlags = SPAuditMaskType.None;
        siteCollection.Audit.Update();
      }
    }
    public override void FeatureInstalled(SPFeatureReceiverProperties properties) {/* no op */}
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) {/* no op */}
  }
}
