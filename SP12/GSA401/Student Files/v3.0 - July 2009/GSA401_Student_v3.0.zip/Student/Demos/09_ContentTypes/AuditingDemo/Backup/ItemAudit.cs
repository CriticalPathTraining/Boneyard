using System;
using System.Data;
using System.IO;
using System.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace AuditingDemo {

  public class ItemAudit : LayoutsPageBase {

    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected Label lblListId;
    protected Label lblItemId;
    protected Label lblListTitle;
    protected Label lblItemTitle;
    protected Label lblItemUrl;
    protected SPGridView SPGridView1;

    protected void Page_Load(object sender, EventArgs e) {

      SPSite siteColl = SPContext.Current.Site;
      SPWeb site = SPContext.Current.Web;

      // create page titles and description
      PageTitle = "Audit Log for Item";
      PageTitleInArea = "Audit Log for Item";
      PageDescription = "This page is used to view the audit log for activity for one specific item";


      string ListId = Request.QueryString["ListId"];
      string ItemId = Request.QueryString["ItemId"];
      lblListId.Text = ListId;
      lblItemId.Text = ItemId;


      SPList list1 = site.Lists[new Guid(ListId)];
      SPListItem item1 = list1.Items.GetItemById(Convert.ToInt32(ItemId));
      item1.Audit.WriteAuditEvent(SPAuditEventType.Custom, "CustomViewAuditEvent", "");

      SPSecurity.RunWithElevatedPrivileges(delegate() {
        using (SPSite ElevatedSiteCollection = new SPSite(siteColl.ID)) {
          using (SPWeb ElevatedSite = ElevatedSiteCollection.OpenWeb(site.ID)) {
            SPList list = ElevatedSite.Lists[new Guid(ListId)];

            lblListTitle.Text = list.Title;
            SPListItem item = list.Items.GetItemById(Convert.ToInt32(ItemId));
            lblItemTitle.Text = item.Name;
            lblItemUrl.Text = item.Url;

            SPAuditQuery wssQuery;
            SPAuditEntryCollection auditCol;

            wssQuery = new SPAuditQuery(ElevatedSiteCollection);
            wssQuery.RestrictToListItem(item);
            auditCol = ElevatedSite.Audit.GetEntries(wssQuery);

            DataTable table = new DataTable();
            table.Columns.Add("User", typeof(string));
            table.Columns.Add("Event", typeof(string));
            table.Columns.Add("Occurred", typeof(DateTime));
            table.Columns.Add("EventSource", typeof(string));
            table.Columns.Add("Version", typeof(string));

            DataRow newRow;

            foreach (SPAuditEntry entry in auditCol) {
              newRow = table.Rows.Add();
              newRow["User"] = GetUserNameById(entry.UserId, site);
              if (entry.SourceName == "CustomViewAuditEvent") {
                newRow["Event"] = "View Audit Log";
              }
              else {
                newRow["Event"] = entry.Event;
              }
              newRow["Occurred"] = entry.Occurred.ToLocalTime();
              newRow["EventSource"] = entry.EventSource;
              newRow["Version"] = ParseVersionNumber(entry.EventData);
            }

            SPBoundField boundField = new SPBoundField();
            boundField.HeaderText = "User";
            boundField.DataField = "User";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Occurred";
            boundField.DataField = "Occurred";
            boundField.ControlStyle.Width = new Unit(140);
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Event";
            boundField.DataField = "Event";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Event Source";
            boundField.DataField = "EventSource";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Version";
            boundField.DataField = "Version";
            SPGridView1.Columns.Add(boundField);

            SPGridView1.AutoGenerateColumns = false;
            SPGridView1.DataSource = table.DefaultView;
            SPGridView1.DataBind();

            SPGridView1.AllowSorting = true;
            SPGridView1.HeaderStyle.Font.Bold = true;
          }
        }
      });
    }

    string GetUserNameById(int UserId, SPWeb site) {
      try {
        return site.SiteUsers.GetByID(UserId).Name;
      }
      catch {
        return UserId.ToString();
      }
    }

    protected string ParseVersionNumber(string versionString) {
      try {
        int startMajor = versionString.IndexOf("<Major>") + 7;
        int endMajor = versionString.IndexOf("</Major>");
        int lengthMajor = endMajor - startMajor;
        int startMinor = versionString.IndexOf("<Minor>") + 7;
        int endMinor = versionString.IndexOf("</Minor>");
        int lengthMinor = endMinor - startMinor;

        string majorNumber = versionString.Substring(startMajor, lengthMajor);
        string minorNumber = versionString.Substring(startMinor, lengthMinor);

        if (majorNumber == "0" && minorNumber == "-1")
          return "N/A";

        return majorNumber + "." + minorNumber;
      }
      catch {
        return "N/A";
      }
    }

  }
}
