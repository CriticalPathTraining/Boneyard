using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace AuditingDemo {

  public class AuditLogViewer : LayoutsPageBase {

    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected Button cmdDeleteAllEntries;
    protected SPGridView SPGridView1;

    protected override void OnLoad(EventArgs e) {

      // only show delete button to site collection owner
      cmdDeleteAllEntries.Visible = SPContext.Current.Web.CurrentUser.IsSiteAdmin;

      // create page titles and description
      PageTitle = "Audit Log Viewer";
      PageTitleInArea = "Audit Log Viewer";
      PageDescription = "This page is used to view the audit log for the site collection at  " + this.Site.Url;

      // read audit log
      SPSecurity.RunWithElevatedPrivileges(delegate() {
        using (SPSite siteColl = new SPSite(SPContext.Current.Site.ID)) {
          using (SPWeb site = siteColl.OpenWeb(SPContext.Current.Web.ID)) {
              SPAuditQuery wssQuery = new SPAuditQuery(siteColl);
              SPAuditEntryCollection auditCol = siteColl.Audit.GetEntries(wssQuery);
            DataTable table = new DataTable();
            table.Columns.Add("User", typeof(string));
            table.Columns.Add("Event", typeof(string));
            table.Columns.Add("ItemType", typeof(string));
            table.Columns.Add("DocLocation", typeof(string));
            table.Columns.Add("Occurred", typeof(DateTime));
            table.Columns.Add("EventSource", typeof(string));
            DataRow newRow;
            foreach (SPAuditEntry entry in auditCol) {
              newRow = table.Rows.Add();
              newRow["User"] = GetUserNameById(entry.UserId, site);
              newRow["Event"] = entry.Event;
              newRow["ItemType"] = entry.ItemType.ToString();
              newRow["DocLocation"] = entry.DocLocation;
              newRow["Occurred"] = entry.Occurred.ToLocalTime();
              newRow["EventSource"] = entry.EventSource;

            }

            SPBoundField boundField = new SPBoundField();
            boundField.HeaderText = "User";
            boundField.DataField = "User";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Event";
            boundField.DataField = "Event";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "ItemType";
            boundField.DataField = "ItemType";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "DocLocation";
            boundField.DataField = "DocLocation";
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Occurred";
            boundField.DataField = "Occurred";
            boundField.ControlStyle.Width = new Unit(120);
            SPGridView1.Columns.Add(boundField);

            boundField = new SPBoundField();
            boundField.HeaderText = "Event Source";
            boundField.DataField = "EventSource";
            SPGridView1.Columns.Add(boundField);

            SPGridView1.AutoGenerateColumns = false;
            SPGridView1.DataSource = table.DefaultView;
            SPGridView1.DataBind();

            SPGridView1.AllowSorting = true;
            SPGridView1.HeaderStyle.Font.Bold = true;
          }
        }
      });    
    }

    string GetUserNameById(int UserId, SPWeb site) {
      if (UserId == -1) {
        return @"SHAREPOINT\System";
      }
      else {
        return site.AllUsers.GetByID(UserId).Name;        
      }
        
    }

    protected void cmdDeleteAllEntries_Click(object sender, EventArgs e) {
      SPSite siteColl = SPContext.Current.Site;
      siteColl.Audit.DeleteEntries(DateTime.Now.ToLocalTime().AddDays(1));
      siteColl.Audit.Update();
      Response.Redirect(Request.RawUrl);
    }

    protected void cmdRefreshPage_Click(object sender, EventArgs e) {
      Response.Redirect(Request.RawUrl);
    }    
  }
}
