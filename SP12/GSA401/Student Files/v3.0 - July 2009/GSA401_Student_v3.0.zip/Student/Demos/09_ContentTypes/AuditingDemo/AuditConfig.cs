using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace AuditingDemo {

  public class AuditConfig : LayoutsPageBase {

    protected string PageTitle;
    protected string PageTitleInArea;
    protected string PageDescription;

    protected RadioButton radAuditingOff;
    protected RadioButton radAuditingOnFull;
    protected RadioButton radAuditingOnSelective;

    protected Panel pnlSelectiveAuditControls;

    protected CheckBox chkAuditView;
    protected CheckBox chkAuditUpdate;
    protected CheckBox chkAuditCopy;
    protected CheckBox chkAuditMove;
    protected CheckBox chkAuditDelete;
    protected CheckBox chkAuditUndelete;
    protected CheckBox chkAuditCheckIn;
    protected CheckBox chkAuditCheckOut;
    protected CheckBox chkAuditSearch;
    protected CheckBox chkAuditWorkflow;
    protected CheckBox chkAuditSecurityChange;
    protected CheckBox chkAuditProfileChange;
    protected CheckBox chkAuditSchemaChange;

    protected override void OnLoad(EventArgs e) {
      // create page titles and description
      PageTitle = "Auditing Configuration";
      PageTitleInArea = "Auditing Configuration";
      PageDescription = "This page is used to configure auditing support for current site collection at " + this.Site.Url;
    }

    protected void cmdCancel_OnClick(object sender, EventArgs e) {
      SPUtility.Redirect("settings.aspx",
                         SPRedirectFlags.RelativeToLayoutsPage,
                         HttpContext.Current);
    }

    protected void cmdSubmit_OnClick(object sender, EventArgs e) {

      SPSite siteCollection = this.Site;

      if (radAuditingOff.Checked) {
        siteCollection.Audit.AuditFlags = SPAuditMaskType.None;
      }

      if (radAuditingOnFull.Checked) {
        siteCollection.Audit.AuditFlags = SPAuditMaskType.All;
      }

      if (radAuditingOnSelective.Checked) {
        siteCollection.Audit.AuditFlags = GetSelectiveAuditingFlags();
      }

      siteCollection.Audit.Update();

      SPUtility.Redirect("settings.aspx",
                         SPRedirectFlags.RelativeToLayoutsPage,
                         HttpContext.Current);
    
    }

    protected SPAuditMaskType GetSelectiveAuditingFlags() {

      SPAuditMaskType AuditFlags = SPAuditMaskType.None;

      if (chkAuditView.Checked) {
        AuditFlags |= SPAuditMaskType.View;
      }

      if (chkAuditUpdate.Checked) {
        AuditFlags |= SPAuditMaskType.Update;
      }

      if (chkAuditCopy.Checked) {
        AuditFlags |= SPAuditMaskType.Copy;
      }

      if (chkAuditMove.Checked) {
        AuditFlags |= SPAuditMaskType.Move;
      }

      if (chkAuditDelete.Checked) {
        AuditFlags |= SPAuditMaskType.Delete;
      }

      if (chkAuditUndelete.Checked) {
        AuditFlags |= SPAuditMaskType.Undelete;
      }

      if (chkAuditCheckIn.Checked) {
        AuditFlags |= SPAuditMaskType.CheckIn;
      }

      if (chkAuditCheckOut.Checked) {
        AuditFlags |= SPAuditMaskType.CheckOut;
      }

      if (chkAuditSearch.Checked) {
        AuditFlags |= SPAuditMaskType.Search;
      }

      if (chkAuditWorkflow.Checked) {
        AuditFlags |= SPAuditMaskType.Workflow;
      }

      if (chkAuditSecurityChange.Checked) {
        AuditFlags |= SPAuditMaskType.SecurityChange;
      }

      if (chkAuditProfileChange.Checked) {
        AuditFlags |= SPAuditMaskType.ProfileChange;
      }

      if (chkAuditSchemaChange.Checked) {
        AuditFlags |= SPAuditMaskType.SchemaChange;
      }

      return AuditFlags;
    }

    protected override void OnPreRender(EventArgs e) {
      InitializeSelectiveAuditingControls();
      switch (this.Site.Audit.AuditFlags) {
        case SPAuditMaskType.None:
          radAuditingOff.Checked = true;
          pnlSelectiveAuditControls.Enabled = false;
          break;
        case SPAuditMaskType.All:
          radAuditingOnFull.Checked = true;
          pnlSelectiveAuditControls.Enabled = false;
          break;
        default:
          radAuditingOnSelective.Checked = true;
          pnlSelectiveAuditControls.Enabled = true;
          break;
      }
    }

    protected void InitializeSelectiveAuditingControls() {
      chkAuditView.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.View) != 0);
      chkAuditUpdate.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Update) != 0);
      chkAuditCopy.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Copy) != 0);
      chkAuditMove.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Move) != 0);
      chkAuditDelete.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Delete) != 0);
      chkAuditUndelete.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Undelete) != 0);
      chkAuditCheckIn.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.CheckIn) != 0);
      chkAuditCheckOut.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.CheckOut) != 0);
      chkAuditSearch.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Search) != 0);
      chkAuditWorkflow.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.Workflow) != 0);
      chkAuditSecurityChange.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.SecurityChange) != 0);
      chkAuditProfileChange.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.ProfileChange) != 0);
      chkAuditSchemaChange.Checked = ((Site.Audit.AuditFlags & SPAuditMaskType.SchemaChange) != 0);
    }



  }
}
