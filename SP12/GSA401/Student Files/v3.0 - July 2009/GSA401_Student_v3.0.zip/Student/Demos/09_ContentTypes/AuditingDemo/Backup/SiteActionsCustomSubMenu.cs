using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Web.UI.WebControls;

namespace AuditingDemo {

public class SiteActionsCustomSubMenu : WebControl {

  protected override void OnLoad(EventArgs e) {
    this.EnsureChildControls();
    base.OnLoad(e);
  }

  protected override void CreateChildControls() {

    SPSite siteCollection = SPContext.Current.Site;
    SPWeb site = SPContext.Current.Web;
    SPUser user = site.CurrentUser;
    // provide security trimming
    if (IsCurrentUserInGroup("Auditors") ||
        IsCurrentUserInGroup("Audit Managers") ||
        user.IsSiteAdmin) {

      string siteCollectionPath = siteCollection.Url;
      if (!siteCollectionPath.EndsWith(@"/"))
        siteCollectionPath += "/";

      SubMenuTemplate smt = new SubMenuTemplate();
      smt.Text = "Auditing Support";
      smt.ID = "mnuAuditingSupport";
      smt.Description = "Configure and View Auditing";
      smt.ImageUrl = siteCollectionPath +
                     @"_layouts/images/AuditingDemo/AfricanPith32.gif";
      smt.Sequence = 400;

      MenuItemTemplate mit1 = new MenuItemTemplate();
      mit1.ID = "mnuAuditLog";
      mit1.Text = "Audit Log";
      mit1.Description = "Inspect Audit Entries";
      mit1.Sequence = 401;
      mit1.ClientOnClickNavigateUrl = siteCollectionPath +
                                      "_layouts/AuditingDemo/AuditLogViewer.aspx";
      mit1.ImageUrl = siteCollectionPath +
                      @"_layouts/images/AuditingDemo/Binoculars32.gif";
      // add menu item to Controls collection
      smt.Controls.Add(mit1);
      // perform extra security trimming for menu for AuditConfig.aspx
      if (IsCurrentUserInGroup("Audit Managers") ||
          user.IsSiteAdmin) {
        MenuItemTemplate mit2 = new MenuItemTemplate();
        mit2.ID = "mnuAuditingConfiguration";
        mit2.Text = "Auditing Configuration";
        mit2.Description = "Enable/Disable Auditing";
        mit2.Sequence = 402;
        mit2.ClientOnClickNavigateUrl = siteCollectionPath +
                                        "_layouts/AuditingDemo/AuditConfig.aspx";
        mit2.ImageUrl = siteCollectionPath +
                        @"_layouts/images/AuditingDemo/Compass32.gif";
        smt.Controls.Add(mit2);
      }

      this.Controls.Add(smt);
    }
  }

  private bool IsCurrentUserInGroup(string GroupName) {
    SPWeb site = SPContext.Current.Web;
    foreach (SPGroup group in site.SiteGroups) {
      if (group.Name.Equals(GroupName)) {
        return group.ContainsCurrentUser;
      }
    }
    throw new ApplicationException("There is no group named " + GroupName);
  }
}
}
