﻿using System;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;


namespace OfficeSpaceFieldTypes {

  public class FieldHelloWorld : SPFieldText {
    public FieldHelloWorld(SPFieldCollection fields, string fieldName)
      : base(fields, fieldName) { }

    public FieldHelloWorld(SPFieldCollection fields, string typeName, string displayName)
      : base(fields, typeName, displayName) { }

    public override BaseFieldControl FieldRenderingControl {
      get {
        BaseFieldControl ctr = new HelloWorldFieldControl();
        ctr.FieldName = this.InternalName;
        return ctr;
      }
    }
    public override string DefaultValue {
      get {
        return "Hello World (default value)";
      }      
    }
  }

  public class HelloWorldFieldControl : BaseFieldControl {
    protected TextBox txtUserInput;
    protected override string DefaultTemplateName {
      get {
        return "HelloWorldRendingTemplate";
      }
    }
    protected override void CreateChildControls() {
      base.CreateChildControls();
      txtUserInput = (TextBox)this.TemplateContainer.FindControl("txtUserInput");      
    }

    public override object Value {
      get {
        this.EnsureChildControls();
        return txtUserInput.Text;
      }
      set {
        this.EnsureChildControls();
        txtUserInput.Text = (string)this.ItemFieldValue;
      }
    }
  }
}
