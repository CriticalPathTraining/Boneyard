//*** Demoware created by Ted Pattison Group ***
//**********************************************
//*** Learn more about SharePoint development
//*** visit us at http://www.TedPattison.net

using System.Reflection;

[assembly: AssemblyVersion("1.0.0.0")]



