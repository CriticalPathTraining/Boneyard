// redirect from ECB menu of document

using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPages {

  public class ApplicationPage4 : LayoutsPageBase {

    protected Label lblSiteTitle;
    protected Label lblSiteID;
    protected Label lblSiteUrl;
    protected Label lblListID;
    protected Label lblListTile;
    protected Label lblRootFolderUrl;
    protected Label lblDocumentID;
    protected Label lblDocumentName;
    protected Label lblDocumentUrl;
    protected Label lblDocumentTemplateUrl;
    protected Label lblFileAuthor;
    protected Label lblFileSize;
    protected Label lblFileLastModified;
    protected Label lblFileCheckOutStatus;

    protected override void OnLoad(EventArgs e) {

      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;

      lblSiteTitle.Text = site.Title;
      lblSiteUrl.Text = site.Url.ToLower();      
      string ListId = Request.QueryString["ListId"];
      lblListID.Text = ListId;
      SPList list = site.Lists[new Guid(ListId)];
      lblListTile.Text = list.Title;
      lblRootFolderUrl.Text = list.RootFolder.Url;      
      string ItemId = Request.QueryString["ItemId"];
      lblDocumentID.Text = ItemId;
      SPListItem item = list.Items.GetItemById(Convert.ToInt32(ItemId));
      lblDocumentName.Text = item.Name;
      lblDocumentUrl.Text = item.Url;

if (list is SPDocumentLibrary) {
  SPDocumentLibrary documentLibrary = (SPDocumentLibrary)list;
  lblDocumentTemplateUrl.Text = documentLibrary.DocumentTemplateUrl;

  SPFile file = site.GetFile(item.Url);
  lblFileAuthor.Text = file.Author.Name;
  lblFileSize.Text = file.TotalLength.ToString("0,###") + " bits";
  lblFileLastModified.Text = "By " + file.ModifiedBy.Name +
                             " on " + file.TimeLastModified.ToLocalTime().ToString();
  lblFileCheckOutStatus.Text = file.CheckOutStatus.ToString();
}
    }
    
  }
}
