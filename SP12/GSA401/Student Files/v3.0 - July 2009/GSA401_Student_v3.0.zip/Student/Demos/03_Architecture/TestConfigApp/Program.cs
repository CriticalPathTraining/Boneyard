
using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace TestConfigApp {
  class Program {
    static void Main() {
      // (1) get reference to SPWebService object for farm
      SPWebService webService;
      webService = SPFarm.Local.Servers.GetValue<SPWebService>();

      // (2) get reference to target SPWebApplication
      SPWebApplication WebApp = webService.WebApplications["Litware Public Site"];

      // (3) create aand intialize SPWebConfigModification object 
      SPWebConfigModification mod = new SPWebConfigModification();
      mod.Name = "add[@key='MyValue']";
      mod.Owner = "MyConfigApp";
      mod.Path = "configuration/appSettings";
      mod.Type = SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode;
      mod.Value = @"<add key=""MyKey"" value=""MyValue"" />";

      // (4) add modification to Web Application
      WebApp.WebConfigModifications.Add(mod);

      // (5) apply modification changes to farm through Web Service
      webService.ApplyWebConfigModifications();
      webService.Update();

    }
  }
}


