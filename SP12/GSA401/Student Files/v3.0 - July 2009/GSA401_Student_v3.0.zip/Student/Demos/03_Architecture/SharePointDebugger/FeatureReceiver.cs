using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace SharePointDebugger {
  public class FeatureReceiver : SPFeatureReceiver  {

    public override void FeatureInstalled(SPFeatureReceiverProperties properties) {}
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) {}

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      SPWebApplication WebApp = (SPWebApplication)properties.Feature.Parent;
      foreach (ModificationEntry modEntry in Entries) {
        WebApp.WebConfigModifications.Add(
          CreateModification(modEntry)
        );
      }
      WebApp.WebService.ApplyWebConfigModifications();
      WebApp.WebService.Update();
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      SPWebApplication WebApp = (SPWebApplication)properties.Feature.Parent;
      foreach (ModificationEntry modEntry in Entries) {
        WebApp.WebConfigModifications.Remove(
          CreateModification(modEntry)
        );
      }
      WebApp.WebService.ApplyWebConfigModifications();
      WebApp.WebService.Update();
    }

    private struct ModificationEntry {
      public string Name;
      public string XPath;
      public string Value;
      public SPWebConfigModification.SPWebConfigModificationType ModType;
      // parameterized contructor
      public ModificationEntry(
          string Name, string XPath, string Value,
          SPWebConfigModification.SPWebConfigModificationType ModType) {
        // intialize structure instances
        this.Name = Name;
        this.XPath = XPath;
        this.Value = Value;
        this.ModType = ModType;
      }
    }

    private ModificationEntry[] Entries = {
      new ModificationEntry( 
        "CallStack",
        "configuration/SharePoint/SafeMode",
        "true", 
         SPWebConfigModification.SPWebConfigModificationType.EnsureAttribute),

      new ModificationEntry( 
        "mode",
        "configuration/system.web/customErrors",
        "Off", 
        SPWebConfigModification.SPWebConfigModificationType.EnsureAttribute),

      new ModificationEntry( 
        "debug",
        "configuration/system.web/compilation",
        "true", 
        SPWebConfigModification.SPWebConfigModificationType.EnsureAttribute),
     };

    private SPWebConfigModification CreateModification(ModificationEntry modEntry) {
      // create and return SPWebConfigModification object
      SPWebConfigModification modification;
      modification = new SPWebConfigModification(modEntry.Name, modEntry.XPath);
      modification.Owner = "SharePointDebugger";
      modification.Sequence = 0;
      modification.Type = modEntry.ModType;
      modification.Value = modEntry.Value;
      return modification;
    }
  }
}











