using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace LitwareBranding {
  public class FeatureReceiverWebApplication : SPFeatureReceiver {

    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      SPWebApplication WebApp = (SPWebApplication)properties.Feature.Parent;
      WebApp.WebConfigModifications.Add(CreateHttpModuleModification());
      WebApp.WebService.ApplyWebConfigModifications();
      WebApp.WebService.Update();
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      SPWebApplication WebApp = (SPWebApplication)properties.Feature.Parent;
      WebApp.WebConfigModifications.Remove(CreateHttpModuleModification());
      WebApp.WebService.ApplyWebConfigModifications();
      WebApp.WebService.Update();
    }

    public SPWebConfigModification CreateHttpModuleModification() {
      SPWebConfigModification modification;
      string ModName = "add[@name='LitwareBrandingModule']";
      string ModXPath = "configuration/system.web/httpModules";
      modification = new SPWebConfigModification(ModName, ModXPath);
      modification.Owner = "LitwareBranding";
      modification.Sequence = 0;
      modification.Type = SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode;
      modification.Value = @"<add name=""LitwareBrandingModule"" type=""LitwareBranding.LitwareBrandingHttpModule, LitwareBranding, Version=1.0.0.0, Culture=neutral, PublicKeyToken=c46c100091f72b4a"" />";
      return modification;
    }
  }
}
