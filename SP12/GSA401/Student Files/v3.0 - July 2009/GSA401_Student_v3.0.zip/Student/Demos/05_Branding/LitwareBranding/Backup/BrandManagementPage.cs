using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace LitwareBranding {
  public class BrandManagementPage : LayoutsPageBase {

    protected CheckBox chkCustomizeMasterUrl;
    protected CheckBox chkCustomizeCustomMasterUrl;
    protected CheckBox chkCustomizeAlternateCss;
    protected CheckBox chkCustomizeSiteLogo;
    protected CheckBox chkUseCustomApplicationPageMaster;
    protected Label lblMasterUrl;
    protected Label lblCustomMasterUrl;
    protected Label lblAlternateCssUrl;
    protected Label lblSiteIcon;
    protected Label lblUseCustomApplicationPageMaster;

    protected void cmdApplyCustomBrand_Click(object sender, EventArgs e) {

      bool ApplyMasterUrl = chkCustomizeMasterUrl.Checked;
      bool ApplyCustomMasterUrl = chkCustomizeCustomMasterUrl.Checked;
      bool ApplyAlternateCss = chkCustomizeAlternateCss.Checked;
      bool ApplySiteLogo = chkCustomizeSiteLogo.Checked;
      bool ApplyCustomApplicationPageMaster = chkUseCustomApplicationPageMaster.Checked;

      BrandManager.ConfigureMasterUrl(ApplyMasterUrl);
      BrandManager.ConfigureCustomMasterUrl(ApplyCustomMasterUrl);
      BrandManager.ConfigureAlternateCss(ApplyAlternateCss);
      BrandManager.ConfigureSiteLogo(ApplySiteLogo);
      BrandManager.ConfigureApplicationPageMaster(ApplyCustomApplicationPageMaster);

      SPUtility.Redirect(Request.RawUrl,
                         SPRedirectFlags.Default,
                         HttpContext.Current);
    }

    protected void cmdCancel_OnClick(object sender, EventArgs e) {
      SPUtility.Redirect(this.Site.Url,
                         SPRedirectFlags.Default,
                         HttpContext.Current);
    }


    protected override void OnPreRender(EventArgs e) {
      SPWeb TopLevelSite = this.Site.RootWeb;

      chkCustomizeMasterUrl.Checked = !TopLevelSite.MasterUrl.Contains("default.master");
      lblMasterUrl.Text = TopLevelSite.MasterUrl;

      chkCustomizeCustomMasterUrl.Checked = !TopLevelSite.CustomMasterUrl.Contains("default.master");
      lblCustomMasterUrl.Text = TopLevelSite.CustomMasterUrl;
      
      chkCustomizeAlternateCss.Checked = !string.IsNullOrEmpty(TopLevelSite.AlternateCssUrl);
      lblAlternateCssUrl.Text = (!string.IsNullOrEmpty(TopLevelSite.AlternateCssUrl) ? TopLevelSite.AlternateCssUrl : "(none)");

      chkCustomizeSiteLogo.Checked = !string.IsNullOrEmpty(TopLevelSite.SiteLogoUrl);
      lblSiteIcon.Text = (!string.IsNullOrEmpty(TopLevelSite.SiteLogoUrl) ? TopLevelSite.SiteLogoUrl : "(none)");

      string UseCustomApplicationPageMaster = TopLevelSite.Properties["UseCustomApplicationPageMaster"];
      if ((!string.IsNullOrEmpty(UseCustomApplicationPageMaster)) &&
           (UseCustomApplicationPageMaster.Equals("True"))) {
        chkUseCustomApplicationPageMaster.Checked = true;
        lblUseCustomApplicationPageMaster.Text = "True";
      }
      else {
        chkUseCustomApplicationPageMaster.Checked = false;
        lblUseCustomApplicationPageMaster.Text = "False";
      }

    }

  }
}
