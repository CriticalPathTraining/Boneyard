using System;
using Microsoft.SharePoint;

namespace LitwareBranding {
  public class FeatureReceiverChildSite : SPFeatureReceiver {
    // methods that do not need code
    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) { }

    // fired whenever a new site is created
    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      SPWeb ChildSite = (SPWeb)properties.Feature.Parent;
      SPWeb TopLevelSite = ChildSite.Site.RootWeb;
      ChildSite.MasterUrl = TopLevelSite.MasterUrl;
      ChildSite.CustomMasterUrl = TopLevelSite.CustomMasterUrl;
      ChildSite.AlternateCssUrl = TopLevelSite.AlternateCssUrl;
      ChildSite.SiteLogoUrl = TopLevelSite.SiteLogoUrl;
      ChildSite.Update();
    }
  }
}
