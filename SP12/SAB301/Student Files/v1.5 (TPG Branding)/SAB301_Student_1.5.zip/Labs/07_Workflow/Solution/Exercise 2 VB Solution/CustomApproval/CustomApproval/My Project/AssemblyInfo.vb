Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("CustomApproval")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("MS")> 
<Assembly: AssemblyProduct("CustomApproval")> 
<Assembly: AssemblyCopyright("Copyright � MS 2006")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("19f4d0d4-d753-4f7f-9cbb-1ba80a6cd11a")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using '*'.

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 

'NOTE: When updating the namespaces in the project please add new or update existing the XmlnsDefinitionAttribute
'You can add additional attributes in order to map any additional namespaces you have in the project
'<Assembly: System.Workflow.ComponentModel.Serialization.XmlnsDefinition("http://schemas.com/CustomApproval", "CustomApproval")> 
