using System;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using Microsoft.SharePoint;

namespace SmallTimeParts {
  public class JoeBob : WebPart {

    protected Label lblDisplay;

    protected override void CreateChildControls() {

      // this code can run at WSS_Minimal
      this.Controls.Clear();
      lblDisplay = new Label();
      lblDisplay.Text = @"Q: What's the last thing a redneck says before he dies?</br>A: Watch this y'all";
      lblDisplay.BackColor = Color.PowderBlue;
      lblDisplay.ForeColor = Color.Purple;  
      lblDisplay.Font.Size = new FontUnit(12);
      lblDisplay.Font.Bold = true;      
      lblDisplay.Width = new Unit("100%");
      lblDisplay.Height = new Unit("100%");
      lblDisplay.Attributes["style"] = "padding:8;";
      this.Controls.Add(lblDisplay);
      
      // this code must be run at WSS_Medium, Full or Custom
      string CurrentSiteTitle = SPContext.Current.Web.Title;

    }

  }
}
