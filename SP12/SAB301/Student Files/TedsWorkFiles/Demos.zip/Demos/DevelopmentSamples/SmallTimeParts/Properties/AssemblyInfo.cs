﻿using System.Reflection;
using System.Security;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AllowPartiallyTrustedCallers()]
