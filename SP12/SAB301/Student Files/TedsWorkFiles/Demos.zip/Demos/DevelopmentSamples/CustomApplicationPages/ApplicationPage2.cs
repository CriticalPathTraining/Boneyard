using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPages {

  public class ApplicationPage2 : LayoutsPageBase {

    // add control fields to match controls tags on .aspx page
    protected SPGridView grdPropertyValues;

    protected override void OnLoad(EventArgs e) {

      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      
      // program against controls on .aspx page
      PropertyCollectionBinder pcb = new PropertyCollectionBinder();
      pcb.AddProperty("Site Title", site.Title);
      pcb.AddProperty("Site ID", site.ID.ToString().ToUpper());
      pcb.AddProperty("Site Master Page Url", site.MasterUrl);
      pcb.AddProperty("Site URL", site.Url);
      pcb.AddProperty("Site Collection URL", siteCollection.Url);
      pcb.AddProperty("Site Collection ID", siteCollection.ID.ToString().ToUpper());
      pcb.AddProperty("Current User Name", site.CurrentUser.Name);
      pcb.AddProperty("Is User Site Collection Admin", site.UserIsSiteAdmin.ToString());
      pcb.AddProperty("Is User Site Admin", site.UserIsWebAdmin.ToString());
      pcb.AddProperty("Site User Count", site.SiteUsers.Count.ToString());
      pcb.AddProperty("Host Name", siteCollection.HostName);
      pcb.AddProperty("Zone", siteCollection.Zone.ToString());
      pcb.AddProperty("Site Collection System Account", siteCollection.SystemAccount.Name);
      pcb.BindGrid(grdPropertyValues);

    }
  }
}
