using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPages {

  public class ApplicationPage1 : LayoutsPageBase {

    // add control fields to match controls tags on .aspx page
    protected Label lblSiteTitle;
    protected Label lblSiteID;

    protected override void OnLoad(EventArgs e) {
      
      // get current site and web
      SPSite siteCollection = this.Site;
      SPWeb site = this.Web;
      
      // program against controls on .aspx page
      lblSiteTitle.Text = site.Title;
      lblSiteID.Text = site.ID.ToString().ToUpper();
    }

  }
}
