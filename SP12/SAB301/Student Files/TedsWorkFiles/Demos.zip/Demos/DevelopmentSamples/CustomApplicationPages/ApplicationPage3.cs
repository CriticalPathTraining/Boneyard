// demo of RequireSiteAdministrator

using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CustomApplicationPages {

public class ApplicationPage3 : LayoutsPageBase {

protected Label lblSiteTitle;
protected Label lblSiteUrl;
protected Label lblSiteCollectionUrl;
protected ListBox lstLists;
protected ListBox lstSiteUsers;

protected override bool RequireSiteAdministrator {
  get { return true; }
}

protected override void OnLoad(EventArgs e) {
  // get current site and web
  SPSite siteCollection = this.Site;
  SPWeb site = this.Web;

  lblSiteTitle.Text = site.Title;
  lblSiteUrl.Text = site.Url.ToLower();
  lblSiteCollectionUrl.Text = siteCollection.Url.ToLower();

  lstLists.Items.Clear();
  foreach (SPList list in site.Lists) {
    lstLists.Items.Add(list.Title);
  }
  lstLists.Rows = lstLists.Items.Count;


  lstSiteUsers.Items.Clear();
  foreach (SPUser user in site.SiteUsers) {
    lstSiteUsers.Items.Add(user.Name);
  }
  lstSiteUsers.Rows = lstSiteUsers.Items.Count;

}

}
}
