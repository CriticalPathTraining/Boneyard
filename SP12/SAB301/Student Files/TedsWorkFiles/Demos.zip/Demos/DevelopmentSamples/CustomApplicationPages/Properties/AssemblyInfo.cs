﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// CustomApplicationPages, Version=1.0.0.0, Culture=neutral, PublicKeyToken=d4e5777b16a5749f
[assembly: AssemblyVersion("1.0.0.0")]


[assembly: AssemblyTitle("CustomApplicationPages")]
[assembly: AssemblyCompany("Ted Pattison Group, Inc.")]
[assembly: AssemblyProduct("CustomApplicationPages")]
[assembly: AssemblyCopyright("Copyright © Ted Pattison Group, Inc. 2007")]



