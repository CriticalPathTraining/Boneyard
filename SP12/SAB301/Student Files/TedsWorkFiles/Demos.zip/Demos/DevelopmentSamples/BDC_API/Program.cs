using System;
using System.Runtime.InteropServices;
using System.Xml.Serialization;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

using System.Web.UI.WebControls;
using System.Data;
using Microsoft.Office.Server.ApplicationRegistry.Runtime;
using Microsoft.Office.Server.ApplicationRegistry.Infrastructure;
using Microsoft.Office.Server.ApplicationRegistry.MetadataModel;
using Microsoft.Office.Server.ApplicationRegistry.SystemSpecific.Db;
using Microsoft.Office;

namespace BDC_API {
  class Program {
    static void Main() {

      SqlSessionProvider.Instance().SetSharedResourceProviderToUse("Litware SSP");
      NamedLobSystemInstanceDictionary ApplicationInstances = ApplicationRegistry.GetLobSystemInstances();
      LobSystemInstance BdcApplication = ApplicationInstances["AdventureWorks"];
      Entity ProductEntity = BdcApplication.GetEntities()["Product"];
      Console.WriteLine("Entity Name: " + ProductEntity.Name);

      int ProductKey = 486;
      IEntityInstance ProductEntityInstance = ProductEntity.FindSpecific(ProductKey, BdcApplication);
      Console.WriteLine("Product Key: " + ProductEntityInstance["ProductKey"].ToString());
    }
  }
}
