using System;
using Microsoft.SharePoint;

namespace SuperBranding {
  public class SiteLevelFeatureReceiver : SPFeatureReceiver {
    // methods that do not need code
    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }
    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) { }

    // fired whenever a new site is created
    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      SPWeb site = (SPWeb)properties.Feature.Parent;
      if (!site.IsRootWeb) {
        if(site.Site.RootWeb.Properties["CurrentBrand"] != null) {          
          string CurrentMasterPage = site.Site.RootWeb.Properties["CurrentMasterPage"];
          site.MasterUrl = CurrentMasterPage;
          string CurrentBrand = site.Site.RootWeb.Properties["CurrentBrand"];
          site.AlternateCssUrl = "/_layouts/1033/STYLES/" + CurrentBrand + "/styles.css";
          site.SiteLogoUrl = "/_layouts/images/" + CurrentBrand + "/Logo.png";
          site.Update();
        }
      }    
    }    
  }
}
