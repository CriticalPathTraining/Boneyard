using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace SuperBranding {
  public class FarmLevelFeatureReceiver : SPFeatureReceiver {
    public override void FeatureInstalled(SPFeatureReceiverProperties properties) { }
    public override void FeatureUninstalling(SPFeatureReceiverProperties properties) { }

    public override void FeatureActivated(SPFeatureReceiverProperties properties) {
      SPService service = (SPService)properties.Feature.Parent;
      SPServiceCollection services = service.Farm.Services;
      SPWebApplicationCollection WebApps = services.GetValue<SPWebService>().WebApplications;
      foreach (SPWebApplication WebApp in WebApps) {
        foreach (ModificationEntry entry in Entries) {
          WebApp.WebConfigModifications.Add(CreateModification(entry.Name, entry.XPath, entry.Value)
          );
        }
        SPFarm.Local.Services.GetValue<SPWebService>().ApplyWebConfigModifications();
      }
    }

    public override void FeatureDeactivating(SPFeatureReceiverProperties properties) {
      SPService service = (SPService)properties.Feature.Parent;
      SPServiceCollection services = service.Farm.Services;
      SPWebApplicationCollection WebApps = services.GetValue<SPWebService>().WebApplications;
      foreach (SPWebApplication WebApp in WebApps) {
        foreach (ModificationEntry entry in Entries) {
          WebApp.WebConfigModifications.Remove(CreateModification(entry.Name, entry.XPath, entry.Value)
          );
        }
        SPFarm.Local.Services.GetValue<SPWebService>().ApplyWebConfigModifications();
      }
    }

    private struct ModificationEntry {
      public string Name;
      public string XPath;
      public string Value;
      public ModificationEntry(string Name, string XPath, string Value) {
        this.Name = Name;
        this.XPath = XPath;
        this.Value = Value;
      }
    }

    private ModificationEntry[] Entries = {
      new ModificationEntry("add[@name='SuperBrandingModule']",
                            "configuration/system.web/httpModules",
                            @"<add name=""SuperBrandingModule"" type=""SuperBranding.SuperBrandingModule, SuperBranding, Version=1.0.0.0, Culture=neutral, PublicKeyToken=b38a04419cc857d9"" />")
    };

    public SPWebConfigModification CreateModification(string Name, string XPath, string Value) {
      SPWebConfigModification modification = new SPWebConfigModification(Name, XPath);
      modification.Owner = "SuperBranding";
      modification.Sequence = 0;
      modification.Type = SPWebConfigModification.SPWebConfigModificationType.EnsureChildNode;
      modification.Value = Value;
      return modification;
    }
  }


}
