using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace SuperBranding {
  public class BrandManagementPage : LayoutsPageBase {

    protected RadioButtonList lstBrands;
    protected Label lblMasterPage;
    protected Label lblAlternateCSS;
    protected Label lblSiteIcon;

    protected string[,] Brands = { {"Default", "Default (no branding)" },
                                    {"TPG", "Ted Pattison Group" },
                                    {"Litware", "Litware Corporation" },
                                    {"Minimal", "Minimal (HTML 4.01)" },
                                    {"PlainJane", "Plain Jane" },
                                    {"Skeleton", "Skeleton Master Page" } };
   

    protected void Page_Load(object sender, EventArgs e) {

      SPSite siteColl = this.Site;
      SPWeb site = this.Web;

      if (!IsPostBack) {
        lstBrands.Items.Clear();
        for (int i = 0; i <= Brands.GetUpperBound(0); i++) {
          lstBrands.Items.Add(new ListItem(Brands[i, 1], Brands[i, 0]));
        }
      }
  
    }

    protected void cmdApplyCustomBrand_Click(object sender, EventArgs e) {

      string NewBrand = lstBrands.SelectedValue;
      if( NewBrand.Equals("Default") ) {
        SPWeb site = SPContext.Current.Web;
        RemoveCustomBrand(site);
        site.Properties["CurrentBrand"] = null;
        site.Properties["CurrentMasterPage"] = null;
        site.Properties.Update();
      }
      else {
        SPWeb site = this.Site.RootWeb;
        string MasterUrlPath = site.ServerRelativeUrl;
        if (!MasterUrlPath.EndsWith(@"/"))
          MasterUrlPath += @"/";
          MasterUrlPath += @"_catalogs/masterpage/" + NewBrand + ".master";
          ApplyCustomBrand(NewBrand, MasterUrlPath, site);
          site.Properties["CurrentBrand"] = NewBrand;
          site.Properties["CurrentMasterPage"] = MasterUrlPath;
          site.Properties.Update();
      }
      Response.Redirect(Request.RawUrl);
    }

    protected void cmdCancel_OnClick(object sender, EventArgs e) {
      SPUtility.Redirect(this.Site.Url,
                         SPRedirectFlags.Default,
                         HttpContext.Current);
    }

    protected void ApplyCustomBrand(string Brand, string MasterUrlPath, SPWeb site) {
      site.ApplyTheme("");
      site.MasterUrl = MasterUrlPath;
      site.AlternateCssUrl = "/_layouts/1033/STYLES/" + Brand + "/styles.css";
      site.SiteLogoUrl = "/_layouts/images/" + Brand + "/Logo.png";
      site.Update();

      foreach (SPWeb child in site.Webs) {
        ApplyCustomBrand(Brand, MasterUrlPath, child);
      }
    }


    protected void RemoveCustomBrand(SPWeb site) {
      string MasterUrlPath = site.ServerRelativeUrl;
      if (!MasterUrlPath.EndsWith(@"/"))
        MasterUrlPath += @"/";
      site.MasterUrl = MasterUrlPath + "_catalogs/masterpage/default.master";
      site.AlternateCssUrl = "";
      site.SiteLogoUrl = "";
      site.Update();
      foreach (SPWeb child in site.Webs) {
        RemoveCustomBrand(child);
      }
    }


    protected override void OnPreRender(EventArgs e) {
      try {
        SPWeb site = this.Site.RootWeb;
        string CurrentBrand = site.Properties["CurrentBrand"];
        if (string.IsNullOrEmpty(CurrentBrand)) {
          lstBrands.Items.FindByValue("Default").Selected = true;
        }
        else {
          lstBrands.Items.FindByValue(CurrentBrand).Selected = true;
        }

        lblMasterPage.Text = site.MasterUrl;
        lblAlternateCSS.Text = (!string.IsNullOrEmpty(site.AlternateCssUrl) ? site.AlternateCssUrl : "(none)");
        lblSiteIcon.Text = (!string.IsNullOrEmpty(site.SiteLogoUrl) ? site.SiteLogoUrl : "(none)");
      }
      catch { }

    }

  }
}
