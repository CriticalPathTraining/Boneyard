﻿using System.Reflection;
using System.Runtime.CompilerServices;


// SuperBranding, Version=1.0.0.0, Culture=neutral, PublicKeyToken=b38a04419cc857d9
[assembly: AssemblyVersion("1.0.0.0")]

