﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// CommonSiteInit, Version=1.0.0.0, Culture=neutral, PublicKeyToken=c5a14f1c8f846635
[assembly: AssemblyVersion("1.0.0.0")]

