using System;
using System.Windows;
using System.Windows.Forms;

using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace SharePointSiteBrowser {

  enum NodeType {
    Farm,
    WebApplication,
    SiteCollection,
    Site
  }


  class NodeTypeImage {
    public const int Farm = 0;
    public const int WebApplication = 1;
    public const int SiteCollection = 2;
    public const int Site = 3;
  }

  struct NodeInfo {
    public NodeType Type;
    public Guid ID;
    public string URL;
    public NodeInfo(NodeType Type, Guid ID, string URL) {
      this.Type = Type;
      this.ID = ID;
      this.URL = URL;
    }
  }

  public class FarmManager {

    public static TreeNode LoadWebAppNodes() {

      SPFarm CurrentFarm = SPFarm.Local;
      TreeNode nodeFarm = new TreeNode("Local Farm (Config DB = " + CurrentFarm.DisplayName + " )", NodeTypeImage.Farm, NodeTypeImage.Farm);
      NodeInfo info = new NodeInfo(NodeType.Farm, Guid.Empty, "http://" + Environment.MachineName);
      nodeFarm.Tag = info;

      SPWebService CurrentWebService = CurrentFarm.Services.GetValue<SPWebService>();
      SPWebApplicationCollection WebApps = CurrentWebService.WebApplications;

      foreach (SPWebApplication WebApp in WebApps) {

        TreeNode nodeWebApp = new TreeNode(WebApp.Name + " (" + WebApp.AlternateUrls[0].IncomingUrl + ")", NodeTypeImage.WebApplication, NodeTypeImage.WebApplication);
        NodeInfo infoWebApp = new NodeInfo(NodeType.WebApplication, WebApp.Id, WebApp.AlternateUrls[0].IncomingUrl);
        nodeWebApp.Tag = infoWebApp;
        LoadSiteCollectionNodes(WebApp, nodeWebApp);
        nodeFarm.Nodes.Add(nodeWebApp);
      }

      return nodeFarm;
    }

    protected static void LoadSiteCollectionNodes(SPWebApplication WebApp, TreeNode nodeWebApp) {

      foreach (SPSite SiteCollection in WebApp.Sites) {

        if (SiteCollection.RootWeb.DoesUserHavePermissions(SPBasePermissions.Open)) {

          TreeNode SiteCollectionNode = new TreeNode("Site Collection [" + SiteCollection.Url.ToString() + "]", NodeTypeImage.SiteCollection, NodeTypeImage.SiteCollection);
          NodeInfo SiteCollectionInfo = new NodeInfo(NodeType.SiteCollection, SiteCollection.ID, SiteCollection.Url);
          SiteCollectionNode.Tag = SiteCollectionInfo;

          SPWeb TopLevelSite = SiteCollection.RootWeb;
          TreeNode TopLevelSiteNode = new TreeNode(TopLevelSite.Title, NodeTypeImage.Site, NodeTypeImage.Site);
          NodeInfo SiteInfo = new NodeInfo(NodeType.Site, TopLevelSite.ID, TopLevelSite.Url);
          TopLevelSiteNode.Tag = SiteInfo;

          LoadChildSiteNodes(TopLevelSite, TopLevelSiteNode);
          SiteCollectionNode.Nodes.Add(TopLevelSiteNode);
          nodeWebApp.Nodes.Add(SiteCollectionNode);

        }
      }

    }

    protected static void LoadChildSiteNodes(SPWeb Site, TreeNode node) {
      try {
        foreach (SPWeb ChildSite in Site.Webs) {
          if (ChildSite.DoesUserHavePermissions(SPBasePermissions.FullMask)) {
            TreeNode ChildNode = new TreeNode(ChildSite.Title, NodeTypeImage.Site, NodeTypeImage.Site);
            NodeInfo SiteInfo = new NodeInfo(NodeType.Site, ChildSite.ID, ChildSite.Url);
            ChildNode.Tag = SiteInfo;
            LoadChildSiteNodes(ChildSite, ChildNode);
            node.Nodes.Add(ChildNode);
          }
        }
      }
      catch (Exception ex) {
        GlobalErrors.AppendError(ex, Site.Url);
      }
    }

    void DisplayLocalMachineInfo(NodeInfo info) {
      //this.tabProperties.SelectedTab = tabMachineInfo;
      //// get local machine info
      //txtLocalMachineName.Text = Environment.MachineName;
      //IPHostEntry entry = Dns.GetHostEntry(Environment.MachineName);
      //lstMachineIPAddresses.Items.Clear();
      //IPAddress[] addresses = entry.AddressList;
      //foreach (IPAddress address in addresses) {
      //  lstMachineIPAddresses.Items.Add(address.ToString());
      //}
      // get deployment-specific WSS configuration information
      //SPGlobalAdmin globalAdmin = new SPGlobalAdmin();
      //txtConfigDBServer.Text = globalAdmin.ConfigDatabase.Server;
      //txtConfigDBName.Text = globalAdmin.ConfigDatabase.Name;
      //txtWebServerName.Text = globalAdmin.Config.WebServers[0].Name;
      //txtWebServerID.Text = globalAdmin.Config.WebServers[0].Id.ToString().ToUpper();

    }

    void DisplayWebApplicationInfo(NodeInfo info) {
      //this.tabProperties.SelectedTab = tabWebApplicationInfo;
      //SPGlobalAdmin globalAdmin = new SPGlobalAdmin();

      //SPWebApplication vserver = globalAdmin.OpenWebApplication(new Uri(info.URL));
      //this.txtWebApplicationID.Text = vserver.WebApplicationId.ToString().ToUpper();
      //this.txtWebApplicationUrl.Text = vserver.Url.ToString();
      //this.txtWebApplicationPort.Text = vserver.Port.ToString();
      //this.txtIISWebSite.Text = vserver.Description;
      //this.txtIISAppPool.Text = vserver.ApplicationPoolId;

      //lstContentDatabases.Items.Clear();
      //foreach (SPContentDatabase ContentDB in vserver.ContentDatabases)
      //{
      //  lstContentDatabases.Items.Add(ContentDB.Name);
      //}
    }

    void DisplaySiteCollectionInfo(NodeInfo info) {
      //this.tabProperties.SelectedTab = tabSiteCollectionInfo;
      //SPSite SiteCollection = new SPSite(info.ID);
      //txtSiteCollectionID.Text = SiteCollection.ID.ToString().ToUpper();
      //txtSiteCollectionUrl.Text = SiteCollection.Url;
      //txtSiteCollectionOwner.Text = SiteCollection.Owner.LoginName;
      //txtSiteCollectionOwnerEmail.Text = SiteCollection.Owner.Email;
      //txtSiteCollectionLastModified.Text = SiteCollection.LastContentModifiedDate.ToString();

    }

    void DisplaySiteInfo(NodeInfo info) {
      //this.tabProperties.SelectedTab = tabSiteInfo;

      //SPSite SiteCollection = new SPSite(info.URL);
      //SPWeb Site = SiteCollection.OpenWeb();
      //txtSiteID.Text = Site.ID.ToString().ToUpper();
      //txtParentSIteID.Text = (Site.ParentWeb != null) ? Site.ParentWeb.ID.ToString().ToUpper() : "No parent site";
      //txtSiteUrl.Text = Site.Url;
      //txtSiteTitle.Text = Site.Title;
      //string TemplateName = Site.WebTemplate + "#" + Site.Configuration.ToString();
      //txtSiteTemplateName.Text = TemplateName;
      //SPWebTemplateCollection Templates = SiteCollection.GetWebTemplates(1033);
      //txtSiteTemplateTitle.Text = Templates[TemplateName].Title;

      //lstSiteLists.Items.Clear();
      //foreach (SPList List in Site.Lists) {
      //  lstSiteLists.Items.Add(List.Title);
      //}

      //lstSiteMembers.Items.Clear();
      //foreach (SPUser User in Site.Users) {
      //  lstSiteMembers.Items.Add(User.LoginName);
      //}
    }

  }
}
